//
//  ViewController.swift
//  PocketPrimary
//
//  Created by  on 1/12/16.
//  Copyright © 2016 HHS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var screenWidth = (Float)(UIScreen.mainScreen().bounds.width)
    var screenHeight = (Float)(UIScreen.mainScreen().bounds.height)
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

}

class democraticViewController: UIViewController {

    @IBOutlet weak var bernieSandersLabel: UILabel!
    @IBOutlet weak var hillaryClintonLabel: UILabel!
    @IBOutlet weak var martinOMalleyLabel: UILabel!
    var screenWidth = (Float)(UIScreen.mainScreen().bounds.width)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    @IBAction func onBernieSandersTapped(sender: AnyObject) {
    }
    
}

class republicanViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

class bernieSandersViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

class hillaryViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

class martinViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

class donaldViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

class tedViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

class benViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

class pollController: UIViewController {
    
    @IBOutlet weak var martinImage: UIImageView!
    @IBOutlet weak var hillaryImage: UIImageView!
    @IBOutlet weak var bernieImage: UIImageView!
    @IBOutlet weak var donaldImage: UIImageView!
    @IBOutlet weak var tedImage: UIImageView!
    @IBOutlet weak var benImage: UIImageView!
    
    
    @IBOutlet weak var leftImageView: UIImageView!
    @IBOutlet weak var rightImageView: UIImageView!
    
    @IBOutlet weak var rightPercentLabel: UILabel!
    @IBOutlet weak var leftPercentLabel: UILabel!
    
    @IBOutlet weak var resultLabel: UILabel!
    
    @IBOutlet weak var scrollThing: UIProgressView!
    
    var rightPerson = ""
    var leftPerson = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        scrollThing.progress = 0.5
    }
    
    @IBAction func clearButton(sender: AnyObject) {
        rightPerson = ""
        leftPerson = ""
        resultLabel.text = "N/A"
        rightPercentLabel.text = "N/A"
        leftPercentLabel.text = "N/A"
        
        leftImageView.image = nil
        rightImageView.image = nil
        
        scrollThing.progress = 0.50
    }
    
    @IBAction func calculateButton(sender: AnyObject) {
        
        if leftPerson == "Bernie Sanders" {
            if rightPerson == "Bernie Sanders" {
                leftPercentLabel.text = "50"
                rightPercentLabel.text = "50"
                resultLabel.text = "Sanders"
                scrollThing.progress = 0.50
            } else if rightPerson == "Hillary Clinton" {
                leftPercentLabel.text = "42.8"
                rightPercentLabel.text = "46.8"
                resultLabel.text = "Clinton + 4.0"
                scrollThing.progress = 0.48
            } else if rightPerson == "Martin Malley" {
                leftPercentLabel.text = "42.8"
                rightPercentLabel.text = "5.2"
                resultLabel.text = "Sanders + 37.6"
                scrollThing.progress = 0.9
            } else if rightPerson == "Donald Trump" {
                leftPercentLabel.text = "48.5"
                rightPercentLabel.text = "40.5"
                resultLabel.text = "Sanders + 8.0"
                scrollThing.progress = 0.54
            } else if rightPerson == "Ted Cruz" {
                leftPercentLabel.text = "45.5"
                rightPercentLabel.text = "42.5"
                resultLabel.text = "Sanders + 3.0"
                scrollThing.progress = 0.52
            } else if rightPerson == "Ben Carson" {
                leftPercentLabel.text = "43"
                rightPercentLabel.text = "42"
                resultLabel.text = "Sanders + 1"
                scrollThing.progress = 0.51
            }
        } else if leftPerson == "Hillary Clinton" {
            if rightPerson == "Bernie Sanders" {
                leftPercentLabel.text = "46.8"
                rightPercentLabel.text = "42.8"
                resultLabel.text = "Clinton + 4.0"
                scrollThing.progress = 0.52
            } else if rightPerson == "Hillary Clinton" {
                leftPercentLabel.text = "50"
                rightPercentLabel.text = "50"
                resultLabel.text = "Clinton"
                scrollThing.progress = 0.50
            } else if rightPerson == "Martin Malley" {
                leftPercentLabel.text = "46.8"
                rightPercentLabel.text = "5.2"
                resultLabel.text = "Clinton + 41.6"
                scrollThing.progress = 0.9
            } else if rightPerson == "Donald Trump" {
                leftPercentLabel.text = "46.5"
                rightPercentLabel.text = "41.5"
                resultLabel.text = "Clinton + 5.0"
                scrollThing.progress = 0.53
            } else if rightPerson == "Ted Cruz" {
                leftPercentLabel.text = "43.5"
                rightPercentLabel.text = "47.0"
                resultLabel.text = "Cruz + 3.5"
                scrollThing.progress = 0.48
            } else if rightPerson == "Ben Carson" {
                leftPercentLabel.text = "45"
                rightPercentLabel.text = "45"
                resultLabel.text = "Tie"
                scrollThing.progress = 0.50
            }
        } else if leftPerson == "Martin Malley" {
            if rightPerson == "Bernie Sanders" {
                leftPercentLabel.text = "5.2"
                rightPercentLabel.text = "42.8"
                resultLabel.text = "Sanders + 37.6"
                scrollThing.progress = 0.1
            } else if rightPerson == "Hillary Clinton" {
                leftPercentLabel.text = "5.2"
                rightPercentLabel.text = "46.8"
                resultLabel.text = "41.2"
                scrollThing.progress = 0.1
            } else if rightPerson == "Martin Malley" {
                leftPercentLabel.text = "50"
                rightPercentLabel.text = "50"
                resultLabel.text = "O'Malley"
                scrollThing.progress = 0.5
            } else if rightPerson == "Donald Trump" {
                leftPercentLabel.text = "N/A"
                rightPercentLabel.text = "N/A"
                resultLabel.text = "N/A"
                scrollThing.progress = 0.50
            } else if rightPerson == "Ted Cruz" {
                leftPercentLabel.text = "N/A"
                rightPercentLabel.text = "N/A"
                resultLabel.text = "N/A"
                scrollThing.progress = 0.50
            } else if rightPerson == "Ben Carson" {
                leftPercentLabel.text = "N/A"
                rightPercentLabel.text = "N/A"
                resultLabel.text = "N/A"
                scrollThing.progress = 0.50
            }
        } else if leftPerson == "Donald Trump" {
            if rightPerson == "Bernie Sanders" {
                leftPercentLabel.text = "40.5"
                rightPercentLabel.text = "48.5"
                resultLabel.text = "Sanders + 8.0"
                scrollThing.progress = 0.46
            } else if rightPerson == "Hillary Clinton" {
                leftPercentLabel.text = "41.5"
                rightPercentLabel.text = "46.5"
                resultLabel.text = "Clinton + 5.0"
                scrollThing.progress = 0.47
            } else if rightPerson == "Martin Malley" {
                leftPercentLabel.text = "N/A"
                rightPercentLabel.text = "N/A"
                resultLabel.text = "N/A"
                scrollThing.progress = 0.50
            } else if rightPerson == "Donald Trump" {
                leftPercentLabel.text = "50"
                rightPercentLabel.text = "50"
                resultLabel.text = "Trump"
                scrollThing.progress = 0.5
            } else if rightPerson == "Ted Cruz" {
                leftPercentLabel.text = "34"
                rightPercentLabel.text = "28"
                resultLabel.text = "Trump + 6.0"
                scrollThing.progress = 0.55
            } else if rightPerson == "Ben Carson" {
                leftPercentLabel.text = "34"
                rightPercentLabel.text = "9"
                resultLabel.text = "Trump + 25.0"
                scrollThing.progress = 0.80
            }
        } else if leftPerson == "Ted Cruz" {
            if rightPerson == "Bernie Sanders" {
                leftPercentLabel.text = "42.5"
                rightPercentLabel.text = "45.5"
                resultLabel.text = "Sanders + 3.0"
                scrollThing.progress = 0.48
            } else if rightPerson == "Hillary Clinton" {
                leftPercentLabel.text = "47.0"
                rightPercentLabel.text = "43.5"
                resultLabel.text = "Cruz + 3.5"
                scrollThing.progress = 0.52
            } else if rightPerson == "Martin Malley" {
                leftPercentLabel.text = "N/A"
                rightPercentLabel.text = "N/A"
                resultLabel.text = "N/A"
                scrollThing.progress = 0.50
            } else if rightPerson == "Donald Trump" {
                leftPercentLabel.text = "28"
                rightPercentLabel.text = "34"
                resultLabel.text = "Trump + 6.0"
                scrollThing.progress = 0.45
            } else if rightPerson == "Ted Cruz" {
                leftPercentLabel.text = "50"
                rightPercentLabel.text = "50"
                resultLabel.text = "Cruz"
                scrollThing.progress = 0.50
            } else if rightPerson == "Ben Carson" {
                leftPercentLabel.text = "28"
                rightPercentLabel.text = "9"
                resultLabel.text = "Cruz + 19"
                scrollThing.progress = 0.76
            }
        } else if leftPerson == "Ben Carson" {
            if rightPerson == "Bernie Sanders" {
                leftPercentLabel.text = "42"
                rightPercentLabel.text = "43"
                resultLabel.text = "Sanders + 1"
                scrollThing.progress = 0.49
            } else if rightPerson == "Hillary Clinton" {
                leftPercentLabel.text = "45"
                rightPercentLabel.text = "45"
                resultLabel.text = "Tie"
                scrollThing.progress = 0.50
            } else if rightPerson == "Martin Malley" {
                leftPercentLabel.text = "N/A"
                rightPercentLabel.text = "N/A"
                resultLabel.text = "N/A"
                scrollThing.progress = 0.50
            } else if rightPerson == "Donald Trump" {
                leftPercentLabel.text = "9"
                rightPercentLabel.text = "34"
                resultLabel.text = "Trump + 25.0"
                scrollThing.progress = 0.20
            } else if rightPerson == "Ted Cruz" {
                leftPercentLabel.text = "9"
                rightPercentLabel.text = "28"
                resultLabel.text = "Cruz + 19"
                scrollThing.progress = 0.24
            } else if rightPerson == "Ben Carson" {
                leftPercentLabel.text = "50"
                rightPercentLabel.text = "50"
                resultLabel.text = "Carson"
                scrollThing.progress = 0.50
            }
        }
    }
    
    @IBAction func onBernieTapped(sender: AnyObject) {
        if leftPerson == "" {
            leftPerson = "Bernie Sanders"
            leftImageView.image = UIImage(named: "BSIcon")
        } else if leftPerson != "" && rightPerson != "" {
        } else {
            rightPerson = "Bernie Sanders"
            rightImageView.image = UIImage(named: "BSIcon")
        }
    }
    
    @IBAction func onHillaryTapped(sender: AnyObject) {
        if leftPerson == "" {
            leftPerson = "Hillary Clinton"
            leftImageView.image = UIImage(named: "HCIcon")
        } else if leftPerson != "" && rightPerson != "" {
        } else {
            rightPerson = "Hillary Clinton"
            rightImageView.image = UIImage(named: "HCIcon")
        }
    }

    @IBAction func onMartinTapped(sender: AnyObject) {
        if leftPerson == "" {
            leftPerson = "Martin Malley"
            leftImageView.image = UIImage(named: "MOMIcon")
        } else if leftPerson != "" && rightPerson != "" {
        } else {
            rightPerson = "Martin Malley"
            rightImageView.image = UIImage(named: "MOMIcon")
        }
    }
    
    @IBAction func onDonaldTapped(sender: AnyObject) {
        if leftPerson == "" {
            leftPerson = "Donald Trump"
            leftImageView.image = UIImage(named: "DTIcon")
        } else if leftPerson != "" && rightPerson != "" {
        } else {
            rightPerson = "Donald Trump"
            rightImageView.image = UIImage(named: "DTIcon")
        }
    }
    
    @IBAction func onTedTapped(sender: AnyObject) {
        if leftPerson == "" {
            leftPerson = "Ted Cruz"
            leftImageView.image = UIImage(named: "TCIcon")
        } else if leftPerson != "" && rightPerson != "" {
        } else {
            rightPerson = "Ted Cruz"
            rightImageView.image = UIImage(named: "TCIcon")
        }
    }
    
    @IBAction func onBenTapped(sender: AnyObject) {
        if leftPerson == "" {
            leftPerson = "Ben Carson"
            leftImageView.image = UIImage(named: "BCIcon")
        } else if leftPerson != "" && rightPerson != "" {
        } else {
            rightPerson = "Ben Carson"
            rightImageView.image = UIImage(named: "BCIcon")
        }
    }
    
}