//
//  ResultsTableCellTableViewCell.swift
//  RPrepSearch
//
//  Created by Nidhi on 12/21/15.
//  Copyright © 2015 Nidhi. All rights reserved.
//

import UIKit

class ResultsTableCellTableViewCell: UITableViewCell
{
  
    
    @IBOutlet var schoolName: UILabel!
    
    @IBOutlet var schoolAddress: UILabel!

    @IBOutlet var schoolImageView: UIImageView!
    

    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        // Initialization code

    }

    override func setSelected(selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
        
        
    }

}
