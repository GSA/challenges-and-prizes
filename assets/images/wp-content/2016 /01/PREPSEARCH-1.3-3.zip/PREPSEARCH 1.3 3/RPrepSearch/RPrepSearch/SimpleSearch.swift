//
//  SimpleSearch.swift
//  pRePSearchData
//
//  Created by Shawn on 12/14/15.
//  Copyright © 2015 Shawn. All rights reserved.
//

import UIKit

class SimpleSearch: NSObject
{
    
    func search(terms:String)->NSMutableArray
    {
        let results = NSMutableArray()
        
        let factory = SchoolFactory()
        let listOfSchools = factory.getListOfSchools()
        
        for(var i = 0; i < listOfSchools.count; i++)
        {
            if(listOfSchools[i].name.containsString(terms))
            {
                print(listOfSchools[i].name)
                results.addObject(listOfSchools[i])
            }
            else
            {
                print("School Not Found")
            }
        }
        
        return results
    }
}
