//
//  AboutViewController.swift
//  RPrepSearch
//
//  Created by Nidhi on 12/18/15.
//  Copyright © 2015 Nidhi. All rights reserved.
//

import UIKit

class AboutViewController: UIViewController
{

    @IBOutlet var aboutDisplay: UITextView!
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
      setUpDisplay()
        
        
      
        
    }
    
   
    
    
    
    func setUpDisplay()
    {
        aboutDisplay.layer.cornerRadius = 8.0
        aboutDisplay.layer.masksToBounds = true
        aboutDisplay.layer.borderColor = UIColor( red: 0, green: 0, blue:0, alpha: 0.4 ).CGColor
        aboutDisplay.layer.borderWidth = 2.0
        
        let deviceDimensions = findDeviceWidthAndHeight()
        let width = deviceDimensions.width
        let height = deviceDimensions.height
        
        print(width)
        print(height)
        
        if(width == 375 && height == 667 ) //iPhone 6
        {
            
             aboutDisplay.bounds = CGRectMake(0, 0, 375, 667)
            
           aboutDisplay.text = "\n\n\n\n\t\t\t\t About Team RPS\n\n\t\t\t    www.rutgersprep.org\n\nMembers & Contributions:\n\nShawn Clark: Simple Search\n\nDhruthi Reddy: Logo & Simple Search\n\nSrinidhi Palwayi: User Interface\n\nStephen Therianos: Advanced Search\n\nRithvik Kondai: Logo & Data Structure\n\nJay Agrawal: Data Structure\n\nAndrew Lorello: Data Structure\n\nThis app finds independent schools that are part of NJAIS. It uses simple and advanced searches."
           
            
        }
        else if(width == 414 && height == 736) //iPhone 6plus
        {
             aboutDisplay.bounds = CGRectMake(0, 0, 414, 736)
            
            aboutDisplay.text = "\n\n\n\n\n\n\n\t\t\t\t       About Team RPS \n\n\t\t\t\t    www.rutgersprep.org\n\nMembers & Contributions:\n\nShawn Clark: Simple Search\n\nDhruthi Reddy: Logo & Simple Search\n\nSrinidhi Palwayi: User Interface\n\nStephen Therianos: Advanced Search\n\nRithvik Kondai: Logo & Data Structure\n\nJay Agrawal: Data Structure\n\nAndrew Lorello: Data Structure\n\nThis app finds independent schools that are part of NJAIS. It uses simple and advanced searches."
            
        }
        else if(width == 320 && height == 568)
        {  //iPhone 5
            
            aboutDisplay.bounds = CGRectMake(0, 0, 320, 605)
            aboutDisplay.text = "\n\n\n\t\t\t   About Team RPS \n\n\t\t\twww.rutgersprep.org\n\nMembers & Contributions:\n\nShawn Clark: Simple Search\n\nDhruthi Reddy: Logo & Simple Search\n\nSrinidhi Palwayi: User Interface\n\nStephen Therianos: Advanced Search\n\nRithvik Kondai: Logo & Data Structure\n\nJay Agrawal: Data Structure\n\nAndrew Lorello: Data Structure\n\nThis app finds independent schools that are part of NJAIS. It uses simple and advanced searches."
            
        }
        else
        {
            aboutDisplay.text = "\n\n\t\t\t About Team RPS \n\n\t\t    www.rutgersprep.org\n\nMembers & Contributions:\n\nShawn Clark: Simple Search\n\nDhruthi Reddy: Logo & Simple Search\n\nSrinidhi Palwayi: User Interface\n\nStephen Therianos: Advanced Search\n\nRithvik Kondai: Logo & Data Structure\n\nJay Agrawal: Data Structure\n\nAndrew Lorello: Data Structure\n\nThis app finds independent schools that are part of NJAIS. It uses simple and advanced searches."
        }
        
        
        
    }
    
    
    
    func findDeviceWidthAndHeight() ->(width: CGFloat, height: CGFloat)
    {
        
        let screenSize: CGRect = UIScreen.mainScreen().bounds
        
        let screenWidth = screenSize.width
        let screenHeight = screenSize.height
        
        
        return (screenWidth, screenHeight)
    }
    
    override func viewWillAppear(animated: Bool)
    {
        setUpDisplay()
        
    }
    

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
