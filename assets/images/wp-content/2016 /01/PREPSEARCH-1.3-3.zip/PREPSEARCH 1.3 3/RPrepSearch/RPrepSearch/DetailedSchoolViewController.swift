//
//  DetailedSchoolViewController.swift
//  RPrepSearch
//
//  Created by Nidhi on 12/21/15.
//  Copyright © 2015 Nidhi. All rights reserved.
//

import UIKit

class DetailedSchoolViewController: UIViewController
{
     var school: School?
     
    @IBOutlet var schoolImage: UIImageView!
    
    @IBOutlet var detailedDisplay: UITextView!
    
    var imageForSchool = UIImage()
    
   

    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        schoolImage.image = imageForSchool
        schoolImage.layer.borderWidth = 2.0
        schoolImage.layer.masksToBounds = false
        schoolImage.layer.cornerRadius = schoolImage.frame.size.width/2
        schoolImage.clipsToBounds = true
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    func setUpDisplay()
    {
        
        
        let deviceDimensions = findDeviceWidthAndHeight()
        let width = deviceDimensions.width
        let height = deviceDimensions.height
        
        print(width)
        print(height)
        
        var myGradeMin = ""
        if(school?.gradeMin == -1)
        {
            myGradeMin = "Pre-K"
            print("got here")
        }
        if(school?.gradeMin == 0)
        {
            myGradeMin = "Kindergarten"
        }
        else if (school?.gradeMin >= 1)
        {
            let minGrade:Int = (school?.gradeMin)!
            myGradeMin = String (minGrade)
        }
        
        var myCoed = ""
        if(school?.coed==0)
        {
            myCoed = "YES"
        }
        
        
        if(school?.coed == 1)
        {
            myCoed = "All Boys"
        }
        if(school?.coed==2)
        {
            myCoed = "All Girls"
        }
        
        var myBoard = ""
        if(school?.boarding==0)
        {
            myBoard = "NO, Day School"
        }
        
        if(school?.boarding==1)
        {
            myBoard = "Yes Boarding "
        }
        
        if(school?.boarding==2)
        {
            myBoard = "Yes, Boarding and Day"
        }
        
        var myRel = ""
        if(school?.religious==true)
        {
            myRel = "YES"
        }
        if(school?.religious==false)
        {
            myRel = "NO"
        }

        
        if(width == 375 && height == 667 ) //iPhone 6
        {
            
          
            
            detailedDisplay.bounds = CGRectMake(0, 0, 380, 667)
             detailedDisplay.text = "\n\n\n\n\n\n\n\((school?.name)! as String)\n\n\((school?.web)! as String) \n\n\((school?.street)! as String),\((school?.town)! as String), NJ \((school?.zip)! as String)\n\n\((school?.phone)! as String) \n\n\((school?.email)! as String)\n\n\n Grades: \((myGradeMin) as String) to \((school?.gradeMax)! as Int)\n Coed: \((myCoed) as String)\n Religious: \((myRel) as String)\n Boarding: \((myBoard )as String)\n Price: $\((school?.price)! as Int)"
           
            
        }
        else if(width == 414 && height == 736) //iPhone 6plus
        {
            detailedDisplay.bounds = CGRectMake(0, 0, 419, 736)
            
          detailedDisplay.text = "\n\n\n\n\n\n\n\n\((school?.name)! as String)\n\n\((school?.web)! as String) \n\n\((school?.street)! as String),\((school?.town)! as String), NJ \((school?.zip)! as String)\n\n\((school?.phone)! as String) \n\n\((school?.email)! as String)\n\n\n Grades: \((myGradeMin) as String) to \((school?.gradeMax)! as Int)\n Coed: \((myCoed) as String)\n Religious: \((myRel) as String)\n Boarding: \((myBoard )as String)\n Price: $\((school?.price)! as Int)"
            
        }
        else if(width == 320 && height == 568)
        {  //iPhone 5
            
        detailedDisplay.bounds = CGRectMake(0, 0, 325, 605)
         detailedDisplay.text = "\n\n\n\n\n\n\n\n\((school?.name)! as String)\n\n\((school?.web)! as String) \n\n\((school?.street)! as String),\((school?.town)! as String), NJ \((school?.zip)! as String)\n\n\((school?.phone)! as String) \n\n\((school?.email)! as String)\n\n Grades: \((myGradeMin) as String) to \((school?.gradeMax)! as Int)\n Coed: \((myCoed) as String)\n Religious: \((myRel) as String)\n Boarding: \((myBoard )as String)\n Price: $\((school?.price)! as Int)"
            
        }
        else
        {
            detailedDisplay.text = "\n\n\n\n\n\n\n\((school?.name)! as String)\n\n\((school?.web)! as String) \n\n\((school?.street)! as String),\((school?.town)! as String), NJ \((school?.zip)! as String)\n\n\((school?.phone)! as String) \n\n\((school?.email)! as String)\n Grades: \((myGradeMin) as String) to \((school?.gradeMax)! as Int)\n Coed: \((myCoed) as String)\n Religious: \((myRel) as String)\n Boarding: \((myBoard )as String)\n Price: $\((school?.price)! as Int)"
        }
        
        
        
    }
    
    
    
    func findDeviceWidthAndHeight() ->(width: CGFloat, height: CGFloat)
    {
        
        let screenSize: CGRect = UIScreen.mainScreen().bounds
        
        let screenWidth = screenSize.width
        let screenHeight = screenSize.height
        
        
        return (screenWidth, screenHeight)
    }
    
    
    override func viewWillAppear(animated: Bool)
    {
        setUpDisplay()
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
