//
//  FirstViewController.swift
//  RPrepSearch
//
//  Created by Nidhi on 12/3/15.
//  Copyright © 2015 Nidhi. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController, UISearchBarDelegate
{

    @IBOutlet var searchLabel: UILabel!
    
    @IBOutlet var searchBar: UISearchBar!
    
    var results = NSMutableArray()
    
    
    //This is where the search begins
    //The search button was pressed
    //The request is sent to the SimpleSearch Object
    //The results are then sent to the results table
    //via a segue
    func searchBarSearchButtonClicked(searchBar: UISearchBar)
    {
        searchBar.resignFirstResponder()
        //Create a SimpleSearch Object and peform the search
        let simpleSearchObject = SimpleSearch()
        
        //Get the results from the search and segue to the results table view where the results are listed
        
         results = simpleSearchObject.search(searchBar.text!)
        
        self.performSegueWithIdentifier("simpleSearch", sender: self)
    }
    
    
    func setUpLabelAndSearchBar()
    {
        let deviceDimensions = findDeviceWidthAndHeight()
        let width = deviceDimensions.width
        let height = deviceDimensions.height
        
       
        
        if(width == 375 && height == 667 ) //iPhone 6
        {
        
            
            searchLabel.frame.origin.x = 58
            searchLabel.frame.origin.y = 150;
            searchBar.frame.origin.x = 58
            searchBar.frame.origin.y = 240
            
            
        }
        else if(width == 414 && height == 736) //iPhone 6plus
        {
            searchLabel.frame.origin.x = 78
            searchLabel.frame.origin.y = 250;
            searchBar.frame.origin.x = 78
            searchBar.frame.origin.y = 340
            
        }
        
        
        
    }
    
    
    
    func findDeviceWidthAndHeight() ->(width: CGFloat, height: CGFloat)
    {
        
        let screenSize: CGRect = UIScreen.mainScreen().bounds
        
        let screenWidth = screenSize.width
        let screenHeight = screenSize.height
        
        
        return (screenWidth, screenHeight)
    }
    

    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    
        
    }
    
    override func viewWillAppear(animated: Bool)
    {
        setUpLabelAndSearchBar()
        
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?)
    {
        
        if (segue.identifier == "simpleSearch") {
            if let destination = segue.destinationViewController as? ResultsTableViewController
            {
                print(destination)
                print("Segue to Results Table View")
                
                destination.results = self.results
                
            }
        }

    }

}

