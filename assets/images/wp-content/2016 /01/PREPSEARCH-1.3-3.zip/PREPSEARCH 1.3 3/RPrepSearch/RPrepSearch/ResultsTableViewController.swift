//
//  ResultsTableViewController.swift
//  RPrepSearch
//
//  Created by Nidhi on 12/21/15.
//  Copyright © 2015 Nidhi. All rights reserved.
//

import UIKit

class ResultsTableViewController: UITableViewController {
    
    
    var results = NSMutableArray()
    var currentSchoolIndex = 0
    var imageForSchool = UIImage()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
       
        
        let index = tabBarController?.selectedIndex
        if(index == 2)
        {
            print("List of Schools")
            //assign the list of all schools to the 
            //data source
            let factory = SchoolFactory()
            results = factory.getListOfSchools()
            
        }
        if(results.count == 0)
        {
            //Alert - no results found
            let alert = UIAlertController(title: "NO RESULTS", message: "Sorry, no school matched your search", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil))
            
            self.presentViewController(alert, animated: true, completion: nil)
            
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return results.count
    }

    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("searchResults", forIndexPath: indexPath) as! ResultsTableCellTableViewCell

        // Configure the cell...
        let row = indexPath.row
        let school = results[row] as! School
       cell.schoolName.text = school.name
       let address = school.street + "\n" + school.town + "\n" + school.zip
       cell.schoolAddress.text = address
        
        //Make image from school name
        let logo = school.name as String + ".png"
        var image = UIImage(named: logo)
        
        //Printing school name and image name
         print("Printing school name and image name")
         print(results[row].name)
         print(logo)
        
        
        
        //RPS placeholder image
         if(image == nil)
         {
            
               image = UIImage(named: "holder.png")
            
         }
        
       //Create the image view to hold the image
        
         let imageView = UIImageView(frame:CGRectMake(0, 0, 125, 125))
        imageView.layer.borderWidth = 1.5
        imageView.layer.masksToBounds = false
        imageView.layer.cornerRadius = imageView.frame.size.width/2
        imageView.clipsToBounds = true
        imageView.image = image
        cell.schoolImageView.removeFromSuperview()
        cell.schoolImageView = imageView
        cell.addSubview(imageView)
        
        imageForSchool = image!
        
        /*
        var image: UIImage = UIImage(named: "imageName")
        imageView.layer.borderWidth = 1.0
        imageView.layer.masksToBounds = false
        imageView.layer.borderColor = UIColor.whiteColor().CGColor
        imageView.layer.cornerRadius = image.frame.size.width/2
        imageView.clipsToBounds = true*/
        
        return cell
    }
    
    
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        let row = indexPath.row
        currentSchoolIndex = row
       
        let school = results[row] as! School
        
        //Make image from school name
        let logo = school.name as String + ".png"
        
        var image = UIImage(named: logo)
        //imageForSchool = image!
        if(image != nil)
        {
          imageForSchool = image!
        }
        else
        {
            image = UIImage(named: "holder.png")
            imageForSchool = image!
        }
      self.performSegueWithIdentifier("schoolResults", sender: self)
        
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if (segue.identifier == "schoolResults") {
            if let destination = segue.destinationViewController as? DetailedSchoolViewController
                {
                    print(destination)
                    print("Segue to School Info")
                    
                    destination.school = results[currentSchoolIndex] as? School
                   destination.imageForSchool = imageForSchool
                    
                }
        }
    }
    

}
