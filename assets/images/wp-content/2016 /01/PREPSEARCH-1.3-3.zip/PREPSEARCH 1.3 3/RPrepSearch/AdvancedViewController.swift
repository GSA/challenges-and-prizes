//
//  AdvancedViewController.swift
//  RPrepSearch
//
//  Created by Nidhi on 12/17/15.
//  Copyright © 2015 Nidhi. All rights reserved.
//

import UIKit

class AdvancedViewController: UIViewController,UIPickerViewDataSource, UIPickerViewDelegate, UITextFieldDelegate {

    @IBOutlet var zip: UITextField!
    @IBOutlet weak var pickerViewPriceRange: UIPickerView!
   
    @IBOutlet weak var pickerViewGender: UIPickerView!
    @IBOutlet weak var pickerViewGrade: UIPickerView!
    
    @IBOutlet var religious: UISwitch!
    
    
  var pickerDataSourcePrice = ["$5,000-$10,000", "$10,000-$15,000", "$15,000-$20,000", "$20,000-$25,000", "$25,000-$30,000", "$30,000-$35,000", "$35,000-$40,000", "$40,000+"]
    
    var pickerDataSourceGender = [ "Both", "All Girls", "All Boys"]
    
    var pickerDataSourceGrade = ["PreK-12th", "K-12th", "K-8th", "7th-12th", "9th-12th", "K-6th"]
    
    var priceRange = ""
    var gender = ""
    var grade = ""
    
    var results = NSMutableArray()
    
    func requestAdvancedSearch()
    {
        
        //Set up religious
        var isReligious = false
        if(religious.isEqual(true))
        {
            isReligious = true
        }
        
        //Set up the min and max price
        var min = 0
        var max = 0
        
        if(priceRange == "$5,000-$10,000")
        {
            min = 5000
            max = 10000
            
        }
        else if(priceRange == "$10,000-$15,000")
        {
            min = 5000
            max = 10000
            
        }
        else if(priceRange == "$15,000-$20,000")
        {
            min = 15000
            max = 20000
            
        }
        else if(priceRange == "$20,000-$25,000")
        {
            min = 20000
            max = 25000
        }
        else if(priceRange == "$25,000-$30,000")
        {
            min = 25000
            max = 30000
        }
        else if(priceRange == "$30,000-$35,000")
        {
            min = 30000
            max = 35000
        }
        else if(priceRange == "$35,000-$40,000")
        {
            min = 35000
            max = 40000
        }
        else
        {
            min = 40000
            max = 200000
        }
        
        var currentGender = 0
        //Set up gender/coed
        //0=coed, 1 = m 2 = f
        if(gender == "All Boys")
        {
            currentGender = 1
            
        }
        else if(gender == "All Girls")
        {
            currentGender = 2
            
        }
     

        //Set up grade levels - min and max grades
        var minGrade = 0
        var maxGrade = 0
        if(grade == "PreK-12th")
        {
           
            minGrade = -1
            maxGrade = 12
            
        }
        else if(grade == "K-12th")
        {
            minGrade = 0
            maxGrade = 12
            
        }
        else if(grade == "K-8th")
        {
            minGrade = 0
            maxGrade = 8
            
        }
        else if(grade == "7th-12th")
        {
            minGrade = 7
            maxGrade = 12
        }
        else if(grade == "9th-12th")
        {
            minGrade = 9
            maxGrade = 12
        }
        else if(grade == "K-6th")
        {
            minGrade = 0
            maxGrade = 6
        }
       
        //Set up zip code
        if(self.zip.text == nil)
        {
            self.zip.text = "08873"
        }
        
        
        //Set up boarding searches
        //0=day_school, 1 = boarding 2 = both
        //Search for day schools
        let placeHolderSchool = School(name: "School", street: "Street", town: "Town", zip: self.zip.text!, phone: "Phone", email: "Email", web: "Web", gradeMin: minGrade, gradeMax: maxGrade, coed: currentGender, religious: isReligious, boarding: 0, price: min)
        let advancedSearchObject = Search(searchTerm: placeHolderSchool, min: min, max: max)
        //self.results = advancedSearchObject.advancedSearch()
        
        let resultsDay = advancedSearchObject.advancedSearch()
        
    
        
        //Search for boading schools
        placeHolderSchool.boarding = 1
        let advancedSearchObject1 = Search(searchTerm: placeHolderSchool, min: min, max: max)
        let resultsBoarding = advancedSearchObject1.advancedSearch()

        
        //Search for both day and boarding schools
        placeHolderSchool.boarding = 2
        let advancedSearchObject2 = Search(searchTerm: placeHolderSchool, min: min, max: max)
        let resultsBoth = advancedSearchObject2.advancedSearch()
    
        
        self.results = getSetAsArray(resultsDay, array2: resultsBoarding, array3: resultsBoth)

        
    }
    
    
    
    
    func getSetAsArray(array1: NSMutableArray, array2:NSMutableArray, array3: NSMutableArray)->NSMutableArray
    {
        let array = NSMutableArray();
        let workingArray = NSMutableArray();
        let set = NSMutableSet()
        
        for(var i = 0; i < array1.count; i++)
        {
            set.addObject(array1[i].name)
            workingArray.addObject(array1[i])
        }
        for(var i = 0; i < array2.count; i++)
        {
            set.addObject(array2[i].name)
            workingArray.addObject(array2[i])
        }
        for(var i = 0; i < array3.count; i++)
        {
            set.addObject(array3[i].name)
            workingArray.addObject(array3[i])
        }
        
        print("List of schools in set")
        for schoolName in set
        {
            
            print(schoolName)
            
            for(var i = 0; i < workingArray.count; i++)
            {
                if(workingArray[i].name == schoolName as! String)
                {
                    array.addObject(workingArray[i])
                    break
                }
            }
            
        }
        
        return array
    }
    
    
    
     func textFieldShouldReturn(textField: UITextField) -> Bool
    {
       zip.resignFirstResponder()
        
        print(priceRange)
        print(gender)
        print(grade)
        
        //Perform advanced search before the segue
        
        //Created a method to request advanced search
        //then called it here
        requestAdvancedSearch()
        
        
         
       self.performSegueWithIdentifier("advancedSearch", sender: self)
       return true
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int
    {
        return 1
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.pickerViewPriceRange.dataSource = self;
        self.pickerViewPriceRange.delegate = self;
        
        self.pickerViewGender.dataSource = self;
        self.pickerViewGender.delegate = self;
        
        self.pickerViewGrade.dataSource = self;
        self.pickerViewGrade.delegate = self;
        
        self.zip.delegate = self
        
        
    }
    
   

    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        if (pickerView.tag == 0)
        {
            return pickerDataSourcePrice.count
        }
        else if (pickerView.tag == 1)
        {
            return pickerDataSourceGrade.count
        }
        else
        {
            return pickerDataSourceGender.count
        }
       

    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        if (pickerView.tag == 0)
        {
            priceRange = pickerDataSourcePrice[row] as String!
            return pickerDataSourcePrice[row]
        }
        else if (pickerView.tag == 1)
        {
            grade = pickerDataSourceGrade[row]
            return pickerDataSourceGrade[row]
        }
        else
        {
            gender = pickerDataSourceGender[row]
            return pickerDataSourceGender[row]
        }
    
        //what the user picks
    }
    
    
    
    @IBAction func showSearchResults(sender: AnyObject)
    {
        print(priceRange)
        print(gender)
        print(grade)
        
    }

  
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?)
    {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if (segue.identifier == "advancedSearch") {
            if let destination = segue.destinationViewController as? ResultsTableViewController
            {
                print(destination)
                print("Segue to Results Table View")
                
                destination.results = self.results
                self.zip.text = ""
                
            }
        }
       
        
    }
   

}
