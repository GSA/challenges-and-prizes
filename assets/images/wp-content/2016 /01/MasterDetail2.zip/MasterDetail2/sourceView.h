//
//  sourceView.h
//  MasterDetail2
//
//  Created by Eric Hoetjes on 1/19/16.
//  Copyright © 2016 . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface sourceView : UIViewController

@end
