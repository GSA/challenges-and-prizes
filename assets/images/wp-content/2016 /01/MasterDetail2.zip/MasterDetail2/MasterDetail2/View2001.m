

#import "View2001.h"

@implementation View2001

@synthesize zSelectedTitle;
@synthesize zSelectedYards;
@synthesize zSelectedDescription;




- (void)didAddSubview:(UIView *)subview
{
    NSLog(@"Did Add Subview");
}


- (void)willMoveToSuperview:(UIView *)newSuperview
{
    self.lblTitle.text = zSelectedTitle;
    self.lblDescription.text = zSelectedDescription;
    self.lblYards.text = zSelectedYards;
}
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        
        
        [[NSBundle mainBundle] loadNibNamed:@"UIView2001" owner:self options:nil];
        
        self.bounds = self.View2001Outlet.bounds;
        
        [self addSubview:self.View2001Outlet];
        
        
    }
    return self;
}


- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if(self)
    {

        [[NSBundle mainBundle] loadNibNamed:@"UIView2001" owner:self options:nil];
            
    }
    
    return self;
}


@end
