//
//  TableCell2.h
//  MasterDetail2
//


#import <UIKit/UIKit.h>

@interface TableCell2 : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lblTitle;
@end
