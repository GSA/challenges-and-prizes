//
//  TableCell1.h
//  MasterDetail2
//


#import <UIKit/UIKit.h>

@interface TableCell1 : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lblTitle;
@property (weak, nonatomic) IBOutlet UILabel *lblDescription;
@property (weak, nonatomic) IBOutlet UIImageView *lblImage;

@end
