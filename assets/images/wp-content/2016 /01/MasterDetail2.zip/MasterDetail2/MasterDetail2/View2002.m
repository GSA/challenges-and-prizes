//
//  View2002.m
//  MasterDetail2
//

#import "View2002.h"

@implementation View2002


 @synthesize zSelectedTitle;
 @synthesize zSelectedYards;
 @synthesize zSelectedDescription;

 
 - (void)willMoveToSuperview:(UIView *)newSuperview
 {
 self.lblTitle.text = zSelectedTitle;
 self.lblDescription.text = zSelectedDescription;
 self.lblYards.text = zSelectedYards;
 }
 - (id)initWithFrame:(CGRect)frame
 {
 self = [super initWithFrame:frame];
 if (self)
 {
 
 
 [[NSBundle mainBundle] loadNibNamed:@"UIView2002" owner:self options:nil];
 
 self.bounds = self.View2002Outlet.bounds;
 
 [self addSubview:self.View2002Outlet];
 
 
 }
 return self;
 }
 
 
 - (id)initWithCoder:(NSCoder *)aDecoder {
 self = [super initWithCoder:aDecoder];
 if(self)
 {
 
 [[NSBundle mainBundle] loadNibNamed:@"UIView2002" owner:self options:nil];
 
 }
 
 return self;
 }


@end
