//
//  ViewController2D.h
//  MasterDetail2
//


#import <UIKit/UIKit.h>
#import "View2001.h"
#import "View2002.h"

@interface ViewController2 : UIViewController

@property (nonatomic,retain) View2001 *view2001;

@property (nonatomic,retain) View2002 *view2002;


@property (nonatomic,assign) NSString *Title;
@property (nonatomic,assign) NSString *Description;
@property (nonatomic,assign) NSString *Yards;
@property (nonatomic,assign) NSString *UIView;

@end
