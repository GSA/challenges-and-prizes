//
//  sourceView.h
//  MasterDetail2
//
//  Created by Eric Hoetjes on 1/19/16.
//  Copyright © 2016 Anthony Dausilio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface sourceView : UIView

@end
