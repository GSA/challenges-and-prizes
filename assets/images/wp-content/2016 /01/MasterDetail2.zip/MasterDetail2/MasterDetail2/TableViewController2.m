//
//  TableViewController2.m
//  MasterDetail2
//


#import "TableViewController2.h"
#import "TableCell2.h"
#import "ViewController2.h"

@interface TableViewController2 ()

@end

@implementation TableViewController2


@synthesize titleArray;
@synthesize descriptionArray;
@synthesize yardsArray;
@synthesize UIViewArray;

@synthesize SelectedTitle;
@synthesize SelectedDescription;
@synthesize SelectedYards;
@synthesize SelectedUIView;

@synthesize navTitleSelected;

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = [NSString stringWithFormat:@"%@",navTitleSelected];   
}

- (void)didReceiveMemoryWarning {[super didReceiveMemoryWarning];}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {return 1;}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {return titleArray.count;}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"TableCell2";
    TableCell2 *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    
    cell.lblTitle.text = titleArray[indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
   long row = [indexPath row];
    
    SelectedTitle = titleArray[row];
    SelectedDescription = descriptionArray[row];
    SelectedYards = yardsArray[row];
    SelectedUIView = UIViewArray[row];

    [self performSegueWithIdentifier:@"ViewController2" sender:self];
    
}


-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    ViewController2 *viewcontroller2 = [segue destinationViewController];
    
    viewcontroller2.Title = SelectedTitle;
    viewcontroller2.Description = SelectedDescription;
    viewcontroller2.Yards = SelectedYards;
    viewcontroller2.UIView = SelectedUIView;
    

}
@end
