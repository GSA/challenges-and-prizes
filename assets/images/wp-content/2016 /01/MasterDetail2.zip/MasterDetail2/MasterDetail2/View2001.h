

#import <UIKit/UIKit.h>

@interface View2001 : UIView

@property (weak, nonatomic) IBOutlet UILabel *lblTitle;

@property (weak, nonatomic) IBOutlet UILabel *lblDescription;
@property (weak, nonatomic) IBOutlet UILabel *lblYards;

@property (nonatomic,assign) NSString *zSelectedTitle;
@property (nonatomic,assign) NSString *zSelectedDescription;
@property (nonatomic,assign) NSString *zSelectedYards;

@property (strong, nonatomic) IBOutlet UIView *View2001Outlet;

@end
