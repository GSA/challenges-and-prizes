//
//  TableViewController1.h
//  MasterDetail2
//


#import <UIKit/UIKit.h>

@interface TableViewController1 : UITableViewController

@property (nonatomic,strong) NSArray *titleArray;
@property (nonatomic,strong) NSArray *descriptionArray;
@property (nonatomic,strong) NSArray *imageArray;

@property (nonatomic,strong) NSString *navTitleSelected;

@property (nonatomic,strong) NSArray *titleArrayOffense;
@property (nonatomic,strong) NSArray *descriptionArrayOffense;
@property (nonatomic,strong) NSArray *yardsArrayOffense;
@property (nonatomic,strong) NSArray *UIViewArrayOffense;

@property (nonatomic,strong) NSArray *titleArrayDefense;
@property (nonatomic,strong) NSArray *descriptionArrayDefense;
@property (nonatomic,strong) NSArray *yardsArrayDefense;
@property (nonatomic,strong) NSArray *UIViewArrayDefense;

@property (nonatomic,strong) NSArray *titleArraySpecialTeams;
@property (nonatomic,strong) NSArray *descriptionArraySpecialTeams;
@property (nonatomic,strong) NSArray *yardsArraySpecialTeams;
@property (nonatomic,strong) NSArray *UIViewArraySpecialTeams;

@property (nonatomic,strong) NSArray *titleArrayMisc;
@property (nonatomic,strong) NSArray *descriptionArrayMisc;
@property (nonatomic,strong) NSArray *yardsArrayMisc;
@property (nonatomic,strong) NSArray *UIViewArrayMisc;


@property (nonatomic,strong) NSArray *titleArraySelected;
@property (nonatomic,strong) NSArray *descriptionArraySelected;
@property (nonatomic,strong) NSArray *yardsArraySelected;
@property (nonatomic,strong) NSArray *UIViewArraySelected;



@end
