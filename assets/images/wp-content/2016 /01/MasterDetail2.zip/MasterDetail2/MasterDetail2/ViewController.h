//
//  ViewController.h
//  MasterDetail2
//


#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)btnPressed:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btnPressedOutlet;
@property (weak, nonatomic) IBOutlet UIButton *sources;

@end

