//
//  View2003.h
//  MasterDetail2
//


#import <UIKit/UIKit.h>

@interface View2003 : UIView
@property (nonatomic,assign) NSString *zSelectedTitle;
@property (nonatomic,assign) NSString *zSelectedDescription;
@property (nonatomic,assign) NSString *zSelectedYards;
@property (strong, nonatomic) IBOutlet UIView *View2003Outlet;

@property (weak, nonatomic) IBOutlet UILabel *lblTitle;
@property (weak, nonatomic) IBOutlet UILabel *lblDescription;
@property (weak, nonatomic) IBOutlet UILabel *lblYards;

@end
