//
//  View2002.h
//  MasterDetail2
//


#import <UIKit/UIKit.h>

@interface View2002 : UIView

@property (weak, nonatomic) IBOutlet UILabel *lblTitle;
@property (weak, nonatomic) IBOutlet UILabel *lblDescription;

@property (weak, nonatomic) IBOutlet UILabel *lblYards;
@property (nonatomic,assign) NSString *zSelectedTitle;
@property (nonatomic,assign) NSString *zSelectedDescription;
@property (nonatomic,assign) NSString *zSelectedYards;
@property (strong, nonatomic) IBOutlet UIView *View2002Outlet;

@end
