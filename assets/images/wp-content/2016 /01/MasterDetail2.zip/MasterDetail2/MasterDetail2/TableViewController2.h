//
//  TableViewController2.h
//  MasterDetail2


#import <UIKit/UIKit.h>

@interface TableViewController2 : UITableViewController

@property (nonatomic,strong) NSArray *titleArray;
@property (nonatomic,strong) NSArray *descriptionArray;
@property (nonatomic,strong) NSArray *yardsArray;
@property (nonatomic,strong) NSArray *UIViewArray;

@property (nonatomic,assign) NSString *SelectedTitle;
@property (nonatomic,assign) NSString *SelectedDescription;
@property (nonatomic,assign) NSString *SelectedYards;
@property (nonatomic,assign) NSString *SelectedUIView;


@property (nonatomic,strong) NSString *navTitleSelected;



@end
