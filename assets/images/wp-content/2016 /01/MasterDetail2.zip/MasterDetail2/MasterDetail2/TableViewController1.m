//
//  TableViewController1.m
//  MasterDetail2
//


#import "TableViewController1.h"
#import "TableCell1.h"

#import "TableViewController2.h"


@interface TableViewController1 ()

@end

@implementation TableViewController1

@synthesize titleArray;
@synthesize descriptionArray;
@synthesize imageArray;

@synthesize titleArrayOffense;
@synthesize descriptionArrayOffense;
@synthesize yardsArrayOffense;
@synthesize UIViewArrayOffense;

@synthesize titleArrayDefense;
@synthesize descriptionArrayDefense;
@synthesize yardsArrayDefense;
@synthesize UIViewArrayDefense;

@synthesize titleArraySpecialTeams;
@synthesize descriptionArraySpecialTeams;
@synthesize yardsArraySpecialTeams;
@synthesize UIViewArraySpecialTeams;

@synthesize titleArrayMisc;
@synthesize descriptionArrayMisc;
@synthesize yardsArrayMisc;
@synthesize UIViewArrayMisc;


@synthesize titleArraySelected;
@synthesize descriptionArraySelected;
@synthesize yardsArraySelected;
@synthesize UIViewArraySelected;

@synthesize navTitleSelected;


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"Select Penalty Category";
    
    titleArray = @[@"Offense",
                   @"Defense",
                   @"Special Teams",
                   @"Miscellaneous",
                   ];
    
    descriptionArray = @[@"Offense Penalties",
                         @"Defense Penalties",
                         @"Special Teams Penalties",
                         @"Misc. Penalties",
                         ];
    
    imageArray = @[@"offense.jpg",
                   @"defense.jpg",
                   @"special.jpg",
                   @"misc.jpg",
                   ];
    
    titleArrayDefense = @[@"Block below the waist",
                          @"Block in the back",
                          @"Clipping",
                          @"Delay of game",
                          @"Encroachment",
                          @"Face Mask",
                          @"Helmet-to-Helmet Collision",
                          @"Holding",
                          @"Horse-collar tackle",
                          @"Illegal Contact",
                          @"Illegal hands to the face",
                          @"Illegal Participation",
                          @"Illegal use of the hands",
                          @"Neutral Zone Infraction",
                          @"Offsides",
                          @"Pass Interference",
                          @"Personal Foul",
                          @"Roughing the passer",
                          @"Spearing",
                          @"Targeting",
                          @"Tripping",
                          @"Unsportsmanlike Conduct",
                          ];
    
    descriptionArrayDefense = @[@"An illegal block, from any direction, below the waist by any defensive player or by an offensive player under certain situations, by any player after change of possession, by any player in high school with certain exceptions. ",
                                @"A blocker contacting a non-ballcarrying member of the opposing team from behind and above the waist.",
                                @"A blocker contacting a non-ballcarrying opponent from behind and at or below the waist.",
                                @"Any action which delays the next play. On defense, it occurs when a player hinders the offense in hurrying to make the next snap. ",
                                @"Before the snap, a defensive player illegally crosses the line of scrimmage and makes contact with an opponent or has a clear path to the quarterback. In high school, this includes any crossing of the neutral zone by either team, whether contact is made or not. The play is not allowed to begin.",
                                @"Grasping the face mask of another player while attempting to block or tackle him. Under high school rules, any grasping of the face mask, any helmet opening, or the chin strap is a foul, though grasping and twisting carries a more severe penalty than incidental grasping without any twisting.",
                                @"The act of banging one's helmet into the helmet of another player. Can also result in a fine and/or suspension.",
                                @"Illegally grasping or pulling an opponent other than the ball carrier while attempting to ward off a block or cover a receiver.",
                                @"Illegally tackling another player by grabbing the inside of the ball carrier's shoulder pads or jersey from behind and yanking the player down.",
                                @"Making significant contact with a receiver after the receiver has advanced five yards beyond the line of scrimmage. The illegal contact is called only if the quarterback is still in pocket and the ball is still in his hands.",
                                @"Pushing or hitting a player on offense in the head or helmet.",
                                @"Twelve or more players participate during the play, because the extra players either are not detected before the snap or enter during the play. Once the down begins, no further players may enter the field and participate, even if there are fewer than 11 players.",
                                @"Illegal use of the hands against a player on offense while attempting to ward off a block, cover a receiver, or tackle a ball carrier.",
                                @"Before the snap, a defensive player (most often a lineman) jumps into the neutral zone and startles an offensive player, causing him to false start.",
                                @"A player is on the wrong side of the line of scrimmage when the ball is snapped. This foul occurs simultaneously with the snap. Unlike offensive players, defensive players are not compelled to come to a set position before the snap. If a defender jumps across the line but gets back to his side before the snap, there is no foul.",
                                @"Making physical contact with an intended receiver, after the ball has been thrown and before it has been touched by another player, in order to hinder or prevent him from catching a forward pass.",
                                @"A conduct- or safety-related infraction. Includes unnecessary roughness, such as hitting a ball carrier after he is already out of bounds, piling on a ball carrier who is already down, or violent contact with an opponent who is away from and out of the play.",
                                @"A defender continues an effort to tackle or hit a passer after the passer has already thrown a pass. ",
                                @"Tackling or otherwise contacting an opponent with one's helmet. ",
                                @"A defensive player tackles with the crown of his helmet, by initiating contact to the opponent's head above the player's neck, or makes helmet-to-helmet collision.",
                                @"A player trips another player with the lower leg.",
                                @"In high school, if a single player, coach or spectator commits two unsportsmanlike conduct fouls, the person in question should automatically be ejected.",
                                ];
    
    yardsArrayDefense = @[@"15 yards",
                          @"10 yards",
                          @"15 yards",
                          @"5 yards",
                          @"5 yards",
                          @"15 yards for grasping and twisting, 5 yards for incidental grasping",
                          @"15 yards",
                          @"10 yards",
                          @"none",
                          @"10 yards",
                          @"15 yards",
                          @"10 yards",
                          @"5 yards",
                          @"5 yards",
                          @"15 yards, regardless of whether or not the foul is in the end zone.",
                          @"15 yards",
                          @"15 yards and an automatic first down",
                          @"15 yards",
                          @"15 yards",
                          @"15 yards",
                          @"15 yards",                        @"15 yards",
                          ];
    
    UIViewArrayDefense = @[@"View2002",
                           @"View2002",
                           @"View2002",
                           @"View2002",
                           @"View2002",
                           @"View2002",
                           @"View2002",
                           @"View2002",
                           @"View2002",
                           @"View2002",
                           @"View2002",
                           @"View2002",
                           @"View2002",
                           @"View2002",
                           @"View2002",
                           @"View2002",
                           @"View2002",
                           @"View2002",
                           @"View2002",
                           @"View2002",
                           @"View2002",
                           @"View2002",
                           ];
    

    titleArrayOffense = @[@"Block below the waist",
                   @"Block in the back",
                   @"Chop Block",
                   @"Clipping",
                   @"Delay of game",
                   @"Face Mask",
                   @"False Start",
                   @"Helmet-to-Helmet Collision",
                   @"Holding",
                   @"Illegal Batting",
                   @"Illegal Pass Forward",
                   @"Illegal hands to the face",
                   @"Illegal Motion",
                   @"Illegal Participation",
                   @"Illegal Shift",
                   @"Illegal touching of a forward pass",
                   @"Illegal receiver downfield",
                   @"Intentional grounding",
                   @"Offside",
                   @"Pass interference",
                   @"Spearing",
                   @"Unsportsmanlike conduct",
                   ];
    
    descriptionArrayOffense = @[@"An illegal block, from any direction, below the waist by any defensive player or by an offensive player under certain situations, by any player after change of possession, by any player in high school with certain exceptions. ",
                         @"A blocker contacting a non-ballcarrying member of the opposing team from behind and above the waist.",
                         @"An offensive player tries to cut block a defensive player that is already being blocked by another offensive player. The second block may need to be below the thigh or knee, depending on the code.",
                         @"A blocker contacting a non-ballcarrying opponent from behind and at or below the waist",
                         @"Any action which delays the next play. On offense, this means failing to snap the ball before the play clock reaches zero. It may also include spiking the ball.",
                         @"Grasping the face mask of another player while attempting to block or tackle him. Under high school rules, any grasping of the face mask, any helmet opening, or the chin strap is a foul, though grasping and twisting carries a more severe penalty than incidental grasping without any twisting.",
                         @"An offensive player illegally moves after lining up for—but prior to—the snap. Since the ball is dead, the down does not begin. Any player who moves after he has gotten in his set position before the snap in a way that simulates the start of the play.",
                         @"The act of banging one's helmet into the helmet of another player. Can also result in a fine and/or suspension.",
                         @"Illegally grasping or pulling an opponent other than the ball carrier while attempting to ward off a block or cover a receiver.",
                         @"Any intentional batting of a loose ball or ball in player possession. Batting is legal in certain limited situations, such as blocking a kick or deflecting a forward pass (any eligible player may bat a forward pass in any direction).",
                         @"A forward pass is thrown from past the line of scrimmage, after a change of possession, or when a second forward pass is thrown on the same play.",
                         @"Pushing or hitting a player on offense in the head or helmet.",
                         @"A player in motion is moving forward at the time of the snap.",
                         @"Twelve or more players participate during the play, because the extra players either are not detected before the snap or enter during the play. Once the down begins, no further players may enter the field and participate, even if there are fewer than 11 players.",
                         @"A player is not in motion but is not set before the snap; more than one player is in motion at the snap; or after more than one player was moving (shifting), all eleven players have not been motionless for one second.",
                         @"A forward pass first touches an ineligible receiver (an offensive lineman). If the ball is touched by the defenders first, any player may touch it.",
                         @"An ineligible receiver is past the line of scrimmage prior to a forward pass. Ineligible receivers must wait until the pass is thrown beyond the line of scrimmage (or touched) before moving past the line of scrimmage.",
                         @"A forward pass is thrown intentionally incomplete so that the passer avoids loss of yardage or to conserve time.",
                         @"A player is on the wrong side of the line of scrimmage when the ball is snapped. This foul occurs simultaneously with the snap.",
                         @"Making physical contact with an intended receiver (intentional physical contact in NFL), after the ball has been thrown and before it has been touched by another player, in order to hinder or prevent him from catching a forward pass.",
                         @"Tackling or otherwise contacting an opponent with one's helmet.",
                         @"In high school, if a single player, coach or spectator commits two unsportsmanlike conduct fouls, the person in question should automatically be ejected.",
                         ];
    yardsArrayOffense = @[@"15 yards",
                   @"10 yards",
                   @"15 yards",
                   @"15 yards",
                   @"5 yards",
                   @"15 yards for grasping and twisting, 5 yards for incidental grasping",
                   @"5 yards",
                   @"15 yards",
                   @"10 yards",
                   @"15 yards",
                   @"5 yards from the spot of the foul and loss of down (safety if the foul occurs in the end zone).",
                   @"10 yards",
                   @"5 yards",
                   @"5 yards",
                   @"5 yards and a loss of down",
                   @"5 yards",
                   @"5 yards from the spot of the foul and loss of down (safety if the foul occurs in the end zone).",
                   @"5 yards",
                   @"15 yards",
                   @"15 yards",
                   @"15 yards",
                   @"15 yards",
                   ];
    UIViewArrayOffense = @[@"View2001",
                    @"View2001",
                    @"View2001",
                    @"View2001",
                    @"View2001",
                    @"View2001",
                    @"View2001",
                    @"View2001",
                    @"View2001",
                    @"View2001",
                    @"View2001",
                    @"View2001",
                    @"View2001",
                    @"View2001",
                    @"View2001",
                    @"View2001",
                    @"View2001",
                    @"View2001",
                    @"View2001",
                    @"View2001",
                    @"View2001",
                    @"View2001",
                    ];
    
    
    titleArraySpecialTeams = @[@"Blocking in the back",
                   @"Clipping",
                   @"Delay of Game",
                   @"Face Mask",
                   @"Illegal Kick",
                   @"Illegal Kickoff",
                   @"Illegal touching of a free kick",
                   @"Illegal touching of a scrimmage kick",
                   @"Roughing the kicker",
                   @"Rouching the snapper",
                   @"Running into the kicker",
                   ];
    
    descriptionArraySpecialTeams = @[@"A blocker contacting a non-ballcarrying member of the opposing team from behind and above the waist.",
                         @"A blocker contacting a non-ballcarrying opponent from behind and at or below the waist.",
                         @"Any action which delays the next play. On special teams, it happens when the return team runs after signaling for a fair catch, or the defense does not unpile in a timely manner after the play ends.",
                         @"Grasping the face mask of another player while attempting to block or tackle him. Under high school rules, any grasping of the face mask, any helmet opening, or the chin strap is a foul, though grasping and twisting carries a more severe penalty than incidental grasping without any twisting.",
                         @"Any ball not kicked in accordance with the rules",
                         @"The ball, after a kickoff, heads out of bounds between both goal lines without touching any player on either team.",
                         @"The ball, after the free kick, first touches a member of the kicking team prior to travelling 10 yards.",
                         @"The ball, during the scrimmage kick, is touched by a kicking team player, unless the kick is touched by the receiving team or another member of the kicking team.",
                         @"A defender, having missed an attempt to block a kick, tackles the kicker or otherwise runs into the kicker in a way that might injure the kicker or his vulnerable extended kicking leg. ",
                         @"On a punt or field goal attempt, the long snapper is allowed to regain his balance and assume a protective position before he is contacted by the defense.",
                         @"On a kicking play where the defense fails to touch (block) the kicked ball, the defense runs into the kicker/punter. If such an act occurs but is not intentional, this foul is assessed. ",
                         ];
    
    yardsArraySpecialTeams = @[@"10 yards",
                   @"15 yards",
                   @"5 yards",
                   @"15 yards for grasping and twisting, 5 yards for incidental grasping.",
                   @"15 yards",
                   @"5 yards and rekick, or receiving team can take possession where kick went out of bounds, or receiving team awarded possession 25 yards in front of kicking team's free kick line.",
                   @"Not a foul",
                   @"Not a foul",
                   @"15 yards and an automatic first down",
                   @"15 yards and an automatic first down",
                   @"5 yards",
                   ];
    
    UIViewArraySpecialTeams = @[@"View2003",
                           @"View2003",
                           @"View2003",
                           @"View2003",
                           @"View2003",
                           @"View2003",
                           @"View2003",
                           @"View2003",
                           @"View2003",
                           @"View2003",
                           @"View2003",
                           ];
    
                           
    
    
    titleArrayMisc = @[@"Equipment Violation",
                       @"Illegal Substitution",
                       @"Palpably unfair act",
                       @"Sideline infraction"];
    
    descriptionArrayMisc = @[@"Any player in the game without necessary safety equipment (mouthpiece, pads), without chin straps properly fastened or in violation of certain clothing rules.",
                             @"The offense has twelve or more players in the huddle for a period of 3–5 seconds; or twelve or more players are in the formation before a play; or a player is attempting to leave the field as the ball is snapped; or an offensive player entering the field fails to step at least nine yards from the sideline (inside the field's yardage numbers) before the snap; or a player who has been suspended or disqualified attempts to enter the field of play.",
                             @"Called as necessary in the case of any illegal action that the officials deem has clearly and indisputably deprived a team of a score.",
                             @"A player is outside of the team box, a coach is outside the coaches' box (along the sideline in front of the team box), or too many coaches are in the coaches' box.",
                             ];
    
    yardsArrayMisc = @[@"5 yards",
                       @"5 yards",
                       @"Game may be forfeited, or other penalty at discretion of referee.",
                       @"No yardage (first infraction—warning), 5 yards (second infraction—interference), 15 yards (subsequent infractions—unsportsmanlike conduct, interference)",
                       ];

    UIViewArrayMisc = @[@"View2004",
                        @"View2004",
                        @"View2004",
                        @"View2004",
                        ];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];

}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {return 1;}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {return titleArray.count;}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"TableCell1";
    TableCell1 *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    
    cell.lblTitle.text = titleArray[indexPath.row];
    cell.lblDescription.text = descriptionArray[indexPath.row];
    cell.lblImage.image = [UIImage imageNamed:imageArray[indexPath.row]];

    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    long row = [indexPath row];
    if (row==0)
    {
        navTitleSelected = @"Offensive Penalties";
        titleArraySelected = [NSArray arrayWithArray:titleArrayOffense];
        descriptionArraySelected = [NSArray arrayWithArray:descriptionArrayOffense];
        yardsArraySelected = [NSArray arrayWithArray:yardsArrayOffense];
        UIViewArraySelected = [NSArray arrayWithArray:UIViewArrayOffense];
    }
    
    if (row==1)
    {
        
        navTitleSelected = @"Defensive Penalities";
        titleArraySelected = [NSArray arrayWithArray:titleArrayDefense];
        descriptionArraySelected = [NSArray arrayWithArray:descriptionArrayDefense];
        yardsArraySelected = [NSArray arrayWithArray:yardsArrayDefense];
        UIViewArraySelected = [NSArray arrayWithArray:UIViewArrayDefense];
        
    }
    if (row==2)
    {
        
        navTitleSelected = @"Special Teams Penalities";
        titleArraySelected = [NSArray arrayWithArray:titleArraySpecialTeams];
        descriptionArraySelected = [NSArray arrayWithArray:descriptionArraySpecialTeams];
        yardsArraySelected = [NSArray arrayWithArray:yardsArraySpecialTeams];
        UIViewArraySelected = [NSArray arrayWithArray:UIViewArraySpecialTeams];
        
    }
    if (row==3)
    {
        navTitleSelected = @"Miscellaneous Penalities";
        titleArraySelected = [NSArray arrayWithArray:titleArrayMisc];
        descriptionArraySelected = [NSArray arrayWithArray:descriptionArrayMisc];
        yardsArraySelected = [NSArray arrayWithArray:yardsArrayMisc];
        UIViewArraySelected = [NSArray arrayWithArray:UIViewArrayMisc];
        
    }
    
    [self performSegueWithIdentifier:@"TableCell2" sender:self];
}

    
    -(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"TableCell2"])
    {
        TableViewController2 *tableviewcontroller2 = [segue destinationViewController];
        
        tableviewcontroller2.titleArray = [NSArray arrayWithArray:titleArraySelected];
        tableviewcontroller2.descriptionArray = [NSArray arrayWithArray:descriptionArraySelected];
        tableviewcontroller2.yardsArray = [NSArray arrayWithArray:yardsArraySelected];
        tableviewcontroller2.UIViewArray = [NSArray arrayWithArray:UIViewArraySelected];
        
        tableviewcontroller2.navTitleSelected = [NSString stringWithFormat:@"%@",navTitleSelected];
        
        
    }
}
@end
