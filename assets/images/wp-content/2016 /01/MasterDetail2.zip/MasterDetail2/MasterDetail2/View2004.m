//
//  View2004.m
//  MasterDetail2
//

#import "View2004.h"

@implementation View2004


@synthesize zSelectedTitle;
@synthesize zSelectedYards;
@synthesize zSelectedDescription;


- (void)willMoveToSuperview:(UIView *)newSuperview
{
    self.lblTitle.text = zSelectedTitle;
    self.lblDescription.text = zSelectedDescription;
    self.lblYards.text = zSelectedYards;
}
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        
        
        [[NSBundle mainBundle] loadNibNamed:@"UIView2004" owner:self options:nil];
        
        self.bounds = self.View2004Outlet.bounds;
        
        [self addSubview:self.View2004Outlet];
        
        
    }
    return self;
}


- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if(self)
    {
        
        [[NSBundle mainBundle] loadNibNamed:@"UIView2004" owner:self options:nil];
        
    }
    
    return self;
}


@end
