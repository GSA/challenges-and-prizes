//
//  sourceView.m
//  MasterDetail2
//
//  Created by Eric Hoetjes on 1/19/16.
//  Copyright © 2016 Anthony Dausilio. All rights reserved.
//

#import "sourceView.h"

@implementation sourceView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
