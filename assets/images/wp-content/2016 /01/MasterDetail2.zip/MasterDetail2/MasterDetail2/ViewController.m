//
//  ViewController.m
//  MasterDetail2
//


#import "ViewController.h"
#import "TableViewController1.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"Home";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"BellsSegue"])
    {
     
        
   
    }

}
- (IBAction)btnPressed:(id)sender {
    
    NSLog(@"Btn Pressed");
}
@end

