//
//  ViewController2D.m
//  MasterDetail2


#import "ViewController2.h"
#import "View2001.h"
#import "View2002.h"
#import "View2003.h"
#import "View2004.h"

@interface ViewController2 ()

@end

@implementation ViewController2

@synthesize Title;
@synthesize Description;
@synthesize Yards;
@synthesize UIView;


- (void)viewWillAppear:(BOOL)animated
{
    
    if ([self.UIView isEqualToString:@"View2001"])
    {
        View2001 *view2001 = [[View2001 alloc] init];
    
        view2001.zSelectedTitle = [NSString stringWithFormat:@"%@",Title];
        view2001.zSelectedDescription = [NSString stringWithFormat:@"%@",Description];
        view2001.zSelectedYards = [NSString stringWithFormat:@"%@",Yards];
    
        [self.view addSubview:view2001];

        view2001.center = self.view.center;
    }
    
    if ([self.UIView isEqualToString:@"View2002"])
    {
        
        View2002 *view2002 = [[View2002 alloc] init];
    
        view2002.zSelectedTitle = [NSString stringWithFormat:@"%@",Title];
        view2002.zSelectedDescription = [NSString   stringWithFormat:@"%@",Description];
        view2002.zSelectedYards = [NSString stringWithFormat:@"%@",Yards];
    
        [self.view addSubview:view2002];
    
        view2002.center = self.view.center;
    }
    
    if ([self.UIView isEqualToString:@"View2003"])
    {
        
        View2003 *view2003 = [[View2003 alloc] init];
        
        view2003.zSelectedTitle = [NSString stringWithFormat:@"%@",Title];
        view2003.zSelectedDescription = [NSString   stringWithFormat:@"%@",Description];
        view2003.zSelectedYards = [NSString stringWithFormat:@"%@",Yards];
        
        [self.view addSubview:view2003];
        
        view2003.center = self.view.center;
    }
    if ([self.UIView isEqualToString:@"View2004"])
    {
        
        View2004 *view2004 = [[View2004 alloc] init];
        
        view2004.zSelectedTitle = [NSString stringWithFormat:@"%@",Title];
        view2004.zSelectedDescription = [NSString   stringWithFormat:@"%@",Description];
        view2004.zSelectedYards = [NSString stringWithFormat:@"%@",Yards];
        
        [self.view addSubview:view2004];
        
        view2004.center = self.view.center;
    }

}

- (void)viewDidDisappear:(BOOL)animated
{
    // Clear out subview (panelView)
    NSArray *subviews = [[self.view subviews] copy];
    for (UIView *subView in subviews)
    {
        [subView removeFromSuperview];
    }
    
}


@end
