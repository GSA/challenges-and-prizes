
//

#import "sourceView.h"

@interface sourceView ()
@property (weak, nonatomic) IBOutlet UILabel *wiki;

@end

@implementation sourceView

- (void)viewDidLoad {
    [super viewDidLoad];
 self.navigationItem.title = @"Sources Used";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
