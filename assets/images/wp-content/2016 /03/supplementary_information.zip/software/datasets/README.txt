This directory contains three files:

	training_data.json - Training data for the BMG model, saved in JSON format
	bmg.data           - Data in a format compatible with Magpie
	oqmd_hull.txt      - Energies and compositions of compounds on the convex hull of the OQMD. Used to compute attributes