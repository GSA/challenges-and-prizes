/**
 * Attribute generators for elements from the periodic table.
 */
package magpie.attributes.generators.element;
