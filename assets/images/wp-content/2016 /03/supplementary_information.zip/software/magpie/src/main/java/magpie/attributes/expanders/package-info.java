
/**
 * Classes that expand the number of available attributes
 */
package magpie.attributes.expanders;
