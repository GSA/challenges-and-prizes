/**
 * Attributes based on the composition of a material.
 */
package magpie.attributes.generators.composition;
