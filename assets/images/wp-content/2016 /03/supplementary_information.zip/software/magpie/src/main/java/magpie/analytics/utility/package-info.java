
/**
 * Classes that handle calculation of useful statistics
 */
package magpie.analytics.utility;
