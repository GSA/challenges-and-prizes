
/**
 * Provides operations designed to analyze and manipulate attributes
 */
package magpie.attributes;


