
/**
 * Classes necessary to generate statistics about model, searcher, clusterer performance.
 */
package magpie.analytics;


