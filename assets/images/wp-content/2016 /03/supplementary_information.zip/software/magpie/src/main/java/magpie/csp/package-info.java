
/**
 * Models that predict what crystal structure will appear under different conditions. 
 */
package magpie.csp;
