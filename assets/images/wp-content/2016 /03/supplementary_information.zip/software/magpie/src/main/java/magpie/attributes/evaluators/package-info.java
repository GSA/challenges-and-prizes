
/**
 * Methods to evaluate the predictive power of single attributes
 */
package magpie.attributes.evaluators;
