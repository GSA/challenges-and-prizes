/**
 * Tools to generate attributes based on crystal structures
 */
package magpie.attributes.generators.crystal;
