/**
 * Objects design to compute new attributes for a dataset.
 */
package magpie.attributes.generators;
