close all
clear
clc


% Surface Grinder: Model SGE-818-2NA. Company: Sharp Industries Inc.
% Cylindrical grinder: RC-Grind 1050. Company: KAAST.
%====geometric dimension of workpiece========
%cylindrical grinding
D=50.15;%workpiece diameter for cylindrical grinding in mm.
Lc=100;%workpiece length in mm.
Df=50;%desired diameter in mm.
%surface grinding
Ls=20;%length of work piece in mm.
W=50;%width of the work piece in mm.
h=50.15;%height of workpiece in mm.
hf=50;%desired height in mm.

%manufacturing process parameters======
ti=0.2;%idle time per piece in min;
tL=25;%tool life;
TCT=0.4;%average tool change time per piece in min/piece
theta=60*(pi()/180);%semi-included angle in radians. 60 degrees is chosen.
CO2kwh=0.53446789;%CO2 emission per work piece in kg/kwh
Costkwh=19.8;%cost per kwh in cents
%====control/input parameters from grinders======
d=[0.04,0.05,0.10,0.15,0.20,0.25];%infeed in mmm
wt=0.5;%transverse feed in mm/rev for cylindrical grinding
wc=4;%cross feed in mm for surface grinding
vw=(0.1:0.0025:25)*10^3;%work speed in mm/min
C=50;%active grits per wheel area in grits/mm^2. 50 is typical one.
U=60;%specific energy of material in W.s/mm^3

grindingApproach='surface';%specify grinding type, surface grinding or cylindrical grinding
convexType='External';%specify type of convex contact, external or internal;
%surface
interestOfPlot='vw-e';%choose which plot you want to focus. Options:
%Surface:
%1.vw-e(workpiece speed versus efficiency for different infeed)
%2. vw-power(workpiece speed versus power for different infeed)
%3. vw-CO2(workpiece speed versus CO2 emission for different infeed)
%4. vw-cost(workpiece speed versus cost for different infeed)
%5. vw-time(workpiece speed versus time for different infeed)
%6. vw-temperature(workpiece speed versus temperature for different infeed.)
%7. vw-aggressiveness number(workpiece speed versus aggressive number for different wheel spindle speed.)
%Choose one from above to plot the relationship.
%Cylindrical:
% vw-CO2

if strcmp(grindingApproach,'surface')==1
    Ds=205; %wheel diameter in mm
    w=wc;%assign cross feed for surface grinding.
    axialSpeed=vw;%in surface grinding, aixal speed is just vw.
    length=Ls;%assign Ls to length.
    N=[2860,3460];%wheel spindle speed in rev/min. 3460 or 2860 RPM
    vs=N*pi()*Ds;%surface speed of wheel in mm/min
    k=51.9/10^3;%thermal conductivity of 1018 steel
    alpha=(51.9/(7870*(0.486*1000)))*10^6;
    K2=20;
    %====geometric dimension of grinding wheel===
    wheelWidth=19;%width of wheel in mm.
    
    Pcross=400;%cross feed power(W)
    Pvertical=400;%vertical feed power(W)
    Phydraulic=2.2;%hydraulic table feed power(W)
    Pspindle=1500;%spindle power;
elseif strcmp(grindingApproach,'cylindrical')==1
    Ds=203; %wheel diameter in mm
    Nw=30:1:264;%workpiece spindle speed in rev/min.
    w=wt;%assign transvers feed to cylindrical grinding.
    vw=(pi()*D*Nw);%workpiece surface speed in m/min.
    N=2500:1:3300;%wheel spindle speed in rev/min;
    fm=N*wt;%machine feed rate in mm/min for cylindrical grinding
    axialSpeed=fm;%in cylindrical grinding, axial speed is just fm.
    length=Lc;%assign Lc to length;
    vs=N*pi()*Ds;%surface speed of wheel in mm/min.
    k=51.9/10^3;%thermal conductivity of 1018 steel
    alpha=(51.9/(7870*(0.486*1000)))*10^6;
    Pgrinding=4000;
    Pspindle=0.75*1000;
    PhydraulicPump=0.75*1000;
    PcoolantPump=0.125*1000;
    %====geometric dimension of grinding wheel===
    wheelWidth=50;%width of wheel in mm.
    if strcmp(convexType,'External')==1
        de=Ds/(1+(Ds/D));%equivalent diameter of external convex contact.
    elseif strcmp(convexType,'Internal')==1
        de=Ds/(1-(Ds/D));%equivalent diameter of internal convex contact.
    else
    end
    Ds=de;%in cylindrical grinding, wheel diameter used in caculating the contact length is equivalent diamter computed as above.
else
end

%parameters for both cylindrical and surface.
nc=vs*w*C;%number of chips formed per unit time.
%Vchip=RMR./nc;%average volume per chip.

%Fc=60000*cuttingPower./vs;%cutting force for grinding.

%A=16.7*(vw./vs)*(d/Ds)^0.5;%aggressive number.Typical A number varies from 3 to 60.

% [row,column]=size(N);
% figure;
% grid on;
% hold on;
% color={'-.r','-.b'};
%
% for i=1:column
%     hm=((3/(C*tan(theta)))*(vw./vs(1,i)).*(d1/Ds)^0.5).^0.5;%maximum chip thickness underformed
%     rg=wheelWidth./hm;%aspect ratio;
%     %Ts=K2.*(d/1000)^(0.75).*((rg.*C.*vs(1,i)./vw).^(0.5)).*(Ds/1000)^(0.25);%temperature in the grinding temperature;
%
% end




[row,column]=size(d);
figure;
grid on;
hold on;
color={'-.r','-.b','-.m','-.c','-.g','-.k'};
for i=1:column
    La=(d(i)*(D-d(i)))^0.5;%length of approach in mm.
    Lt=length+La;%total work length;
    tl=Lt./axialSpeed;%grinding time per work length in min.
    
    
    if strcmp(grindingApproach,'surface')==1
        np=(W/w)*(h-hf)/d(i);%number of passes for surface grinding.
        tc=np*tl;%acutal cutting time per workpiece in min.
        tp=tc+ti+(tc/tL)*TCT;%total grinding time per workpiece in min.
        Etotal=(Pspindle*(tp*60))+((h-hf)/d(i))*((60*length./vw)*(W/wheelWidth)*Phydraulic+(60*W/wc)*Pcross)+60*((h-hf)/d(i))*Pvertical;%total power per piece;
        Ptotal=Etotal./(tp*60);
        RMR=vw*w*d(i);%material removal rate
    end
    if strcmp(grindingApproach,'cylindrical')==1
        np=(D-Df)/(2*d(i));%number of passes for cylindrical grinding.
        tc=np*tl;%acutal cutting time per workpiece in min.
        tp=tc+ti+(tc/tL)*TCT;%total grinding time per workpiece in min.
        Ptotal=zeros(size(axialSpeed));
        Ptotal(:,:)=Pgrinding+PcoolantPump+PhydraulicPump+Pspindle;%total power rating for cylindrical grinding.
        Etotal=Ptotal.*(tp/60);%total energy.
        RMR=vw(71)*w*d(i); %material removal rate, fix vw at 100 rev/min.
    end
    
    
    cuttingPower=U*RMR/60;%required cutting power.
    e=(cuttingPower./Ptotal)*100;
    CO2=CO2kwh*Etotal*2.78*10^-7;%CO2 emission in kg per piece.
    Cost=2.78*10^(-7)*Etotal*Costkwh;%cost per workpiece.
    lc=(Ds*d(i)).^0.5;%contact length.
    q=0.67*U*(vw/60)*d(i)*w/(lc*w);%heat flux;
    l=lc/2;%half length;
    maximumTemp=3.543*((vw/60)*l/(2*alpha)).^(0.5).*(2*alpha*q./(pi()*k*(vw/60)));%maximum temperature.
    
    if strcmp(interestOfPlot,'vw-e')==1
        plot(vw,e,color{i},'lineWidth',2);
        if strcmp(grindingApproach,'surface')==1
            ylim([0,50]);
            xlim([0,9000]);%9000mm/min feed rate is usually the upper bound.
        end
    end
    if strcmp(interestOfPlot,'vw-power')==1
        plot(vw,Ptotal,color{i},'lineWidth',2);
        if strcmp(grindingApproach,'surface')==1
            ylim([0,50000]);
            xlim([0,9000]);%9000mm/min feed rate is usually the upper bound.
        end
    end
    if strcmp(interestOfPlot,'vw-CO2')==1
        if strcmp(grindingApproach,'surface')==1
            plot(vw,CO2,color{i},'lineWidth',2);
            ylim([0,0.32]);
            xlim([0,9000]);
            
        else
            plot(axialSpeed,CO2,color{i},'lineWidth',2);
            
        end
        
    end
    if strcmp(interestOfPlot,'vw-cost')==1
        if strcmp(grindingApproach,'surface')==1
            plot(vw,Cost,color{i},'lineWidth',2);
            ylim([0,15]);
            xlim([0,9000]);
            
        else
            plot(axialSpeed,Cost,color{i},'lineWidth',2);
            
        end
    end
    if strcmp(interestOfPlot,'vw-time')==1
        if strcmp(grindingApproach,'surface')==1
            plot(vw,tp,color{i},'lineWidth',2);
            ylim([0,2]);
            xlim([0,9000]);
        else
            plot(axialSpeed,tp,color{i},'lineWidth',2);
            
        end
    end
    if strcmp(interestOfPlot,'vw-temperature')==1
        if strcmp(grindingApproach,'surface')==1
            plot(vw,maximumTemp,color{i},'lineWidth',2);
            ylim([0,1500]);
            xlim([0,9000]);
        else
            plot(axialSpeed,maximumTemp,color{i},'lineWidth',2);
            
        end
    end
end
if strcmp(interestOfPlot,'vw-e')==1
    xlabel('Workpiece surface speed (mm/min)');
    ylabel('Overall power efficiency of the grinder (%)');
end
if strcmp(interestOfPlot,'vw-power')==1
    xlabel('Workpiece surface speed (mm/min)');
    ylabel('Overal machine power(W)');
    
end
if strcmp(interestOfPlot,'vw-CO2')==1
    xlabel('Workpiece surface speed (mm/min)');
    ylabel('Carbon dioxide emission per workpiece (kg)');
end
if strcmp(interestOfPlot,'vw-cost')==1
    xlabel('Workpiece surface speed (mm/min)');
    ylabel('Cost per workpiece due to the electrical power (cents)');
end
if strcmp(interestOfPlot,'vw-time')==1
    xlabel('Workpiece surface speed (mm/min)');
    ylabel('Time required to finish the part(min)');
end
if strcmp(interestOfPlot,'vw-temperature')==1
    xlabel('Workpiece surface speed (mm/min)');
    ylabel('Maximum temperature at the work surface (K)');
end
hold off;
legend('0.04mm infeed', '0.05mm infeed','0.10mm infeed','0.15mm infeed','0.20mm infeed','0.25mm infeed');


if strcmp(interestOfPlot,'vw-aggressiveness number')==1
    
    figure;
    hold on;
    grid on;
    [row1,column1]=size(vs);
    d1=d(2);%select 0.05 mm for depth of cut for the aggressive number analysis.
    for i=1:column1
        A=16.7*(vw./(vs(i)/60000))*(d1/Ds).^0.5;%aggressive number.Typical A number varies from 3 to 60.
        
        plot(vw,A,color{i},'lineWidth',2);
        %ylim([0,1500]);
        xlim([0,9000]);
        
        
    end
    if strcmp(interestOfPlot,'vw-aggressiveness number')
        xlabel('Workpiece surface speed (mm/min)');
        ylabel('Aggresiveness number (A typical number varies from 3 to 60)');
    end
    legend('2860 rev/min wheel spindle speed','3460 rev/min wheel spindle speed');
    %Cylindrical
end





