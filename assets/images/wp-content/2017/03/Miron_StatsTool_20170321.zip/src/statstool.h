#ifndef SAMPLINGTOOL_H
#define SAMPLINGTOOL_H

#include <QDebug>

#include "scythestat/stat.h"

#include <boost/math/distributions/students_t.hpp>
#include <boost/math/distributions/hypergeometric.hpp>
#include <boost/math/distributions/binomial.hpp>
#include <boost/math/policies/policy.hpp>
#include <math.h>

#include <QtXlsx/QtXlsx>
#include <QDropEvent>
#include <QMimeData>
#include <QRegExp>
#include <QMainWindow>
#include <QMessageBox>
#include <QFile>
#include <QFileDialog>
#include <QTextStream>
#include <QDateTime>
#include <QTextEdit>
#include <QString>
#include <QStringList>
#include <QTableView>
#include <QStandardItemModel>
#include <QStandardItem>


#define PROGRAM_TITLE QString("Stats Tool")
#define PROGRAM_VERSION_MAJOR 1
#define PROGRAM_VERSION_MINOR 0
#define PROGRAM_VERSION_STRING (QString("v") + QString("%1").arg(PROGRAM_VERSION_MAJOR) + "." + QString("%1").arg(PROGRAM_VERSION_MINOR))
#define PROGRAM_STRING_FULL PROGRAM_TITLE + " " + PROGRAM_VERSION_STRING

#define ST_ERRORBOX(str) { QMessageBox errBox; errBox.setWindowTitle(PROGRAM_STRING_FULL); errBox.setText(str); errBox.exec(); }

#define STRIP_REGEXP QRegExp("\\$|,|\\(|\\)")
#define SPLIT_REGEXP QRegExp("\t| ")

typedef scythe::Matrix<long double, scythe::Row, scythe::Concrete> matrix_t;
typedef boost::math::policies::policy<
    boost::math::policies::domain_error<boost::math::policies::errno_on_error>,
    boost::math::policies::pole_error<boost::math::policies::errno_on_error>,
    boost::math::policies::overflow_error<boost::math::policies::errno_on_error>,
    boost::math::policies::evaluation_error<boost::math::policies::errno_on_error>
> boost_error_policy;

namespace Ui {
class StatsTool;
}

class StatsTool : public QMainWindow
{
    Q_OBJECT

public:
    explicit StatsTool(QWidget *parent = 0);
    ~StatsTool();
    static QString excelFileToPlainText(QString &fileName);
    static QString excelFileToPlainText(QXlsx::Document &excel);
    static double ratstats_skewness(matrix_t &matrix, int column, double mean);
    static double ratstats_kurtosis(matrix_t &matrix, int column, double mean);

public slots:
    void displayText(QString str);
    void displayHtml(QString str);


private slots:
    void on_actionSingle_Stage_Random_Number_triggered();
    void on_actionUnrestricted_Attribute_Appraisal_triggered();
    void on_pushButton_saveToFile_clicked();

    void on_pushButton_quit_clicked();

    void on_actionUnrestricted_Variable_Appraisal_triggered();

    void on_actionAbout_triggered();

    void on_actionStratified_Variable_Appraisal_triggered();

private:
    Ui::StatsTool *ui;
    void setupDisplayArea();
    void displayImage(QString file);
};

#endif // SAMPLINGTOOL_H
