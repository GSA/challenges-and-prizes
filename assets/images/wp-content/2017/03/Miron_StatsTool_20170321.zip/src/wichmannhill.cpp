#include "wichmannhill.h"
#include "statstool.h"


// C++ implementation (of an R version provided by the OIG) of the Visual Basic function used by RAT-STATS
void ExcelRand64(int64_t ExcelSeed, int64_t outputmax, int64_t &Step, long double &ExcelOutput, long double &RATSTAT)
{
    int64_t vara = ExcelSeed;
    int64_t varb = 1140671485;
    int64_t varc = 12820163;
    bool firstflag = true;
    long double ValueA = 0;
    while ((ValueA >= outputmax) || firstflag) {
        firstflag = false;
        vara = ExcelSeed;
        ExcelSeed = (vara * varb + varc) % ((int64_t)pow(2, 24));
        ValueA = outputmax * ExcelSeed / pow(2, 24) + 1;
    }
    Step = ExcelSeed;
    ExcelOutput = ExcelSeed / pow(2, 24);
    RATSTAT = ValueA;
}

// C++ implementation (of an R version provided by the OIG) of the Visual Basic function used by RAT-STATS
int64_t ExcelRandomize64(double startingpoint, int64_t ExcelSeed)
{
    unsigned char testhelptemp[8] = { 0 };
    unsigned char bitlist[8] = { 0 };
    unsigned char bitseed[8] = { 0 };
    int64_t vara = 0, varb = 0, ret = 0;
    int64_t temp_a = 0, temp_b = 0;

    memcpy(testhelptemp, &startingpoint, 8);
    memcpy(bitlist, testhelptemp + 4, 4);
    memcpy(bitseed, &ExcelSeed, 8);
    memcpy(&vara, bitlist, 2);
    memcpy(&varb, bitlist + 2, 2);
    ret = vara ^ varb;
    vara = 0;
    varb = 0;
    memcpy( ((unsigned char *)&temp_a) + 1, &ret, 2 );
    memcpy( ((unsigned char *)&temp_b), ((unsigned char *)&ExcelSeed), 1 );
    ret = temp_a | temp_b;
    return ret;
}

int64_t WichmannHill::sum(std::map<int64_t, int64_t> &randoms)
{
    int64_t sum = 0;

    for (std::map<int64_t, int64_t>::iterator it = randoms.begin(); it != randoms.end(); it++)
        sum += it->second;

    return sum;
}

WichmannHill::WichmannHill(double seed = 0)
{
    int64_t Step, temp;
    long double ExcelOutput;
    long double RATSTAT;

    int64_t currentseed = 3758214;
    currentseed = ExcelRandomize64(seed, currentseed);
    ExcelRand64(currentseed, 30269, Step, ExcelOutput, RATSTAT);
    this->seed_a = floor(RATSTAT);
    temp = Step;
    ExcelRand64(temp, 30307, Step, ExcelOutput, RATSTAT);
    this->seed_b = floor(RATSTAT);
    temp = Step;
    ExcelRand64(temp, 30323, Step, ExcelOutput, RATSTAT);
    this->seed_c = floor(RATSTAT);
    return;
}

static bool check_duplicate(std::unordered_map<int64_t, int64_t> &hashmap, int64_t temp)
{
    return hashmap.count(temp) > 0;
}

/*
 * RAT-STATS compliant version of the Wichmann-Hill algorithm
*/
int WichmannHill::generateNumbers(int how_many, int64_t min, int64_t max, std::map<int64_t, int64_t> &randoms)
{
	int samsiz = how_many;
    int64_t universe = max - min + 1;
	bool duplicate;
    double term1, term2, term3;
    int64_t temp;
    std::unordered_map<int64_t, int64_t> hashmap;

    if (how_many > universe)
        return -1;
    for (int j = 1; j < samsiz + 1; j++)
	{
		duplicate = false;
		do {
            term1 = floor(this->seed_a / 177.0);
            term2 = this->seed_a - (177 * term1);
            this->seed_a = 171 * term2 - (2 * term1);
            if (this->seed_a <= 0) this->seed_a += 30269;

            term1 = floor(this->seed_b / 176.0);
            term2 = this->seed_b - (176 * term1);
            this->seed_b = (172 * term2) - (35 * term1);
            if (this->seed_b <= 0) this->seed_b += 30307;

            term1 = floor(this->seed_c / 178.0);
            term2 = this->seed_c - (178 * term1);
            this->seed_c = 170 * term2 - 63 * term1;
            if (this->seed_c <= 0) this->seed_c += 30323;

            term3 = this->seed_a / 30269.0 + this->seed_b / 30307.0 + this->seed_c / 30323.0;
            temp = floor((term3 - floor(term3)) * universe) + min;
            if (check_duplicate(hashmap, temp)) {
				duplicate = true;
            } else {
                randoms.insert(std::pair<int64_t, int64_t>(j, temp));
                hashmap.insert(std::pair<int64_t, int64_t>(temp, j));
				duplicate = false;
			}
		} while (duplicate);
	}
    return 0;
}
