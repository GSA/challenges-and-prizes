#ifndef DIALOGUNRESTRICTEDVARIABLEAPPRAISAL_H
#define DIALOGUNRESTRICTEDVARIABLEAPPRAISAL_H

#include <QDialog>
#include "statstool.h"


namespace Ui {
class DialogUnrestrictedVariableAppraisal;
}

class DialogUnrestrictedVariableAppraisal : public QDialog
{
    Q_OBJECT

public:
    explicit DialogUnrestrictedVariableAppraisal(QWidget *parent = 0);
    ~DialogUnrestrictedVariableAppraisal();

    static bool first_column_is_examined(QString str);
    static bool second_column_is_difference(QString str);
    static bool first_column_is_audited(QString str);
    static bool first_column_is_difference(QString str);

    static void fill_in_column(matrix_t &mat, int examined_column, int audited_column, int difference_column, int n_rows);
    static double ratstats_kurtosis(matrix_t &matrix, int column, double mean);
    static double ratstats_skewness(matrix_t &matrix, int column, double mean);
    static void build_report(matrix_t &mat, QStringList &report, QString &inputFileName, int universeSize, int exa_col, int aud_col, int dif_col);

signals:
    void displayHtml(QString str);
    void displayText(QString str);

private slots:
    void on_pushButton_chooseInputFile_clicked();
    void on_buttonBox_accepted();
    void on_checkBox_enableEditing_toggled(bool checked);
    void readFromFile(QString inputFileName);
    void dropEvent(QDropEvent *event);
    void dragEnterEvent(QDragEnterEvent *event);

private:
    Ui::DialogUnrestrictedVariableAppraisal *ui;
    QString inputFileName;
};

#endif // DIALOGUNRESTRICTEDVARIABLEAPPRAISAL_H
