#ifndef DIALOGSINGLESTAGERANDOMNUMBERS_H
#define DIALOGSINGLESTAGERANDOMNUMBERS_H

#include <QDialog>
#include <QFileDialog>

namespace Ui {
class DialogSingleStageRandomNumbers;
}

class DialogSingleStageRandomNumbers : public QDialog
{
    Q_OBJECT

public:
    explicit DialogSingleStageRandomNumbers(QWidget *parent = 0);
    ~DialogSingleStageRandomNumbers();

signals:
    void displayText(QString str);
    void displayHtml(QString str);

private slots:
    void on_buttonBox_accepted();
    void accept();


private:
    Ui::DialogSingleStageRandomNumbers *ui;
};

#endif // DIALOGSINGLESTAGERANDOMNUMBERS_H
