#include "dialogsinglestagerandomnumbers.h"
#include "ui_dialogsinglestagerandomnumbers.h"
#include "samplingtool.h"
#include "ui_samplingtool.h"
#include "wichmannhill.h"

DialogSingleStageRandomNumbers::DialogSingleStageRandomNumbers(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogSingleStageRandomNumbers)
{
    ui->setupUi(this);
}

DialogSingleStageRandomNumbers::~DialogSingleStageRandomNumbers()
{
    delete ui;
}

static void insert_ratstats_compliant_number_list(std::map<int64_t, int64_t> &randoms, QStringList &out, int n_sorted)
{
    std::map<int64_t, int64_t> sorted_randoms;

    if (n_sorted > 0) {
        // sort by value (std::map objects are sorted by key)
        for (std::map<int64_t, int64_t>::iterator it = randoms.begin(); it != randoms.end(); it++)
        {
            sorted_randoms.insert(std::pair<int64_t, int64_t>(it->second, it->first));
            if (it->first == n_sorted)
                break;
        }
        // insert strings for sorted-by-value numbers
        for (std::map<int64_t, int64_t>::iterator it = sorted_randoms.begin(); it != sorted_randoms.end(); it++)
        {
            out << QString::asprintf("%6ld  %6ld\n", it->second, it->first);
        }
    }
    // insert strings for sorted-by-generation-order numbers
    for (std::map<int64_t, int64_t>::iterator it = randoms.find(n_sorted + 1); it != randoms.end(); it++)
    {
        out << QString::asprintf("%6ld   %6ld\n", it->first, it->second);
    }
}

void DialogSingleStageRandomNumbers::on_buttonBox_accepted()
{
    double seed = ui->doubleSpinBox_seed->value();
    int numbers = ui->spinBox_numbersToGenerate->value();
    int spares = ui->spinBox_spareNumbersToGenerate->value();
    int min = ui->spinBox_minimumValue->value();
    int max = ui->spinBox_maximumValue->value();
    std::map<int64_t, int64_t> randoms;

    // generate a random seed via the system clock
    if (seed == 0.00) {
        qsrand(QDateTime::currentMSecsSinceEpoch());
        seed = (double)qrand() / 10000;
    }
    WichmannHill rng(seed);

    // sanity check on requested values
    if (max - min + 1 < numbers + spares) {
        ST_ERRORBOX("Not enough unique values in your universe to generate that many numbers.");
        return;
    }

    // generate numbers and handle general RNG failure (return value < 0) just in case
    if (rng.generateNumbers(numbers + spares, min, max, randoms) < 0) {
        ST_ERRORBOX("The Wichmann-Hill RNG failed; please check the input values.");
        return;
    }

    // build output
    QStringList out;
    out << "<b><u><big><center>Random Numbers - Single Stage</center></big></u></b>" << "\n";
    out << "Audit: " << ui->lineEdit_auditName->text() << "\n";
    out << "Time: " << QDateTime::currentDateTime().toString() << "\n\n";
    out << "Seed: " << QString::asprintf("%f", seed) << "\n";
    out << "Frame size: " << QString::asprintf("%'ld", max - min + 1) << "\n";
    out << QString::asprintf("Sum of all %d random numbers: %'ld\n", numbers + spares, rng.sum(randoms));
    out << "<pre>";
    out << "Selection\n  Order   Value\n\n";
    insert_ratstats_compliant_number_list(randoms, out, numbers);
    out << "</pre>";

    emit displayHtml(out.join(""));
    //this->reject();
}

void DialogSingleStageRandomNumbers::accept()
{
    on_buttonBox_accepted();
}

