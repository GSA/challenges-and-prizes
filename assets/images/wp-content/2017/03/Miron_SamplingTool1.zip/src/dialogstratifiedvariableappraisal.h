#ifndef DIALOGSTRATIFIEDVARIABLEAPPRAISAL_H
#define DIALOGSTRATIFIEDVARIABLEAPPRAISAL_H

#include <QDialog>
#include "dialogunrestrictedvariableappraisal.h"
#include "ui_dialogunrestrictedvariableappraisal.h"

namespace Ui {
class DialogStratifiedVariableAppraisal;
}

class DialogStratifiedVariableAppraisal : public QDialog
{
    Q_OBJECT

public:
    explicit DialogStratifiedVariableAppraisal(QWidget *parent = 0);
    ~DialogStratifiedVariableAppraisal();

    void build_report(matrix_t &mat, QStringList &report, int universeSize);

signals:
    void displayHtml(QString str);
    void displayText(QString str);

private slots:
    void on_pushButton_openDataFile_clicked();

    void on_pushButton_openStrataFile_clicked();

    void on_buttonBox_accepted();

    void on_checkBox_enableStrataEditing_toggled(bool checked);

    void on_checkBox_enableDataEditing_toggled(bool checked);

private:
    Ui::DialogStratifiedVariableAppraisal *ui;
    DialogUnrestrictedVariableAppraisal *unres;
    QString strataFileName, dataFileName;
};

#endif // DIALOGSTRATIFIEDVARIABLEAPPRAISAL_H
