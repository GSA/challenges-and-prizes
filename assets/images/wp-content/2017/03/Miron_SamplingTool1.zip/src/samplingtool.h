#ifndef SAMPLINGTOOL_H
#define SAMPLINGTOOL_H

#include <QDebug>

#include "scythestat/stat.h"

#include <boost/math/distributions/students_t.hpp>
#include <boost/math/distributions/hypergeometric.hpp>
#include <boost/math/distributions/binomial.hpp>
#include <boost/math/policies/policy.hpp>
#include <math.h>

#include <QtXlsx/QtXlsx>
#include <QDropEvent>
#include <QMimeData>
#include <QRegExp>
#include <QMainWindow>
#include <QMessageBox>
#include <QFile>
#include <QFileDialog>
#include <QTextStream>
#include <QDateTime>
#include <QTextEdit>
#include <QString>
#include <QStringList>
#include <QTableView>
#include <QStandardItemModel>
#include <QStandardItem>


#define PROGRAM_TITLE QString("Sampling Tool")
#define PROGRAM_VERSION_MAJOR 1
#define PROGRAM_VERSION_MINOR 0
#define PROGRAM_VERSION_STRING (QString("v") + QString("%1").arg(PROGRAM_VERSION_MAJOR) + "." + QString("%1").arg(PROGRAM_VERSION_MINOR))
#define PROGRAM_STRING_FULL PROGRAM_TITLE + " " + PROGRAM_VERSION_STRING

#define ST_ERRORBOX(str) { QMessageBox errBox; errBox.setWindowTitle(PROGRAM_STRING_FULL); errBox.setText(str); errBox.exec(); }

typedef scythe::Matrix<double, scythe::Row, scythe::Concrete> matrix_t;


namespace Ui {
class SamplingTool;
}

class SamplingTool : public QMainWindow
{
    Q_OBJECT

public:
    explicit SamplingTool(QWidget *parent = 0);
    ~SamplingTool();
    static QString excelFileToPlainText(QString &fileName);
    static QString excelFileToPlainText(QXlsx::Document &excel);


public slots:
    void displayText(QString str);
    void displayHtml(QString str);


private slots:
    void on_actionSingle_Stage_Random_Number_triggered();
    void on_actionUnrestricted_Attribute_Appraisal_triggered();
    void on_pushButton_saveToFile_clicked();

    void on_pushButton_quit_clicked();

    void on_actionUnrestricted_Variable_Appraisal_triggered();

    void on_actionAbout_triggered();

    void on_actionStratified_Variable_Appraisal_triggered();

private:
    Ui::SamplingTool *ui;
    void setupDisplayArea();
};

#endif // SAMPLINGTOOL_H
