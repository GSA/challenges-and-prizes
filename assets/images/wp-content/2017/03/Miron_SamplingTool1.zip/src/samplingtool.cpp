#include "samplingtool.h"
#include "ui_samplingtool.h"
#include "dialogsinglestagerandomnumbers.h"
#include "dialogunrestrictedattributeappraisal.h"
#include "ui_dialogsinglestagerandomnumbers.h"
#include "dialogunrestrictedvariableappraisal.h"
#include "ui_dialogunrestrictedvariableappraisal.h"
#include "dialogstratifiedvariableappraisal.h"
#include "ui_dialogstratifiedvariableappraisal.h"


SamplingTool::SamplingTool(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::SamplingTool)
{
    ui->setupUi(this);
    ui->textEdit_outputArea->hide();
    ui->pushButton_saveToFile->setDisabled(true);
}

SamplingTool::~SamplingTool()
{
    delete ui;
}

void SamplingTool::setupDisplayArea()
{
    ui->textEdit_outputArea->show();
    ui->pushButton_saveToFile->setEnabled(true);
}

void SamplingTool::displayHtml(QString str)
{
    ui->textEdit_outputArea->setHtml(str.replace("\n", "<br/>"));
    setupDisplayArea();
}

void SamplingTool::displayText(QString str)
{
    ui->textEdit_outputArea->setText(str);
    setupDisplayArea();
}

QString SamplingTool::excelFileToPlainText(QString &fileName)
{
    QXlsx::Document excel(fileName);
    return excelFileToPlainText(excel);
}

QString SamplingTool::excelFileToPlainText(QXlsx::Document &excel)
{
    QStringList ret;
    QString row;

    for (int i = 1; excel.cellAt(i, 1) != 0; i++)
    {
        for (int j = 1; excel.cellAt(i, j) != 0; j++)
        {
            row.append(QString(" %1").arg(excel.read(i, j).toString()));
        }
        ret << row;
        row.clear();
    }
    return ret.join("\n");
}

void SamplingTool::on_actionSingle_Stage_Random_Number_triggered()
{
    DialogSingleStageRandomNumbers *dialog = new DialogSingleStageRandomNumbers(this);
    connect(dialog, SIGNAL(displayText(QString)), this, SLOT(displayText(QString)));
    connect(dialog, SIGNAL(displayHtml(QString)), this, SLOT(displayHtml(QString)));
    try {
        dialog->exec();
    } catch(std::exception &e) {
        qDebug() << e.what();
        ST_ERRORBOX("An unknown error occurred; please check your input values.");
    }
}

void SamplingTool::on_actionUnrestricted_Attribute_Appraisal_triggered()
{
    DialogUnrestrictedAttributeAppraisal *dialog = new DialogUnrestrictedAttributeAppraisal(this);
    connect(dialog, SIGNAL(displayText(QString)), this, SLOT(displayText(QString)));
    connect(dialog, SIGNAL(displayHtml(QString)), this, SLOT(displayHtml(QString)));
    try {
        dialog->exec();
    } catch(std::exception &e) {
        qDebug() << e.what();
        ST_ERRORBOX("An unknown error occurred; please check your input values.");
        return;
    }
}

void SamplingTool::on_pushButton_saveToFile_clicked()
{
    // Get file to save to
    QString filename = QFileDialog::getSaveFileName(this, tr("Select Output File"), ".", tr("*.txt"));
    if (filename.isEmpty())
        return;
    QFile file(filename);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        ST_ERRORBOX("Error opening file.");
        return;
    }
    QTextStream out(&file);
    out << PROGRAM_STRING_FULL << ": ";
    out << ui->textEdit_outputArea->toPlainText();
    file.close();

    ST_ERRORBOX("Saved to " + filename);
}

void SamplingTool::on_pushButton_quit_clicked()
{
    exit(0);
}

void SamplingTool::on_actionUnrestricted_Variable_Appraisal_triggered()
{
    DialogUnrestrictedVariableAppraisal *dialog = new DialogUnrestrictedVariableAppraisal(this);
    connect(dialog, SIGNAL(displayText(QString)), this, SLOT(displayText(QString)));
    connect(dialog, SIGNAL(displayHtml(QString)), this, SLOT(displayHtml(QString)));
    try {
        dialog->exec();
    } catch (std::exception &e) {
        qDebug() << e.what();
        ST_ERRORBOX("An unknown error occurred; please check your input values.");
        return;
    }
}

void SamplingTool::on_actionAbout_triggered()
{
    ST_ERRORBOX(PROGRAM_STRING_FULL + ", by Murray Miron.");
}

void SamplingTool::on_actionStratified_Variable_Appraisal_triggered()
{
    DialogStratifiedVariableAppraisal *dialog = new DialogStratifiedVariableAppraisal(this);
    connect(dialog, SIGNAL(displayText(QString)), this, SLOT(displayText(QString)));
    connect(dialog, SIGNAL(displayHtml(QString)), this, SLOT(displayHtml(QString)));
    try {
        dialog->exec();
    } catch (std::exception &e) {
        qDebug() << e.what();
        ST_ERRORBOX("An unknown error occurred; please check your input values.");
        return;
    }
}
