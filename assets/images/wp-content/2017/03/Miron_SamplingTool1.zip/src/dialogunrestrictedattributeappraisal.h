#ifndef DIALOGUNRESTRICTEDATTRIBUTEAPPRAISAL_H
#define DIALOGUNRESTRICTEDATTRIBUTEAPPRAISAL_H

#include <QDialog>

namespace Ui {
class DialogUnrestrictedAttributeAppraisal;
}

class DialogUnrestrictedAttributeAppraisal : public QDialog
{
    Q_OBJECT

public:
    explicit DialogUnrestrictedAttributeAppraisal(QWidget *parent = 0);
    ~DialogUnrestrictedAttributeAppraisal();

signals:
    void displayText(QString str);
    void displayHtml(QString str);

private slots:
    void on_buttonBox_accepted();

private:
    Ui::DialogUnrestrictedAttributeAppraisal *ui;
};

#endif // DIALOGUNRESTRICTEDATTRIBUTEAPPRAISAL_H
