#ifndef SHEETDATA_H
#define SHEETDATA_H
#include<string.h>
#include<vector>

#include "excelWrapper.h"


class CellContents {
 public:
  static int numIds;
  const char * cellReference;
  int row;
  int col;
  int id;
  const char * value;
  const char * dataType;

 private:
  CellContents( const CellContents &obj);  // make copy private
  
public:
  CellContents(const char* ref, const char * val, const char* data_t);
  CellContents(int row, int col, double value);  
  CellContents(const char* contents[3]);  
  ~CellContents();
  int Row();
  int Col();
  const char * Value();
  const char* DataType();
  const char* CellReference();
};


class SheetData{
  const char * sheetName;
  CellContents **cells;
  int numCells;
  int maxCells;
  int selectedSheet[3],selectedCol[3],selectedRow[3];
  char selectedCell[3][8];

  
 private:
  SheetData(const SheetData &obj); // make copy private 
public:
  SheetData(int numCells);
  ~SheetData();

  CellContents * AddCell(const char * contents[3]);
  CellContents * AddCell(int row, int col, double value);  
  CellContents ** Cells();
  const char* SheetName();
  void SetName(const char *);
};

#endif
