#ifndef EXCELDLG_H
#define EXCELDLG_H

#ifdef __cplusplus
extern "C" {
#endif

// Dialog procedure for our "Excel" dialog.
INT_PTR CALLBACK ExcelDialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam) 
#ifdef __cplusplus
}
#endif  

#endif
