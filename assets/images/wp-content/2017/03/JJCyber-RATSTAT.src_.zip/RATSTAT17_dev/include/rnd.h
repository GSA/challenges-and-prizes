/*********************************************************************************
*
* FILE: util.h
*
* COPYRIGHT (2017): J&J CyberSecurity LLC   http://www.jjcybersecurity.com
* All Rights Reserved 
* 
* Header File for rnd.cpp
*
*********************************************************************************/
#ifndef RATSTAT_RND_H
#define RATSTAT_RND_H

#include<cmath>
#include<cstring>
#include<cstdio>
#include<cstdint>
#include<cstdbool>
#include<cstdlib>
#include<ctime>

#ifdef __cplusplus
extern "C" {
#endif

#define TwoTo24 0x1000000
#define Eight0s "00000000"
#define Sixteen0s "0000000000000000"
#define TwentyFour0s "000000000000000000000000"
#define maxVars 4
#define maxHash 50000

typedef  struct returnHelp {
  uint64_t step;
  double excelOutput;
  double RATSTAT;
} returnHelp;

typedef struct randoms {
  int32_t index;
  uint32_t hashSum;
  int32_t values[maxVars];
  randoms * nextHash;
} randoms;

typedef struct rndResults {
  uint64_t frameSize;
  uint64_t sum;
  uint32_t count;
  double seed;
  wchar_t auditName[BUFSIZE];
  LPCWSTR fileName;
  uint32_t numSeq, numRnd,numVars;
  uint32_t lowRange[maxVars],hiRange[maxVars];
  randoms *randNum;

} RndResults;

  

  
returnHelp ExcelRand64(int64_t excelSeed, int64_t outputmax);
int32_t ExcelRandInit (float num);
int64_t ExcelRandomize64(double startingpoint, int64_t ExcelSeed);
  void genRnd(RndResults * res);
void qsortRandoms(randoms randNums[], uint32_t numEntries);

void RndShowResults(HWND hWnd, RndResults * results);
INT_PTR CALLBACK RndResultsProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);  

  
#ifdef __cplusplus
}
#endif
#endif
