/*********************************************************************************
*
* FILE: util.h
*
* COPYRIGHT (2017): J&J CyberSecurity LLC   http://www.jjcybersecurity.com
* All Rights Reserved 
* 
* Header File for var.cpp
*
*********************************************************************************/

#ifndef VAR_H
#define VAR_H

#define _USE_MATH_DEFINES
#define M_PI 3.14159265358979323846
#include<cmath>

#include<cstring>
#include<cstdio>
#include<cstdint>
#include<cstdbool>
#include<cstdlib>
#include<ctime>
#include "SheetData.h"
#include "resource.h"


typedef struct varResults {
  int64_t univ, samp, nonZero[3];
  int64_t fFormat;  //selection file format -- combination of AUDIT/EXAM/DIFF  
  double mean[3], stdDev[3], stdErr[3], skew[3], kurtosis[3];
  double pointEst[3], sums[3],sqrs[3],cubes[3],quads[3];

// values for Audit/DIFF/EXAM for 80% 90% and 95%  
  int64_t confLow[3][3], confHi[3][3];
  double precision[3][3];  
  double tVal[3];

  // where is data stored
  // Audit/DIFF/EXAM and Strat Univ and Strata Size data
  int64_t col[5], row[5], sheet[5], maxRow[5], minRow[5];  
  int64_t maxR,minR;
  int64_t id;
  double *sheetContents[5];  
  
} VarResults;

typedef struct selected {
  bool unrestricted;

  uint64_t numStrata,id;
  int64_t fFormat;  //selection file format -- combination of AUDIT/EXAM/DIFF

  wchar_t fileName[300];
  wchar_t auditName[300];
  SheetData ** sheetData;
  VarResults results[maxStrat];
  char cell[3][10];  
  // The following are all in results[0];
  /*int64_t nonZero[3],samp,univ;  

  double sums[3],stdDev[3], stdErr[3];
  double pointEst[3];
  int64_t confLow[3][3], confHi[3][3];
  double precision[3][3];
  */
} Selection;



bool IsExcelSpreadSheet(const wchar_t * fileName);
bool ProcessSpreadSheet(HWND hWnd, const wchar_t *fileName, Selection *selection);
const std::vector<std::vector<double>> GetTextInputContents(const wchar_t * fileName);
bool ProcessTextInput(HWND hWnd, const wchar_t * fileName, Selection *selection);
bool VarValidateBox(HWND hWnd, int id);

  
void ResetSelection(Selection *selection, int index, int strata);

void GetSums(Selection *selection);
void GetStrata(Selection *selection);
void SumResult(Selection *selection, VarResults *results);
void SumTotals(Selection *selection);
void CalculateStatistics(Selection *selection);

double FindCumProb(double tval, int df, double a, double b);
double Square(double val);
double Cube(double val);
void DetermineTVal(int df, double confidenceInterval, double *result);
void Process(Selection * selection);


void VarShowResults(HWND hwnd, Selection *selection, int64_t strat, int64_t id);
  
void ClearResults (VarResults *res);
void ClearSelection (Selection *sel);


bool IsExcelSpreadSheet(const wchar_t * fileName);
bool ProcessSpreadSheet(const wchar_t *fileName, Selection *selection);
const std::vector<std::vector<double>> GetTextInputContents(const wchar_t * fileName);
bool ProcessTextInput(const wchar_t * fileName, Selection *selection);


#ifdef __cplusplus
extern "C" {
#endif



#ifdef __cplusplus
}
#endif

#endif

