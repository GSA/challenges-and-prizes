/*********************************************************************************
*
* FILE: util.h
*
* COPYRIGHT (2017): J&J CyberSecurity LLC   http://www.jjcybersecurity.com
* All Rights Reserved 
* 
* Header File for winUtil.cpp
*
*********************************************************************************/
#ifndef WINUTIL_H
#define WINUTIL_H

#include<windows.h>
#include<windowsx.h>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<cstdint>
#include<cstdbool>
#include<cstddef>  

#include<string>
#include<sstream>
#include<iostream>

#include <Shobjidl.h>
#include <Objbase.h>
#include <knownfolders.h> // for KnownFolder APIs/datatypes/function headers
#include <propvarutil.h>  // for PROPVAR-related functions
#include <propkey.h>      // for the Property key APIs/datatypes
#include <propidl.h>      // for the Property System APIs
#include <shtypes.h>      // for COMDLG_FILTERSPEC
#include <vector>

#include "resource.h"
#include <Commctrl.h>
#define noop

#ifdef __cplusplus
extern "C" {
#endif

   
void SetDialogFocus(HWND hdlg, HWND hwndControl);
void ClearChildWindow(HWND hCtrl);
void ClearDialog(HWND hWnd);
int CALLBACK ClearChildWindowCallBack(HWND hCtrl, LPARAM lparam);
  
void BalloonTip(HWND hCtrl, LPCWSTR ttiel, LPCWSTR pszText, int Icon);
void BalloonWarning(HWND hCtrl, LPCWSTR pszText);
void BalloonError(HWND hCtrl, LPCWSTR pszText);
void BalloonNotice(HWND hCtrl, LPCWSTR pszText);
void BalloonPlain(HWND hCtrl, LPCWSTR pszText);
void showWarning(HWND hWnd, int id, LPCWSTR pszText);
void hideWarning(HWND hWnd, int id);


typedef struct toolTipInit {
  int id;
  LPWSTR text;
  HWND ptrToolTip;
} TOOLTIPINIT;

  
HWND CreateToolTip(int toolID, HWND hDlg, LPWSTR pszText);
  void HideMyToolTip(TOOLTIPINIT *toolTips, int id);
  
extern "C" bool SaveFileDialog(wchar_t * strFile,
			       size_t maxSize,
			       wchar_t const * strTitle,
			       std::vector<std::wstring> astrFilter,
			       std::vector<std::wstring> astrFilterExtension,
			       LONG nFlags,
			       HWND hParentWnd);

extern "C" bool myOpenFileDialog(wchar_t * strFile,
			   size_t maxSize,
			   wchar_t const * strTitle,
			   std::vector<std::wstring> astrFilter,
			   std::vector<std::wstring> astrFilterExtension,
			   LONG nFlags,
			   HWND hParentWnd);
  
bool c_SaveFileDialog(wchar_t *strFile,size_t maxChars, wchar_t const * strTitle,
		      wchar_t const * astrFilter[], long astrFilterCnt,
		      wchar_t const * astrFilterExtension[], long astrFilterExtCnt,
		      LONG nFlags, HWND hParentWnd);
  
bool c_OpenFileDialog(wchar_t *strFile,size_t maxChars, wchar_t const * strTitle,
		      wchar_t const * astrFilter[], long astrFilterCnt,
		      wchar_t const * astrFilterExtension[], long astrFilterExtCnt,
		      LONG nFlags, HWND hParentWnd);


  bool ValidateInt(HWND hWnd);
bool ValidateNonNegInt(HWND hWnd);
bool ValidateFloat(HWND hWnd);
bool ValidateNonNegFloat(HWND hWnd);
bool ValidateDouble(HWND hWnd);
bool ValidateNonNegDouble(HWND hWnd);  
bool ValidateBox(HWND hWnd, int id);
  bool ValidateDialogSave(HWND hWnd, int *optList);
  
bool Get32Int(HWND hWnd, int32_t* res);
bool GetNonNeg32Int(HWND hWnd, uint32_t* res);
bool GetInt(HWND hWnd, int64_t* res);
bool GetNonNegInt(HWND hWnd, uint64_t* res);  
bool GetFloat(HWND hWnd, float * res);
bool GetNonNegFloat(HWND hWnd, float * res);  
bool GetDouble(HWND hWnd,double * res);
bool GetNonNegDouble(HWND hWnd,double * res);  
bool GetBoxValue(HWND hWnd, int id, void * value);  

  // Child Window Recovery Functions
HWND GetSplash();
  
#ifdef __cplusplus
}
#endif  
extern HINSTANCE g_hInst;
  

#endif
