#ifndef PRINTTEXT_H
#define PRINTTEXT_H

#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include "rnd.h"
#include"var.h"
#include"attr.h"
#ifdef __cplusplus
extern "C" {
#endif

  bool RndPrintText(LPCWSTR fileName,RndResults * res);
  bool RndPrintXlsx(LPCWSTR fileName,RndResults * res);

  void AttrPrintText(LPCWSTR fileName,AttrResults * res);

  void VarAnalysisPrintText(LPCWSTR fileName, Selection *selection);
  void VarAnalysisPrintXlsx(LPCWSTR fileName, Selection *selection);  


  void Center(FILE *fn,size_t width, wchar_t const * str);


  
  void SCenter(wchar_t * res, size_t width, wchar_t const * str);
  void SCenterAscii(char * res, size_t width, char const * str);    

  void PrintCommaHelper(FILE *fn,
			int64_t num, bool greaterThan1000, bool fullWidth);
  void PrintComma(FILE *fn, int64_t num);
  void PrintDblComma(FILE *fn, double num, int precision);  

  void SPrintCommaHelper(wchar_t *buff,
		       int64_t num, bool greaterThan1000, bool fullWidth);
  void SPrintComma(wchar_t *buff, int64_t num);
  void SPrintDblComma(wchar_t *buff, double num, int precision);  
  
  void SPrintCommaAsciiHelper(char *buff,
		       int64_t num, bool greaterThan1000, bool fullWidth);  
  void SPrintCommaAscii(char *buff, int64_t num);
  



#ifdef __cplusplus
}
#endif
#endif
