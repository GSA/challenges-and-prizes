//*************************************************************************************
// file: resource.h
//
// Copyright (2017) J&J Cyber Security LLC
// All rights reserved
//
//
// Resource Identifier Definitions for RATSTAT17
//    used by resource.rc and resource compiler to generate linkable binary of GUI resources
//    also used by control software to reference GUI resources
//
// resource definition script follows format specified in MSDN guide :
//    https://msdn.microsoft.com/en-us/library/aa380599(v=vs.85).aspx
//
// except the identifiers in this file use equations, therefore must use GNU windres
//    http://www.cs.colorado.edu/~main/cs1300/doc/gnu/binutils_13.html
//
//************************************************************************************


#ifndef RESOURCE_H
#define RESOURCE_H

#ifdef __cplusplus
extern "C" {
#endif

  //Constants and limits for application
#define maxStrat 100
  
#define EXAM 0
#define AUDIT 1  
#define DIFF 2
#define STRAT_UNIV 3
#define STRAT_SIZE 4

  // Constants for input data file contents
#define FAUDIT 0x001
#define FEXAM  0x010
#define FDIFF  0x100
#define FAUDITEXAM (FAUDIT|FEXAM)
#define FAUDITDIFF (FAUDIT|FDIFF)
#define FDIFFEXAM  (FDIFF|FEXAM)
#define FALL (FEXAM|FAUDIT|FDIFF)


  // Constants for Maximimums

#define BUFSIZE 300

#define MAXSTRAT 100

  
// screen size
#define wXMin 700
#define wYMin 500  
  
// use hex numbers to simplify pattern matching when needed
//  --  IS_<class> is true if  ID & IS_<class> == IS_<class>
//      or ID & 0xf000 (ID_CLASS_MASK)  == IS_<class>
//
//      We use IS_<class> to detemine class membership
//      for example IS_IMAGE or IS_DIALOG or IS_EDIT
//  
//
//  --  Then can also use subclasses
//  --   IS_<subclass> is true if ID & IS_<subclass> == IS_<subclass>
//      or ID & 0xff00(ID_MASK)  == IS_<subclass>
//
//  items in subclass are create sequentially
//  We use parens with qualtions to be safe 

#define ID_CLASS_MASK                   0xf000
#define ID_MASK                         0xff00  
#define ID_ITEM_MASK                    0x00ff
  
// image resource identifiers 0x1000+
#define IS_IMAGE                        0x1000 
#define IDI_APPICON                     (IS_IMAGE + 1)
#define IDI_APPICON_SM                  (IS_IMAGE + 2)
#define IDI_APPBMP                      (IS_IMAGE + 3)
#define IDI_WARNING1                    (IS_IMAGE + 4)
#define IDI_BLANK                       (IS_IMAGE + 5)
#define IDI_WARN_BMP                    (IS_IMAGE + 6)
#define IDI_BLANK_BMP                   (IS_IMAGE + 7)    

  
  
// accelerators 0x2000+
#define IS_ACCELERATOR                  0x2000
#define IDR_ACCELERATOR                 (IS_ACCELERATOR + 1)

//pop-up dialogs 0x3000+
#define IS_DIALOG                       0x3000
#define IDD_ABOUT_DIALOG                (IS_DIALOG + 1)
#define IDD_EXCELVAR_DIALOG             (IS_DIALOG + 2)
#define IDD_TEXTVAR_DIALOG              (IS_DIALOG + 4)
#define IDD_RND_RESULTS                 (IS_DIALOG + 5)  
#define IDD_VAR_ANALYSIS_RESULTS        (IS_DIALOG + 6)
#define IDD_ATTR_APPRAISAL_RESULTS      (IS_DIALOG + 7)      

//edit text boxes 0x4000+
#define IS_EDIT                         0x4000

//icons to display by edit box (for warnings/errors/etc)
#define IS_WARN                         0x5000

// define subclasses of EDIT (we will allow up to 255  unique boxes of each type)
// We could probably have reuse on each separate dialog box, but we decided that
// for the RATSTATS application, this would be sufficient. Having unique ids for
// every object in the system helps with software integrity.

#define IS_INTEGER                      (IS_EDIT | 0x0100)
#define IS_INTEGER_WARN                 (IS_WARN | 0x0100)
#define IS_NONNEG_INT                   (IS_EDIT | 0x0200)
#define IS_NONNEG_INT_WARN              (IS_WARN | 0x0200)  
#define IS_FLOAT                        (IS_EDIT | 0x0300)
#define IS_FLOAT_WARN                   (IS_WARN | 0x0300)  
#define IS_NONNEG_FLOAT                 (IS_EDIT | 0x0400)
#define IS_NONNEG_FLOAT_WARN            (IS_WARN | 0x0400)
#define IS_DOUBLE                       (IS_EDIT | 0x0500)
#define IS_DOUBLE_WARN                  (IS_WARN | 0x0500)  
#define IS_NONNEG_DOUBLE                (IS_EDIT | 0x0600)
#define IS_NONNEG_DOUBLE_WARN           (IS_WARN | 0x0600)      
#define IS_TEXT                         (IS_EDIT | 0x0700)
#define IS_TEXT_WARN                    (IS_WARN | 0x0700)
#define IS_READONLY                     (IS_EDIT | 0x0A00)


 // define the different text boxes (up to 255 of them)
#define IDT_AUDIT_NAME                  (IS_TEXT + 1)
#define IDT_AUDIT_NAME_WARN             (IS_TEXT_WARN + 1)  
#define IDT_FILE_NAME                   (IS_TEXT + 2)
#define IDT_FILE_NAME_WARN              (IS_TEXT_WARN + 2)


  
  // we will reserve 3* these 
#define IDT_EXCEL_CELL                  (IS_TEXT+0x10) 
#define IDT_EXCEL_AUDIT_CELL            (IDT_EXCEL_CELL+AUDIT)   // +10 to +14
#define IDT_EXCEL_EXAM_CELL             (IDT_EXCEL_CELL+EXAM)
#define IDT_EXCEL_DIFF_CELL             (IDT_EXCEL_CELL+DIFF)
#define IS_EXCEL_STRAT_CELL             (IDT_EXCEL_CELL+STRAT_UNIV)  
#define IDT_EXCEL_STRAT_UNIV_CELL       (IDT_EXCEL_CELL+STRAT_UNIV)
#define IDT_EXCEL_STRAT_SIZE_CELL       (IDT_EXCEL_CELL+STRAT_SIZE)  

  
#define IDT_EXCEL_SHEET                 (IS_TEXT+0x20)  // +0x20 to +0x24
#define IDT_EXCEL_AUDIT_SHEET           (IDT_EXCEL_SHEET+AUDIT)
#define IDT_EXCEL_EXAM_SHEET            (IDT_EXCEL_SHEET+EXAM)
#define IDT_EXCEL_DIFF_SHEET            (IDT_EXCEL_SHEET+DIFF)
#define IS_EXCEL_STRAT_SHEET            (IDT_EXCEL_SHEET+STRAT_UNIV)  
#define IDT_EXCEL_STRAT_UNIV_SHEET      (IDT_EXCEL_SHEET+STRAT_UNIV)
#define IDT_EXCEL_STRAT_SIZE_SHEET      (IDT_EXCEL_SHEET+STRAT_SIZE)  
  

#define IDT_SUM                         (IS_TEXT + 0x30) 
#define IDT_SUM_AUDIT                   (IDT_SUM + AUDIT) // +30 to +32
#define IDT_SUM_EXAM                    (IDT_SUM + EXAM)
#define IDT_SUM_DIFF                    (IDT_SUM + DIFF)     

#define IDT_NONZERO_DIFF                (IS_TEXT + 0x40)  

#define IDT_QUANT                       (IS_TEXT + 0x41)
#define IDT_PROJ                        (IS_TEXT + 0x42)
#define IDT_PERCENT                     (IS_TEXT + 0x43)


// here we duplcate base numbers for separate screens
  
  // More boxes  
#define IDT_FILENAME                    (IS_TEXT +0x50)

#define IDT_DATE                        (IS_TEXT +0x51)
#define IDT_TIME                        (IS_TEXT +0x52)
#define IDT_MEAN                        (IS_TEXT +0x53)
#define IDT_SKEW                        (IS_TEXT +0x54)
#define IDT_STDDEV                      (IS_TEXT +0x55)
#define IDT_KURT                        (IS_TEXT +0x56)
#define IDT_STDERR_MEAN                 (IS_TEXT +0x57)
#define IDT_STDERR_TOT                  (IS_TEXT +0x58)
#define IDT_POINT_EST                   (IS_TEXT +0x59)
#define IDT_NON_ZERO                    (IS_TEXT +0x5A)      


  // Variable Analysis   && Some Attribute Appraisal
  // we will reserve 3* these   
#define EIGHTY 0
#define NINETY 1
#define NINETYFIVE 2  
#define IS_CONF_LOW                     (IS_TEXT+0x60)
#define IDT_CONF_LOW_80                 (IS_CONF_LOW+EIGHTY)
#define IDT_CONF_LOW_90                 (IS_CONF_LOW+NINETY)
#define IDT_CONF_LOW_95                 (IS_CONF_LOW+NINETYFIVE)

#define IS_CONF_HI                      (IS_TEXT+0x70)
#define IDT_CONF_HI_80                  (IS_CONF_HI+EIGHTY)
#define IDT_CONF_HI_90                  (IS_CONF_HI+NINETY)
#define IDT_CONF_HI_95                  (IS_CONF_HI+NINETYFIVE)        

#define IS_PREC                         (IS_TEXT+0x80)
#define IDT_PREC_80                     (IS_PREC+EIGHTY)
#define IDT_PREC_90                     (IS_PREC+NINETY)
#define IDT_PREC_95                     (IS_PREC+NINETYFIVE)

#define IS_PREC_PER                     (IS_TEXT+0x90)
#define IDT_PREC_PER_80                 (IS_PREC_PER+EIGHTY)
#define IDT_PREC_PER_90                 (IS_PREC_PER+NINETY)
#define IDT_PREC_PER_95                 (IS_PREC_PER+NINETYFIVE)        

#define IS_TVAL                         (IS_TEXT+0xA0)
#define IDT_TVAL_80                     (IS_TVAL+EIGHTY)
#define IDT_TVAL_90                     (IS_TVAL+NINETY)
#define IDT_TVAL_95                     (IS_TVAL+NINETYFIVE)

#define IS_LOW_PER                      (IS_TEXT+0x80)
#define IDT_LOW_PER_80                  (IS_LOW_PER+EIGHTY)
#define IDT_LOW_PER_90                  (IS_LOW_PER+NINETY)
#define IDT_LOW_PER_95                  (IS_LOW_PER+NINETYFIVE)

#define IS_HI_PER                       (IS_TEXT+0x90)
#define IDT_HI_PER_80                   (IS_HI_PER+EIGHTY)
#define IDT_HI_PER_90                   (IS_HI_PER+NINETY)
#define IDT_HI_PER_95                   (IS_HI_PER+NINETYFIVE)        

  
  
// define the non-negative integer boxes (up to 255 of them)

// For Random Number Screen
#define IDT_LOW1                        (IS_NONNEG_INT +1)
#define IDT_LOW1_WARN                   (IS_NONNEG_INT_WARN +1)  
#define IDT_LOW2                        (IS_NONNEG_INT +2)
#define IDT_LOW2_WARN                   (IS_NONNEG_INT_WARN +2)
#define IDT_LOW3                        (IS_NONNEG_INT +3)
#define IDT_LOW3_WARN                   (IS_NONNEG_INT_WARN +3)  
#define IDT_LOW4                        (IS_NONNEG_INT +4)
#define IDT_LOW4_WARN                   (IS_NONNEG_INT_WARN +4)
  
#define IDT_HI1                         (IS_NONNEG_INT +5)
#define IDT_HI1_WARN                    (IS_NONNEG_INT_WARN +5)  
#define IDT_HI2                         (IS_NONNEG_INT +6)
#define IDT_HI2_WARN                    (IS_NONNEG_INT_WARN +6)  
#define IDT_HI3                         (IS_NONNEG_INT +7)
#define IDT_HI3_WARN                    (IS_NONNEG_INT_WARN +7)
#define IDT_HI4                         (IS_NONNEG_INT +8)
#define IDT_HI4_WARN                    (IS_NONNEG_INT_WARN +8)
  
#define IDT_NUMSEQ                      (IS_NONNEG_INT +9)
#define IDT_NUMSEQ_WARN                 (IS_NONNEG_INT_WARN +9)  
#define IDT_NUMRND                      (IS_NONNEG_INT +10)
#define IDT_NUMRND_WARN                 (IS_NONNEG_INT_WARN +10)

// define the different non neg double boxes (up to 255 of them)
#define IDT_SEED                        (IS_NONNEG_DOUBLE +1)
#define IDT_SEED_WARN                   (IS_NONNEG_DOUBLE_WARN +1)


// For Attribute Screen
#define IDT_UNIV                        (IS_NONNEG_INT +20)
#define IDT_UNIV_WARN                   (IS_NONNEG_INT_WARN +20)
#define IDT_SAMP                        (IS_NONNEG_INT +21)
#define IDT_SAMP_WARN                   (IS_NONNEG_INT_WARN +21)
#define IDT_INTEREST                    (IS_NONNEG_INT +22)
#define IDT_INTEREST_WARN               (IS_NONNEG_INT_WARN +22)      
#define IDT_STRATA                      (IS_NONNEG_INT +23)
#define IDT_STRATA_WARN                 (IS_NONNEG_INT_WARN +22)      
//Define the READ ONLY text boxes

  
// buttons 0x6000+
 
#define IS_BUTTON                       0x6000  
#define IDB_MAIN_BUTTON                 (IS_BUTTON + 1)
#define IDB_BROWSE_BUTTON               (IS_BUTTON + 2)
#define IDB_CLEAR                       (IS_BUTTON + 3)
#define IDB_PRINT                       (IS_BUTTON + 4)
#define IDB_SAVE                        (IS_BUTTON + 5)     
#define IDB_SELECT                      (IS_BUTTON + 6)
#define IDB_DONE                        (IS_BUTTON + 7)
#define IDB_VIEW                        (IS_BUTTON + 8)
#define IDB_MORE                        (IS_BUTTON + 9)
#define IDB_NEXT_STRATA                 (IS_BUTTON + 10)
#define IDB_PREV_STRATA                 (IS_BUTTON + 11)
#define IDB_OVERALL                     (IS_BUTTON + 12)
#define IDB_EXIT                        (IS_BUTTON + 13)
  
//  menus 0x7000+
#define IS_MENU                         0x7000

// define groups of menus (subclasses)
#define IS_TOP_MENU                     (IS_MENU | 0x0100)    
#define IS_RND_MENU                     (IS_MENU | 0x0200)
#define IS_ATTR_MENU                    (IS_MENU | 0x0300)
#define IS_VAR_MENU                     (IS_MENU | 0x0400)
#define IS_SAMP_MENU                    (IS_MENU | 0x0500)
#define IS_HELP_MENU                    (IS_MENU | 0x0F00)
  
#define ID_MAINMENU                     (IS_TOP_MENU + 1)

// Random Number Generation menu items
#define ID_RND_ONE                      (IS_RND_MENU +1)
#define ID_RND_TWO                      (IS_RND_MENU +2)
#define ID_RND_THREE                    (IS_RND_MENU +3)
#define ID_RND_FOUR                     (IS_RND_MENU +4)

// Attribute Appraisal Menu items

#define ID_ATTR_UNRES                   (IS_ATTR_MENU +1)
#define ID_ATTR_STRAT                   (IS_ATTR_MENU +2)
#define ID_ATTR_2_STAGE_UNRES           (IS_ATTR_MENU +3)
#define ID_ATTR_3_STAGE_UNRES           (IS_ATTR_MENU +4)
#define ID_ATTR_2_STAGE_RHC             (IS_ATTR_MENU +5)
#define ID_ATTR_3_STAGE_RHC             (IS_ATTR_MENU +6)
#define ID_ATTR_STRAT_CLUST             (IS_ATTR_MENU +7)
#define ID_ATTR_STRAT_MULTI             (IS_ATTR_MENU +8)

// Variable Appraisal Menu items
#define ID_VAR_UNRES                    (IS_VAR_MENU +1)
#define ID_VAR_STRAT                    (IS_VAR_MENU +2)
#define ID_VAR_2_STAGE_UNRES            (IS_VAR_MENU +3)
#define ID_VAR_3_STAGE_UNRES            (IS_VAR_MENU +4)
#define ID_VAR_2_STAGE_RHC              (IS_VAR_MENU +5)
#define ID_VAR_3_STAGE_RHC              (IS_VAR_MENU +6)
#define ID_VAR_STRAT_CLUST              (IS_VAR_MENU +7)
#define ID_VAR_STRAT_MULTI              (IS_VAR_MENU +8)
#define ID_VAR_POST_STRAT               (IS_VAR_MENU +9)
#define ID_VAR_UNKNOWN_UNIV             (IS_VAR_MENU +10)

// Sample Size determination menu items
#define ID_SAMP_SIZE_PROBE              (IS_SAMP_MENU +1)
#define ID_SAMP_SIZE_EST                (IS_SAMP_MENU +2)
#define ID_SAMP_SIZE_STRAT              (IS_SAMP_MENU +3)
#define ID_SAMP_SIZE_ATTR               (IS_SAMP_MENU +4)

// Help menu items
#define ID_HELP_TOPICS                  (IS_HELP_MENU +1)
#define ID_HELP_ABOUT                   (IS_HELP_MENU +2)


// use 0x8000 for check boxes
#define IS_CHECKBOX                      0x8000  
#define IS_VAR_CHECKBOX            (IS_CHECKBOX | 0x0100)


  // variable analysis check boxes
#define IS_VAR_CHK                    (IS_VAR_CHECKBOX + 0x10)  // +10 to +14
#define ID_VAR_AUDIT_CHK              (IS_VAR_CHK+AUDIT)
#define ID_VAR_EXAM_CHK               (IS_VAR_CHK+EXAM)
#define ID_VAR_DIFF_CHK               (IS_VAR_CHK+DIFF)
#define IS_VAR_STRAT_CHK              (IS_VAR_CHK+STRAT_UNIV)  
#define ID_VAR_STRAT_UNIV_CHK         (IS_VAR_CHK+STRAT_UNIV)
#define ID_VAR_STRAT_SIZE_CHK         (IS_VAR_CHK+STRAT_SIZE)    
  
// use 0xF000 for list boxes
#define IS_LISTBOX                      0xF000
#define ID_EXCEL_SHEET_LIST             (IS_LISTBOX +1)
#define ID_EXCEL_CONTENTS               (IS_LISTBOX +2)
  
  
//  use 0xA000 for windows


#define ID_WINDOW                       0xA000
#define IDW_SPLASH                      (ID_WINDOW + 1)
#define IDW_RND                         (ID_WINDOW + 2)
#define IDW_UNRES_ATTR                  (ID_WINDOW + 3)
#define IDW_VAR_SUMMARY                 (ID_WINDOW + 4)
#define IDW_STRAT_VAR                   (ID_WINDOW + 5)  
#define IDW_SAMP                        (ID_WINDOW + 6)  


  // use 0xF000 + to specify static controls that may need to be shown or hidden
// (optionally visible)
#define IS_OPT_STATIC                   0xF000
  
#define ID_STATIC_VAR1                  (IS_OPT_STATIC + 1)
#define ID_STATIC_VAR2                  (IS_OPT_STATIC + 2)
#define ID_STATIC_VAR3                  (IS_OPT_STATIC + 3)
#define ID_STATIC_VAR4                  (IS_OPT_STATIC + 4)
#define ID_STATIC_TITLE1                (IS_OPT_STATIC + 5)
#define ID_STATIC_TITLE2                (IS_OPT_STATIC + 6)
#define ID_STATIC_TITLE3                (IS_OPT_STATIC + 7)
#define ID_STATIC_TITLE4                (IS_OPT_STATIC + 8)
#define ID_STATIC_TITLE5                (IS_OPT_STATIC + 9)
#define ID_STATIC_DATATYPE              (IS_OPT_STATIC + 10)
#define ID_STATIC_STRATUM               (IS_OPT_STATIC + 11)
#define ID_STATIC_STRAT                 (IS_OPT_STATIC + 12)  
#define ID_STATIC_STRAT_UNIV            (IS_OPT_STATIC + 12)
#define ID_STATIC_STRAT_SIZES           (IS_OPT_STATIC + 13)    
  
#define ID_MSG                          (IS_OPT_STATIC + 20)




  
#ifndef IDC_STATIC
  #define IDC_STATIC                   -1
#endif


#define DATABOX WS_BORDER|WS_DISABLED|ES_READONLY|ES_CENTER
  
#ifdef __cplusplus
}
#endif
#endif
  
