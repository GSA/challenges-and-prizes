/*********************************************************************************
*
* FILE: function.h
*
* COPYRIGHT (2017): J&J CyberSecurity LLC   http://www.jjcybersecurity.com
* All Rights Reserved 
* 
* Header File for callback functions  -- the *UI.cpp 
*
*********************************************************************************/

#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <windows.h>
#include <vector>
#include <ctime>
#include <chrono>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct childWndStruct {
  LPCWSTR name;            // Searchable unique name for child window
  HWND hWnd, parentWnd;    // handles for current window and parent 
  HINSTANCE hInstance;     // specific window instance
  WNDPROC callBack;        // callBack routine
  int id;                  // unique integer identifier for window
} childWndStruct;


// For individual menu options that open a new screen
INT_PTR CALLBACK RndCallbackProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
void CreateRndWindow(HINSTANCE hInstance, HWND hWnd, int numVars);
bool RndValidateBox(HWND hWnd, int id);
  
INT_PTR CALLBACK UnresAttrCallbackProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
void CreateUnresAttrWindow(HINSTANCE hInstance, HWND hWnd);
bool UnresAttrValidateBox(HWND hWnd, int id);
  
INT_PTR CALLBACK VarCallbackProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);  
void CreateStratVarWindow(HINSTANCE hInstance, HWND hWnd);
void CreateUnresVarWindow(HINSTANCE hInstance, HWND hWnd);
bool VarValidateBox(HWND hWnd, int id);
 
INT_PTR CALLBACK SampSizeCallbackProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);  


// Dialog procedure for our "Excel" dialog.
INT_PTR CALLBACK ExcelDialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK TextInputDialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK VarResultsProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK VarCallbackProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

 
// Utilities
void SetActiveChildWnd(HWND child);
HWND GetActiveChildWnd();

  
#ifdef __cplusplus
}
#endif  
#endif


  
