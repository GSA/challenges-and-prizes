#include "util.h"
#include "resource.h"
#include "functions.h"
#include "printText.h"
#include <sys/time.h>

bool validateAttrSave(HWND hWnd) {
  // tab through all controls -- are they non-empty except for possible seed?
  bool result = true;
  HWND hCtrl = GetNextDlgGroupItem(hWnd,NULL,false);
  hCtrl=GetNextDlgTabItem(hWnd,hCtrl,false);
  int firstId = GetDlgCtrlID(hCtrl);
  int id = firstId;
  do
    {
      if((id & ID_CLASS_MASK) == IS_EDIT) {
	wchar_t resStr[10];
	int hr = Edit_GetText(hCtrl,resStr,10);
	if(hr == 0) {
	  wchar_t msg[80];
	  wsprintf(msg,L"Save failed on ID %x :: %s",id,resStr);
	  DebugString(msg);
	  result=false;
	}
      }
      hCtrl=GetNextDlgTabItem(hWnd,hCtrl,false);
      id =  GetDlgCtrlID(hCtrl);
    } while (result && id != firstId);
  return result;
}

	    
uint32_t numVars;
INT_PTR CALLBACK AttrCallbackProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
  static bool enableSave = false;
  bool result = false;
  switch (uMsg) {
  case WM_COMMAND: {
    switch (HIWORD (wParam))
      {
      case EN_UPDATE:
      case EN_SETFOCUS:	{
        int id = LOWORD(wParam);	 	  
	validateBox(hWnd,id);
	result= false;
	break;
      }

      case EN_KILLFOCUS: {
	enableSave=validateAttrSave(hWnd);
	// Should Focus go to Save?
	if(enableSave) {
	  HWND hSaveCtrl = GetDlgItem(hWnd,IDB_SAVE);	  
	  if(hSaveCtrl != NULL) {
	    Button_Enable(hSaveCtrl, enableSave);
	  }
	  int id = LOWORD(wParam);	  
	  HWND hCtrl = GetDlgItem(hWnd,id);
	  HWND hNextCtrl=GetNextDlgTabItem(hWnd,hCtrl,false);
	  int nextId = GetDlgCtrlID(hNextCtrl);
	  if(nextId == IDB_CLEAR) {
	    DebugString(L"Change focus from Clear to Save");
	    SetDialogFocus(hWnd,hSaveCtrl);
	  } else if (nextId == IDB_SAVE) {
	    DebugString(L"Change focus from Save to Save");	   
	   SetDialogFocus(hWnd,hSaveCtrl);
	   break;
	 }
	}
	result= false;
	break;
      }	
	
      default:  {
	switch (LOWORD(wParam))
	  {
	  case IDB_CLEAR: {
	    ClearDialog(hWnd);
	    enableSave=validateRndSave(hWnd);	    
	    result = false;
	    break;
	  }
	  case IDB_SAVE: {
	    if(!validateRndSave(hWnd)) {
	      //	      HWND hCtrl = GetDlgItem(hWnd,IDB_SAVE);
	      DebugString(L"Failed to save");
	      MessageBox(hWnd,L"At least one field is incomplete or incorrect",L"Warning",
			 MB_OK |MB_ICONWARNING );
	      result = false;
	      break;
	    }
	    
	    wchar_t auditName[100];
	    uint32_t univSize,sampSize,numItems;
	    wchar_t fileName[300];
	    int hr;
	    wchar_t resStr[80];
	    HWND hCtrl;
	    //Get values from all dialogs -- could probably be more efficient
	    //	    DebugString(L"Getting Save Stuff");
	    hCtrl = GetDlgItem(hWnd,IDT_AUDIT_NAME);	    
	    hr = Edit_GetText(hCtrl,auditName,80);
	    if(!SUCCEEDED(hr)) {
	      result = false;
	      break;
	    }
	    
	    hCtrl = GetDlgItem(hWnd,IDT_UNIV);	    
	    hr = Edit_GetText(hCtrl,resStr,80);
	    result=isNonNeg(resStr,&univSize);
	    if(!SUCCEEDED(hr) || !result){
	      result = false;
	      break;
	    }

	    hCtrl = GetDlgItem(hWnd,IDT_SAMP);	    
	    hr = Edit_GetText(hCtrl,resStr,80);
	    result=isNonNeg(resStr,&sampSize);
	    if(!SUCCEEDED(hr) || !result){
	      result = false;
	      break;
	    }

	    hCtrl = GetDlgItem(hWnd,IDT_ITEMS);
	    hr = Edit_GetText(hCtrl,resStr,80);
	    result=isNonNeg(resStr,&numItems);
	    if(!SUCCEEDED(hr) || !result){
	      result = false;
	      break;
	    }

	    // get File Name
	    wchar_t const * arr1[2]={L"Text Files"};
	    wchar_t const * arr2[2]={L"*.txt"};
	    wchar_t const title[200]=L"Enter Name of .TXT Save File";
	    if (c_OpenFileDialog(fileName,200,title,arr1,1,arr2,1,
				 FOS_STRICTFILETYPES,hWnd)) {
	      wchar_t const defExt[] = L".txt";
	      int extLen=wcslen(defExt);
	      int fnameLen=wcslen(fileName);
	      if((fnameLen < extLen) || (wcsncmp(fileName+fnameLen-extLen,defExt,extLen)!=0)) {
		wcsncat(fileName,defExt,200-fnameLen);
	      }
	    } else {
	      result = false;
	      break;
	    }
	    
	    DebugString(L"Got ALL Save Stuff");	    
	    genRnd(seed, numSeq,numRnd,lowRange,hiRange,numVars,randNums);
	    uint64_t frameSize =1;
	    for (uint32_t i=0;i<numVars;i++) {
	      frameSize = frameSize*(hiRange[i]-lowRange[i]+1);
	    }
	    DebugString(L"Call Print");  	    
	    printText(auditName, seed, frameSize,
		      fileName, numVars, numSeq+numRnd, randNums);
	    DebugString(L"Done Print");  	    	    
	    free(randNums);
	    break;
	  }	    
	  case IDCANCEL: {
	    EndDialog(hWnd, (INT_PTR) LOWORD(wParam));
	    setActiveChildWnd(getSplash());
	    ShowWindow(getActiveChildWnd(),SW_SHOW);	      	      
	    result = true;
	    break;
	  }
	  }
	    
	break;
      }
      }
    
    break;
  }
    
  case WM_INITDIALOG: {
    SetFocus(hWnd);
    result = false;
  }
  }

  HWND hCtrl = GetDlgItem(hWnd,IDB_SAVE);  
  //  if(hCtrl != NULL) {
  //  Button_Enable(hCtrl, enableSave);
  //}
  
  return (INT_PTR) result;
}
