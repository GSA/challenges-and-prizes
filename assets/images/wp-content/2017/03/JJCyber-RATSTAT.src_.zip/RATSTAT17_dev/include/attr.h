#ifndef ATTR_H
#define ATTR_H

#include<cmath>
#include<cstring>
#include<cstdio>
#include<cstdint>
#include<cstdbool>
#include<cstdlib>
#include<ctime>

#ifdef __cplusplus
extern "C" {
#endif


typedef struct attrResults {
  wchar_t auditName[BUFSIZE];
  uint64_t univ, samp, quant;
  int64_t lowCfd[3],hiCfd[3];
} AttrResults;
  
double sumCfd(int64_t x, int64_t n,int64_t k,int64_t N);
int64_t hypergCfd(int64_t x,int64_t n, int64_t N,char * dir,double per);

  void AttrShowResults(HWND hWnd, AttrResults * results);
  INT_PTR CALLBACK AttrResultsProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);  
#ifdef __cplusplus
}
#endif

#endif

