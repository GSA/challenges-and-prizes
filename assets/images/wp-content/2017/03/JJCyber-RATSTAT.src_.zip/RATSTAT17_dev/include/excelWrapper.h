#ifndef EXCELWRAPPER_H
#define EXCELWRAPPER_H

#include<stdint.h>
class ExcelAPIWrapperPrivate;

class ExcelAPIWrapper
{
    private: ExcelAPIWrapperPrivate* _private;

    public: ExcelAPIWrapper();
 
    public: ~ExcelAPIWrapper();
    
 public: void ExcelMain(const char* st1, const char* st2);
 public: void ExcelMain2(const char* st1, int v1, const char* st2, int v2);
 public: void InsertNumber(const char* sheetName,
			   const char* column, uint32_t row,
			   const char* data);
 public: void InsertText(const char* sheetName,
			   const char* column, uint32_t row,
			   const char* data);  
 public: const char* GetCellValue(const char* sheetName,const char* cellRef);
 public: const char* GetCellDataType(const char* sheetName,const char* cellRef);  
 public: void CloseSpreadsheet();
 public: const char ** GetSheetNames();
 public: const char ** GetCellReferences(const char* sheetName);
 public: const char *** GetContents(const char* sheetName);
 public: const wchar_t *** wGetContents(const char* sheetName);    
 public: void FreeStrings(const char** strs,int num);
 public: void FreeString(const char* str);    
 public: void CreateSpreadsheet(const char* fileName);
 public: void OpenSpreadsheet(const char* fileName);
 public: void OpenReadonlySpreadsheet(const char* fileName);  
 public: unsigned int AddSheet(const char* sheetName);
  
};

#endif
