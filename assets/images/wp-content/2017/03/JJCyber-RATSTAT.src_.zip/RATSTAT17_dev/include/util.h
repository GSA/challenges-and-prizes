/*********************************************************************************
*
* FILE: util.h
*
* COPYRIGHT (2017): J&J CyberSecurity LLC   http://www.jjcybersecurity.com
* All Rights Reserved 
* 
* Header File for util.cpp
*
*********************************************************************************/
#ifndef UTIL_H
#define UTIL_H

#include<windows.h>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<cstdint>
#include<cstdbool>
#include<cstddef>  

#include<string>
#include<sstream>
#include<iostream>

#include <Shobjidl.h>
#include <Objbase.h>
#include <knownfolders.h> // for KnownFolder APIs/datatypes/function headers
#include <propvarutil.h>  // for PROPVAR-related functions
#include <propkey.h>      // for the Property key APIs/datatypes
#include <propidl.h>      // for the Property System APIs
#include <shtypes.h>      // for COMDLG_FILTERSPEC
#include <vector>

#include "resource.h"
#include <Commctrl.h>
#define noop
using namespace std;

bool EndsWith(const string& str, const string& suff);

#ifdef __cplusplus
extern "C" {
#endif
   

bool ParseFloat(LPCWSTR charBuf, float *fOut);
bool ParseNonNegFloat(LPCWSTR charBuf, float *fOut);  
bool ParseDouble(LPCWSTR charBuf, double *dOut);
bool ParseNonNegDouble(LPCWSTR charBuf, double *dOut);    
bool ParseInt(LPCWSTR charBuf,  int64_t *iOut);
bool ParseNonNegInt(LPCWSTR myString, uint64_t *);
bool Parse32Int(LPCWSTR charBuf,  int32_t *iOut);
bool ParseNonNeg32Int(LPCWSTR myString, uint32_t *);  
  
void ByteToBits(uint8_t x, char buf[9]);
void BytesToBits(uint8_t *x, int numBytes, char buf[]);
void IntToBits(uint32_t num, char strOut[]);
void LongToBits(uint64_t num, char strOut[]);
void FloatToBits(float num, char strOut[]);
void DoubleToBits(double num, char strOut[]);

uint8_t BitsToByte(char buf[9]);
void BitsToBytes(char buf[], int numBytes, uint8_t *x);
uint32_t BitsToInt(char bitStr[]);
uint64_t BitsToLong(char bitStr[]);
float BitsToFloat(char bitStr[]);
double BitsToDouble(char bitStr[]);

  
void DebugStringFn(LPCWSTR str);
 
bool c_OpenFileDialog(wchar_t *strFile,size_t maxChars, wchar_t const * strTitle,
		      wchar_t const * astrFilter[], long astrFilterCnt,
		      wchar_t const * astrFilterExtension[], long astrFilterExtCnt,
		      LONG nFlags, HWND hParentWnd);

#define DEBUG

#ifdef DEBUG
#define DebugString(x)DebugStringFn((x))
#else
#define DebugString(x) ((void)0)
#endif
  

  
#ifdef __cplusplus
}
#endif  
#endif
