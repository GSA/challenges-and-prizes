/*********************************************************************************
 *
 * FILE: attr.cpp
 *
 * COPYRIGHT (2017): J&J CyberSecurity LLC   http://www.jjcybersecurity.com
 * All Rights Reserved 
 * 
 *
 * This file implements the functional code for Attribtue Appraisal
 * for RAT-STATS 2017 as specified in the Challenge Documentation.
 *
 * implements the following functions
 * sumCfd -- calculate sum of Confidence Intervals
 * hypergCfd -- calculate confidence intervals
 *
 *********************************************************************************/

#include "util.h"
#include "attr.h"
#include "printText.h"


#ifdef __cplusplus
extern "C" {
#endif
  

  static char sumCfd_docstring[] =  "Calculate the cumulative probabilty ";

  const double Max = 1000000000000.0;
  const double Min = 1.0 / Max;

  /*****************************************************
   * Function: sumCfd
   * Sum of confidence interval
   *
   * parameters:
   *  N = universe size
   *  n = sample size
   *  k = total number of universe items in error
   *  x = number of samples in error
   *
   * returns:
   *  sum of the cumulative probability
   *
   * Notes:
   *    To avoid issues with data overflows, uses a
   *    separate exponent variable to keep track of
   *    powers (1x10^12)
   *
   *****************************************************/
  
  double sumCfd(int64_t x, int64_t n,int64_t k,int64_t N) {
  
    double z, cumProb;
    int64_t j;
    int64_t exponent, good, minBad;
    int64_t PB, PG, SS, SB;

    exponent=0;
    good=N-k;
    minBad=n-good;
  
    if(x<minBad) {
      return 0.0;
    }
    if(minBad<0) {
      minBad=0;
    }

    z = 1.0;
    if (minBad>0) {
      for (j=0;j<n;j++) {
        if (j<minBad){
          z=z*(k-j)/(double)(N-j);
        }       else {
          z=z*(j+1)/(double)(N-j);
        }

        if(z<Min) {
          z=z*Max;
          exponent=exponent-1;
        } else if (z>Max) {
          z=z*Min;
          exponent=exponent+1;
        }
      }
    } else {
      for (j =0; j<n; j++) {
        double diff=(good-j)/(double)(N-j);
        z=z*diff;
        if(z<Min) {
          z=z*Max;
          exponent=exponent-1;
        } else if (z>Max) {
          z=z*Min;
          exponent=exponent+1;
        }
      }
    }

    if(z<Min) {
      z=z*Max;
      exponent=exponent-1;
    } else if (z>Max) {
      z=z*Min;
      exponent=exponent+1;
    }
  
    cumProb=z;
    if (exponent < -1) {
      cumProb=0;
    } else if (exponent == -1) {
      cumProb=z*Min;
    } else if (exponent > 0) {
      for (j=0;j<exponent;j++) {
        cumProb=cumProb*Max;
      }
    }

    if(minBad >0){
      PB = k - minBad;
      PG = good + minBad;
      SS = n - minBad;
      SB = x - minBad;
    } else {
      PB = k;
      PG = good;
      SS = n;
      SB = x;
    }
    for (j=1;j<=SB;j++) {
      z = z*(PB - j + 1)*(SS - j +1);
      z = z / ((j + minBad)*1.0*(PG - n + j));
      if (z > Max) {
        z=z*Min;
        exponent+=1;
      } else if (z < Min) {
        z=z*Max;
        exponent-=1;
      }

      if(exponent==-1) {
        cumProb=cumProb+z*Min;
      } else if (exponent==0) {
        cumProb=cumProb+z;
      } else if (exponent==1) {
        cumProb=cumProb+z*Max;
      }
    }

    return cumProb;
  }



  /*****************************************************
   * Function: hypergCfd
   * Sum of confidence interval
   *  
   * parameters:  
   *   x - # of samples with characteristic of interest
   *   n -- sample size
   *   N -- universe size
   *   dir -- direction seeking bounds, upper or lower 
   *   per -- percentage/confidence bounds of interest
   *          assumed to be 0.1 0.5 or 0.025
   *
   * Uses binary search to reach solution
   *
   *****************************************************/
  
  int64_t hypergCfd(int64_t x,int64_t n, int64_t N,char * dir,double per) {
    double zValue,est,term,delta,guessCfd,tail,kEst;
    int64_t topGuess,lowGuess,guess;

    if(per == 0.1) 
      zValue=1.28155;
    else if (per == 0.05)
      zValue=1.64485;
    else // if (per == 0.025)
      zValue=1.95996;

    est = ((double)x)/n;
    term = est*(1-est)*N*(N-n)/(n-1);
    if(term <1) term = 1;
    tail=per;
    delta=zValue*sqrt(term);  // IF TERM < 1 then we have a problem, nothing ever changes.

    kEst=est*N;

    if(strcmp("lower",dir)==0) {
      if(kEst<x)
        kEst=(double)x;
      lowGuess=(int64_t)(kEst-delta*2);
      topGuess=(int64_t)(kEst+1);

      //Bin Search    
      while (topGuess - lowGuess > 1) {
        guess = (topGuess+lowGuess)/2;
        guessCfd = 1-sumCfd(x-1,n,guess,N);
        if (guessCfd > per) 
          topGuess = guess;
        else
          lowGuess = guess;

      }
      //find smallest guess > per

      if(1-sumCfd(x-1,n,lowGuess,N)>per)
        guess=lowGuess;
      else
        guess=topGuess;
    } else {  // dir not "lower"
      topGuess=(int64_t)(kEst+2*delta+1);
      lowGuess=(int64_t)(kEst);
      if(lowGuess<x) lowGuess=x;

      // Bin Search    
      while( topGuess - lowGuess > 1) {

        guess = (int64_t)(topGuess+lowGuess)/2;
            
        guessCfd = sumCfd(x,n,guess,N);
        if (guessCfd < per) 
          topGuess = guess;
        else
          lowGuess = guess;

      }

      if(sumCfd(x,n,topGuess,N)>=per)
        guess=topGuess;
      else
        guess=lowGuess;
    }       
    return guess;
  }


#ifdef __cplusplus
}
#endif
