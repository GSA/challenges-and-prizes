/*********************************************************************************
 *
 * FILE: util.cpp
 *
 * COPYRIGHT (2017): J&J CyberSecurity LLC   http://www.jjcybersecurity.com
 * All Rights Reserved 
 * 
 * This file provides a collection of utility functions for use by the
 * functional code
 *
 *
 *********************************************************************************/
#include "util.h"

#ifdef __cplusplus
extern "C" {
#endif


  /***************************************************
   *
   * Parse functions, convert from string to value
   *
   ***************************************************/

  bool ParseFloat(LPCWSTR charBuf, float *fOut) {
    std::wstring myString(charBuf);
    std::wistringstream iss(myString);

    float f;
    iss >> std::noskipws >> f; // noskipws considers leading whitespace invalid
    // Check the entire string was consumed and if either failbit or badbit is set
    bool result = iss.eof() && !iss.fail();
    if(result && fOut ) *fOut=f;
    return result;
  }

  bool ParseNonNegFloat(LPCWSTR charBuf, float *fOut) {
    float f;
    bool result = ParseFloat(charBuf,&f);
    result = result && f>=0;
    if(result && fOut) *fOut = f;
    return result;
  }

  bool ParseDouble(LPCWSTR charBuf, double *dOut) {
    std::wstring myString(charBuf);
    std::wistringstream iss(myString);

    double d;
    iss >> std::noskipws >> d; // noskipws considers leading whitespace invalid
    // Check the entire string was consumed and if either failbit or badbit is set
    bool result = iss.eof() && !iss.fail();
    if(result && dOut) *dOut=d;
    return result;
  }

  bool ParseNonNegDouble(LPCWSTR charBuf, double *dOut) {
    double d;
    bool result = ParseDouble(charBuf,&d);
    result = result && d>=0;
    if(result && dOut) *dOut = d;
    return result;
  }  

  bool ParseInt(LPCWSTR charBuf, int64_t *iOut) {
    std::wstring myString(charBuf);
    std::wistringstream iss(myString);
    int64_t i;
    iss >> std::noskipws >> i; // noskipws considers leading whitespace invalid
    // Check the entire string was consumed and if either failbit or badbit is set
    bool result = iss.eof() && !iss.fail();
    if(result && iOut) *iOut=i;
    return result; 
  }

  bool Parse32Int(LPCWSTR charBuf, int32_t *iOut) {
    std::wstring myString(charBuf);
    std::wistringstream iss(myString);
    int32_t i;
    iss >> std::noskipws >> i; // noskipws considers leading whitespace invalid
    // Check the entire string was consumed and if either failbit or badbit is set
    bool result = iss.eof() && !iss.fail();
    if(result && iOut) *iOut=i;
    return result; 
  }    

  bool ParseNonNegInt(LPCWSTR charBuf, uint64_t *uOut) {
    int64_t i;
    wchar_t msg[BUFSIZ];
    bool result = ParseInt(charBuf,&i);
    result = result && i>=0;
    if(result && uOut) {
      *uOut = (uint64_t) i;
      wsprintf(msg,L"Parsed %ls as %I64d for uOut = %I64u",charBuf,i,*uOut);
      DebugString(msg);
    }
    return result;
  }

  bool ParseNonNeg32Int(LPCWSTR charBuf, uint32_t *uOut) {
    int32_t i;
    bool result = Parse32Int(charBuf,&i);
    result = result && i>=0;
    if(result && uOut) *uOut = (uint32_t) i;
    return result;
  } 



  /***************************************************
   *
   * nnnToBits functions, convert from value to bit string
   *  stored as an array of characters either a '0' or a '1'
   *  uses little endian format per byte, 
   *
   ***************************************************/
  
  // The returns format in little endian per byte
  void ByteToBits(uint8_t x, char buf[]) {
    for(int i=0; i<8; i++) {
      buf[i]= '0'+x%2;
      x=x/2;
    }
    buf[8]=0;
  }

  // convert numBytes bytes into a little endian bit string
  // least significant BIT first, least significant byte first
  void BytesToBits(uint8_t *bytes, int numBytes, char strOut[]) {
    for (int i=0;i<numBytes;i++){
      ByteToBits(bytes[i], &strOut[i*8]);
    }
    strOut[numBytes*8]=0;
  }

  // assumes 4 byte int
  void IntToBits(uint32_t num, char strOut[]) {
    BytesToBits((uint8_t *)&num, 4, strOut);
  }

  // assumes 8 byte int
  void LongToBits(uint64_t num, char strOut[]) {
    BytesToBits((uint8_t *)&num, 8, strOut);
  }

  // assumes 4 byte float
  void FloatToBits(float num, char strOut[]) {
    BytesToBits((uint8_t *)&num, 4, strOut);
  }

  // assumes 8 byte double
  void DoubleToBits(double num, char strOut[]) {
    BytesToBits((uint8_t *)&num, 8, strOut);
  }



  /***************************************************
   *
   * bitsTo nnn functions, convert from bit string to value
   *
   * assumes input is little endian representation
   * and maps byt to byte to memory layout
   *
   *****************************************************/
  
  // take little endian bit string and convert to 8bit uint8_t
  // 
  uint8_t BitsToByte(char bitStr[]){
    uint8_t tmp=0;
    for(int i=0;i<8;i++) {
      tmp=tmp*2;
      if(bitStr[7-i]=='1') {
        tmp=tmp+1;
      }
    }
    return tmp;
  }

  // take little endian bit string and convert to int
  // assumed 4 byte int
  void BitsToBytes(char bitStr[], int numBytes, uint8_t* bytes){
    for(int i=0;i<numBytes;i++) {
      bytes[i]=BitsToByte(&(bitStr[i*8]));
    }
  }

  // assumes 4 byte int
  uint32_t BitsToInt(char bitStr[]) {
    int tmp;
    BitsToBytes(bitStr,4,(uint8_t *)& tmp);
    return tmp;
  }


  // assumes 8 byte long
  uint64_t BitsToLong(char bitStr[]) {
    uint64_t tmp;
    BitsToBytes(bitStr,8,(uint8_t *)& tmp);
    return tmp;
  }


  // assumes 4 byte float
  float BitsToFloat(char bitStr[]) {
    float tmp;
    BitsToBytes(bitStr,4,(uint8_t *)& tmp);
    return tmp;
  }

  // assumes 8 byte double
  double BitsToDouble(char bitStr[]) {
    double tmp;
    BitsToBytes(bitStr,8,(uint8_t *)& tmp);
    return tmp;
  }


  // Debug by writing to console  
  void DebugStringFn(LPCWSTR str) {
    HANDLE outHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    DWORD result;
    LPDWORD res=&result;
    LPCWSTR term=L"\n";
    WriteConsole(outHandle,str,wcslen(str),res,NULL);
    WriteConsole(outHandle,term,wcslen(term),res,NULL);    
  }

#ifdef __cplusplus
}
#endif


    

