/*********************************************************************************
 *
 * FILE: printText.cpp
 *
 * COPYRIGHT (2017): J&J CyberSecurity LLC   http://www.jjcybersecurity.com
 * All Rights Reserved 
 * 
 * 
 * This file provide the functions necessary to output
 * RAT-STATS data to text files. Includes some utilities to 
 * add "thousand-separators "," (commas) to numbers to match the 
 * current RAT-STATS output. All of the spacing is hardcoded here 
 * to match current RAT-STATS output.
 *
 * Also has functions to write to Excel files. 
 *
 *********************************************************************************/

#include "util.h"
#include "printText.h"
#include "excelWrapper.h"

#ifdef __cplusplus
extern "C" {
#endif


  /*****************************************************
   * Function: SPrintCommaHelper
   *
   *  "Helper" function for recursive creation of a wide string
   *  representation of an integer with thousand's separators (commas)
   *
   *****************************************************/
  
  void SPrintCommaHelper(wchar_t *buff,
                         int64_t num, bool greaterThan1000, bool fullWidth) {
    wchar_t tmpbuff[80];
    if (num < 1000) {
      if(fullWidth) swprintf(tmpbuff,80,L"%03lld",num);
      else swprintf(tmpbuff,80,L"%lld",num);
      wcsncat(buff,tmpbuff,80);
      if(greaterThan1000) wcsncat(buff,L",",80);
    } else {
      SPrintCommaHelper(buff,num/1000,true,fullWidth);
      SPrintCommaHelper(buff,num%1000, greaterThan1000,true);
    }
  }


  /*****************************************************
   * Function: SPrintComma
   *
   *  Creates a wide string representation of an integer 
   * with thousand's separators (commas)
   *
   *****************************************************/  
  void SPrintComma(wchar_t *buff, int64_t num) {
    if (num< 0) {
      buff[0]='-';
      buff[1]=0;
      SPrintCommaHelper(buff,-num,false,false);    
    } else {
      buff[0]=0;
      SPrintCommaHelper(buff,num,false,false);    
    }
  }

  /*****************************************************
   * Function: SPrintDblComma
   *
   *  Creates a string representation of a double
   *  with thousand's separators (commas), prints
   *  precision number of digits after the decimal
   *
   *****************************************************/  
  void SPrintDblComma(wchar_t *buff, double num, int precision ) {
    double frac,intPart;
    if (num< 0) {
      buff[0]='-';
      buff[1]=0;  
      frac = modf(-num,&intPart);
    } else {
      buff[0]=0;
      frac = modf(num,&intPart);
    }
    SPrintCommaHelper(buff,(int64_t)intPart,false,false);
    char buff2[40];
    wchar_t buff3[40];
    sprintf(buff2,"%*.*f",precision+2,precision,frac);
    mbstowcs(buff3,&(buff2[1]),40);
    wcsncat(buff,buff3,80);  
  }


  /*****************************************************
   * Function: SPrintCommaAsciiHelper
   *
   *  "Helper" function for recursive creation of a non-wide string
   *  representation of an integer with thousand's separators (commas)
   *
   *****************************************************/
  
  void SPrintCommaAsciiHelper(char *buff,
                              int64_t num, bool greaterThan1000, bool fullWidth) {
    char tmpbuff[80];
    if (num < 1000) {
      if(fullWidth) snprintf(tmpbuff,80,"%03lld",num);
      else snprintf(tmpbuff,80,"%lld",num);
      strncat(buff,tmpbuff,80);
      if(greaterThan1000) strncat(buff,",",80);
    } else {
      SPrintCommaAsciiHelper(buff,num/1000,true,fullWidth);
      SPrintCommaAsciiHelper(buff,num%1000, greaterThan1000,true);
    }
  }

  /*****************************************************
   * Function: SPrintCommaAscii
   *
   *  Creates a non-wide string representation of an integer 
   * with thousand's separators (commas)
   *
   *****************************************************/    
  void SPrintCommaAscii(char *buff, int64_t num) {
    if (num< 0) {
      buff[0]='-';
      buff[1]=0;
      SPrintCommaAsciiHelper(buff,-num,false,false);    
    } else {
      buff[0]=0;
      SPrintCommaAsciiHelper(buff,num,false,false);    
    }
  }
  


  /*****************************************************
   * Function: PrintComma
   *
   *  Prints integer to output file, using thousand's separators
   *
   *****************************************************/
  
  void PrintComma(FILE *fn, int64_t num) {
    wchar_t buff[100];
    SPrintComma(buff,num);
    fwprintf(fn,L"%s",buff);
  }


  /*****************************************************
   * Function: PrintDblComma
   *
   *  Prints double to output file, using thousand's separators
   *  Formats for "precision" digits past the decimal point
   *
   *****************************************************/  
  void PrintDblComma(FILE *fn, double num, int precision) {
    wchar_t buff[100];
    SPrintDblComma(buff,num,precision);
    fwprintf(fn,L"%s",buff);
  }  

  
  /*****************************************************
   * Function: SCenter
   *
   *  Creates a wide string representation of a string
   *  centered in a field of specified width
   *
   *****************************************************/    

  void SCenter(wchar_t * res, size_t width, wchar_t const* str) {
    char asciiMsg1[BUFSIZE+1];
    char asciiMsg2[BUFSIZE+1];
    wcstombs(asciiMsg1,str,width);
    asciiMsg1[width]=0;
    int len1 = (width+strlen(asciiMsg1))/2;
    int len2 = width-len1;    
    sprintf(asciiMsg2,"%*s%*s",len1,asciiMsg1,len2," ");
    asciiMsg2[width]=0;  
    mbstowcs(res,asciiMsg2,width+1);
  }

  /*****************************************************
   * Function: SCenterAsicc
   *
   *  Creates a non-wide string representation of a string
   *  centered in a field of specified width
   *
   *****************************************************/    
  
  void SCenterAscii(char * res, size_t width, char const* str) {
    int len1 = (width+strlen(str))/2;
    int len2 = width-len1;
    sprintf(res,"%*s%*s",len1,str,len2," ");
    res[width]=0;
  }  


  /*****************************************************
   * Function: Center
   *
   *  Prints a specified sstring  to the specified file, 
   *  centered in a field of specified width
   *
   *****************************************************/    
  
  void Center(FILE *fn,size_t width, wchar_t const * str) {
    wchar_t res[BUFSIZE];
    SCenter(res,width,str);
    fwprintf(fn,L"%ls\n",res);
  }


  /*****************************************************
   * Function: RndPrintText
   *
   *  Prints the outputs for the RND Function Module.
   * 
   *  Parameterized by number of random variables. 
   *
   *****************************************************/    
  
  bool RndPrintText(LPCWSTR fileName,RndResults *results) {

    uint32_t numRndNums = results->numSeq + results->numRnd;
  
    char asciiFileName[301];
    wcstombs(asciiFileName,fileName,BUFSIZE);
    asciiFileName[BUFSIZE]=0;
    FILE *fn = fopen(asciiFileName,"w");
    if (fn == NULL) {
      return false;
    }
    wchar_t res[BUFSIZE];
    char asciiRes[BUFSIZE],asciiRes2[BUFSIZE];
    time_t timeNow = time(NULL);
    struct tm *now = localtime(&timeNow);
  
    Center(fn,77,L"Windows RAT-STATS 2017 -- by J&J Cyber Security LLC");
    Center(fn,78,L"Statistical Software");
    strftime(asciiRes,14,"%#m/%d/%Y",now);
    mbstowcs(res,asciiRes,78);
    fwprintf(fn,L"Date: %ls ",res);

    SCenter(res,48,L"Random Number Generator  ");
    fwprintf(fn,L"%ls",res);

    wcsftime(res,14,L"%H:%M",now);  
    fwprintf(fn,L"     Time: %ls\n",res);

    wcscpy(res,L"AUDIT: ");
    wcsncat(res,results->auditName,72);
    Center(fn,77,res);
    fwprintf(fn,L"\n");

    SPrintCommaAscii(asciiRes,results->frameSize);

    sprintf(asciiRes2,"SEED NUMBER: %-20.2f%18sFRAME SIZE:%16s\n\n\n\n",results->seed," ",asciiRes);
    mbstowcs(res,asciiRes2,80);
    fwprintf(fn,res);
    fwprintf(fn,L"     FILE OF RANDOM NUMBERS: %ls\n\n",fileName);
    fwprintf(fn,L"     TOTAL RANDOM NUMBERS GENERATED: %-d\n\n",numRndNums);
    fwprintf(fn,L"THE NUMBERS ARE IN THE FOLLOWING FORMAT IN YOUR FILE:\n");
    fwprintf(fn,L"   POSITIONS 1 THROUGH  6 - ORDER OF SELECTION\n");
    if(results->numVars == 1) {
      fwprintf(fn,L"   POSITIONS 7 THROUGH 17 - RANDOM NUMBER\n");
    } else {
      if( results->numVars>1) {
        fwprintf(fn,L"   POSITIONS 7 THROUGH 17 - FIRST NUMBER OF SET\n");
        fwprintf(fn,L"   POSITIONS 18 THROUGH 30 - SECOND NUMBER OF SET\n");
      }
      if( results->numVars>2)
        fwprintf(fn,L"   POSITIONS 31 THROUGH 43 - THIRD NUMBER OF SET\n");
      if( results->numVars>3)
        fwprintf(fn,L"   POSITIONS 44 THROUGH 56 - FIRST NUMBER OF SET\n");    
    }
    fwprintf(fn,L"EACH COLUMN OF NUMBERS IS RIGHT JUSTIFIED.\n\n\n");


    // could be neater
    if(results->numVars == 1) {
      fwprintf(fn,L"Selection\n");
      fwprintf(fn,L"  Order     Value\n");
    } else {
      if (results->numVars > 1) {
        fwprintf(fn,L"Selection   First       Second");
      }
      if (results->numVars > 2) {    
        fwprintf(fn,L"        Third");
      }
      if (results->numVars > 3){
        fwprintf(fn,L"       Fourth");
      }
      fwprintf(fn,L"\n");    
      if(results->numVars > 1) {
        fwprintf(fn,L"  Order    Number       Number");
      }
      if(results->numVars > 2) {
        fwprintf(fn,L"       Number");
      }
      if (results->numVars > 3){
        fwprintf(fn,L"       Number");
      }
      fwprintf(fn,L"\n");        
    }

    // Print out numbers in columns, 1st column is order, next are values for each variable
    for (uint32_t i=0;i<numRndNums;i++) {
      fwprintf(fn,L"%6d",results->randNum[i].index);
      fwprintf(fn,L"%11d",results->randNum[i].values[0]);    
      for (uint32_t varId =1;varId < results->numVars; varId++) {
        fwprintf(fn,L"%13d",results->randNum[i].values[varId]);
      }
      fwprintf(fn,L"\n");
    }

    if(results->numVars ==1) {
      fwprintf(fn,L"\nSUMMATION OF RANDOM NUMBERS = ");
      PrintComma(fn,results->sum);
      fwprintf(fn,L"\n");
    }
    fclose(fn);
    return true;
  }


  /*****************************************************
   * Function: RndPrintXlsx
   *
   *  Stores he outputs for the RND Function Module.
   *  in an Excel File. Creates Two Worksheets
   *  VALUES - General Info + columns for random values
   *  SPARES - Columns of spare random values
   * 
   *  Parameterized by number of random variables. 
   *
   *****************************************************/    

  bool RndPrintXlsx(LPCWSTR fileName,RndResults *results) {
    char asciiRes[BUFSIZE];
    time_t timeNow = time(NULL);
    struct tm *now = localtime(&timeNow);
    ExcelAPIWrapper excel;

    char asciiFileName[BUFSIZE];
    wcstombs(asciiFileName,fileName,BUFSIZE);
    asciiFileName[BUFSIZE-1]=0;


    string str(asciiFileName);

    std::size_t found = str.rfind(".txt");
    if (found!=std::string::npos)
      str.replace(found,4,".xlsx");
  
    try {
      excel.CreateSpreadsheet(str.c_str());
      excel.AddSheet("SPARES");
      excel.AddSheet("VALUES");

    char column[]="A";
  
    excel.InsertText("VALUES","A",1,"          Windows RAT-STATS");
    excel.InsertText("VALUES","A",2,"           Statistical Software");
    excel.InsertText("VALUES","A",3,"      Random Number Generator");
    excel.InsertText("VALUES","A",4,"Date:");
    strftime(asciiRes,14,"%m/%d/%Y",now);
    excel.InsertText("VALUES","B",4,asciiRes);
    excel.InsertText("VALUES","C",4,"Time:");
    strftime(asciiRes,14,"%H:%M",now);
    excel.InsertText("VALUES","D",4,asciiRes);  
    excel.InsertText("VALUES","A",5,"Audit");
    wcstombs(asciiRes,results->auditName,BUFSIZE);
    excel.InsertText("VALUES","B",5,asciiRes);
    excel.InsertText("VALUES","A",6,"Order");
    excel.InsertText("SPARES","A",1,"Order");  
    if(results->numVars == 1) {
      column[0]='B';
      excel.InsertText("VALUES",column,6,"Value");
      excel.InsertText("SPARES",column,1,"Value");    
    } else {
      char *colNames[]={"First Value","Second Value","Third Value","Fourth Value"};
      for (uint32_t i=0;i<results->numVars;i++) {
        column[0]=(char)('B'+i);
        excel.InsertText("VALUES",column,6,colNames[i]);
        excel.InsertText("SPARES",column,1,colNames[i]);      
      }
    }
    column[0]++;
    excel.InsertText("VALUES",column,6,"Seed Number");
    sprintf(asciiRes,"%.2f",results->seed);
    excel.InsertNumber("VALUES",column,7,asciiRes);
    column[0]++;
    excel.InsertText("VALUES",column,6,"Frame Size");
    sprintf(asciiRes,"%I64d",results->frameSize);
    excel.InsertNumber("VALUES",column,7,asciiRes);      

  
    for (uint32_t i=0;i<results->numSeq;i++) {
      column[0]='A';
      sprintf(asciiRes,"%d",results->randNum[i].index);
      excel.InsertNumber("VALUES",column,7+i,asciiRes);
      for (uint32_t varId =0;varId < results->numVars; varId++) {
        column[0]=(char)('B'+varId);
        sprintf(asciiRes,"%d",results->randNum[i].values[varId]);
        excel.InsertNumber("VALUES",column,7+i,asciiRes);
      }    
    }


    for (uint32_t i=0;i<results->numRnd;i++) {
      column[0]='A';
      int index=i+results->numSeq;
      sprintf(asciiRes,"%d",results->randNum[index].index);
      excel.InsertNumber("SPARES",column,2+i,asciiRes);
      for (uint32_t varId =0;varId < results->numVars; varId++) {
        column[0]=(char)('B'+varId);
        sprintf(asciiRes,"%d",results->randNum[index].values[varId]);      
        excel.InsertNumber("SPARES",column,2+i,asciiRes);
      }    
    }
  
    excel.CloseSpreadsheet();

    } catch (std::exception (void*)) {
      return false;
    }    
    return true;
  }


    
  /*****************************************************
   * Function: AttrPrintText
   *
   *  Prints the outputs for the Attribute Appraisal Function Module.
   * 
   *****************************************************/    
  void AttrPrintText(LPCWSTR fileName,AttrResults * results) {

    char asciiFileName[301];
    wcstombs(asciiFileName,fileName,BUFSIZE);
    asciiFileName[BUFSIZE]=0;
    FILE *fn = fopen(asciiFileName,"w");
    if (fn == NULL) {
      return;
    }
    wchar_t res[100];
    char asciiRes[100];
    time_t timeNow = time(NULL);
    struct tm *now = localtime(&timeNow);
  
    Center(fn,78,L"Windows RAT-STATS 2017 -- by J&J Cyber Security LLC");
    Center(fn,78,L"Statistical Software");
    strftime(asciiRes,14,"%#m/%d/%Y",now);
    mbstowcs(res,asciiRes,80);
    fwprintf(fn,L"Date: %ls ",res);

    SCenter(res,44,L"Single Stage Attribute Appraisal");
    fwprintf(fn,L"%ls",res);

    wcsftime(res,14,L"%H:%M",now);  
    fwprintf(fn,L"             Time: %ls\n",res);

    wcscpy(res,L"AUDIT/REVIEW: ");
    wcsncat(res,results->auditName,72);
    Center(fn,78,res);

    wcscpy(res,L"OUTPUT FILE: ");
    wcsncat(res,fileName,72);
    Center(fn,78,res);
    fwprintf(fn,L"\n\n");

    fwprintf(fn,L"%9s%-63s",L"",L"UNIVERSE SIZE");
    PrintComma(fn,results->univ);
    fwprintf(fn,L"\n");  

    fwprintf(fn,L"%9s%-63s",L"",L"SAMPLE SIZE");
    PrintComma(fn,results->samp);
    fwprintf(fn,L"\n");

    fwprintf(fn,L"%9s%-63s\n",L"",L"CHARACTERISTIC(S) OF INTEREST");

    fwprintf(fn,L"%11s%-61s",L"",L"QUANTITY IDENTIFIED IN SAMPLE");
    PrintComma(fn,results->quant);
    fwprintf(fn,L"\n");
  
    fwprintf(fn,L"%11s%-61s",L"",L"PROJECTED QUANTITY IN UNIVERSE");
    double ratio = ((double)results->quant)/results->samp;  
    int32_t proj = (int32_t)(round(ratio*results->univ));
    PrintComma(fn,proj);
    fwprintf(fn,L"\n");

    fwprintf(fn,L"%11s%-61s%.3f%%\n",L"",L"PERCENT",ratio*100);
    double frac = (double)results->samp/results->univ;
    double variance = results->samp*ratio*(1.0-ratio)*(1.0-frac);
    double stdErr = sqrt(variance);
    double estQuant = stdErr*sqrt((double)results->samp/(results->samp-1))/frac;
    fwprintf(fn,L"%9s%-63s\n",L"",L"STANDARD ERROR");
    fwprintf(fn,L"%11s%-61s",L"",L"PROJECTED QUANTITY");
    PrintComma(fn,(int64_t)round(estQuant));
    fwprintf(fn,L"\n");
    fwprintf(fn,L"%11s%-61s%.3f%%\n",L"",L"PERCENT",100.0*estQuant/results->univ);
    fwprintf(fn,L"\n");
    fwprintf(fn,L"%40s%s\n\n",L"",L"CONFIDENCE LIMITS");


    int32_t conf[3]={80,90,95};

    wchar_t buff[100];
  
    for(int i=0;i<3;i++) {
  
      fwprintf(fn,L"%39s%2d%s\n",L"",conf[i],L"% CONFIDENCE LEVEL");
      SPrintComma(buff,results->lowCfd[i]);
      fwprintf(fn,L"%9s%-24s%26s\n",L"",L"LOWER LIMIT - QUANTITY",buff);
      fwprintf(fn,L"%23s%-28s%#8.3f%%\n",L"",L"PERCENT",((double)results->lowCfd[i])/results->univ*100);
      SPrintComma(buff,results->hiCfd[i]);  
      fwprintf(fn,L"%9s%-24s%26s\n",L"",L"UPPER LIMIT - QUANTITY",buff);
      fwprintf(fn,L"%23s%-28s%8.3f%%\n\n",L"",L"PERCENT",((double)results->hiCfd[i])/results->univ*100);
    }

    fclose(fn);  
  }


  /*****************************************************
   * Function: VarAnalysisPrintText
   *
   *  Prints the outputs for the Variable Appraisal Function Module.
   *
   * Parameterized whether this is for unrestricted or stratified data. 
   * The Selection data structure contains all of the data
   *  with results in a specific member of the structure.
   * Results[0] is overall info (only one for unrestricted)
   * Results[i] is for stratum "i"
   *
   * Has results for Examined, Audited and Difference values
   *  if provided with two of these to start, otherwise 
   *  just one.
   * 
   *****************************************************/      
  void VarAnalysisPrintText(LPCWSTR fileName, Selection *selection) {
    VarResults *results;
    char asciiFileName[301];
    wcstombs(asciiFileName,fileName,BUFSIZE);
    asciiFileName[BUFSIZE]=0;
    FILE *fn = fopen(asciiFileName,"w");
    if (fn == NULL) {
      return;
    }
    wchar_t res[100];
    char asciiRes[100];
    time_t timeNow = time(NULL);
    struct tm *now = localtime(&timeNow);

  
    Center(fn,80,L"Windows RAT-STATS 2017 -- by J&J Cyber Security LLC");
    Center(fn,80,L"Statistical Software");
    strftime(asciiRes,14,"%#m/%d/%Y",now);
    mbstowcs(res,asciiRes,80);
    fwprintf(fn,L"Date: %ls ",res);

    if(selection->unrestricted) 
      SCenter(res,52,L"VARIABLE UNRESTRICTED APPRAISAL");
    else
      SCenter(res,52,L"STRATIFIED VARIABLE APPRAISAL ");    
    fwprintf(fn,L"%ls",res);

    wcsftime(res,14,L"%H:%M",now);  
    fwprintf(fn,L"          Time: %ls\n",res);

    wcscpy(res,L"AUDIT: ");
    wcsncat(res,selection->auditName,72);
    Center(fn,80,res);
    fwprintf(fn,L"\n");

    fwprintf(fn,L"DATA FILE USED: ");
    fwprintf(fn,L"%ls\n\n",selection->fileName);

    if(selection->unrestricted) {
      fwprintf(fn,L"     SAMPLE         EXAMINED    NONZERO        TOTAL OF          TOTAL OF\n");
      fwprintf(fn,L"      SIZE            VALUE      DIFFS        DIFF VALUES        AUD VALUES\n");
    } else {
      fwprintf(fn,L" STR SAMPLE         EXAMINED    NONZERO        TOTAL OF          TOTAL OF\n");
      fwprintf(fn,L" NBR  SIZE            VALUE      DIFFS        DIFF VALUES        AUD VALUES\n");
    }
  
    //  fprintf(fn,"%11I64d%17.2f%11I64d%18.2f%18.2f\n\n",results->samp,results->sums[EXAM],results->nonZero[DIFF],results->sums[DIFF],results->sums[AUDIT]);  


    if(!selection->unrestricted) {
      for(uint32_t i=1; i<=selection->numStrata; i++) {
        results = &selection->results[i];
        fprintf(fn,"%3d%8I64d",i,results->samp);
        SPrintDblComma(res,results->sums[EXAM],2);
        fwprintf(fn,L"%17s%11I64d",res,results->nonZero[DIFF]);
        SPrintDblComma(res,results->sums[DIFF],2);
        fwprintf(fn,L"%18s",res);
        SPrintDblComma(res,results->sums[AUDIT],2);
        fwprintf(fn,L"%18s\n",res);    
      }
      fprintf(fn,"\n");
    }
    results = &selection->results[0];
    fprintf(fn,"%11I64d",results->samp);
    SPrintDblComma(res,results->sums[EXAM],2);
    fwprintf(fn,L"%17s%11I64d",res,results->nonZero[DIFF]);
    SPrintDblComma(res,results->sums[DIFF],2);
    fwprintf(fn,L"%18s",res);
    SPrintDblComma(res,results->sums[AUDIT],2);
    fwprintf(fn,L"%18s\n\n\n",res);    

  

    string titles[3];
    titles[EXAM]=std::string("----------------------- E X A M I N E D ------------------------");
    titles[AUDIT]=std::string("----------------------- A U D I T E D --------------------------");
    titles[DIFF]=std::string("--------------------- D I F F E R E N C E ----------------------");
  
    int order[]={EXAM,AUDIT,DIFF};
    int formats [] = {FEXAM,FAUDIT,FDIFF};
    char buff[20];
  
    for(int i=0;i<3;i++) {
      if(!(selection->fFormat & formats[i])) continue;    
      int ind = order[i];
      fprintf(fn,"%11s%s\n"," ",titles[ind].c_str());
    
      for(uint32_t strata=1; strata<=selection->numStrata+1;strata++) {

        if(strata==selection->numStrata+1) // print Overall
          results = &selection->results[0];
        else if (selection->unrestricted)
          continue;  // just skip -- this is a hack to allow us to loop
        else
          results = &selection->results[strata];      

        if(selection->unrestricted) {
          fprintf(fn,"%11s%-26s"," ","MEAN / UNIVERSE");
        } else {
          if(strata==selection->numStrata+1) // print Overall
            fprintf(fn,"%-11s%-26s","Overall ","MEAN / UNIVERSE");
          else
            fprintf(fn,"Stratum %d  %-26s",strata,"MEAN / UNIVERSE");      
        }
        SPrintDblComma(res,results->mean[i],2);
        fwprintf(fn,L"%19s",res);    
        SPrintCommaAscii(buff,results->univ);
        fprintf(fn,"%19s\n",buff);
      
    
        fprintf(fn,"%11s%-26s"," ","STANDARD DEVIATION");
        SPrintDblComma(res,results->stdDev[i],2);
        fwprintf(fn,L"%19s\n",res);        

        fprintf(fn,"%11s%-26s"," ","SKEWNESS");
        SPrintDblComma(res,results->skew[i],2);
        fwprintf(fn,L"%19s\n",res);        

        fprintf(fn,"%11s%-26s"," ","KURTOSIS");
        SPrintDblComma(res,results->kurtosis[i],2);
        fwprintf(fn,L"%19s\n",res);            

        fprintf(fn,"%11s%-26s"," ","STANDARD ERROR (MEAN)");
        SPrintDblComma(res,results->stdErr[i],2);
        fwprintf(fn,L"%19s\n",res);                

        fprintf(fn,"%11s%-26s"," ","STANDARD ERROR (TOTAL)");
        SPrintCommaAscii(buff,(int64_t)round((results->stdErr[i]*results->univ)));
        fprintf(fn,"%19s\n",buff);

        fprintf(fn,"%11s%-26s"," ","POINT ESTIMATE");
        SPrintCommaAscii(buff,(int64_t)round(results->pointEst[i]));
        fprintf(fn,"%19s\n\n",buff);
    
        fprintf(fn,"%40s%s"," ","CONFIDENCE LIMITS\n");
        int32_t conf[3]={80,90,95};
    
        wchar_t wBuff[100];
  
        for(int j=0;j<3;j++) {
  
          fwprintf(fn,L"%39s%2d%s\n",L"",conf[j],L"% CONFIDENCE LEVEL");
          SPrintComma(wBuff,results->confLow[i][j]);
          fwprintf(fn,L"%11s%-22s%26s\n",L"",L"LOWER LIMIT",wBuff);
          SPrintComma(wBuff,results->confHi[i][j]);
          fwprintf(fn,L"%11s%-22s%26s\n",L"",L"UPPER LIMIT",wBuff);
          SPrintComma(wBuff,(int64_t)round(results->precision[i][j]));
          fwprintf(fn,L"%11s%-22s%26s\n",L"",L"PRECISION AMOUNT",wBuff);
          if(results->pointEst[i] !=0) 
            fwprintf(fn,L"%11s%-22s%26.2f%%\n",L"",L"PRECISION PERCENT",
                     100*results->precision[i][j]/results->pointEst[i]);  // Precision Amount/Point Estimate
          else
            fwprintf(fn,L"%11s%-22s\n",L"",L"PRECISION PERCENT");
          fwprintf(fn,L"%11s%-22s%26.12f\n\n",L"",L"T-VALUE USED",results->tVal[j]);
        }
      }
    }
 
    fclose(fn);  
  }

  
  /*****************************************************
   * Function: VarAnalysisPrintXlsx
   *
   * Prints the outputs for the Variable Appraisal Function Module in
   * an Excel File
   *
   * Parameterized whether this is for unrestricted or stratified data. 
   * The Selection data structure contains all of the data
   *  with results in a specific member of the structure.
   * Results[0] is overall info (only one for unrestricted)
   * Results[i] is for stratum "i"
   *
   * Has results for Examined, Audited and Difference values
   *  if provided with two of these to start, otherwise 
   *  just one.
   *
   * "General Info" sheet has info of this audit
   * "Overall" sheet has overall results
   * "Strata <i>" sheet has results for stratum <i>.
   *
   *****************************************************/      
  void VarAnalysisPrintXlsx(LPCWSTR fileName, Selection *selection) {
    VarResults *results;
    char asciiFileName[BUFSIZE];
    char asciiRes[BUFSIZE];
    time_t timeNow = time(NULL);
    struct tm *now = localtime(&timeNow);
    ExcelAPIWrapper excel;
    int order[]={EXAM,AUDIT,DIFF};
    int formats [] = {FEXAM,FAUDIT,FDIFF};
  
    wcstombs(asciiFileName,fileName,BUFSIZE);
    asciiFileName[BUFSIZE-1]=0;

    string str(asciiFileName);

    std::size_t found = str.rfind(".txt");
    if (found!=std::string::npos)
      str.replace(found,4,".xlsx");


    excel.CreateSpreadsheet(str.c_str());

    excel.AddSheet("General Info");
    excel.AddSheet("Overall");  
    if(!selection->unrestricted) {
      for(uint32_t i=1;i<selection->numStrata;i++) {
        sprintf(asciiRes,"Strata %d",i);
      }
    }

      
    char sheet[50];

    // Print General Information
    sprintf(sheet,"General Info");  
    int row =1;
    excel.InsertText(sheet,"A",row,"Windows RAT-STATS 2017 -- by J&J Cyber Security LLC");
    row++;
    excel.InsertText(sheet,"A",row,"Statistical Software");
    row++;
    if(selection->unrestricted) 
      sprintf(asciiRes,"VARIABLE UNRESTRICTED APPRAISAL");
    else
      sprintf(asciiRes,"STRATIFIED VARIABLE APPRAISAL ");    
    excel.InsertText(sheet,"A",row,asciiRes);
    row++;
  
    excel.InsertText(sheet,"A",row,"Audit/Review");
    wcstombs(asciiRes,selection->auditName,BUFSIZE);
    excel.InsertText(sheet,"B",row,asciiRes);
    row++;
    excel.InsertText(sheet,"A",row,"Data File Used");
    wcstombs(asciiRes,selection->fileName,BUFSIZE);
    excel.InsertText(sheet,"B",row,asciiRes);
    row++;    
  
    excel.InsertText(sheet,"A",row,"Date");
    strftime(asciiRes,14,"%#m/%d/%Y",now);
    excel.InsertText(sheet,"B",row,asciiRes);
    row++;
    
    excel.InsertText(sheet,"A",row,"Time");
    strftime(asciiRes,14,"%H:%M",now);
    excel.InsertText(sheet,"B",row,asciiRes);


    // Print Overall and Per Strata Info

    for(uint32_t strata =0;strata <= selection->numStrata;strata++) {
      if(strata > 0 && selection->unrestricted) continue;  // no strata to print
      results = &selection->results[strata];    
      if(strata == 0)
        sprintf(sheet,"Overall");
      else
        sprintf(sheet,"Strata %d",strata);

      row = 1;
      excel.InsertText(sheet,"A",row,"Universe");
      sprintf(asciiRes,"%I64d",results->univ);
      excel.InsertNumber(sheet,"B",row,asciiRes);
      row++;
      excel.InsertText(sheet,"A",row,"Sample Size");
      sprintf(asciiRes,"%I64d",results->samp);
      excel.InsertNumber(sheet,"B",row,asciiRes);
      row++;

      excel.InsertNumber(sheet,"B",row,asciiRes);
      char *titles[]={"Examined","Audited","Difference"};
      char col[]="B";

      for(int i=0;i<3;i++) {
        if(!(selection->fFormat & formats[i])) continue;  // nothing to print for that format            
        excel.InsertText(sheet,col,row,titles[i]);
        col[0]++;
      }

      row++;

      char *rows1[] = {"Mean","Std Deviation","Skewness","Kurtosis",
                       "Std Err (Mean)","Std Err (Total)","Non-Zero Values","Point Estimate",NULL};

      char *rows2[] = {"80% Confidence Level","90% Confidence Level","95% Confidence Level",NULL};
      char *rows3[] = {"Lower Limit","Upper Limit","Precision","Precision %","t-Value used",NULL};


      int nextRow = row;
    
      for(int i=0;rows1[i]!=NULL;i++) {
        excel.InsertText(sheet,"A",row,rows1[i]);
        row++;
      }

      for(int per=0;per<3;per++) {
        excel.InsertText(sheet,"A",row,rows2[per]);
        row++;
        for (int i=0;rows3[i] != NULL; i++) {
          excel.InsertText(sheet,"A",row,rows3[i]);
          row++;
        }
      }
    
      col[0]='B';

    
      for(int i=0;i<3;i++) {
        row = nextRow;      
        if(!(selection->fFormat & formats[i])) continue;  // nothing to print for that format  
        sprintf(asciiRes,"%.2f",results->mean[i]);
        excel.InsertNumber(sheet,col,row,asciiRes);
        row++;
        sprintf(asciiRes,"%.2f",results->stdDev[i]);
        excel.InsertNumber(sheet,col,row,asciiRes);
        row++;
        sprintf(asciiRes,"%.2f",results->skew[i]);
        excel.InsertNumber(sheet,col,row,asciiRes);
        row++;
        sprintf(asciiRes,"%.2f",results->kurtosis[i]);
        excel.InsertNumber(sheet,col,row,asciiRes);
        row++;
        sprintf(asciiRes,"%.2f",results->stdErr[i]);
        excel.InsertNumber(sheet,col,row,asciiRes);
        row++;
        sprintf(asciiRes,"%I64d",(int64_t)round((results->stdErr[i]*results->univ)));
        excel.InsertNumber(sheet,col,row,asciiRes);
        row++;    
        sprintf(asciiRes,"%I64d",(int64_t)round(results->nonZero[i]));
        excel.InsertNumber(sheet,col,row,asciiRes);
        row++;

        sprintf(asciiRes,"%I64d",(int64_t)round(results->pointEst[i]));
        excel.InsertNumber(sheet,col,row,asciiRes);
        row++;      
      
        for(int per =0; per < 3; per++) {
          row++; // nothing next to title
          sprintf(asciiRes,"%I64d",results->confLow[i][per]);
          excel.InsertNumber(sheet,col,row,asciiRes);
          row++;

          sprintf(asciiRes,"%I64d",results->confHi[i][per]);
          excel.InsertNumber(sheet,col,row,asciiRes);
          row++;

          sprintf(asciiRes,"%I64d",(int64_t)round(results->precision[i][per]));
          excel.InsertNumber(sheet,col,row,asciiRes);
          row++;

          if(results->pointEst[i] !=0) {
            sprintf(asciiRes,"%.2f",results->precision[i][per]/results->pointEst[i]);  // Precision Amount/Point Estimate
            excel.InsertNumber(sheet,col,row,asciiRes);
          } else {
            excel.InsertText(sheet,col,row,"N/A");
          }
          row++;                

          sprintf(asciiRes,"%.12f",results->tVal[per]);
          excel.InsertNumber(sheet,col,row,asciiRes);
          row++;
        }
        col[0]++;
      }
    }

    excel.CloseSpreadsheet();
  }
  
#ifdef __cplusplus
}
#endif
