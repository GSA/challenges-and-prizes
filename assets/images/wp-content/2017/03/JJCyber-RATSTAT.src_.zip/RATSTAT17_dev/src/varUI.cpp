/*********************************************************************************
 *
 * FILE: varUI.cpp
 *
 * COPYRIGHT (2017): J&J CyberSecurity LLC   http://www.jjcybersecurity.com
 * All Rights Reserved 
 * 
 * This file implements the user interface for Attribtue Appraisal
 * for RAT-STATS 2017 as specified in the Challenge Documentation.
 *
 * implements the following function:
 *
 * VarValidateBox -- validates that inputs satify additional contraints
 *                         beyond standard data typing of input boxes
 * VarCallbackProc -- Dialog InputBox Callback
 * CreateUnresVarWindow -- Create Input Dialog for Unrestricted Variables
 * CreateStratVarWindow -- Create Input Dialog for Stratified Varialbes
 * VarResultsProc -- Handler for results pop-up dialog box
 * AttrShowResults -- Display Pop-up results dialog box
 *
 *********************************************************************************/
#include "util.h"
#include "winUtil.h"
#include "resource.h"
#include "functions.h"
#include "printText.h"
#include "var.h"
#include "SheetData.h"
#include "excelWrapper.h"
#include <ctime>
#include <iostream>
#include <sstream>
#include <fstream>



// Pop-up hints for controls
static TOOLTIPINIT unresVarToolTips[] = {
  {IDT_AUDIT_NAME,TEXT("Enter name of this audit/review.")},
  {IDT_UNIV,TEXT("Enter universe size")},
  {IDT_SAMP,TEXT("Enter sample size")},
  {0,TEXT("")}
};


bool VarValidateBox(HWND hWnd, int id) {
  bool res=true;
  if(!ValidateBox(hWnd,id)) res = false;  
  return res;
}


// Wrapper for Dilaog Box
//  A lot of this is standard, see DIALOG SPECIFIC section for where to edit when copied
//

INT_PTR CALLBACK VarCallbackProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
  //  TOOLTIPINIT *toolTips = unresVarToolTips;
  static Selection selection;
  static bool enableSave = false;
  //  TCHAR myCookie1[] = {TEXT("ABCD")};
  wchar_t msg[BUFSIZE];
  char asciiMsg[BUFSIZE];	    

  bool result = false;
  switch (uMsg) {
  case WM_COMMAND: {
    switch (HIWORD (wParam))
      {
      case EN_SETFOCUS:		
      case EN_UPDATE:{
        int id = LOWORD(wParam);	 	  
	ValidateBox(hWnd,id);
	result= false;   
	break;
      }

      case EN_KILLFOCUS: {

        int id = LOWORD(wParam);
	// order matters here, it may hide warning
	enableSave= ValidateDialogSave(hWnd,NULL) && VarValidateBox(hWnd,id);
	// Should Focus go to Save?
	HWND hSaveCtrl = GetDlgItem(hWnd,IDB_VIEW);	  
	if(hSaveCtrl != NULL) {
	  Button_Enable(hSaveCtrl, enableSave);
	}
	hSaveCtrl = GetDlgItem(hWnd,IDB_SAVE);	  
	if(hSaveCtrl != NULL) {
	  Button_Enable(hSaveCtrl, enableSave);
	}

	  

	  /*	  HWND hCtrl = GetDlgItem(hWnd,id);
	  	  HWND hNextCtrl=GetNextDlgTabItem(hWnd,hCtrl,false);
	  	  int nextId = GetDlgCtrlID(hNextCtrl);
	  	  if(nextId == IDB_CLEAR) {
	    DebugString(TEXT("Change focus from Clear to Save"));
	    SetDialogFocus(hWnd,hSaveCtrl);
	  } else if (nextId == IDB_SAVE) {
	    DebugString(TEXT("Change focus from Save to Save"));	   
	    SetDialogFocus(hWnd,hSaveCtrl);
	    break;
	    }
	    }*/
	result= false;
	break;
      }
 
      default:  {
	switch (LOWORD(wParam))
	  {
   
	    
	  case IDB_CLEAR: {
	    ClearDialog(hWnd);
	    enableSave=ValidateDialogSave(hWnd,NULL);	    
	    result = false;
	    break;
	  }
	  case IDB_SAVE:
	  case IDB_VIEW: {
	    int hr;
	    HWND hCtrl;
	    DebugString(L"Save or View hit");
	    
	    if(!ValidateDialogSave(hWnd,NULL)) {
	      //	      HWND hCtrl = GetDlgItem(hWnd,IDB_SAVE);
	      DebugString(TEXT("Failed to save"));
	      MessageBox(hWnd,TEXT("At least one field is incomplete or incorrect"),TEXT("Warning"),
			 MB_OK |MB_ICONWARNING );
	      result = false;
	      break;
	    }
	    uint64_t universe, sampleSize;	    
	    hCtrl = GetDlgItem(hWnd,IDT_AUDIT_NAME);	    
	    hr = Edit_GetText(hCtrl,selection.auditName,80);
	    if(!SUCCEEDED(hr)) {
	      result = false;
	      break;
	    }

	    hCtrl = GetDlgItem(hWnd,IDT_STRATA);
	    result=GetNonNegInt(hCtrl,&selection.numStrata);
	    if(!result){
	      result = false;
	      break;
	    }	    
	    
	    hCtrl = GetDlgItem(hWnd,IDT_UNIV);
	    result=GetNonNegInt(hCtrl,&universe);
	    if(!result){
	      result = false;
	      break;
	    }
	    selection.results[0].univ = universe;
	    
	    hCtrl = GetDlgItem(hWnd,IDT_SAMP);
	    result=GetNonNegInt(hCtrl,&sampleSize);
	    if(!result){
	      result = false;
	      break;
	    }

	    
	    selection.results[0].samp = sampleSize;	    
	    // Call calculation routine
	    // then if VIEW/SAVE choose appropriate function

	    Process(&selection);


	    if(LOWORD(wParam) == IDB_SAVE) {	    
	      // Get File Name
	      int numExt=2;
	      wchar_t const * sarr1[]={L"Excel Workbook",L"Formatted Text",};
	      wchar_t const * sarr2[]={L"*.xlsx",L"*.txt"};
	      wchar_t const stitle[200]=L"Enter Name of Save File";
	      wchar_t saveFileName[BUFSIZE]=L"*.txt";

	      if (!c_SaveFileDialog(saveFileName,200,stitle,sarr1,numExt,sarr2,numExt,   //numExt is filter length
				    FOS_STRICTFILETYPES,hWnd)) {
		break;
	      }
	      
	      size_t saveFnameLen=wcslen(saveFileName);
	      int  extFound = -1;
	      for(int i=0;i<numExt;i++) {
		size_t extLen = wcslen(sarr2[i])-1;
		if((saveFnameLen > extLen) &&
		   (wcsncmp(saveFileName+saveFnameLen-extLen,sarr2[i]+1,extLen)==0)) {
		  extFound = i;
		  break;
		}
	      }
	      
	      switch (extFound) {
	      case 0:
		VarAnalysisPrintXlsx(saveFileName, &selection);
		break;
	      default:
		VarAnalysisPrintText(saveFileName, &selection);
		break;
	      }
	      wsprintf(msg,L"Data saved to file: %s",saveFileName);
	      MessageBox(hWnd,msg,L"File Save Successful",MB_OK);
	    } else {  // Was VIEW
	      DialogBoxParam(g_hInst, MAKEINTRESOURCE(IDD_VAR_ANALYSIS_RESULTS),
			     hWnd, &VarResultsProc, (LPARAM)(&selection));
	    }
	    // HERE


	    break;
	  }

	  case IDB_SELECT: {
	    // *********************************************************************
	    // START DIALOG SPECIFIC
	    //Get values from all dialogs -- could probably be more efficient

	    // Get File Name
	    ClearSelection(&selection);
	    HWND hCtrl;
	    int hr;

	    int numExt = 3;
	    TCHAR const * arr1[]={TEXT("Excel Files"),TEXT("Text Files"),TEXT("All Files")};
	    TCHAR const * arr2[]={TEXT("*.xlsx"),TEXT("*.txt"),TEXT("*.*")};
	    TCHAR const title[200]=TEXT("Enter Name of Input File");
	    TCHAR fileName[BUFSIZE]={TEXT("")};
	    
	    if (!c_OpenFileDialog(fileName,200,title,arr1,numExt,arr2,numExt,
				 FOS_STRICTFILETYPES,hWnd)) {
	      result = false;
	      break;
	    }
	    
	    hCtrl = GetDlgItem(hWnd,IDT_FILENAME);	    
	    hr = Edit_SetText(hCtrl,fileName);
	    ShowWindow(hCtrl,SW_SHOW);
	    if(!SUCCEEDED(hr)) {
	      result = false;
	      break;
	    }

	    if(IsExcelSpreadSheet(fileName)) {
	      if(!ProcessSpreadSheet(fileName, &selection)) return NULL;

	      //Open IDW_EXCEL_VAR Dialog, populate with sheets & use this reference
	      // Keep dialog going until selection is made?
	      //	    UnresVarExcelDialog(excel,sheetData);

	      DialogBoxParam(g_hInst, MAKEINTRESOURCE(IDD_EXCELVAR_DIALOG),
			     hWnd, &ExcelDialogProc, (LPARAM)(&selection));	    

	      
	    } else {
	      if(!ProcessTextInput(fileName, &selection)) return NULL;
	      //Open IDW_TEXTVAR Dialog, populate with sheets & use this reference
	      // Keep dialog going until selection is made?
	      //	    UnresVarExcelDialog(excel,sheetData);
  
	      DialogBoxParam(g_hInst, MAKEINTRESOURCE(IDD_TEXTVAR_DIALOG),
			     hWnd, &TextInputDialogProc, (LPARAM)(&selection));	    
	      
	    }

	    
	    VarResults *totRes = &selection.results[0];
  
	    // GetSums and update boxes
	    DebugString(L"	    // Get number of Strata, Sums and update boxes");
	    GetStrata(&selection);
	    DebugString(L"After GetStrata");
	    GetSums(&selection);
	    hCtrl = GetDlgItem(hWnd,IDT_NONZERO_DIFF);	    
	    if(totRes->nonZero[DIFF] >=0) {
	      wsprintf(msg,L"%d",totRes->nonZero[DIFF]);
	      Edit_SetText(hCtrl,msg);
	    } else {
	      wsprintf(msg,L"N/A");
	      Edit_SetText(hCtrl,msg);
	    }
	    for(uint32_t i=0;i<3;i++) {
	      hCtrl = GetDlgItem(hWnd,IDT_SUM+i);
	      
	      if(selection.fFormat != FALL && selection.id != i) { // no data 
		wsprintf(msg,L"N/A");
		Edit_SetText(hCtrl,msg);
	      } else {
		
		sprintf(asciiMsg,"sums[%d] = %.2f",i,totRes->sums[i]);
		mbstowcs(msg,asciiMsg,BUFSIZE);
		DebugString(msg);
		SPrintDblComma(msg,totRes->sums[i],2);
		Edit_SetText(hCtrl,msg);		  
	      }
	    }
  
	    hCtrl = GetDlgItem(hWnd,IDT_SAMP);
	    wsprintf(msg,L"%d",totRes->samp);
	    Edit_SetText(hCtrl,msg);
	    
	    hCtrl = GetDlgItem(hWnd,IDT_STRATA);	    
	    if(!selection.unrestricted) {
	      wsprintf(msg,L"%d",selection.numStrata);
	      Edit_SetText(hCtrl,msg);
	    } else {
	      selection.numStrata=1;
	      wsprintf(msg,L"1");
	      Edit_SetText(hCtrl,msg);
	    }
	    
	    hCtrl = GetDlgItem(hWnd,IDT_UNIV);	    
	    if(totRes->univ >=0) {
	      wsprintf(msg,L"%d",totRes->univ);
	      Edit_SetText(hCtrl,msg);
	    }
	    break;

	    // END DIALOG SPECIFIC
	    // *********************************************************************	    
	  }	    
	  case IDCANCEL: {
	    EndDialog(hWnd, (INT_PTR) LOWORD(wParam));
	    SetActiveChildWnd(GetSplash());
	    ShowWindow(GetActiveChildWnd(),SW_SHOW);	      	      
	    result = true;
	    break;
	  }
	  }
	    
	break;
      }
      }
    
    break;
  }
    //Not a Command, so something else

  case WM_INITDIALOG: {
    HWND hCtrl;
    selection.unrestricted = (bool)lParam;
    if(selection.unrestricted) {
      hCtrl=GetDlgItem(hWnd,ID_STATIC_TITLE1);
      Edit_SetText(hCtrl,L"Unrestricted Variable Appraisal");
      hCtrl=GetDlgItem(hWnd,IDT_STRATA);
      ShowWindow(hCtrl,SW_HIDE);
      hCtrl = GetDlgItem(hWnd,ID_STATIC_STRAT);
      ShowWindow(hCtrl,SW_HIDE);
      
    } else {
      hCtrl=GetDlgItem(hWnd,ID_STATIC_TITLE1);
      Edit_SetText(hCtrl,L"Stratified Variable Appraisal");
      hCtrl=GetDlgItem(hWnd,IDT_STRATA);
      ShowWindow(hCtrl,SW_SHOW);
      hCtrl = GetDlgItem(hWnd,ID_STATIC_STRAT);
      ShowWindow(hCtrl,SW_SHOW);
      
    }
    

    
    SetFocus(hWnd);
    result = false;
  }
  }

  return (INT_PTR) result;
}

void CreateStratVarWindow(HINSTANCE hInstance, HWND hWnd) {
  static HWND hChildWnd = NULL;

  if(hChildWnd == NULL) {
    DebugString(TEXT("Making Instance")); // just once make instance to prevent memory leakage
    hChildWnd=CreateDialogParam(hInstance,
			   MAKEINTRESOURCE(IDW_VAR_SUMMARY),
			   hWnd, &VarCallbackProc,(LPARAM)false);
  }

  SetActiveChildWnd(hChildWnd);
  ClearDialog(hChildWnd);

  TOOLTIPINIT *toolTips = unresVarToolTips;
  
  int index=0;
  while (toolTips[index].id !=0) {
    toolTips[index].ptrToolTip =
      CreateToolTip(toolTips[index].id,hChildWnd,toolTips[index].text);
    index++;
  }
  
  ShowWindow(hChildWnd, SW_SHOW);
}  

void CreateUnresVarWindow(HINSTANCE hInstance, HWND hWnd) {
  static HWND hChildWnd = NULL;

  if(hChildWnd == NULL) {
    DebugString(TEXT("Making Instance")); // just once make instance to prevent memory leakage
    hChildWnd=CreateDialogParam(hInstance,
			   MAKEINTRESOURCE(IDW_VAR_SUMMARY),
				hWnd, &VarCallbackProc,(LPARAM)true);
  }

  SetActiveChildWnd(hChildWnd);
  ClearDialog(hChildWnd);

  TOOLTIPINIT *toolTips = unresVarToolTips;
  
  int index=0;
  while (toolTips[index].id !=0) {
    toolTips[index].ptrToolTip =
      CreateToolTip(toolTips[index].id,hChildWnd,toolTips[index].text);
    index++;
  }
  
  ShowWindow(hChildWnd, SW_SHOW);
}  




void ResetSelection(Selection *selection, int index, int strata) {
  selection->results[strata].col[index]=-1;
  selection->results[strata].row[index]=-1;
  selection->results[strata].sheet[index]=-1;
  selection->cell[index][0]=0;
}


 
   
INT_PTR CALLBACK VarResultsProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) 
{
  static int64_t strat, id;
  static Selection *selection;

  switch (uMsg)
    {
    case WM_COMMAND: {
      switch (LOWORD(wParam))
	{
	case IDOK:
	case IDCANCEL: {
	  EndDialog(hWnd, (INT_PTR) LOWORD(wParam));
	  return (INT_PTR) TRUE;
	}
	case IDB_MORE: {
	  id = (id +1) % 3;
	  VarShowResults(hWnd,selection,strat,id);
	  return (INT_PTR) TRUE;
	}

	  // strat [0] is Overallvar
	case IDB_NEXT_STRATA: {
	  strat = (strat +1) % (selection->numStrata+1);
	  if(strat==0) strat=1;
	  id=0;  // reset to Examined
	  VarShowResults(hWnd,selection,strat,id);
	  return (INT_PTR) TRUE;
	}

	case IDB_PREV_STRATA: {
	  strat = strat -1;
	  if(strat<=0) strat=selection->numStrata;	  	  
	  VarShowResults(hWnd,selection,strat,id);
	  return (INT_PTR) TRUE;
	}

	case IDB_OVERALL: {
	  strat =0;
	  VarShowResults(hWnd,selection,strat,id);
	  return (INT_PTR) TRUE;
	}	  	  	  
	}
      break;
    }
      
    case WM_INITDIALOG: {
      strat=0;
      selection = (Selection *)lParam;

      HWND hCtrl;
      wchar_t res[100];
      char asciiRes[100];
      time_t timeNow = time(NULL);
      
      struct tm *now = localtime(&timeNow);      
      strftime(asciiRes,14,"%#m/%d/%Y",now);
      mbstowcs(res,asciiRes,80);
  
      id = selection->id;
      
      hCtrl=GetDlgItem(hWnd,IDT_DATE);	        
      Edit_SetText(hCtrl,res);

      strftime(asciiRes,14,"%H:%M",now);
      mbstowcs(res,asciiRes,80);
      hCtrl=GetDlgItem(hWnd,IDT_TIME);	        
      Edit_SetText(hCtrl,res);

      DebugString(L"Names");      
      hCtrl=GetDlgItem(hWnd,IDT_AUDIT_NAME);	        
      Edit_SetText(hCtrl,selection->auditName);
      
      hCtrl=GetDlgItem(hWnd,IDT_FILENAME);	        
      Edit_SetText(hCtrl,selection->fileName);            


      // Hide Prev/Next/Overall Strata Selection if not needed
 
      if(selection->unrestricted) {
	hCtrl=GetDlgItem(hWnd,IDB_NEXT_STRATA);
	ShowWindow(hCtrl,SW_HIDE);
	hCtrl=GetDlgItem(hWnd,IDB_PREV_STRATA);
	ShowWindow(hCtrl,SW_HIDE);
	hCtrl = GetDlgItem(hWnd,IDB_OVERALL); // disable OVERALL options
	ShowWindow(hCtrl,SW_HIDE);    
	
      } else {
	hCtrl=GetDlgItem(hWnd,ID_STATIC_TITLE1);	
	Edit_SetText(hCtrl,L"Stratified Variable Appraisal");
      }
      VarResults *results = &selection->results[0];

      hCtrl=GetDlgItem(hWnd,IDT_UNIV);
      SPrintComma(res,results->univ);      
      Edit_SetText(hCtrl,res);

      hCtrl=GetDlgItem(hWnd,IDT_SAMP);
      SPrintComma(res,results->samp);      
      Edit_SetText(hCtrl,res);

      VarShowResults(hWnd, selection, strat, id);
      return (INT_PTR) FALSE;
    }
    }
  
  return (INT_PTR) FALSE;
}


void VarShowResults(HWND hWnd, Selection * selection, int64_t strat, int64_t id) {

  VarResults *results = &(selection->results[strat]);
  HWND hCtrl;
  wchar_t res[100];
  char asciiRes[100];


  const wchar_t *dataTypes[]= {L"Examined Values",L"Audited Values",L"Difference Values"};

  hCtrl=GetDlgItem(hWnd,ID_STATIC_STRATUM);
  if(strat==0) 
    wsprintf(res,L"(Overall)");
  else 
    wsprintf(res,L"(Stratum %d)",strat);
  Edit_SetText(hCtrl,res);      

  hCtrl=GetDlgItem(hWnd,IDT_UNIV);
  SPrintComma(res,results->univ);      
  Edit_SetText(hCtrl,res);

  hCtrl=GetDlgItem(hWnd,IDT_SAMP);
  SPrintComma(res,results->samp);      
  Edit_SetText(hCtrl,res);        	      
  
  hCtrl=GetDlgItem(hWnd,IDT_POINT_EST);
  SPrintComma(res,(int64_t)round(results->pointEst[id]));      
  Edit_SetText(hCtrl,res);      
  
  hCtrl=GetDlgItem(hWnd,ID_STATIC_DATATYPE);
  Edit_SetText(hCtrl,dataTypes[id]);  
  
  hCtrl=GetDlgItem(hWnd,IDT_MEAN);
  SPrintDblComma(res,results->mean[id],2);      
  Edit_SetText(hCtrl,res);
  
  hCtrl=GetDlgItem(hWnd,IDT_SKEW);
  SPrintDblComma(res,results->skew[id],2);      
  Edit_SetText(hCtrl,res);

  hCtrl=GetDlgItem(hWnd,IDT_STDDEV);
  SPrintDblComma(res,results->stdDev[id],2);      
  Edit_SetText(hCtrl,res);
  
  hCtrl=GetDlgItem(hWnd,IDT_KURT);
  SPrintDblComma(res,results->kurtosis[id],2);      
  Edit_SetText(hCtrl,res);

  hCtrl=GetDlgItem(hWnd,IDT_NON_ZERO);
  SPrintComma(res,results->nonZero[id]);      
  Edit_SetText(hCtrl,res);  

  hCtrl=GetDlgItem(hWnd,IDT_STDERR_MEAN);
  SPrintDblComma(res,results->stdErr[id],2);      
  Edit_SetText(hCtrl,res);                        

  hCtrl=GetDlgItem(hWnd,IDT_STDERR_TOT);
  SPrintComma(res,(int64_t)round((results->stdErr[id]*results->univ)));
  Edit_SetText(hCtrl,res);

  if(selection->fFormat != FALL) {
    hCtrl = GetDlgItem(hWnd,IDB_MORE); // disable more options
    ShowWindow(hCtrl,SW_HIDE);
  }
  
  for(int i=0;i<3;i++) {
    hCtrl=GetDlgItem(hWnd,IS_CONF_LOW+i);
    SPrintComma(res,results->confLow[id][i]);
    Edit_SetText(hCtrl,res);
    hCtrl=GetDlgItem(hWnd,IS_CONF_HI+i);
    SPrintComma(res,results->confHi[id][i]);
    Edit_SetText(hCtrl,res);

    hCtrl=GetDlgItem(hWnd,IS_PREC+i);
    SPrintComma(res,(int64_t)results->precision[id][i]);
    Edit_SetText(hCtrl,res);

    hCtrl=GetDlgItem(hWnd,IS_PREC_PER+i);
    sprintf(asciiRes,"%.2f%%",100*results->precision[id][i]/results->pointEst[id]);
    mbstowcs(res,asciiRes,50);
	//SPrintDblComma(res,100*results->precision[id][i]/results->pointEst[id],2);    
    Edit_SetText(hCtrl,res);

    hCtrl=GetDlgItem(hWnd,IS_TVAL+i);
    sprintf(asciiRes,"%.12f",results->tVal[i]);
    mbstowcs(res,asciiRes,50);
    Edit_SetText(hCtrl,res);            
    
  }
}

