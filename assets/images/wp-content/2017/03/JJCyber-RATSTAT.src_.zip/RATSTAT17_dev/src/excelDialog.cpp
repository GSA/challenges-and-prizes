/*********************************************************************************
 *
 * FILE: excelDialog.cpp
 *
 * COPYRIGHT (2017): J&J CyberSecurity LLC   http://www.jjcybersecurity.com
 * All Rights Reserved 
 * 
 *
 * This file implements the functional code for excel (and text file)
 * data selection dialog box. For an excel Dialog, this is two listboxes
 * one for Worksheet names and one for rows and columns of data. For text
 * it is just the one list box of rows and columns of data
 *
 * implements the following functions
 *   UpdateExcelContents -- show contents of specified Worksheet (file)
 *
 *  
 *
 *********************************************************************************/
#include "util.h"
#include "winUtil.h"
#include "resource.h"
#include "functions.h"
#include "SheetData.h"
#include "var.h"

// Parameters for Worksheet contents listbox
#define maxNumCol 10
#define maxNumRow 10  
#define colWidth 11

/*****************************************************
 * Function: UndateExcelContents
 *  show contents of specified Worksheet (file)
 *
 * parameters:
 *   hCtrl : Parent window
 *   selId : identifier of selected worksheet
 *   contents : work

 *****************************************************/

void UpdateExcelContents(HWND hCtrl,CellContents **contents) {

  int itemsPerCol = GetListBoxInfo(hCtrl);
  ListBox_SetCurSel(hCtrl,-1);

  if(contents == NULL) {

    return;
  }
  
  while(ListBox_DeleteString(hCtrl,0) != LB_ERR); // delete all
  wchar_t listStrings[maxNumRow][maxNumCol][colWidth];

  //  DebugString(L"Update zeroing/initializing listbox");  
  for(uint32_t row =0;row<maxNumRow;row++) {
    if(row < maxNumRow) {
      for(uint32_t col=0;col<maxNumCol;col++) {
	listStrings[row][col][0]=L'\0';
      }
    }
  }

  //  DebugString(L"Update loading values to local variables");
  wchar_t tmpString[colWidth];  
  for (uint32_t i=0;contents[i]!=0;i++) {
    mbstowcs(tmpString,contents[i]->Value(),colWidth-1);
    tmpString[colWidth-1]=L'\0';

    if (contents[i]->Row() < maxNumRow && contents[i]->Col() < maxNumCol && (contents[i]->Row() <= itemsPerCol)) {
      wcsncpy(listStrings[contents[i]->Row()][contents[i]->Col()],tmpString,colWidth-1);
      listStrings[contents[i]->Row()][contents[i]->Col()][colWidth-1]=L'\0';    
    }
  }

  //  DebugString(L"Update listbox adding strings");      
  // Remember Excel row count start at 1
  for(int col=0;col<maxNumCol;col++)
    for (int row=1;row<=itemsPerCol;row++) {
      if(row <= maxNumRow)
	ListBox_AddString(hCtrl,listStrings[row][col]);
      else
	ListBox_AddString(hCtrl,L"...");	
    }

  ListBox_SetCurSel(hCtrl,0);
  SendNotifyMessage(hCtrl,WM_COMMAND,
		    MAKEWPARAM(ID_EXCEL_CONTENTS,LBN_SELCHANGE),
		    (LPARAM)hCtrl);  
}

//***************************************************************************
// Pop-up hints for controls in main input dialog
// Notice here the numbering scheme Since we allow for three types of data:
//   Examined, Audited and Differences,
//   and two types of Stratum size data: Universe size and Stratum size,
// We use a base value plus offset to select specific input boxes. These
// offsets are used in other code and allow for easier future changes
//***************************************************************************
static TOOLTIPINIT excelVarToolTips[] = {
  {IDT_EXCEL_SHEET+AUDIT,TEXT("Click here to select the Excel Sheet Name from the list below")},
  {IDT_EXCEL_SHEET+EXAM,TEXT("Click here to select the Excel Sheet Name from the list below")},
  {IDT_EXCEL_SHEET+DIFF,TEXT("Click here to select the Excel Sheet Name from the list below")},
  {IDT_EXCEL_SHEET+STRAT_UNIV,TEXT("Click here to select the Excel Sheet Name from the list below")},
  {IDT_EXCEL_SHEET+STRAT_SIZE,TEXT("Click here to select the Excel Sheet Name from the list below")},    
  {IDT_EXCEL_CELL+AUDIT,TEXT("Click here to select the starting Data Cell the list below")},
  {IDT_EXCEL_CELL+EXAM,TEXT("Click here to select the starting Data Cell the list below")},
  {IDT_EXCEL_CELL+DIFF,TEXT("Click here to select the starting Data Cell the list below")},
  {IDT_EXCEL_CELL+STRAT_UNIV,TEXT("Click here to select the starting Data Cell the list below")},
  {IDT_EXCEL_CELL+STRAT_SIZE,TEXT("Click here to select the starting Data Cell the list below")},    
  {0,TEXT("")}
};


/*****************************************************
 * Function: Excel Dialog Proc
 *   Handler for this Pop-Up Dialog box for input from
 *   Excel File
 *
 *****************************************************/

INT_PTR CALLBACK ExcelDialogProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) 
{
  TOOLTIPINIT *toolTips = excelVarToolTips;  
  bool result=false,enableSave=false, check=false;
  static int lastFocus=0;
  static SheetData **sheetData;
  static Selection *selection;
  static VarResults *results;
  static const char** excelContents;
  int32_t fFlags[3];
  fFlags[AUDIT]=FAUDIT;
  fFlags[EXAM]=FEXAM;
  fFlags[DIFF]=FDIFF;
  
  switch (uMsg)
    {
    case WM_COMMAND:
      {
	switch (HIWORD (wParam)) {

	case LBN_SELCHANGE:
	case LB_SETCURSEL:{
	  switch (LOWORD(wParam)) {
	    // Process what happens when user selects a Sheet from the
	    // Worksheet Listbox	    
	  case ID_EXCEL_SHEET_LIST: {
	    int index=0;
	    HWND hCtrl = (HWND)lParam;
	    int selId = ListBox_GetCurSel(hCtrl);
	    wchar_t selText[BUFSIZE];
	    ListBox_GetText(hCtrl,selId,selText);

	    // Redraw the contents listbox to reflect new worksheet
	    // Put worksheet name in appropiate data box

	    hCtrl = GetDlgItem(hwnd,ID_EXCEL_CONTENTS);	      
	    UpdateExcelContents(hCtrl,sheetData[selId]->Cells());

	    if(lastFocus!=0) {
	      hCtrl = GetDlgItem(hwnd,lastFocus);
	      Edit_SetText(hCtrl,selText);
	      ShowWindow(hCtrl,true);

	      if((lastFocus & IDT_EXCEL_SHEET) == IDT_EXCEL_SHEET) {
		index = lastFocus & ~IDT_EXCEL_SHEET;
	      }
	      results->sheet[index]=selId;
	      
	    }
	    result = TRUE;
	    break;
	  }

	    // Process what happens when user selects a Cell from
	    // the contents Listbox
	    //
	  case ID_EXCEL_CONTENTS: {
	    wchar_t msg[BUFSIZE];
	    HWND hCtrl = (HWND)lParam;
	    int selId = ListBox_GetCurSel(hCtrl);
	    DWORD itemsPerCol = GetListBoxInfo(hCtrl);	      
	    wchar_t selCol[3];
	    uint32_t colNum=selId/itemsPerCol;
	    int index=0;
	    DebugString(L"Sel change start");
	    if(colNum>26) {
	      selCol[0]=(wchar_t)('A'+colNum/26);
	      selCol[1]=(wchar_t)('A'+colNum%26);
	      selCol[2]=0;
	    } else {
	      selCol[0]=(wchar_t)('A'+colNum);
	      selCol[1]=0;
	    }
	    int focus=lastFocus;

	    // Place cell identifier in correct data box.
	    // If we had previously clicked on the worksheet
	    // selection box, move over to cell selection box
	    if((focus & IDT_EXCEL_SHEET) == IDT_EXCEL_SHEET) {
	      focus = focus & ~IDT_EXCEL_SHEET | IDT_EXCEL_CELL;
	    }
	    HWND cellCtrl=GetDlgItem(hwnd,focus);
	    if(cellCtrl !=0) {
	      index = focus & ~IDT_EXCEL_CELL;

	      results->col[index]=colNum;
	      results->row[index]=selId%itemsPerCol+1;	    	      
	      sprintf(selection->cell[index],"%ls%d",selCol,selId%itemsPerCol+1);
	      wsprintf(msg,L"%ls%d",selCol,selId%itemsPerCol+1);
	      Edit_SetText(cellCtrl,msg);
	      
	    } else {
	      Edit_SetText(cellCtrl,L"Duh..");
	    }
	    result = TRUE;
	    break;
	  }
	  }
	  break;
	}

	  // Process what happen when a button was clicked
        case BN_CLICKED: {
	  int id;
	  HWND hCtrl, hCtrlSheet, hCtrlCell;
	  bool isChecked;
	  wchar_t msg[BUFSIZE];
	  result = false;
	  hCtrl = (HWND)lParam;
	  id = (LOWORD(wParam));

	  switch (id) {
	  case ID_VAR_AUDIT_CHK:
	  case ID_VAR_EXAM_CHK:
	  case ID_VAR_DIFF_CHK:
	  case ID_VAR_STRAT_UNIV_CHK:
	  case ID_VAR_STRAT_SIZE_CHK:	    
	    {
	      int excelSheet=0, excelCell=0,index=0;

	      // If user clicked a check box, enable/disable the cells of the
	      // cooresponding data input boxes
	      if((id & IS_VAR_CHK) == IS_VAR_CHK ) {
		index = id - IS_VAR_CHK;
		excelSheet = IDT_EXCEL_SHEET+index;
		excelCell = IDT_EXCEL_CELL+index;
	      }
	      isChecked = !(Button_GetCheck(hCtrl) == BST_CHECKED);
	      Button_SetCheck(hCtrl,isChecked);
	      hCtrlSheet=GetDlgItem(hwnd,excelSheet);
	      Edit_Enable(hCtrlSheet,isChecked);
	      hCtrlCell=GetDlgItem(hwnd,excelCell);
	      Edit_Enable(hCtrlCell,isChecked);	    
	      if(isChecked) {
		Edit_SetText(hCtrlSheet,TEXT("Click to Choose"));
		Edit_SetText(hCtrlCell,TEXT("Click to Choose"));
		if(index <3) {	      
		  selection->fFormat |= fFlags[index];
		  wsprintf(msg,L"Step fFormat = 0x%03x",selection->fFormat);
		  DebugString(msg);
		}
	      } else {
		// unclicked so reset selection to nothing
		Edit_SetText(hCtrlSheet,TEXT(""));
		Edit_SetText(hCtrlCell,TEXT(""));
		ResetSelection(selection,index,0);	      
		if(index<3){
		  selection->fFormat &= ~fFlags[index];
		  wsprintf(msg,L"Step fFormat = 0x%03x",selection->fFormat);
		  DebugString(msg);
		}

	      }	    
	      check=true;
	      result = true;
	      break;
	    }
	    // Should call validate here for Done
	  case IDB_DONE:
	  case IDCANCEL: {
	    EndDialog(hwnd, (INT_PTR) LOWORD(wParam));
	    result = true;
	    break;
	  }
	  case IDB_CLEAR: {
	    ClearDialog(hwnd);
	    enableSave=false;
	    result = false;
	    break;
	  }
	  case IDB_SAVE: {
	    break;
	  }
	  }
	  break;
	
	}
	  // Process clicking on an input box
	case EN_SETFOCUS: {

	  HWND hCtrl = GetDlgItem(hwnd,ID_EXCEL_CONTENTS);
	  ListBox_Enable(hCtrl,false);
	  hCtrl = GetDlgItem(hwnd,ID_EXCEL_SHEET_LIST);
	  ListBox_Enable(hCtrl,false);	    	  	  
	  lastFocus=(LOWORD(wParam));

	  // The following enables the listboxes and copies selected item over
	  hCtrl = GetDlgItem(hwnd,ID_EXCEL_SHEET_LIST);
	  ListBox_Enable(hCtrl,true);	  
	  if(ListBox_GetCurSel(hCtrl) == LB_ERR) {
	    ListBox_SetCurSel(hCtrl,0);
	  }
	  SendNotifyMessage(hwnd,WM_COMMAND,
			    MAKEWPARAM(ID_EXCEL_SHEET_LIST,LBN_SELCHANGE),
			    (LPARAM)hCtrl);
	  
	  if((lastFocus & IDT_EXCEL_SHEET) == IDT_EXCEL_SHEET) {
	    SetFocus(hCtrl);	    
	  }

	  hCtrl = GetDlgItem(hwnd,ID_EXCEL_CONTENTS);
	  ListBox_Enable(hCtrl,true);	  
	  if(ListBox_GetCurSel(hCtrl) == LB_ERR) {
	    ListBox_SetCurSel(hCtrl,0);
	  }
	  SendNotifyMessage(hwnd,WM_COMMAND,
			    MAKEWPARAM(ID_EXCEL_CONTENTS,LBN_SELCHANGE),
			    (LPARAM)hCtrl);
	  
	  if((lastFocus & IDT_EXCEL_CELL) == IDT_EXCEL_CELL) {
	    SetFocus(hCtrl);	    
	  }
	  result = false;	    
	  break;
	}
	default: {
	  DebugString(L"Other command?");	  
	  switch (LOWORD(wParam)) {
	  case IDOK:
	  case IDCANCEL:
	    {
	      EndDialog(hwnd, (INT_PTR) LOWORD(wParam));
	      result = true;
	      return (INT_PTR) TRUE;
	    }
	  }
	}
	  break;
	}
	    
	break;
	
      }
      
      // Initialize the Pop-up dialog. This is called when dialog box
      // first created
    case WM_INITDIALOG:
      selection = (Selection*)lParam;
      selection->numStrata=1;
      results = &selection->results[0];
      sheetData = selection->sheetData;
      for (int i=0;i<3;i++) 
	ResetSelection(selection,i,0);

      HWND hCtrl = GetDlgItem(hwnd,ID_EXCEL_SHEET_LIST);
      wchar_t tmpMsg[BUFSIZE];

      for (int i=0;sheetData[i] !=0;i++) {
	mbstowcs(tmpMsg,sheetData[i]->SheetName(),BUFSIZE);
	DebugString(tmpMsg);
	ListBox_AddString(hCtrl,tmpMsg);
      }

      // ListBox_SetSel is for multi selection,
      // ListBox_SetCurSel for single selection
      //      ListBox_SetCurSel(hCtrl,0);

      hCtrl = GetDlgItem(hwnd,ID_EXCEL_CONTENTS);
      ListBox_SetColumnWidth(hCtrl,90);
      UpdateExcelContents(hCtrl,sheetData[0]->Cells());
      int index=0;

      // Set up tool tips
      while (toolTips[index].id !=0) {
	toolTips[index].ptrToolTip =
	  CreateToolTip(toolTips[index].id,hwnd,toolTips[index].text);
	index++;
      }

      if(selection->unrestricted) {
	for (int i=0;i<2;i++) {
	  //remove STRAT Check boxes and Data boxes for unrestricted var Appraisal
	  hCtrl=GetDlgItem(hwnd,IS_EXCEL_STRAT_SHEET+i);
	  ShowWindow(hCtrl,SW_HIDE);
	  hCtrl=GetDlgItem(hwnd,IS_EXCEL_STRAT_CELL+i);
	  ShowWindow(hCtrl,SW_HIDE);
	  hCtrl=GetDlgItem(hwnd,IS_VAR_STRAT_CHK+i);	  
	  ShowWindow(hCtrl,SW_HIDE);	  
	}
	result = false;
      }
    }

  // we selected a check box -- should hide excel dialogs to be safe
  if(check) {
    HWND hCtrl;
    hCtrl = GetDlgItem(hwnd,ID_EXCEL_SHEET_LIST);
    ListBox_Enable(hCtrl,false);
    hCtrl = GetDlgItem(hwnd,ID_EXCEL_CONTENTS);
    ListBox_Enable(hCtrl,false);	          
  }    

  return (INT_PTR) result;
}



/*****************************************************
 * Function: TextInputDialogProc
 *   Handler for this Pop-Up Dialog box for input from
 *   Text File
 *
 * Similar to Excel one, but no worksheet listbox
 * and need to select Strata Input File if Stratified 
 * Variable Appraisal
 *
 *****************************************************/

INT_PTR CALLBACK TextInputDialogProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) 
{
  TOOLTIPINIT *toolTips = excelVarToolTips;  
  bool result=false,enableSave=false, check=false, strataSelected=false;
  static int lastFocus=0;
  static SheetData **sheetData;
  static Selection *selection;
  static VarResults *results;
  static const char** excelContents;
  TCHAR strataFileName[BUFSIZE]={TEXT("")};

  
  int32_t fFlags[3];
  fFlags[AUDIT]=FAUDIT;
  fFlags[EXAM]=FEXAM;
  fFlags[DIFF]=FDIFF;
  
  switch (uMsg)
    {
    case WM_COMMAND:
      {
	switch (HIWORD (wParam)) {
	case LBN_SELCHANGE:
	case LB_SETCURSEL:{
	  switch (LOWORD(wParam)) {	  

	  case ID_EXCEL_CONTENTS: {   // Not actually EXCEL But we use the same box
	    wchar_t msg[BUFSIZE];
	    HWND hCtrl = (HWND)lParam;
	    int selId = ListBox_GetCurSel(hCtrl);
	    DWORD itemsPerCol = GetListBoxInfo(hCtrl);	      
	    wchar_t selCol[3];
	    uint32_t colNum=selId/itemsPerCol;
	    int index=0;
	    DebugString(L"Sel change start");
	    if(colNum>26) {
	      selCol[0]=(wchar_t)('A'+colNum/26);
	      selCol[1]=(wchar_t)('A'+colNum%26);
	      selCol[2]=0;
	    } else {
	      selCol[0]=(wchar_t)('A'+colNum);
	      selCol[1]=0;
	    }
	    wsprintf(msg,L"Results changed to id #%d, at: %s%d",selId,selCol,selId%itemsPerCol+1);
	    DebugString(msg);
	    DebugString(L"Sel change next");
	    int focus=lastFocus;

	    HWND cellCtrl=GetDlgItem(hwnd,focus);
	    if(cellCtrl !=0) {
	      index = focus & ~IDT_EXCEL_CELL;
	      results->col[index]=colNum;
	      results->row[index]=selId%itemsPerCol+1;	    	      
	      sprintf(selection->cell[index],"%ls%d",selCol,selId%itemsPerCol+1);
	      wsprintf(msg,L"%ls%d",selCol,selId%itemsPerCol+1);
	      Edit_SetText(cellCtrl,msg);
	      if(index <3) results->sheet[index]=0; // for data sheet
	      else results->sheet[index]=1; // for strata sheet
	      
	    } else {
	      Edit_SetText(cellCtrl,L"Duh..");
	    }
	    result = TRUE;
	    break;
	  }
	  }
	  break;
	}
	  
        case BN_CLICKED: {
	  int id;
	  HWND hCtrl, hCtrlCell;
	  bool isChecked;
	  wchar_t msg[BUFSIZE];
	  result = false;
	  DebugString(L"Button clicked");
	  hCtrl = (HWND)lParam;
	  id = (LOWORD(wParam));

	  switch (id) {
	  case ID_VAR_AUDIT_CHK:
	  case ID_VAR_EXAM_CHK:
	  case ID_VAR_DIFF_CHK:
	  case ID_VAR_STRAT_UNIV_CHK:
	  case ID_VAR_STRAT_SIZE_CHK:	    
	    {
	      int excelCell=0,index=0;

	      if((id & IS_VAR_CHK) == IS_VAR_CHK ) {
		index = id - IS_VAR_CHK;
		excelCell = IDT_EXCEL_CELL+index;
		wsprintf(msg,L"Good:: id is 0x%x, IS_VAR_CHK is 0x%x\n",id,IS_VAR_CHK);
		DebugString(msg);	      
	      } else {
		wsprintf(msg,L"Error :: id is 0x%x, IS_VAR_CHK is 0x%x\n",id,IS_VAR_CHK);
		DebugString(msg);
	      }

	      isChecked = !(Button_GetCheck(hCtrl) == BST_CHECKED);
	      Button_SetCheck(hCtrl,isChecked);

	      hCtrlCell=GetDlgItem(hwnd,excelCell);
	      Edit_Enable(hCtrlCell,isChecked);	    
	      if(isChecked) {
		Edit_SetText(hCtrlCell,TEXT("Click to Choose"));
		if(index <3) {	      
		  selection->fFormat |= fFlags[index];
		  hCtrl = GetDlgItem(hwnd,ID_EXCEL_CONTENTS);	      		
		  UpdateExcelContents(hCtrl,sheetData[0]->Cells()); // For data
		  hCtrl = GetDlgItem(hwnd,ID_STATIC_TITLE1);
		  Edit_SetText(hCtrl,L"Data File Contents");		
		} else {
		  hCtrl = GetDlgItem(hwnd,ID_EXCEL_CONTENTS);	      		
		  UpdateExcelContents(hCtrl,sheetData[1]->Cells()); // For strata data				
		  hCtrl = GetDlgItem(hwnd,ID_STATIC_TITLE1);
		  Edit_SetText(hCtrl,L"Strata Sizes File Contents");		
		}

	      
	      } else {
		// unclicked so reset selections
		Edit_SetText(hCtrlCell,TEXT(""));
		ResetSelection(selection,index,0);	      
		if(index<3){
		  selection->fFormat &= ~fFlags[index];
		  wsprintf(msg,L"Step fFormat = 0x%03x",selection->fFormat);
		  DebugString(msg);
		}

	      }	    
	      check = true;
	      result = true;
	      break;
	    }
	  case IDB_DONE:
	  case IDCANCEL:
	    {
	      wsprintf(msg,L"Finished with fFormat = 0x%03x",selection->fFormat);
	      DebugString(msg);
	      EndDialog(hwnd, (INT_PTR) LOWORD(wParam));
	      result = true;
	      break;
	    }
	  case IDB_CLEAR: {
	    ClearDialog(hwnd);
	    enableSave=false;
	    result = false;
	    break;
	  }
	  case IDB_SAVE: {
	    break;
	  }
	  case IDB_SELECT: {

	    int numExt = 2;
	    TCHAR const * arr1[]={TEXT("Text Files"),TEXT("All Files")};
	    TCHAR const * arr2[]={TEXT("*.txt"),TEXT("*.*")};
	    TCHAR const title[]=TEXT("Enter Name of Strata Data File");

	    DebugString(L"Open File");
	    if (!c_OpenFileDialog(strataFileName,200,title,arr1,numExt,arr2,numExt,
				  FOS_STRICTFILETYPES,hwnd)) {
	      result = false;
	      DebugString(L"Open File failed!!");	      
	      break;
	    }
	    DebugString(L"Open File done");
	    DebugString(strataFileName);	    
	    strataSelected = true;
	    // Get data

	    std::vector<std::vector<double>> contents=GetTextInputContents(strataFileName);	      
	    int numRows=(int)contents[0][0];
	    sheetData[1]=new SheetData(numRows*3);
	    sheetData[1]->SetName("Default");
	    
	    CellContents **cells = sheetData[1]->Cells();
	    if(cells==NULL) {
	      DebugString(TEXT("Null Cells"));
	      return false;
	    }
  
	    for(int row=1;row<=numRows;row++)
	      for (int col=0; col < 3; col++) {
		sheetData[1]->AddCell(row,col,contents[row][col]);		
	      }  
	    for (int i=0;i<2;i++) {
	      //enable STRAT Check boxes and Data boxes
	      hCtrl=GetDlgItem(hwnd,IS_VAR_STRAT_CHK+i);	  
	      EnableWindow(hCtrl,true);	  
	    }
	  
	    break;
	  }
	  }
	  break;
	}
	case EN_SETFOCUS: {
	  DebugString(L"Got a Focus");
	  HWND hCtrl = GetDlgItem(hwnd,ID_EXCEL_CONTENTS);
	  ListBox_Enable(hCtrl,false);
	  lastFocus=(LOWORD(wParam));

	  // The following enables the box and copies selected item over
	  hCtrl = GetDlgItem(hwnd,ID_EXCEL_CONTENTS);
	  ListBox_Enable(hCtrl,true);	  
	  if(ListBox_GetCurSel(hCtrl) == LB_ERR) {
	    ListBox_SetCurSel(hCtrl,0);
	  }
	  SendNotifyMessage(hwnd,WM_COMMAND,
			    MAKEWPARAM(ID_EXCEL_CONTENTS,LBN_SELCHANGE),
			    (LPARAM)hCtrl);
	  
	  if((lastFocus & IDT_EXCEL_CELL) == IDT_EXCEL_CELL) {
	    SetFocus(hCtrl);	    
	  }
	  result = false;	    
	  break;
	}
	default: {
	  DebugString(L"Other command?");	  
	  switch (LOWORD(wParam)) {
	  case IDOK:
	  case IDCANCEL:
	    {
	      EndDialog(hwnd, (INT_PTR) LOWORD(wParam));
	      result = true;
	      return (INT_PTR) TRUE;
	    }
	  }
	}
	}
	    
	break;
	
      }

      //Not a WM_COMMAND
    case WM_INITDIALOG: {
      selection = (Selection*)lParam;
      selection->numStrata=1;
      results = &selection->results[0];
      sheetData = selection->sheetData;
      for (int i=0;i<3;i++) 
	ResetSelection(selection,i,0);

      HWND hCtrl;

      hCtrl = GetDlgItem(hwnd,ID_EXCEL_CONTENTS);
      ListBox_SetColumnWidth(hCtrl,90);
      UpdateExcelContents(hCtrl,sheetData[0]->Cells());
      hCtrl = GetDlgItem(hwnd,ID_STATIC_TITLE1);
      Edit_SetText(hCtrl,L"Data File Contents");
      
      int index=0;
      DebugString(L"Starting this 3");      
      while (toolTips[index].id !=0) {
	toolTips[index].ptrToolTip =
	  CreateToolTip(toolTips[index].id,hwnd,toolTips[index].text);
	index++;
      }

      if(selection->unrestricted) {
	hCtrl=GetDlgItem(hwnd,IDB_SELECT);
	ShowWindow(hCtrl,SW_HIDE);      
	for (int i=0;i<2;i++) {
	  //remove STRAT Check boxes and Data boces
	  hCtrl=GetDlgItem(hwnd,IS_EXCEL_STRAT_CELL+i);
	  ShowWindow(hCtrl,SW_HIDE);
	  hCtrl=GetDlgItem(hwnd,IS_VAR_STRAT_CHK+i);	  
	  ShowWindow(hCtrl,SW_HIDE);	  
	}
	result = false;
      } else {
	for (int i=0;i<2;i++) {
	  //remove STRAT Check boxes and Data boces
	  hCtrl=GetDlgItem(hwnd,IS_VAR_STRAT_CHK+i);	  
	  EnableWindow(hCtrl,false);	  
	}
	result = false;
      }	

    }
    }

  // we selected a check box -- should hide excel dialogs to be safe
  if(check) {
    HWND hCtrl;
    hCtrl = GetDlgItem(hwnd,ID_EXCEL_CONTENTS);
    ListBox_Enable(hCtrl,false);	          
  }    

  return (INT_PTR) result;
}

