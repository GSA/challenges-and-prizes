/*********************************************************************************
 *
 * FILE: sheetData.cpp
 *
 * COPYRIGHT (2017): J&J CyberSecurity LLC   http://www.jjcybersecurity.com
 * All Rights Reserved 
 * 
 * 
 * This file implements the CellContents and SheetData classes
 * for RAT-STATS 2017,
 *
 *********************************************************************************/

#include"util.h"
#include"SheetData.h"


/********************************************************************************************/
/************************************* CellContents *****************************************/
/********************************************************************************************/

int CellContents::numIds=0;


/*****************************************************
 * Function: CellContents
 *
 * Constructor for CellContents object given strings
 *
 *****************************************************/

CellContents::CellContents(const char* ref, const char * val, const char* data_t) {
  CellContents::cellReference = ref;
  CellContents::value = val;
  CellContents::dataType = data_t;
  CellContents::col = ref[0]-'A';
  CellContents::id = CellContents::numIds++;
  sscanf(&ref[1],"%d",&(CellContents::row));
}


/*****************************************************
 * Function: CellContents
 *
 * Constructor for CellContents object given numbers
 *  integer column (0..n) and row (1..n) 
 *  double value
 *
 *****************************************************/
CellContents::CellContents(int row, int col, double val) {

  char *ref1,*ref2;
  ref1 = new char[40];
  ref2 = new char[40];
  snprintf(ref1,40,"%c%d",'A'+col,row);

  
  CellContents::cellReference = ref1;
  if(col==0)   // column 0 is row number or unique ID
    snprintf(ref2,40," %d",(int32_t)val);
  else
    snprintf(ref2,40,"%.2f",val);    
    
  CellContents::value = ref2;
  CellContents::dataType = "Number";
  CellContents::col = col;
  CellContents::row=row;
  CellContents::id = CellContents::numIds++;

}

/*****************************************************
 * Function: CellContents
 *
 * Constructor for CellContents object given array of 3 strings
 *
 *****************************************************/
CellContents::CellContents(const char* contents[3]): CellContents(contents[0],contents[1],contents[2]) {}


/*****************************************************
 * Function: ~CellContents()
 *
 * destructor for CellContents object
 *
 *****************************************************/
CellContents::~CellContents() {
  wchar_t msg[80];
  wsprintf(msg,L"Deleting CellContents %d",CellContents::id);
  DebugString(msg);
}


/*****************************************************
 *
 * These functions return CellContents data
 * 
 *****************************************************/
int CellContents::Row() { return CellContents::row;}
int CellContents::Col() {return CellContents::col;}
const char * CellContents::Value() {return CellContents::value;}
const char* CellContents::DataType()  {return CellContents::dataType;}
const char* CellContents::CellReference() {return CellContents::cellReference;}



/********************************************************************************************/
/************************************* SHEET DATA *******************************************/
/********************************************************************************************/

/*****************************************************
 * Function: SheetData
 *
 * Constructor for SheetData object, with an initial cell count
 *
 *****************************************************/
SheetData::SheetData(int cellCount) {
  numCells=0;
  maxCells = cellCount;
  cells = new CellContents*[cellCount+1];
}

/*****************************************************
 * Function: ~SheetData
 *
 * destructor for SheetData object
 *
 *****************************************************/
SheetData::~SheetData() {
  DebugString(L"Deleting SheetData");}

/*****************************************************
 * Function: AddCell
 *
 * Add specified contents as new cell.
 * Assumes input is array of 3 strings 
 * (cellReference, cellValue and cellData type
 *****************************************************/
CellContents *SheetData::AddCell(const char ** contents) {
  CellContents *cell = new CellContents(contents);
  SheetData::cells[SheetData::numCells++]=cell;
  SheetData::cells[numCells]=0;
  return cell;
}


/*****************************************************
 * Function: AddCell
 *
 * Add specified values as new cells
 *
 *****************************************************/
CellContents *SheetData::AddCell(int row, int col, double val) {
  CellContents *cell = new CellContents(row, col, val);
  SheetData::cells[SheetData::numCells++]=cell;
  SheetData::cells[numCells]=0;
  return cell;
}


/*****************************************************
 * Function: SetName
 *
 * Sets name of sheet
 *
 *****************************************************/
void SheetData::SetName(const char * name) {
  SheetData::sheetName=name;
}


/*****************************************************
 * Function: SheetName
 *
 * Gets name of sheet
 *
 *****************************************************/
  
const char* SheetData::SheetName() {
  if(sheetName == 0) return "Default";
  else return SheetData::sheetName;
}


/*****************************************************
 * Function: Cells
 *
 * Gets array of all cell contents.
 *
 *****************************************************/
CellContents** SheetData::Cells(){return SheetData::cells;}

  
