/*********************************************************************************
 *
 * FILE: rndUI.cpp
 *
 * COPYRIGHT (2017): J&J CyberSecurity LLC   http://www.jjcybersecurity.com
 * All Rights Reserved 
 * 
 * 
 * This file implements the user interface for Random Number Generaton
 * for RAT-STATS 2017 as specified in the Challenge Documentation.
 *
 * implements the following function:
 *
 * RndValidateBox -- validates that inputs satify additional contraints
 *                         beyond standard data typing of input boxes
 * RndCallbackProc -- Dialog InputBox Callback
 * CreateRndWindow -- Create Input Dialog for Attributes
 * AttrResultsProc -- Handler for results pop-up dialog box
 * AttrShowResults -- Display Pop-up results dialog box
 *
 *********************************************************************************/
#include "util.h"
#include "winUtil.h"
#include "resource.h"
#include "functions.h"
#include "printText.h"
#include <ctime>


// Identifiers used for 1 through 4 variables. Could have done this more generically.

int lowIds[]={IDT_LOW1,IDT_LOW2,IDT_LOW3,IDT_LOW4};
int hiIds[]={IDT_HI1,IDT_HI2,IDT_HI3,IDT_HI4};
int titleIds[] = {ID_STATIC_TITLE1,ID_STATIC_TITLE2,ID_STATIC_TITLE3,ID_STATIC_TITLE4};
int varIds[] = {ID_STATIC_VAR1,ID_STATIC_VAR2,ID_STATIC_VAR3,ID_STATIC_VAR4};



// Pop-up hints for controls
static TOOLTIPINIT toolTips[] = {
  {IDT_AUDIT_NAME,L"Enter name of this audit/review."},
  {IDT_NUMSEQ,L"Enter number of random values in sequential order"},
  {IDT_NUMRND,L"Enter number of spare values in random order"},
  {IDT_SEED,L"Enter optional seed"},
  {IDT_LOW1,L"Enter smallest universe value for the set"},
  {IDT_LOW2,L"Enter smallest universe value for the second set"},
  {IDT_LOW3,L"Enter smallest universe value for the third set"},
  {IDT_LOW4,L"Enter smallest universe value for the fourth set"},
  {IDT_HI1,L"Enter largest universe value for the set"},
  {IDT_HI2,L"Enter largest universe value for the second set"},
  {IDT_HI3,L"Enter largest universe value for the third set"},
  {IDT_HI4,L"Enter largest universe value for the fourth set"},  
  {0,L""}
};


/*****************************************************
 * Function: RndValidateBox
 *   Validates additional constraints for the window
 *   Uses standard validation plus app-specific
 *
 * parameters:
 *   hWnd : Parent window
 *   id : identifier of box to validate

 *****************************************************/
bool RndValidateBox(HWND hWnd, int id) {
  // use standard validation
  HWND hCtrl;
  bool res1, res2, res=true;
  uint64_t hi, low;  


  //Make sure box is initially valid
  if(!ValidateBox(hWnd,id)) res = false;

  // Is IDT_HIx larger than IDT_LOWx  
  if (id == IDT_HI1) {

    hCtrl = GetDlgItem(hWnd,IDT_LOW1);        
    res1=GetNonNegInt(hCtrl,&low);

    hCtrl = GetDlgItem(hWnd,IDT_HI1);    
    res2=GetNonNegInt(hCtrl,&hi);

    if(!(res1&&res2)) res = false;
    else {
      if (hi <= low) {
        BalloonPlain(hCtrl,L"High value must be greater than low value");
        res=false;
      }
    }
  }

  else if (id == IDT_HI2) {
    hCtrl = GetDlgItem(hWnd,IDT_LOW2);        
    res1=GetNonNegInt(hCtrl,&low);
    hCtrl = GetDlgItem(hWnd,IDT_HI2);    
    res2=GetNonNegInt(hCtrl,&hi);
    if(!(res1&&res2)) res = false;
    else if (hi <= low) {
      BalloonPlain(hCtrl,L"High value must be greater than low value");
      res=false;
    }
  } 

  int warnId = (id & (~ID_CLASS_MASK)) | IS_WARN;
  // show/HIDE  Warning
  hCtrl = GetDlgItem(hWnd,warnId);
  if(res) {
    ShowWindow(hCtrl,FALSE);
  }
  else {
    ShowWindow(hCtrl,TRUE);
  }
  return res;
}



/*****************************************************
 * Function: RndCallbackProc
 *   Handler for Dilaog Box
 *
 * parameters:
 *   hWnd : Parent window
 *   id : identifier of box to validate
 *
 * A lot of this is standard, see DIALOG SPECIFIC section for where
 * to edit when copied
 *
 *****************************************************/
// result of false says the callback handled the command, a true says that windows
// should still look at it ??
//
int numVars;
INT_PTR CALLBACK RndCallbackProc(HWND hWnd, UINT uMsg, WPARAM wParam,
                                 LPARAM // lParam --ignored
                                 )
  
{
  static bool enableSave = false;
  
  int optList[] = {IDT_SEED,0};
  
  bool result = false;
  switch (uMsg) {
  case WM_COMMAND: {
    switch (HIWORD (wParam))
      {
      case EN_SETFOCUS:
        break;
      case EN_UPDATE:{
        int id = LOWORD(wParam);                  
        ValidateBox(hWnd,id);
        result= false;   
        break;
      }

      case EN_KILLFOCUS: {
        int id = LOWORD(wParam);
        // order matters here, it may hide warning
	// also need to ignore Optional boxes (like seed)
        enableSave= RndValidateBox(hWnd,id);
        enableSave = ValidateDialogSave(hWnd,optList) && enableSave;
        // Should Focus go to Save?
        HWND hSaveCtrl = GetDlgItem(hWnd,IDB_SAVE);       
        if(hSaveCtrl != NULL) {
          Button_Enable(hSaveCtrl, enableSave);
        }

        result= false;
        break;
      } 
        
      default:  {
        switch (LOWORD(wParam))
          {
          case IDB_CLEAR: {
            ClearDialog(hWnd);
            enableSave=false;
            result = false;
            break;
          }
          case IDB_SAVE: {
            if(!ValidateDialogSave(hWnd,optList)) {
              //              HWND hCtrl = GetDlgItem(hWnd,IDB_SAVE);
              MessageBox(hWnd,L"At least one field is incomplete or incorrect",L"Warning",
                         MB_OK |MB_ICONWARNING );
              result = false;
              break;
            }

// START DIALOG SPECIFIC
// Get values from all dialog boxes -- could probably be more efficient
//
	    RndResults results;
	    results.numVars = numVars;
            int hr;
            wchar_t resStr[80];
            HWND hCtrl;
            //Get values from all dialogs -- could probably be more efficient
            hCtrl = GetDlgItem(hWnd,IDT_AUDIT_NAME);        
            hr = Edit_GetText(hCtrl,results.auditName,80);
            if(!SUCCEEDED(hr)) {
              result = false;
              break;
            }
            
            hCtrl = GetDlgItem(hWnd,IDT_SEED);
            hr = Edit_GetText(hCtrl,resStr,80);
            
            if(hr == 0) { // no seed entered, use clock value
              results.seed=(double)GetTickCount64();
            } else {
              result=ParseNonNegDouble(resStr,&results.seed);
              if(!result) break;
            }

            results.seed=round(results.seed*100)/100;
            // Need to round seed to nearest 100th
            
            
            hCtrl = GetDlgItem(hWnd,IDT_NUMSEQ);            
            result=GetNonNeg32Int(hCtrl,&results.numSeq);
            if(!result){
              result = false;
              break;
            } 

            hCtrl = GetDlgItem(hWnd,IDT_NUMRND);
            result=GetNonNeg32Int(hCtrl,&results.numRnd);
            if(!result){
              result = false;
              break;
            }

            for (uint32_t i=0;i<results.numVars;i++) {
              hCtrl = GetDlgItem(hWnd,lowIds[i]);
              result=GetNonNeg32Int(hCtrl,&(results.lowRange[i]));
              if(!result) {
                result = false;
                break;
              }
              hCtrl = GetDlgItem(hWnd,hiIds[i]);
              result=GetNonNeg32Int(hCtrl,&(results.hiRange[i]));
              if(!result) {
                result = false;
                break;
              }       
            }


            // Get File Name
            int numExt=3;
            wchar_t const * arr1[]={L"CSV (Comma Delimited)",L"Excel Workbook",L"Formatted Text",};
            wchar_t const * arr2[]={L"*.csv",L"*.xlsx",L"*.txt"};
            wchar_t const title[200]=L"Enter Name of Save File";
            wchar_t fileName[BUFSIZE]=L"*.txt";
            
            if (!c_SaveFileDialog(fileName,200,title,arr1,numExt,arr2,numExt,   //numExt is filter length
                                  FOS_STRICTFILETYPES,hWnd)) {
              break;
            }
            results.randNum=(randoms *)calloc(results.numSeq+results.numRnd,sizeof(randoms));
            genRnd(&results);
            results.frameSize =1;
            for (int i=0;i<numVars;i++) {
              results.frameSize = results.frameSize*(results.hiRange[i]-results.lowRange[i]+1);
            }
            size_t fnameLen=wcslen(fileName);
            int  extFound = -1;
            for(int i=0;i<numExt;i++) {
              size_t extLen = wcslen(arr2[i])-1;
              if((fnameLen > extLen) && (wcsncmp(fileName+fnameLen-extLen,arr2[i]+1,extLen)==0)) {
                extFound = i;
                break;
              }
            }

	    wchar_t msg[BUFSIZE];
            switch (extFound) {
            case 0:
              break;

	    case 1:
	      if(!RndPrintXlsx(fileName,&results)) {
		wsprintf(msg,L"Data NOT Saved to File: %s",fileName);
		
		MessageBox(hWnd,msg,L"File Save Failure",MB_ICONERROR | MB_OK);
	      } else {
		results.fileName = fileName;
		DialogBoxParam(g_hInst, MAKEINTRESOURCE(IDD_RND_RESULTS),
			       hWnd, &RndResultsProc, (LPARAM)(&results));
	      }
              break;
            default:
              if(!RndPrintText(fileName,&results)) {
		wsprintf(msg,L"Data NOT Saved to File: %s",fileName);
		MessageBox(hWnd,msg,L"File Save Failure",MB_ICONERROR | MB_OK);
	      } else {
		results.fileName = fileName;		
		DialogBoxParam(g_hInst, MAKEINTRESOURCE(IDD_RND_RESULTS),
			       hWnd, &RndResultsProc, (LPARAM)(&results));
	      }
	    }
			
            free(results.randNum);
	    
            break;
          }

// END DIALOG SPECIFIC
            
          case IDCANCEL: {
            EndDialog(hWnd, (INT_PTR) LOWORD(wParam));
            SetActiveChildWnd(GetSplash());
            ShowWindow(GetActiveChildWnd(),SW_SHOW);                  
            result = true;
            break;
          }
          }
            
        break;
      }
      }
    
    break;
  }


  case WM_INITDIALOG: {
    SetFocus(hWnd);
    result = false;
  }
  }

  return (INT_PTR) result;
}


/*****************************************************
 * Function: Set/Get ActiveChildWnd
 *
 *  Used to change which window is active. Mostly used
 * to go from menu item to Splash.
 *
 *****************************************************/

// FIX THIS FOR EACH MENU CHOICE
static HWND hActiveChildWnd;
void SetActiveChildWnd(HWND child) {
  hActiveChildWnd=child;
}

HWND GetActiveChildWnd() {
  return hActiveChildWnd;
}

/*****************************************************
 * Function: CreateUnresAttrWindow
 *   DialogBox creation rounting
 *
 *  This will probably be unique for each menu item
 *  So that it can specify parameters
 *
 *****************************************************/

// FIX THIS FOR EACH MENU CHOICE

void CreateRndWindow(HINSTANCE hInstance, HWND hWnd, int menuSelect) {
  static HWND hChildWnd = NULL;

  int numVarSpec= menuSelect-IS_RND_MENU;
  
  if(hChildWnd == NULL) {
    hChildWnd=CreateDialog(hInstance,
                           MAKEINTRESOURCE(IDW_RND),
                           hWnd, &RndCallbackProc);
  }     

  numVars = numVarSpec;
  SetActiveChildWnd(hChildWnd);

  //hide unused titles and vars

  HWND hCtrl;
  for (int index=0; index < maxVars; index++) {
    // hide unused titles
    if(index != numVars-1) {
      hCtrl = GetDlgItem(hChildWnd,titleIds[index]);
      if(hCtrl != NULL) {
        ShowWindow(hCtrl, SW_HIDE);
      }
    } else {
      hCtrl = GetDlgItem(hChildWnd,titleIds[index]);
      if(hCtrl != NULL) ShowWindow(hCtrl, SW_SHOW);
    }
   
    // hide unused low and hi var entry boxes, and titles
    if(index > numVars-1) {
      hCtrl = GetDlgItem(hChildWnd,lowIds[index]);
      if(hCtrl != NULL) {
        ShowWindow(hCtrl, SW_HIDE);
      }
      hCtrl = GetDlgItem(hChildWnd,hiIds[index]);
      if(hCtrl != NULL) ShowWindow(hCtrl, SW_HIDE);
      hCtrl = GetDlgItem(hChildWnd,varIds[index]);
      if(hCtrl != NULL) ShowWindow(hCtrl, SW_HIDE);            
    } else {
      hCtrl = GetDlgItem(hChildWnd,lowIds[index]);
      if(hCtrl != NULL) ShowWindow(hCtrl, SW_SHOW);
      hCtrl = GetDlgItem(hChildWnd,hiIds[index]);
      if(hCtrl != NULL) ShowWindow(hCtrl, SW_SHOW);
      hCtrl = GetDlgItem(hChildWnd,varIds[index]);
      if(hCtrl != NULL) ShowWindow(hCtrl, SW_SHOW);            
    }     
    //  hit Var title if only one var
    if(numVars == 1) {
      hCtrl = GetDlgItem(hChildWnd,varIds[0]);
      if(hCtrl != NULL) ShowWindow(hCtrl, SW_HIDE);           
    }

  }

  ClearDialog(hChildWnd);
  hCtrl = GetNextDlgGroupItem(hChildWnd,NULL,FALSE);
  
  hCtrl = GetNextDlgTabItem(hChildWnd,hCtrl,FALSE);           
  int initialId = GetDlgCtrlID(hCtrl);
  int id = initialId;

  do
    {
      if(id == IDT_SEED) {
        Edit_SetCueBannerText(hCtrl,L"Opt. Non-Neg #");
      } else if((id & ID_MASK) == IS_NONNEG_INT) {
        Edit_SetCueBannerText(hCtrl,L"Non-negative #");           
      } else if((id & ID_MASK) == IS_INTEGER) {
        Edit_SetCueBannerText(hCtrl,L"Integer");
      } else if((id & ID_MASK) == IS_FLOAT) {
        Edit_SetCueBannerText(hCtrl,L"Number");
      }
      hCtrl = GetNextDlgTabItem(hChildWnd,hCtrl,FALSE);
      if(hCtrl == NULL) break;
      id = GetDlgCtrlID(hCtrl);
    } while (id != initialId);


  //Set toolTips 
    
  int index=0;
  while (toolTips[index].id !=0) {
    toolTips[index].ptrToolTip =
      CreateToolTip(toolTips[index].id,hChildWnd,toolTips[index].text);
    index++;
  }
  
  ShowWindow(hChildWnd, SW_SHOW);
}


/*****************************************************
 * Function: RndResultsProc
 *   Handler for Dialog With Results of Random Generation
 *
 *  This will probably be unique for each results dialog
 *  In this case it is pretty generic
 *
 *****************************************************/


INT_PTR CALLBACK RndResultsProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
  
  RndResults *results;
  switch (uMsg)
    {
    case WM_COMMAND: {
      switch (LOWORD(wParam))
        {
        case IDOK:
        case IDCANCEL: {
          EndDialog(hWnd, (INT_PTR) LOWORD(wParam));
          return (INT_PTR) TRUE;
        }
        }
      break;
    }
    case WM_INITDIALOG: {
      results = (RndResults *)lParam;

      RndShowResults(hWnd, results);
      
      return (INT_PTR) FALSE;
    }
    }

  return (INT_PTR) FALSE;
}

/*****************************************************
 * Function: RndShowResults
 *   Display Pop-up Dialog Box With Results of Generation
 *
 * parameters:
 *   hWnd : Parent window
 *   results : data structure containing results of generation
 *
 *  This will probably be unique for each menu choice  
 *  or could possibly be parameterized
 *
 *****************************************************/


wchar_t *sets[] = {L"One",L"Two",L"Three",L"Four"};

void RndShowResults(HWND hWnd, RndResults * results) {
  HWND hCtrl;
  wchar_t res[BUFSIZE];
  char asciiRes [BUFSIZE];
  time_t timeNow = time(NULL);
      
  struct tm *now = localtime(&timeNow);

  // Set text requires unicode (wide) strings
  // Time function only works regular char strings
  // So store result in regular ascii string
  // and then convert to wide character string
  
  strftime(asciiRes,14,"%#m/%d/%Y",now);
  mbstowcs(res,asciiRes,BUFSIZE);

  // Get dialog box handle
  // and set text
  hCtrl=GetDlgItem(hWnd,IDT_DATE);              
  Edit_SetText(hCtrl,res);
  
  strftime(asciiRes,14,"%H:%M",now);
  mbstowcs(res,asciiRes,BUFSIZE);
  hCtrl=GetDlgItem(hWnd,IDT_TIME);              
  Edit_SetText(hCtrl,res);


  hCtrl=GetDlgItem(hWnd,IDT_AUDIT_NAME);
  Edit_SetText(hCtrl,results->auditName);  
  
  hCtrl=GetDlgItem(hWnd,IDT_UNIV);
  SPrintComma(res,results->frameSize);
  Edit_SetText(hCtrl,res);
  
  hCtrl=GetDlgItem(hWnd,IDT_QUANT);
  SPrintComma(res,results->count);  
  Edit_SetText(hCtrl,res);
  
  hCtrl=GetDlgItem(hWnd,IDT_SEED);
  SPrintDblComma(res,results->seed,2);    
  Edit_SetText(hCtrl,res);

  hCtrl=GetDlgItem(hWnd,IDT_FILE_NAME);
  Edit_SetText(hCtrl,results->fileName);  


  if(results->numVars == 1) {
    hCtrl=GetDlgItem(hWnd,IDT_SUM);
    SPrintComma(res,results->sum);    
    Edit_SetText(hCtrl,res);
    ShowWindow(hCtrl,SW_SHOW);    
    hCtrl=GetDlgItem(hWnd,ID_STATIC_TITLE1);
    Edit_SetText(hCtrl,L"Single Stage Random Number Generation");
    hCtrl=GetDlgItem(hWnd,ID_STATIC_TITLE2);
    ShowWindow(hCtrl,SW_SHOW);        
  } else {
    hCtrl=GetDlgItem(hWnd,IDT_SUM);
    ShowWindow(hCtrl,SW_HIDE);
    hCtrl=GetDlgItem(hWnd,ID_STATIC_TITLE2);
    ShowWindow(hCtrl,SW_HIDE);    

    hCtrl=GetDlgItem(hWnd,ID_STATIC_TITLE1);
    wsprintf(res,L"Random Number Generator -- Sets of %ls",sets[results->numVars-1]);
    Edit_SetText(hCtrl,res);
  }
  ShowWindow(hWnd, SW_SHOW);          
}
  
