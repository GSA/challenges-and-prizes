/*********************************************************************************
 *
 * FILE: rnd.cpp
 *
 * COPYRIGHT (2017): J&J CyberSecurity LLC   http://www.jjcybersecurity.com
 * All Rights Reserved 
 * 
 * 
 * This file provide the functions necessary to execute the 
 * Random Number Functions specified in the RAT-STATS
 * challenge documents.
 *
 * Provides functions that emulate random number generation features of 
 * Ms Excel's Visual Basic
 *
 *********************************************************************************/
#include"util.h"
#include "rnd.h"


/*****************************************************
 * Function: ExcelRand64
 *
 * Given a specified 64-bit seed, generate a pseudo 
 * random number, not to exceed "outputmax". 
 *
 * Returns a structure with a new seed, and the output values
 *****************************************************/
returnHelp ExcelRand64(int64_t excelSeed, int64_t outputmax) {
  returnHelp returnVal;
  int64_t vara = excelSeed;
  uint64_t varb = 1140671485;
  uint64_t varc = 12820163;
  bool firstflag = true;
  double valueA = 0;

  while(valueA >= outputmax || firstflag) {
    firstflag = false;
    vara = excelSeed;
    excelSeed = (vara *varb +varc ) % TwoTo24;
    valueA = 1.0*outputmax*excelSeed/TwoTo24+1;
  }           
  returnVal.step = excelSeed;
  returnVal.excelOutput = 1.0*excelSeed / TwoTo24;
  returnVal.RATSTAT = valueA;
  return returnVal;
}

/*****************************************************
 * Function: ExcelRandInit
 *
 * Given a specified 4-byte number/seed, initialize the
 * random number generator
 *
 *****************************************************/
int32_t ExcelRandInit (float num){
  char bitStr[33];
  char newStr1[33],newStr2[33];
  FloatToBits(num,bitStr);
  bitStr[32]=0;
  strncpy(newStr1,&bitStr[24],8);
  strncpy(&newStr1[8],TwentyFour0s,24);
  newStr1[32]=0;
  strncpy(newStr2,bitStr,24);
  strncpy(&newStr2[24],Eight0s,8);
  newStr2[32]=0;
  int32_t res=BitsToInt(newStr1)+BitsToInt(newStr2);
  return res;
}


/*****************************************************
 * Function: ExcelRandomize64
 *
 * Given a specified 64-bit seed, generate a pseudo 
 * random number, using the specified inputs
 *
 * Duplicates internal functions of Excel's Visual Basic
 *****************************************************/
int64_t ExcelRandomize64(double startingPoint, int64_t excelSeed) {
  char testHelpTemp[65],bitList[33],bitSeed[33],moshedBitsA[33];
  int32_t vara,varb;

  DoubleToBits(startingPoint,testHelpTemp);
  strncpy(bitList,&testHelpTemp[32],32);
  bitList[32]=0;
  
  IntToBits((int32_t)excelSeed,bitSeed);
  strncpy(testHelpTemp,bitList,16);
  strncpy(&testHelpTemp[16],Sixteen0s,16);
  testHelpTemp[32]=0;
  vara = BitsToInt(testHelpTemp);

  strncpy(testHelpTemp,&bitList[16],16);
  strncat(testHelpTemp,Sixteen0s,16);
  testHelpTemp[32]=0;
  varb = BitsToInt(testHelpTemp);

  IntToBits(vara^varb,moshedBitsA);
  strncpy(testHelpTemp,Eight0s,8);
  strncpy(&testHelpTemp[8],moshedBitsA,16);
  strncpy(&testHelpTemp[24],Eight0s,8);
  testHelpTemp[32]=0;
  vara = BitsToInt(testHelpTemp);

  strncpy(testHelpTemp,bitSeed,8);
  strncpy(&testHelpTemp[8],TwentyFour0s,24);
  testHelpTemp[32]=0;
  varb = BitsToInt(testHelpTemp);
  return( vara | varb);
}


/*****************************************************
 * Function: Compare Values of random data structure lexically
 *
 * Data structure has internal array of random variables.
 * Sort these by comparing first, second, third... numbers 
 * between the two elements.
 *  
 * Examples:
 *  1,23,4  < 2,11,3  and 22,2,1 > 22,1,5
 *
 * Use this for quick sorting
 *
 *****************************************************/
int comp (const void * elem1, const void* elem2) {
  int32_t f,s;

  // compare lexically
  for(int i=0;i< maxVars; i++) {
    f=((randoms*)elem1)->values[i];
    s=((randoms*)elem2)->values[i];
    if (f > s) return 1;
    if (f < s) return -1;
  }
  return 0;
}

/*****************************************************
 * Function: qSortRandoms
 *
 * Quicksort random numbers in arrayof randoms data structure
 *
 *****************************************************/
void qsortRandoms(randoms randNums[], uint32_t numEntries) {
  qsort(randNums, numEntries, sizeof(randoms),comp);
}

/*****************************************************
 * Function: genRnd
 *
 * Generate an array of random numbers (randoms data strcuture)
 * within specified bounds
 *
 * The data structure can store multipl erandom variables, each
 * with its own bounds.
 *
 * Sort the first "results->numSeq" by value/random number(s) leave
 * the rest in generated order
 *
 *****************************************************/


void genRnd(RndResults *results) {

  //Emulates the three calls to the Visual Basic 6 function Rnd().
  int64_t currentSeed = 3758214;
  currentSeed = ExcelRandomize64(results->seed,currentSeed);
  uint32_t sampleSize=results->numSeq+results->numRnd;
  returnHelp ResA = ExcelRand64(currentSeed,30269);
  returnHelp ResB = ExcelRand64(ResA.step,30307);
  returnHelp ResC = ExcelRand64(ResB.step,30323);
  double seedA = floor(ResA.RATSTAT);
  double seedB = floor(ResB.RATSTAT);
  double seedC = floor(ResC.RATSTAT);
  int32_t value;
  randoms *randomNumbers = results->randNum;

  wchar_t msg[BUFSIZE];
  wsprintf(msg,L"Found addr of randNum as 0x%x and randomNumbers as 0x%x\n",results->randNum,randomNumbers);
  DebugString(msg);
  randoms ** repCheck=(randoms **)calloc(maxHash,sizeof(randoms *));

  results->sum = 0;
  value=0;
  results->count = 0;
  //  randomNumbers[440].index=441;
  for (uint32_t j=0;j<sampleSize;j++){
    bool repFlag=true;
    results->count++;
    while (repFlag) {
      randomNumbers[j].hashSum=0;
      randomNumbers[j].nextHash=NULL;      
      for (uint32_t varId =0; varId < results->numVars; varId++){
        double term1= floor(seedA/177);
        double term2= seedA - (177*term1);
        seedA = 171*term2 - 2*term1;
        if (seedA <= 0) seedA = seedA +30269;
      
        term1 = floor(seedB/176);
        term2 = seedB - (176*term1);
        seedB = 172*term2 - 35*term1;
        if (seedB <= 0) seedB = seedB +30307;
      
        term1 = floor(seedC/178);
        term2= seedC - (178*term1);
        seedC = 170*term2 - 63*term1;
        if (seedC <= 0) seedC = seedC +30323;
      
        double term4 = seedA/30269 +  seedB/30307 + seedC/30323;
        randomNumbers[j].index=j+1;
	value = (int32_t)((term4 - floor(term4))*
			  (results->hiRange[varId]-results->lowRange[varId]+1))+
          results->lowRange[varId];
	randomNumbers[j].values[varId]=value;
        randomNumbers[j].hashSum = (randomNumbers[j].hashSum +
                                    randomNumbers[j].values[varId]) % maxHash;
      }

      // Have a hash table of maxHash size, indexed by a hash sum
      // sume is sum of all random variables (1-4 of them in multi column)
      // modulo max hash. Result is pointer to a randoms struct.
      // Each randoms struct has a pointer to next with same hash sum
      // for a linked list
      //
      // look up first entry in hash table, may be null
      uint32_t hashIndex=randomNumbers[j].hashSum;
      randoms *nextHash=repCheck[hashIndex];
      // search for full duplicate (repFlag=true if repeated)
      repFlag=false;

      while(nextHash != NULL && !repFlag) {
        // compare returns 0 if same)
        if(comp((const void*)&(randomNumbers[j]),(const void*)nextHash)==0) {
          repFlag = true;
        }else {
          nextHash = nextHash->nextHash;
        }
      }
      // not repeated so put at front of hash linked list
      if(!repFlag) {
        randomNumbers[j].nextHash = repCheck[hashIndex];
        repCheck[hashIndex] = &(randomNumbers[j]);
      }
    }
    results->sum += value;
  }

  qsortRandoms(randomNumbers,results->numSeq);

  DebugString(L"End Rnd");  
  free(repCheck);
}
