/*********************************************************************************
 *
 * FILE: winmain.cpp
 *
 * COPYRIGHT (2017): J&J CyberSecurity LLC   http://www.jjcybersecurity.com
 * All Rights Reserved 
 * 
 * This file provides the main entry point for RAT-STATS 2017
 * GUI interface. Most of this is pretty standard application wrappers
 *
*********************************************************************************/

#include "util.h"
#include "resource.h"
#include "functions.h"

#include <windows.h>
#include <windowsx.h>
#include<Commctrl.h>
#include<Shobjidl.h>
#include <cstdbool>
#include <cstddef>
#include<cstring>

//
// forward declaration
//
extern "C" LRESULT CALLBACK MainWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

HWND hSplash;
HINSTANCE g_hInst;


/*********************************************************************************
*
* Function: WinMain
*
*
* Our application entry point.
*
*********************************************************************************/
int WINAPI WinMain(HINSTANCE hInstance,
		   HINSTANCE // hPrevInstance -- ignored
		   , LPSTR // lpCmdLine -- ignored
		   , int nCmdShow)
{
  INITCOMMONCONTROLSEX icc;
  WNDCLASSEX wc;
  g_hInst = hInstance;
  LPCTSTR MainWndClass = TEXT("RAT-STATS 2017 :: submission from J&J Cyber Security LLC ");
  HWND hWnd;
  HACCEL hAccelerators;
  HMENU hSysMenu;
  MSG msg;

  // Initialise common controls
  icc.dwSize = sizeof(icc);
  icc.dwICC = ICC_WIN95_CLASSES;
  InitCommonControlsEx(&icc);

  // Class for our main window.
  wc.cbSize        = sizeof(wc);
  wc.style         = 0;
  wc.lpfnWndProc   = &MainWndProc;
  wc.cbClsExtra    = 0;
  wc.cbWndExtra    = 0;
  wc.hInstance     = hInstance;
  wc.hIcon         = (HICON) LoadImage(hInstance, MAKEINTRESOURCE(IDI_APPICON), IMAGE_ICON, 0, 0,
                                       LR_DEFAULTSIZE | LR_DEFAULTCOLOR | LR_SHARED);
  wc.hCursor       = (HCURSOR) LoadImage(NULL, IDC_ARROW, IMAGE_CURSOR, 0, 0, LR_SHARED);
  wc.hbrBackground = (HBRUSH) (COLOR_BTNFACE + 1);
  wc.lpszMenuName  = MAKEINTRESOURCE(ID_MAINMENU);
  wc.lpszClassName = MainWndClass;
  wc.hIconSm       = (HICON) LoadImage(hInstance, MAKEINTRESOURCE(IDI_APPICON), IMAGE_ICON,
                                       GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON),
                                       LR_DEFAULTCOLOR | LR_SHARED);

  // Register our window classes, or error.
  if (! RegisterClassEx(&wc))
  {
    MessageBox(NULL, TEXT("Error registering window class."), TEXT("Error"), MB_ICONERROR | MB_OK);
    return 0;
  }
  
  // Create instance of main window.
  hWnd = CreateWindowEx(0, MainWndClass, MainWndClass, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT,
                        700, 500, NULL, NULL, hInstance, NULL);

  // Error if window creation failed.
  if (! hWnd)
  {
    MessageBox(NULL, TEXT("Error creating main window."), TEXT("Error"), MB_ICONERROR | MB_OK);
    return 0;
  }

  // Load accelerators.
  hAccelerators = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDR_ACCELERATOR));

  // Add "about" to the system menu.
  hSysMenu = GetSystemMenu(hWnd, FALSE);
  InsertMenu(hSysMenu, 5, MF_BYPOSITION | MF_SEPARATOR, 0, NULL);
  InsertMenu(hSysMenu, 6, MF_BYPOSITION, ID_HELP_ABOUT, TEXT("About"));

  
  // Show window and force a paint.
  hSplash = CreateWindow(L"Static", L"", 
			 WS_CHILD | WS_VISIBLE | SS_BITMAP | WS_DISABLED,
			    0, 0, 0, 0, hWnd, NULL, NULL, NULL);
  
  if (! hSplash)
  {
    MessageBox(NULL, TEXT("Error creating splash window."), TEXT("Error"), MB_ICONERROR | MB_OK);
    return 0;
  }

 
  HBITMAP hBitmap =  LoadBitmap(hInstance, MAKEINTRESOURCE(IDI_APPBMP));
  SendMessage(hSplash, STM_SETIMAGE,
	      (WPARAM) IMAGE_BITMAP, (LPARAM) hBitmap); 

  //  AllocConsole();   // Enable this line if you want Debug Output to a console
  ShowWindow(hWnd, nCmdShow);

  UpdateWindow(hWnd);
  
  // Main message loop -- enabling tabbing in dialog plus accelarators
  while(GetMessage(&msg, NULL, 0, 0) > 0)
  {
    HWND hActive=GetActiveChildWnd();
    if (//hActive != NULL && hActive !=hSplash &&
	!IsDialogMessage(hActive, &msg))
      {
	TranslateMessage(&msg);
	DispatchMessage(&msg);
      }
  }

  return (int) msg.wParam;
}


#ifdef __cplusplus
extern "C" {
#endif

  
extern HINSTANCE g_hInst;


/*********************************************************************************
*
* Function: GetSplash
*
*
* Return pointer to main "splash" window -- Graphics shown when program first starts
*
*********************************************************************************/
  
HWND GetSplash() {
  if(hSplash == NULL) {
    DebugString (L"In getSplash, result is null");
  } else {
    DebugString (L"In getSplash, result good");
  }    
  return hSplash;
}



/************************** Main Menu Start Routines ******************************
*
* These wrappers are called to show the main dialogs for each top-level menu
*
*********************************************************************************/  

LRESULT AttrMenu(HWND hWnd, WPARAM wParam) {
  switch (LOWORD(wParam))
    {
    case ID_ATTR_UNRES:
  
      ShowWindow(GetActiveChildWnd(),SW_HIDE);
      CreateUnresAttrWindow(g_hInst,hWnd);
      return 0;
    }
  return true;

}

LRESULT VarMenu(HWND hWnd, WPARAM wParam) {
  switch (LOWORD(wParam))
    {
    case ID_VAR_UNRES:
  
      ShowWindow(GetActiveChildWnd(),SW_HIDE);
      CreateUnresVarWindow(g_hInst,hWnd);
      return 0;
    case ID_VAR_STRAT:
  
      ShowWindow(GetActiveChildWnd(),SW_HIDE);
      CreateStratVarWindow(g_hInst,hWnd);
      return 0;      
    }
  return true;
}

/*  Not implementented yet
LRESULT SampMenu(HWND hWnd, WPARAM wParam) {
  return true;
}
*/

LRESULT RndMenu(HWND hWnd, WPARAM wParam) {
  switch (LOWORD(wParam))
    {
    case ID_RND_ONE:
    case ID_RND_TWO:
    case ID_RND_THREE:
    case ID_RND_FOUR:      
      {
	ShowWindow(GetActiveChildWnd(),SW_HIDE);
	CreateRndWindow(g_hInst,hWnd,LOWORD(wParam));
	return 0;
      }
    }
  return true;   // did not handle menu
}


/*****************************************************
 * Function: AboutDialogProc
 *   
 * Simple callback routine to handle I/O with About Dialog
 *
 *****************************************************/
  
INT_PTR CALLBACK AboutDialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam) 
{
  int ignore = LOWORD(lParam);
  switch (uMsg)
    {
    case WM_COMMAND:
      {
	switch (LOWORD(wParam))
	  {
	  case IDOK:
	  case IDCANCEL:
	    {
	      EndDialog(hwndDlg, (INT_PTR) LOWORD(wParam));
	      return (INT_PTR) TRUE;
	    }
	  }
	break;
      }

    case WM_INITDIALOG:
      return (INT_PTR) TRUE;
    }

  return (INT_PTR) FALSE;
}


/*****************************************************
 * Function: MainWndProc
 *   
 * Simple callback routine to handle I/O with main application window
 *
 *****************************************************/
LRESULT CALLBACK MainWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  switch (msg)
    {  
    case WM_COMMAND:
      if (GetActiveChildWnd()==NULL) {
	SetActiveChildWnd(GetSplash());
	DebugString(L"Active was null");
      } else {
	DebugString(L"Active not null");
      }

      switch (LOWORD(wParam) & ID_MASK)
	{
	case IS_TOP_MENU:
	  break;
	case IS_RND_MENU:  // Random Sample Menu
	  return RndMenu(hWnd,wParam);
	  
	case IS_ATTR_MENU:  // Attribute Appraisal
	  return AttrMenu(hWnd,wParam);
	case IS_VAR_MENU:   // Variable Appraisal
	  return VarMenu(hWnd,wParam);	  

/*  Not implemented yet
	case IS_SAMP_MENU:  // Sample Size Determination Menu
	  return SampMenu(hWnd,wParam);	  	
*/
	  
	case IS_HELP_MENU:  // Help & About Menu
	  switch (LOWORD(wParam))
	    {
	    case ID_HELP_ABOUT:
	      {
		DialogBox(g_hInst, MAKEINTRESOURCE(IDD_ABOUT_DIALOG),
			  hWnd, &AboutDialogProc);
		return 0;
	      }
	    }      	
	  break;
	}

      // Fix minimum window size
    case WM_GETMINMAXINFO:
      {
	MINMAXINFO *minMax = (MINMAXINFO*) lParam;
	minMax->ptMinTrackSize.x = wXMin;
	minMax->ptMinTrackSize.y = wYMin;
	return 0;
      }
      
    case WM_SYSCOMMAND:
      {
	switch (LOWORD(wParam))
	  {
	  case ID_HELP_ABOUT:
	    {
	      DialogBox(g_hInst, MAKEINTRESOURCE(IDD_ABOUT_DIALOG),
			hWnd, &AboutDialogProc);
	      return 0;
	    }
	  }
	break;
      }
      
    case WM_CREATE:
      {
	g_hInst = ((LPCREATESTRUCT) lParam)->hInstance;
	SetActiveChildWnd(NULL);
	return 0;
      }
      
    case WM_DESTROY:
      {
	PostQuitMessage(0);
	return 0;
      }
    }
  return DefWindowProc(hWnd, msg, wParam, lParam);
}

#ifdef __cplusplus
}
#endif  

