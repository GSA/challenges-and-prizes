/*********************************************************************************
 *
 * FILE: winUtil.cpp
 *
 * COPYRIGHT (2017): J&J CyberSecurity LLC   http://www.jjcybersecurity.com
 * All Rights Reserved 
 * 
 * This file provides a collection of utility functions for use by a 
 * GUI interface tied to Windows Controls/Dialog Boxes
 *
 *
 * Utilities to Manage Dialog Boxes
 * -- Set Dialog Focus
 * -- Clear Child windows
 * -- Clear Dialog
 * -- ClearChildWindowCallBack
 *
 * Error Messaeg Display Utilities
 * -- BalloonTip
 * -- BalloonWarning
 * -- BalloonError
 * -- BalloonNotice
 * -- BalloonPlain
 * -- showWarning
 * -- hideWarning
 * 
 * -- Dialog Box validation Functions
 * 
 * TextBox, and validate that the text match specific Data Format Characteristics


 *********************************************************************************/


#include"util.h"
#include "winUtil.h"


#ifdef __cplusplus
extern "C" {
#endif


  /*********************************************************************************
   *
   * Function: SetDialogFocus
   * 
   * Set focus to specified control
   *
   *********************************************************************************/
  void SetDialogFocus(HWND hdlg, HWND hwndControl)
  {
    SendMessage(hdlg, WM_NEXTDLGCTL, (WPARAM)hwndControl, TRUE);
    UpdateWindow(hdlg);
  }


  /*********************************************************************************
   *
   * Function: ClearChildWindow
   * 
   * Clear edit box, and warnings
   *
   *********************************************************************************/
  
  void ClearChildWindow(HWND hCtrl) {
    int id = GetDlgCtrlID(hCtrl);
    wchar_t msg[BUFSIZE];    

    if((id & ID_CLASS_MASK) == IS_EDIT) {
      Edit_SetText(hCtrl,L"");
      wsprintf(msg,L"Clearing ID 0x%x",id);
      DebugString(msg);
    } else if ((id & ID_CLASS_MASK) == IS_WARN) { // Hide all warnings
      ShowWindow(hCtrl,FALSE);
      wsprintf(msg,L"Clearing BMPID 0x%x",id);
      DebugString(msg);
    }
  }


  /*********************************************************************************
   *
   * Function: ClearChildWindowCallBack
   * 
   * Clear edit box, and warnings, callback function
   *
   *********************************************************************************/
  int CALLBACK ClearChildWindowCallBack(HWND hCtrl,
                                        LPARAM //lparam -- ignored
                                        ) {
    ClearChildWindow(hCtrl);
    return 1;
  }

  /*********************************************************************************
   *
   * Function: ClearDialog
   * 
   * Clear all child windows: edit boxs and warnings
   *
   *********************************************************************************/  
  void ClearDialog(HWND hWnd) {

    WNDENUMPROC childProc = ClearChildWindowCallBack;
    EnumChildWindows(hWnd,childProc,0);
    RedrawWindow(hWnd,NULL,NULL,RDW_ERASE);
  }
  

  /*********************************************************************************
   * Function:  BalloonTip
   *
   * Description:
   *   Creates a ballon tooltip for an item in a dialog box. 
   *
   * Parameters:
   *   idTool - identifier of an dialog box item.
   *   nDlg - window handle of the dialog box.
   *   pszText - string to use as the tooltip text.
   *
   * Returns:
   *   nothing
   *********************************************************************************/

  void BalloonTip(HWND hCtrl, LPCWSTR title, LPCWSTR pszText, int hIcon) {

    EDITBALLOONTIP ei;
    ei.cbStruct = sizeof(ei);
    ei.pszTitle = title;
    ei.pszText = pszText;
    ei.ttiIcon = hIcon;
    Edit_ShowBalloonTip(hCtrl,&ei);
  }

  void BalloonWarning(HWND hCtrl, LPCWSTR pszText) {
    BalloonTip(hCtrl, L"Warning", pszText, TTI_WARNING);
  }

  void BalloonError(HWND hCtrl, LPCWSTR pszText) {
    BalloonTip(hCtrl, L"Error", pszText, TTI_ERROR);
  }

  void BalloonNotice(HWND hCtrl, LPCWSTR pszText) {
    BalloonTip(hCtrl, L"Notice", pszText, TTI_INFO);
  }

  void BalloonPlain(HWND hCtrl, LPCWSTR pszText) {
    BalloonTip(hCtrl, NULL, pszText, TTI_NONE);
    DebugString(L"Showing Balloon Warning");
  }




  /*********************************************************************************
   *
   * Function: CreateToolTip
   * Description:
   *   Creates a tooltip for an item in a dialog box. 
   * Parameters:
   *   idTool - identifier of an dialog box item.
   *   nDlg - window handle of the dialog box.
   *   pszText - string to use as the tooltip text.
   * Returns:
   *   The handle to the tooltip.
/*********************************************************************************/  

   HWND CreateToolTip(int toolID, HWND hDlg, LPWSTR pszText) {
     if (!toolID || !hDlg || !pszText)
       {
         return FALSE;
       }
     // Get the window of the tool.
     HWND hwndTool = GetDlgItem(hDlg, toolID);
    
     // Create the tooltip. g_hInst is the global instance handle.
     HWND hwndTip = CreateWindowEx(NULL, TOOLTIPS_CLASS, NULL,
                                   WS_POPUP ,
                                   CW_USEDEFAULT, CW_USEDEFAULT,
                                   CW_USEDEFAULT, CW_USEDEFAULT,
                                   hDlg, NULL, 
                                   g_hInst, NULL);
    
     if (!hwndTool || !hwndTip)
       {
         return (HWND)NULL;
       }                              
                              
     // Associate the tooltip with the tool.
     TOOLINFO toolInfo = { 0 };
     toolInfo.cbSize = sizeof(toolInfo);
     toolInfo.hwnd = hDlg;
     toolInfo.uFlags = TTF_IDISHWND | TTF_SUBCLASS;
     toolInfo.uId = (UINT_PTR)hwndTool;
     toolInfo.lpszText = pszText;
     SendMessage(hwndTip, TTM_ADDTOOL, 0, (LPARAM)&toolInfo);
    
     return hwndTip;
   }


  /*********************************************************************************
   *
   * Function: CreateToolTip
   *
   * Hidd tooltip
   *
   *********************************************************************************/  
  void HideMyToolTip(TOOLTIPINIT *toolTips, int id) {
    int index=0;
    while (toolTips[index].id !=0) {
      if(toolTips[index].id == id) {
        ShowWindow(toolTips[index].ptrToolTip,SW_HIDE);
        break;
      }
    }
  }  



  // Open and Save File Dialog Codes -- obtained from MSDN website,
  // Not happy with these

  
  static const CLSID CLSIDFileOpenDialog = {
    0xDC1C5A9C, 0xE88A, 0X4DDE, {0xA5, 0xA1, 0x60, 0xF8, 0x2A, 0x20, 0xAE, 0xF7}};
  const IID IIDIFileDialog = { 0x42F85136, 0xDB7E, 0x439C, 0x85, 0xF1, 0xE4, 0x07, 0x5D, 0x13, 0x5F, 0xC8 };
  const IID CLSIDFileSaveDialog = { 0xC0B4E2F3, 0xBA21, 0x4773, 0x8D, 0xBA, 0x33, 0x5E, 0xC9, 0x46, 0xEB, 0x8B };



  /*********************************************************************************
   *
   * Function: mySaveFileDialog
   * 
   * Dialog to open standard FileSaveDialog, based on code from MSDN
   *
   *********************************************************************************/  
  extern "C" bool mySaveFileDialog(wchar_t * strFile,
                                   size_t maxSize,
                                   wchar_t const * strTitle,
                                   std::vector<std::wstring> astrFilter,
                                   std::vector<std::wstring> astrFilterExtension,
                                   LONG nFlags,
                                   HWND hParentWnd) {
    //USES_CONVERSION;
    size_t  nFilterCount = astrFilter.size();

    IFileDialog* pfod = 0;
    HRESULT hr = ::CoCreateInstance(CLSIDFileSaveDialog, NULL,// CLSCTX_FROM_DEFAULT_CONTEXT,
                                    CLSCTX_INPROC_SERVER,                                     
                                    IID_PPV_ARGS(&pfod));
      
    if(SUCCEEDED(hr))
      {
        // Zero out data structure
          
        // New dialog starting with Vista/Windows 7
        COMDLG_FILTERSPEC*  pOpenTypes = 0;
        if((nFilterCount > 0) && (nFilterCount == astrFilterExtension.size()))
          {
            pOpenTypes = new COMDLG_FILTERSPEC[nFilterCount];

            for(uint32_t nIdx = 0; nIdx < nFilterCount; nIdx++)
              {
                pOpenTypes[nIdx].pszName = (LPCWSTR)astrFilter.at(nIdx).data();
                pOpenTypes[nIdx].pszSpec = (LPCWSTR)astrFilterExtension.at(nIdx).data();
              }
          }

        if(strFile != NULL)
          hr=pfod->SetFileName(strFile);

        if(strTitle != NULL)
          hr = hr && pfod->SetTitle(strTitle);

        if(!SUCCEEDED(hr)) return false;
        // Set the file types to display.
        if(pOpenTypes)
          {
            hr = pfod->SetFileTypes(nFilterCount, pOpenTypes);

            if(SUCCEEDED(hr))
              hr = pfod->SetFileTypeIndex(0);
          }

      
        if(SUCCEEDED(hr))
          {
            // Ensure the dialog only returns file system paths.
            DWORD dwFlags = 0;
            hr = pfod->GetOptions(&dwFlags);

            if(SUCCEEDED(hr))
              {
                dwFlags |= FOS_FORCEFILESYSTEM | FOS_NODEREFERENCELINKS;

                if(nFlags & OFN_FILEMUSTEXIST)
                  dwFlags |= FOS_FILEMUSTEXIST;

                if(nFlags & OFN_PATHMUSTEXIST)
                  dwFlags |= FOS_PATHMUSTEXIST;


                hr = pfod->SetOptions(dwFlags);
                if(SUCCEEDED(hr))
                  {
                    // Now show the dialog. Usually called with hParent == 0
                    if(hParentWnd)
                      hr = pfod->Show(::GetWindow(hParentWnd, GW_OWNER));
                    else
                      hr = pfod->Show(0);

                    if(SUCCEEDED(hr)) {
                      IShellItem *psiResult;
                        
                      hr = pfod->GetResult(&psiResult);
                      if (SUCCEEDED(hr))
                        {
                          PWSTR pszFilePath = NULL;
                          //SIGDN_DESKTOPABSOLUTEEDITING or
                          //SIGDN_FILESYSPATH, 
                          hr = psiResult->GetDisplayName(SIGDN_FILESYSPATH,
                                                         &pszFilePath);
                          wcsncpy(strFile,pszFilePath,maxSize-1);
                          strFile[maxSize-1]=0;
                          CoTaskMemFree(pszFilePath);  // must free up allocated info
                          psiResult->Release();
                          return true;
                        }
                    }
                  }
              }
          }
      }
    return false;
  }



  /*********************************************************************************
   *
   * Function: c_SaveFileDialog  
   * 
   * Wrapper to take c strings for Save file dialog and convert to mySaveFileDialog
   *
   *********************************************************************************/    
  bool c_SaveFileDialog(wchar_t * strFile, size_t maxSize,
                        wchar_t const * strTitle,
                        wchar_t const * astrFilter[], long astrFilterCnt,
                        wchar_t const * astrFilterExtension[], long astrFilterExtCnt,
                        LONG nFlags, HWND hParentWnd) {
    bool result = false;
    std::vector<std::wstring> astrFilt1,astrFiltExt1;

    if(astrFilter != NULL) {
      astrFilt1.assign (astrFilter,astrFilter+astrFilterCnt);
    } 
    if(astrFilterExtension != NULL) {  
      astrFiltExt1.assign (astrFilterExtension, astrFilterExtension+astrFilterExtCnt);
    }
  
    result = mySaveFileDialog(strFile, maxSize, strTitle, astrFilt1, astrFiltExt1, nFlags, hParentWnd);
    return result;
  }




  /*********************************************************************************
   *
   * Function: myOpenFileDialog
   * 
   * Dialog to open standard FileOpenDialog, based on code from MSDN
   *
   *********************************************************************************/  
  extern "C" bool myOpenFileDialog(wchar_t * strFile,
                                   size_t maxSize,
                                   wchar_t const * strTitle,
                                   std::vector<std::wstring> astrFilter,
                                   std::vector<std::wstring> astrFilterExtension,
                                   LONG nFlags,
                                   HWND hParentWnd) {
    //USES_CONVERSION;
    size_t  nFilterCount = astrFilter.size();

    IFileDialog* pfod = 0;
    DebugString(L"Starting co create");
    HRESULT hr = ::CoCreateInstance(CLSIDFileOpenDialog, NULL, 
                                    CLSCTX_INPROC_SERVER,
                                    IID_PPV_ARGS(&pfod));
    DebugString(L"end co create");
    if(SUCCEEDED(hr))
      {
        // New dialog starting with Vista/Windows 7
        COMDLG_FILTERSPEC*  pOpenTypes = 0;
        if((nFilterCount > 0) && (nFilterCount == astrFilterExtension.size()))
          {
            pOpenTypes = new COMDLG_FILTERSPEC[nFilterCount];

            for(uint32_t nIdx = 0; nIdx < nFilterCount; nIdx++)
              {
                pOpenTypes[nIdx].pszName = (LPCWSTR)astrFilter.at(nIdx).data();
                pOpenTypes[nIdx].pszSpec = (LPCWSTR)astrFilterExtension.at(nIdx).data();
              }
          }

        if(strFile != NULL)
          hr=pfod->SetFileName(strFile);

        if(strTitle != NULL)
          hr = hr && pfod->SetTitle(strTitle);

        if(!SUCCEEDED(hr)) return false;
        // Set the file types to display.
        if(pOpenTypes)
          {
            hr = pfod->SetFileTypes(nFilterCount, pOpenTypes);

            if(SUCCEEDED(hr))
              hr = pfod->SetFileTypeIndex(0);
          }

      
        if(SUCCEEDED(hr))
          {
            // Ensure the dialog only returns file system paths.
            DWORD dwFlags = 0;
            hr = pfod->GetOptions(&dwFlags);

            if(SUCCEEDED(hr))
              {
                dwFlags |= FOS_FORCEFILESYSTEM | FOS_NODEREFERENCELINKS;
                dwFlags |= FOS_FILEMUSTEXIST;
                dwFlags |= FOS_PATHMUSTEXIST;

                hr = pfod->SetOptions(dwFlags);
                if(SUCCEEDED(hr))
                  {
                    // Now show the dialog. Usually called with hParent == 0
                    if(hParentWnd && false) {
                      DebugString(L"Starting show window w/parent");
                      hr = pfod->Show(::GetWindow(hParentWnd, GW_OWNER));
                    } else {
                      DebugString(L"Starting show(0)");
                      hr = pfod->Show(0);
                    }
                    DebugString(L"done show window");                                 

                    if(SUCCEEDED(hr)) {
                      IShellItem *psiResult;

                      hr = pfod->GetResult(&psiResult);
                      if (SUCCEEDED(hr))
                        {
                          PWSTR pszFilePath = NULL;
                          //SIGDN_DESKTOPABSOLUTEEDITING or
                          //SIGDN_FILESYSPATH, 
                          hr = psiResult->GetDisplayName(SIGDN_FILESYSPATH,
                                                         &pszFilePath);
                          wcsncpy(strFile,pszFilePath,maxSize-1);
                          strFile[maxSize-1]=0;
                          CoTaskMemFree(pszFilePath);  // must free up allocated info
                          psiResult->Release();
                          return true;
                        }
                    }
                  }
              }
          }
      }
    return false;
  }


  /*********************************************************************************
   *
   * Function: c_OpenFileDialog  
   * 
   * Wrapper to take c strings for Save file dialog and convert to myOpenFileDialog
   *
   *********************************************************************************/
  bool c_OpenFileDialog(wchar_t * strFile, size_t maxSize,
                        wchar_t const * strTitle,
                        wchar_t const * astrFilter[], long astrFilterCnt,
                        wchar_t const * astrFilterExtension[], long astrFilterExtCnt,
                        LONG nFlags, HWND hParentWnd) {
    bool result = false;
    std::vector<std::wstring> astrFilt1,astrFiltExt1;

    if(astrFilter != NULL) {
      astrFilt1.assign (astrFilter,astrFilter+astrFilterCnt);
    } 
    if(astrFilterExtension != NULL) {  
      astrFiltExt1.assign (astrFilterExtension, astrFilterExtension+astrFilterExtCnt);
    }
  
    result = myOpenFileDialog(strFile, maxSize, strTitle, astrFilt1, astrFiltExt1, nFlags, hParentWnd);
    return result;
  }



  /*************************** Validation Utility Functions ***********************
   *
   *
   * Functions to validate data type of entry box, based on type
   * Will pop up a warning if not correct
   *
   ****************************************************************************/
  bool ValidateInt(HWND hWnd) {
    wchar_t charBuf[81];
    int size = GetWindowText(hWnd,charBuf,80);  
    if(size == 1 && charBuf[0] == '-')  { //OK to move on
      noop;
    } else if( size > 0 && !ParseInt(charBuf,NULL)) {
      BalloonPlain(hWnd,L"Please Enter an Integer ");
      return false;
    }
    Edit_HideBalloonTip(hWnd);
    return true;
  }


  bool ValidateNonNegInt(HWND hWnd) {
    wchar_t charBuf[81];
    if(GetWindowText(hWnd,charBuf,80) > 0 &&
       !ParseNonNegInt(charBuf,NULL)) {
      BalloonPlain(hWnd,L"Please Enter a non-Negative Integer ");
      return false;
    }
    Edit_HideBalloonTip(hWnd);
    return true;
  }

  
  bool ValidateFloat(HWND hWnd) {
    wchar_t charBuf[81];
    int size = GetWindowText(hWnd,charBuf,80);
    if(size == 1 && charBuf[0] == '-')  { //OK to move on
      noop;
    } else if (size >0 && !ParseFloat(charBuf,NULL)) {
      BalloonWarning(hWnd,L"Please Enter a Number");
      return FALSE;
    }
    Edit_HideBalloonTip(hWnd);  
    return TRUE;
  }

  bool ValidateNonNegFloat(HWND hWnd) {
    wchar_t charBuf[81];
    if(GetWindowText(hWnd,charBuf,80) > 0 &&
       !ParseNonNegFloat(charBuf,NULL)) {
      BalloonWarning(hWnd,L"Please Enter a Non-Negative Number");
      return FALSE;
    }
    Edit_HideBalloonTip(hWnd);  
    return TRUE;
  }

  bool ValidateDouble(HWND hWnd) {
    wchar_t charBuf[81];
    int size = GetWindowText(hWnd,charBuf,80);  
    if(size == 1 && charBuf[0] == '-')  { //OK to move on
      noop;
    } else if(size > 0 && !ParseDouble(charBuf,NULL)) {
      BalloonWarning(hWnd,L"Please Enter a Number");
      return FALSE;
    }
    Edit_HideBalloonTip(hWnd);  
    return TRUE;
  }

  bool ValidateNonNegDouble(HWND hWnd) {
    wchar_t charBuf[81];
    if(GetWindowText(hWnd,charBuf,80) > 0 &&
       !ParseNonNegDouble(charBuf,NULL)) {
      BalloonWarning(hWnd,L"Please Enter a Non-Negative Number");
      return FALSE;
    }
    Edit_HideBalloonTip(hWnd);  
    return TRUE;
  }


  /*********************************************************************************
   *
   * Funciton: ValidateBox
   * 
   * Given an identifier of a control, find its specified type. 
   * The type comes from the nunbering convention used in resource.h
   * Then validate that type/showing error if not valid. 
   *
   *********************************************************************************/  
  bool ValidateBox(HWND hWnd, int id) {  
    HWND hCtrl = GetDlgItem(hWnd,id);
    bool res=true;
    if(!hCtrl) return res;
    switch (id & ID_MASK) {
    case IS_INTEGER: 
      res=ValidateInt(hCtrl);
      break;    

    case IS_NONNEG_INT:
      DebugString(L"Asking for non-neg");
      res=ValidateNonNegInt(hCtrl);
      break;
    
    case IS_FLOAT:
      res=ValidateFloat(hCtrl);
      break;

    case IS_NONNEG_FLOAT:
      res=ValidateFloat(hCtrl);
      break;

    case IS_DOUBLE:
      res=ValidateDouble(hCtrl);
      break;

    case IS_NONNEG_DOUBLE:
      res=ValidateNonNegDouble(hCtrl);
      break;        

    default:
      res=true;
    }
  

    int warnId = (id & (~ID_CLASS_MASK)) | IS_WARN;
    // show/HIDE  Warning
    hCtrl = GetDlgItem(hWnd,warnId);
    if(res) {
      wchar_t msg[BUFSIZE];
      wsprintf(msg,L"For id 0x%x, hiding icon 0x%x",id,warnId);
      DebugString(msg);
      ShowWindow(hCtrl,FALSE);
    }
    else {
      wchar_t msg[BUFSIZE];
      wsprintf(msg,L"For id 0x%x, show warning icon 0x%x",id,warnId);
      DebugString(msg);    
      wsprintf(msg,L"For id 0x%x, show warning BMP 0x%x with hctrl = 0x%x",id,warnId,hCtrl);
      DebugString(msg);          
      ShowWindow(hCtrl,TRUE);
    }
    return res;
  }


  /*********************************************************************************
   *
   * Funciton: ValidateDialogSave -- is this good?
   * 
   * Loop through all controls of dialog -- are they non-empty except 
   * for optional value?
   * Validate them
   *
   *********************************************************************************/  
  bool ValidateDialogSave(HWND hWnd, int *optList) {

    bool result = true;
    HWND hCtrl = GetNextDlgGroupItem(hWnd,NULL,false);
    hCtrl=GetNextDlgTabItem(hWnd,hCtrl,false);
    int firstId = GetDlgCtrlID(hCtrl);
    int id = firstId;
    do
      {
        if((id & ID_CLASS_MASK) == IS_EDIT) {
          wchar_t resStr[10];
          int hr = Edit_GetText(hCtrl,resStr,10);
          if(hr == 0) {
	    result = false;  // empty box is error unless in optional list
	    if(optList != NULL) 
	      for(int i=0; optList[i] != 0; i++) {
		if (id == optList[i]) {
		  result = true;
		  break;
		}
	      }
	  
	    wchar_t msg[BUFSIZE];
            wsprintf(msg,L"Save failed?(%d)on ID %x :: %s",result,id,resStr);
            DebugString(msg);
          }
        }
        hCtrl=GetNextDlgTabItem(hWnd,hCtrl,false);
        id =  GetDlgCtrlID(hCtrl);
      } while (result && id != firstId);
    return result;
  }


  /************** Functions to control warnings ***************/
  
  void showWarning(HWND hWnd, int id, LPCWSTR str) {
    int warnId = (id & (~ID_CLASS_MASK)) | IS_WARN;
    // show Warning
    BalloonWarning(hWnd,str);
    HWND hCtrl;
    hCtrl = GetDlgItem(hWnd,warnId);
    ShowWindow(hCtrl,TRUE);
  }


  void hideWarning(HWND hWnd, int id) {
    int warnId = (id & (~ID_CLASS_MASK)) | IS_WARN;
    // show Warning
    HWND hCtrl;  
    hCtrl = GetDlgItem(hWnd,warnId);
    ShowWindow(hCtrl,FALSE);
  }
  



  /****************** Utility Functions ********************
   * 
   * These are used to get parsed value from text box strings
   *
  ****************** Utility Functions ********************/
  bool GetInt(HWND hWnd, int64_t * value) {
    wchar_t charBuf[81];    
    bool res = ValidateInt(hWnd);
    int size = GetWindowText(hWnd,charBuf,80);
    if (!res || size ==0) return false;
    ParseInt(charBuf,value);
    return true;
  }

  bool Get32Int(HWND hWnd, int32_t * value) {
    wchar_t charBuf[81];    
    bool res = ValidateInt(hWnd);
    int size = GetWindowText(hWnd,charBuf,80);
    if (!res || size ==0) return false;
    Parse32Int(charBuf,value);
    return true;
  }  

  bool GetNonNegInt(HWND hWnd, uint64_t * value) {
    wchar_t charBuf[81];    
    bool res = ValidateNonNegInt(hWnd);
    int size = GetWindowText(hWnd,charBuf,80);
    if (!res || size ==0) return false;
    ParseNonNegInt(charBuf,value);
    return true;
  }

  bool GetNonNeg32Int(HWND hWnd, uint32_t * value) {
    wchar_t charBuf[81];    
    bool res = ValidateNonNegInt(hWnd);
    int size = GetWindowText(hWnd,charBuf,80);
    if (!res || size ==0) return false;
    ParseNonNeg32Int(charBuf,value);
    return true;
  }

  bool GetFloat(HWND hWnd, float* value) {
    wchar_t charBuf[81];    
    bool res = ValidateFloat(hWnd);
    int size = GetWindowText(hWnd,charBuf,80);
    if (!res || size ==0) return false;
    ParseFloat(charBuf,value);
    return true;
  }  


  bool GetNonNegFloat(HWND hWnd, float* value) {
    wchar_t charBuf[81];    
    bool res = ValidateFloat(hWnd);
    int size = GetWindowText(hWnd,charBuf,80);
    if (!res || size ==0) return false;
    ParseNonNegFloat(charBuf,value);
    return true;
  }  

  bool GetDouble(HWND hWnd, double* value) {
    wchar_t charBuf[81];    
    bool res = ValidateFloat(hWnd);
    int size = GetWindowText(hWnd,charBuf,80);
    if (!res || size ==0) return false;
    ParseDouble(charBuf,value);
    return true;
  }

  bool GetNonNegDouble(HWND hWnd, double* value) {
    wchar_t charBuf[81];    
    bool res = ValidateFloat(hWnd);
    int size = GetWindowText(hWnd,charBuf,80);
    if (!res || size ==0) return false;
    ParseDouble(charBuf,value);
    return true;
  }



  // Code to help event handling?
  BOOL WaitWithMessageLoop(HANDLE hEvent)
  {
    DWORD dwRet;
    MSG msg;

    while(1)
      {
        dwRet = MsgWaitForMultipleObjects( 1,    // One event to wait for
                                           &hEvent,        // The array of events
                                           FALSE,          // Wait for 1 event
                                           INFINITE,       // Timeout value
                                           QS_ALLINPUT);   // Any message wakes up
        if(dwRet == WAIT_OBJECT_0)
          {
            // The event was signaled, return
            return TRUE;
          } else if(dwRet == WAIT_OBJECT_0 + 1)
          {
            // There is a window message available. Dispatch it.
            while(PeekMessage(&msg,NULL,NULL,NULL,PM_REMOVE))
              {
                TranslateMessage(&msg);
                DispatchMessage(&msg);
              }
          } else
          {
            // Something else happened. Return.
            return FALSE;
          }
      }
  }  
  
  



  

    
#ifdef __cplusplus
}
#endif

