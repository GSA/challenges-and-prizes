/*********************************************************************************
 *
 * FILE: attrUI.cpp
 *
 * COPYRIGHT (2017): J&J CyberSecurity LLC   http://www.jjcybersecurity.com
 * All Rights Reserved 
 * 
 *
 * This file implements the user interface for Attribtue Appraisal
 * for RAT-STATS 2017 as specified in the Challenge Documentation.
 *
 * implements the following function:
 *
 * UnresAttrValidateBox -- validates that inputs satify additional contraints
 *                         beyond standard data typing of input boxes
 * UnresAttrCallbackProc -- Dialog InputBox Callback
 * CreateUnresAttrWindow -- Create Input Dialog for Attributes
 * AttrResultsProc -- Handler for results pop-up dialog box
 * AttrShowResults -- Display Pop-up results dialog box
 *
 *********************************************************************************/


#include "util.h"
#include "winUtil.h"
#include "resource.h"
#include "functions.h"
#include "printText.h"
#include "attr.h"
#include <ctime>

// Pop-up hints for controls first entry is control name, second is content
// 
static TOOLTIPINIT unresAttrToolTips[] = {
  {IDT_AUDIT_NAME,L"Enter name of this audit/review."},
  {IDT_NUMSEQ,L"Enter number of random values in sequential order"},
  {IDT_NUMRND,L"Enter number of spare values in random order"},
  {IDT_SEED,L"Enter optional seed"},
  {IDT_LOW1,L"Enter smallest universe value for the set"},
  {IDT_LOW2,L"Enter smallest universe value for the second set"},
  {IDT_LOW3,L"Enter smallest universe value for the third set"},
  {IDT_LOW4,L"Enter smallest universe value for the fourth set"},
  {IDT_HI1,L"Enter largest universe value for the set"},
  {IDT_HI2,L"Enter largest universe value for the second set"},
  {IDT_HI3,L"Enter largest universe value for the third set"},
  {IDT_HI4,L"Enter largest universe value for the fourth set"},  
  {0,L""}
};


// ************************* Unretricted Attribute Appraisal Functions


/*****************************************************
 * Function: UnresAttrValidateBox
 *   Validates additional constraints for the window
 *
 * parameters:
 *   hWnd : Parent window
 *   id : identifier of box to validate

 *****************************************************/
bool UnresAttrValidateBox(HWND hWnd, int id) {
  bool res=true;
  if(!ValidateBox(hWnd,id)) res = false;  
  return res;
}


/*****************************************************
 * Function: UnresAttrCallbackBox
 *   Handler for Dilaog Box
 *
 * parameters:
 *   hWnd : Parent window
 *   id : identifier of box to validate
 *
 * A lot of this is standard, see DIALOG SPECIFIC section for where
 * to edit when copied
 *
 *****************************************************/

INT_PTR CALLBACK UnresAttrCallbackProc(HWND hWnd, UINT uMsg, WPARAM wParam,
                                       LPARAM // lParam -- ignored
                                       )
{
  static bool enableSave = false;
  
  bool result = false;
  switch (uMsg) {
  case WM_COMMAND: {
    switch (HIWORD (wParam))
      {
      case EN_SETFOCUS:         
      case EN_UPDATE:{
        int id = LOWORD(wParam);                  
        ValidateBox(hWnd,id);
        result= false;   
        break;
      }

      case EN_KILLFOCUS: {
        int id = LOWORD(wParam);
        // order matters here, it may hide warning
        enableSave= ValidateDialogSave(hWnd,NULL) && UnresAttrValidateBox(hWnd,id);
        // Should Focus go to Save?
        HWND hSaveCtrl = GetDlgItem(hWnd,IDB_VIEW);       
        if(hSaveCtrl != NULL) {
          Button_Enable(hSaveCtrl, enableSave);
        }
        
        hSaveCtrl = GetDlgItem(hWnd,IDB_SAVE);    
        if(hSaveCtrl != NULL) {
          Button_Enable(hSaveCtrl, enableSave);
        }         

        result= false;
        break;
      } 
        
      default:  {
        switch (LOWORD(wParam))
          {
          case IDB_CLEAR: {
            ClearDialog(hWnd);
            enableSave=ValidateDialogSave(hWnd,NULL);            
            result = false;
            break;
          }

          case IDB_SAVE:
          case IDB_VIEW: {
            // check if we are ready to save/view. Validation may say no.
            // if so, pop-up message
            if(!ValidateDialogSave(hWnd,NULL)) {
              MessageBox(hWnd,L"At least one field is incomplete or incorrect",L"Warning",
                         MB_OK |MB_ICONWARNING );
              result = false;
              break;
            }

            // START DIALOG SPECIFIC
            //Get values from all dialog boxes -- could probably be more efficient
            //

            int hr;
            HWND hCtrl;
            AttrResults results;
            
            hCtrl = GetDlgItem(hWnd,IDT_AUDIT_NAME);        
            hr = Edit_GetText(hCtrl,results.auditName,80);
            if(!SUCCEEDED(hr)) {
              result = false;
              break;
            }
            
            hCtrl = GetDlgItem(hWnd,IDT_UNIV);
            result=GetNonNegInt(hCtrl,&results.univ);
            if(!result){
              result = false;
              break;
            } 

            hCtrl = GetDlgItem(hWnd,IDT_SAMP);
            result=GetNonNegInt(hCtrl,&results.samp);
            if(!result){
              result = false;
              break;
            }

            hCtrl = GetDlgItem(hWnd,IDT_INTEREST);
            result=GetNonNegInt(hCtrl,&results.quant);
            if(!result){
              result = false;
              break;
            }       

            // call functions to perform calculations
            double pers[] = {0.1,0.05,0.025};
            for (int i=0;i<3;i++) {
              results.hiCfd[i]=hypergCfd(results.quant,results.samp,results.univ,"upper",pers[i]);
              results.lowCfd[i]=hypergCfd(results.quant,results.samp,results.univ,"lower",pers[i]);
            }

              
            if(LOWORD(wParam) == IDB_SAVE) {                
              // Get File Name
              int numExt=2;           
              wchar_t const * arr1[2]={L"Text Files",L"All Files"};
              wchar_t const * arr2[2]={L"*.txt",L"*.*"};
              wchar_t const title[200]=L"Enter Name of Save File";
              wchar_t fileName[BUFSIZE]={L"*.txt"};
              
              if (!c_SaveFileDialog(fileName,200,title,arr1,numExt,arr2,numExt,
                                   FOS_STRICTFILETYPES,hWnd)) {
                result = false;
                break;
              }
              wchar_t msg[BUFSIZE];
              
              AttrPrintText(fileName,&results);
              wsprintf(msg,L"Data saved to file: %s",fileName);
              MessageBox(hWnd,msg,L"File Save Successful",MB_OK);
            } else { // Was VIEW
              DialogBoxParam(g_hInst, MAKEINTRESOURCE(IDD_ATTR_APPRAISAL_RESULTS),
                             hWnd, &AttrResultsProc, (LPARAM)(&results));
            }         
            break;

            // END DIALOG SPECIFIC
          }         
          case IDCANCEL: {
            EndDialog(hWnd, (INT_PTR) LOWORD(wParam));
            SetActiveChildWnd(GetSplash());
            ShowWindow(GetActiveChildWnd(),SW_SHOW);                  
            result = true;
            break;
          }
          }
            
        break;
      }
      }
    
    break;
  }

  case WM_INITDIALOG: {
    SetFocus(hWnd);
    result = false;
  }
  }

  return (INT_PTR) result;
}


/*****************************************************
 * Function: CreateUnresAttrWindow
 *   DialogBox creation rounting
 *
 *  This will probably be unique for each menu item
 *  So that it can specify parameters
 *
 *****************************************************/

// FIX THIS FOR EACH MENU CHOICE

void CreateUnresAttrWindow(HINSTANCE hInstance, HWND hWnd) {
  static HWND hChildWnd = NULL;

  if(hChildWnd == NULL) {
    DebugString(L"Making Instance"); // just once make instance to prevent memory leakage
    hChildWnd=CreateDialog(hInstance,
                           MAKEINTRESOURCE(IDW_UNRES_ATTR),
                           hWnd, &UnresAttrCallbackProc);
  }

  SetActiveChildWnd(hChildWnd);
  ClearDialog(hChildWnd);

  //Set toolTips ??
  TOOLTIPINIT *toolTips = unresAttrToolTips;
  
  int index=0;
  while (toolTips[index].id !=0) {
    toolTips[index].ptrToolTip =
      CreateToolTip(toolTips[index].id,hChildWnd,toolTips[index].text);
    index++;
  }
  
  ShowWindow(hChildWnd, SW_SHOW);
}  

/*****************************************************
 * Function: AttrResultsProc
 *   Handler for Dialog With Results of Analysis
 *
 *  This will probably be unique for each results dialog
 *  In this case it is pretty generic
 *
 *****************************************************/


INT_PTR CALLBACK AttrResultsProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {

  AttrResults *results;
  switch (uMsg)
    {
    case WM_COMMAND: {
      switch (LOWORD(wParam))
        {
        case IDOK:
        case IDCANCEL: {
          EndDialog(hWnd, (INT_PTR) LOWORD(wParam));
          return (INT_PTR) TRUE;
        }
        }
      break;
    }
    case WM_INITDIALOG: {
      results = (AttrResults *)lParam;

      AttrShowResults(hWnd, results);

      return (INT_PTR) FALSE;
    }
    }

  return (INT_PTR) FALSE;
}


/*****************************************************
 * Function: AttrShowResults
 *   Display Pop-up Dialog Box With Results of Analysis
 *
 * parameters:
 *   hWnd : Parent window
 *   results : data structure containing results of appraisal
 *
 *  This will probably be unique for each menu choice  
 *  or could possibly be parameterized
 *
 *****************************************************/


void AttrShowResults(HWND hWnd, AttrResults * results) {
  HWND hCtrl;
  wchar_t res[BUFSIZE];
  char asciiRes [BUFSIZE];
  time_t timeNow = time(NULL);
      
  struct tm *now = localtime(&timeNow);

  // Set text requires unicode (wide) strings
  // Time function only works regular char strings
  // So store result in regular ascii string
  // and then convert to wide character string
  
  strftime(asciiRes,14,"%#m/%d/%Y",now);
  mbstowcs(res,asciiRes,BUFSIZE);

  // Get dialog box handle
  // and set text
  hCtrl=GetDlgItem(hWnd,IDT_DATE);              
  Edit_SetText(hCtrl,res);
  
  strftime(asciiRes,14,"%H:%M",now);
  mbstowcs(res,asciiRes,BUFSIZE);
  hCtrl=GetDlgItem(hWnd,IDT_TIME);              
  Edit_SetText(hCtrl,res);


  hCtrl=GetDlgItem(hWnd,IDT_AUDIT_NAME);
  Edit_SetText(hCtrl,results->auditName);  
  
  hCtrl=GetDlgItem(hWnd,IDT_UNIV);
  SPrintComma(res,results->univ);
  Edit_SetText(hCtrl,res);
  
  hCtrl=GetDlgItem(hWnd,IDT_SAMP);
  SPrintComma(res,results->samp);  
  Edit_SetText(hCtrl,res);
  
  hCtrl=GetDlgItem(hWnd,IDT_QUANT);
  SPrintComma(res,results->quant);    
  Edit_SetText(hCtrl,res);
  
  double ratio = ((double)results->quant)/results->samp;

  // Use rounding to match results found in current RAT-STATS
  int64_t proj = (int64_t)(round(ratio*results->univ));      
  
  hCtrl=GetDlgItem(hWnd,IDT_PROJ);
  SPrintComma(res,proj);    
  Edit_SetText(hCtrl,res);
  
  hCtrl=GetDlgItem(hWnd,IDT_PERCENT);
  sprintf(asciiRes,"%.3f%%",ratio*100);
  mbstowcs(res,asciiRes,BUFSIZE);
  Edit_SetText(hCtrl,res);      
  
  for(int i=0;i<3;i++) {        
    hCtrl=GetDlgItem(hWnd,IS_CONF_LOW+i);
    SPrintComma(res,results->lowCfd[i]);
    Edit_SetText(hCtrl,res);

    hCtrl=GetDlgItem(hWnd,IS_CONF_HI+i);
    SPrintComma(res,results->hiCfd[i]);
    Edit_SetText(hCtrl,res);        

    hCtrl=GetDlgItem(hWnd,IS_LOW_PER+i);
    sprintf(asciiRes,"%.3f%%",100.0*results->lowCfd[i]/results->univ);
    mbstowcs(res,asciiRes,BUFSIZE);    
    Edit_SetText(hCtrl,res);

    hCtrl=GetDlgItem(hWnd,IS_HI_PER+i);
    sprintf(asciiRes,"%.3f%%",100.0*results->hiCfd[i]/results->univ);
    mbstowcs(res,asciiRes,BUFSIZE);
    Edit_SetText(hCtrl,res);        
  }

  ShowWindow(hWnd, SW_SHOW);        
}
  
