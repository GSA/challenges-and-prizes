/*********************************************************************************
 *
 * FILE: var.cpp
 *
 * COPYRIGHT (2017): J&J CyberSecurity LLC   http://www.jjcybersecurity.com
 * All Rights Reserved 
 * 
 * 
 * This file implements the user interface for Varaiable Appriasal
 * for RAT-STATS 2017 as specified in the Challenge Documentation.
 *
 *
 *********************************************************************************/
#include "util.h"
#include "var.h"
#include <ctime>
#include <iostream>
#include <sstream>
#include <fstream>
#include <algorithm>



/*****************************************************
 * Function: GetStrata
 *   Get data from Strata / Overall
 * 
 * Find minRow, column, maxRow and sample size
 *   Copy data from spreadsheet to results[].cells
 *   toprepare for calculations
 *
 *
 *****************************************************/
void GetStrata(Selection *selection) {
  CellContents **cells[3];
  SheetData *sheetData[3];
    
  VarResults *totRes = &(selection->results[0]);  // Get overall results from "strata" 0
  int64_t strataData[MAXSTRAT][2];
  int64_t index[2]={STRAT_UNIV,STRAT_SIZE};
  int64_t minR = -1;

  for(int i=0;i<MAXSTRAT;i++) {
    strataData[i][0] = strataData[i][1]=0;
  }
  
  // find max Row

  for (int i=0;i<3;i++) {
    totRes->maxRow[i]=-1;
    if(totRes->sheet[i] == -1) continue; // no sheet selected
    
    sheetData[i] = selection->sheetData[totRes->sheet[i]];
    cells[i]=sheetData[i]->Cells();

    for(int ind =0; cells[i][ind] != 0; ind++) {
      if(cells[i][ind]->Col() != totRes->col[i]) continue;  //wrong column

      int row = cells[i][ind]->Row();
      if(row < totRes->row[i]) continue;  //wrong row   

      if (row > totRes->maxRow[i]) {
        totRes->maxRow[i]=row;  // update max row
      }
    }
  }

  // Need to find maxRow, minRow and sample sizes for overall and each strata
  
  strataData[1][0] =  -1; // universe size   -- don't know yet
  
  totRes->maxR = max(max(totRes->maxRow[AUDIT],totRes->maxRow[EXAM]),totRes->maxRow[DIFF]);
  
  for(int i=0;i<3;i++) {
    if(totRes->row[i] != -1 && (minR ==-1 || totRes->row[i] < minR))
      minR = totRes->row[i];
  }
  totRes->minR = minR;
  totRes->samp = totRes->maxR - totRes->minR+1;  // samp size
  
  // The preceding works for unrestricted
  // Now if we have stratified, we need to read Size information for each Strat
  
  if(totRes->col[STRAT_UNIV] == -1 ||
     totRes->col[STRAT_SIZE] == -1) { // strata data not selected
    selection->numStrata = 1;
    strataData[1][1] =totRes->samp;    // set smaple size
  } else {
    
    int64_t minStratRow = -1;
    int64_t maxStratRow = -1;
    //    DebugString(L"Get Strata 1");
    for(int i=0;i<2;i++) {
      minStratRow =  totRes->row[index[i]];
      totRes->maxRow[index[i]]=-1;
      if(index[i] ==-1) continue; // no data
      sheetData[i] = selection->sheetData[totRes->sheet[index[i]]];  
      cells[i]=sheetData[i]->Cells();
      for(int ind =0; cells[i][ind] != 0; ind++) {
        if(cells[i][ind]->Col() != totRes->col[index[i]]) continue;  //wrong column
        int row = cells[i][ind]->Row();
        if(row < totRes->row[index[i]]) continue;  //wrong row          
        double value = strtod(cells[i][ind]->Value(),NULL);
        int64_t val = (int64_t) value;
        if(row < MAXSTRAT) {
          strataData[row-minStratRow+1][i]=val;
        }
        if (row > totRes->maxRow[index[i]]) {
          totRes->maxRow[index[i]]=row;  // update max row for STRATUNIV and STRATSIZES
        }
      }
    }

    minStratRow = min(totRes->row[STRAT_UNIV],totRes->row[STRAT_SIZE]);
    maxStratRow = max(totRes->maxRow[STRAT_UNIV],totRes->maxRow[STRAT_SIZE]);    

    selection->numStrata = maxStratRow-minStratRow+1;    
  }

  // now we have max rows -  should be same for both columns
  // now lets populate the different strata

  int64_t currentMin = totRes->minR;
  for(uint64_t strata =1;strata <= selection->numStrata; strata++) {
    int64_t currentUniv = strataData[strata][0];
    int64_t currentSize = strataData[strata][1];
    VarResults *results = &selection->results[strata];
    results->id = strata;
    results->fFormat = selection->fFormat;
    results->minR = currentMin;
    results->maxR = currentMin+currentSize-1;
    results->univ = currentUniv;
    results->samp = currentSize;

    for(int i=0;i<3;i++) {
      results->col[i]=totRes->col[i];
      results->row[i]=currentMin;
      results->sheet[i]=totRes->sheet[i];
      results->maxRow[i] = results->maxR;
      results->minRow[i] = results->minR;
    }
    
    currentMin += currentSize;

  }
}



/*****************************************************
 * Function: GetSums
 *   
 * 
 * For overall and each strata
 *   Copy data from spreadsheet to results[].cells
 *   to prepare for calculations
 * then calculate Sum of values/Sqrs/Quads/Cubes for each strata
 * then caculat overall
 *
 *****************************************************/
// probably not the most efficient, but pretty fast still

void GetSums(Selection * selection) {
  VarResults * results;
  CellContents **cells;
  SheetData *sheetData;

  for(uint64_t strat=1;strat<= selection->numStrata;strat++) {
    results=&(selection->results[strat]);
    results->id = strat;
    
    for(int i=0;i<3;i++) {
      if(results->sheet[i] == -1) continue; // no data
      sheetData = selection->sheetData[results->sheet[i]];

      // loop through cells to find max and then again to copy data
      
      if(results->sheet[i]==-1 || results->col[i] == -1 ||
         results->row[i]==-1) {
        continue;  // nothing to see here so continue loop of 3
      }
      
      cells=sheetData->Cells();

    }

    int64_t maxRow = max(max(results->maxRow[AUDIT],results->maxRow[EXAM]),results->maxRow[DIFF]);

    for(int i=0;i<3;i++) {
      results->maxR = maxRow;

      // allocate and initialize space

      results->sheetContents[i] = new double[maxRow+1];
      for(int j=0;j<=maxRow;j++) results->sheetContents[i][j] =0.0;
      if(results->sheet[i]==-1) continue;  // nothing  more to do here

      sheetData = selection->sheetData[results->sheet[i]];
      cells=sheetData->Cells();        

      // copy data from spreadsheet cell list. Data is stored in cells array
      // with a column #, row # and value. Copy matching values
      for(int ind =0; cells[ind] != 0; ind++) {
        if(cells[ind]->Col() != results->col[i]) continue;  //wrong column
        int row = cells[ind]->Row();
        if(row < results->minR || row > results->maxR) continue; //wrong row
        double value = strtod(cells[ind]->Value(),NULL);
        results->sheetContents[i][row-results->minR]=value;
      }
      
    }
  }

  // Sum results for each stata
  for(uint64_t strat=1;strat<= selection->numStrata;strat++) {
    results=&(selection->results[strat]);  
    SumResult(selection,results);
  }

  // Now sum totals into overall
  SumTotals(selection);
}


/*****************************************************
 * Function: SumTotals
 *   Add up sums of all strata into overall
 *
 *****************************************************/
void SumTotals(Selection *selection) {
  VarResults *results,*totRes;
  totRes=&selection->results[0];
  totRes->id = 0;
  ClearResults(totRes);


  for(int i=0;i<3;i++) {  
    totRes->minRow[i] = selection->results[1].minRow[i];
    totRes->maxRow[i] = selection->results[1].maxRow[i];
  }

  
  for(uint64_t strat=1;strat<= selection->numStrata;strat++) {
    results=&(selection->results[strat]);
    totRes->samp += results->samp;
    totRes->univ += results->univ;
    if(results->maxR >= totRes->maxR)  totRes->maxR = results->maxR;
    if(results->minR <= totRes->minR)  totRes->minR = results->minR;
    for(int i=0;i<3;i++) {      
      totRes->nonZero[i]+=results->nonZero[i];
      totRes->sums[i]+=results->sums[i];
      totRes->sqrs[i]+=results->sqrs[i];
      totRes->cubes[i]+=results->cubes[i];
      totRes->quads[i]+=results->quads[i];                
      if(results->maxRow[i] >= totRes->maxRow[i])  totRes->maxRow[i] = results->maxRow[i];
      if(results->minRow[i] <= totRes->minRow[i])  totRes->minRow[i] = results->minRow[i];      
    }
  }
  totRes->minR = totRes->minRow[0];
  totRes->maxR = totRes->maxRow[0];  
  for(int i=1;i<3;i++) {  
    if(totRes->minRow[i] <= totRes->minR) totRes->minR = totRes->minRow[i];
    if(totRes->maxRow[i] >= totRes->maxR) totRes->maxR = totRes->maxRow[i];
  }
}

/*****************************************************
 * Function: SumResult
 *
 * For each strata add up sums of 
 *   values, sqaures, cubes and quads
 *
 * Do this for each data type: Examined, Audited, Differences
 * 
 * If have data for two of these data types, create third
 * Set fFormat flag to indicate what type of data we have
 *****************************************************/

void SumResult(Selection *selection, VarResults *results) {
  // loop through audit/exam/diff    
  wchar_t msg[BUFSIZE];
  int64_t minRow = -1;
  int fFlags[3];
  fFlags[AUDIT]=FAUDIT;
  fFlags[EXAM]=FEXAM;
  fFlags[DIFF]=FDIFF;  

  for(int i=0;i<3;i++) {
    if(results->maxRow[i] >0) {
      if(minRow == -1 || results->row[i] < minRow) 
        minRow = results->row[i];    
    }
  }

  results->minR = minRow;
  
  for(int i=0;i<3;i++) {
    results->sums[i] = 0;
    results->sqrs[i] = 0;
    results->cubes[i] = 0;
    results->quads[i] = 0;
    
    for(int64_t row=results->minR;row <= results->maxR;row++) {
      if(results->sheetContents[i] == NULL) DebugString(L"No sheet contents?");
      double tmp= results->sheetContents[i][row-results->minR];
      double value=tmp;
      results->sums[i] += tmp;
      tmp=tmp*value;
      results->sqrs[i] += tmp;
      tmp=tmp*value;
      results->cubes[i] += tmp;
      tmp=tmp*value;      
      results->quads[i] += tmp;
    }    
  }

  // Finding non-zero diffs AND 
  // If have a pair (like audit and examined) can calculate third (like diff)
  // 
  // EXAM - AUDIT = DIFF
  // empty rows assumed to be zero
  // starts counting at row 1 -- row 0 ignored
  
  if(results->fFormat == FAUDITEXAM) {
    DebugString(L"Making DIFF");
    results->maxRow[DIFF] = results->maxR;
    results->row[DIFF] = results->minR;    
    for(int64_t jInd=results->minR;jInd <= results->maxR; jInd++) {
      int64_t j = jInd-results->minR;
      double value=
        results->sheetContents[EXAM][j] -
        results->sheetContents[AUDIT][j];
      double tmp=value;
      
      results->sheetContents[DIFF][j] = tmp;
      if(tmp == 0) continue;
      results->nonZero[DIFF]++;
      results->sums[DIFF] += tmp;
      tmp=tmp*value;
      results->sqrs[DIFF] += tmp;
      tmp=tmp*value;
      results->cubes[DIFF] += tmp;
      tmp=tmp*value;      
      results->quads[DIFF] += tmp;
      
    }
    results->fFormat = FALL;
  } else if(results->fFormat == FAUDITDIFF) {
    results->maxRow[EXAM] = results->maxR;
    for(int64_t jInd=results->minR;jInd <= results->maxR; jInd++) {
      int64_t j = jInd-results->minR;
      double value=
        results->sheetContents[DIFF][j] +
        results->sheetContents[AUDIT][j];       
      double tmp=value;
      results->sheetContents[EXAM][j]=tmp;
      if(tmp == 0) continue;
      results->nonZero[EXAM]++;      
      results->sums[EXAM] += tmp;
      tmp=tmp*value;
      results->sqrs[EXAM] += tmp;
      tmp=tmp*value;
      results->cubes[EXAM] += tmp;
      tmp=tmp*value;      
      results->quads[EXAM] += tmp;                      
    }
    results->fFormat = FALL;    
  } else if(results->fFormat == FDIFFEXAM) {
    results->maxRow[AUDIT] = results->maxR;
    for(int64_t jInd=results->minR;jInd <= results->maxR; jInd++) {
      int64_t j = jInd-results->minR;
      double value=
        results->sheetContents[EXAM][j] -
        results->sheetContents[DIFF][j];
      double tmp=value;
      results->sheetContents[AUDIT][j]=tmp;
      if(tmp == 0) continue;
      results->nonZero[AUDIT]++;      
      results->sums[AUDIT] += tmp;
      tmp=tmp*value;
      results->sqrs[AUDIT] += tmp;
      tmp=tmp*value;
      results->cubes[AUDIT] += tmp;
      tmp=tmp*value;      
      results->quads[AUDIT] += tmp;                             
    }
    results->fFormat = FALL;     // Havce ALL Fomats = F[ormat]ALL = FALL
  }


  if(results->id == selection->numStrata) {  // on last one -- now update formats
    selection->fFormat = results->fFormat;
  }
  if(selection->fFormat != FALL) {  // don't have all datatypes just one
    switch (selection->fFormat) {
    case FEXAM: {
      selection->id = EXAM;
      break;
    }
    case FAUDIT: {
      selection->id = AUDIT;
      break;
    }
    case FDIFF: {
      selection->id = DIFF;
      break;
    }
    default: {
      wsprintf(msg,L"Found something else : %x",selection->fFormat);
      DebugString(msg);
    }
    }
  } else {
    selection->id = EXAM;
  }
  
  for(int i=0;i<3;i++) {
    results->nonZero[i]=0;
    for(int64_t j=results->minR; j<=results->maxR;j++) {
      if(results->sheetContents[i][j-results->minR] !=0.0)
        results->nonZero[i]++;
    }
  }
} // END SumResults



/******************************************************
INITIALIZATION:  For Statistical Calculations
*****************************************************/

double examValue[MAXSTRAT][4];
double audValue[MAXSTRAT][4];
double diffValue[MAXSTRAT][4];
double tVals[30][4];
int sampleSize[MAXSTRAT];
double c[1000];
double skew[2][4];

char *colHeading[] =
  {"----------------------- E X A M I N E D ------------------------",
   "----------------------- A U D I T E D --------------------------",
   "--------------------- D I F F E R E N C E ----------------------"};

int colWidth[]= {2,21,40,59};
char NBRCHK[] = "0123456789.-";
char *descript[] = {"MEAN / UNIVERSE",
                    "STANDARD DEVIATION",
                    "STANDARD ERROR",
                    "SKEWNESS",
                    "KURTOSIS",
                    "POINT ESTIMATE",
                    "LOWER LIMIT",
                    "UPPER LIMIT",
                    "PRECISION AMOUNT",
                    "PRECISION PERCENT",
                    "POINT ESTIMATE / UNIVERSE"};

int MSGROW = 22;
int maxLines = 55;
int lineNumber = 0;
int rowCounter = 0;

/*** Simple Math functions *******/

double Square(double val) {
  return val*val;
}

double Cube(double val) {
  return val*val*val;
}

double Quad(double val) {
  double sqr = Square(val);
  return Square(sqr);
}

/*****************************************************
 * Function: FindCumProb
 *   Find Cumulative Probablity given tValue, degrees of freedom
 *   and bounds a amd b (used by DetermineTVals tp refine tValue).
 *
 *****************************************************/
double FindCumProb(double tval, int64_t df, double a, double b)  {
  int numTerms = 100;
  
  double xval = (Square(tval)) / (Square(tval) + df);
  double c0;
  //
  //   Find C0
  //
  if( df == 2) {
    c0 = 1;
  } else if (df == 3) {
    c0 = 4 / M_PI;
  } else if ((df - 2 * (df / 2)) == 0) {
    c0 = 1;
    int64_t nterms = df / 2 - 1;
    for (int i = 1; i<=nterms; i++) {
      double temp = 2 * i + 1;
      c0 = (c0 * temp) / (temp - 1);
    }
  } else {
    c0 = 4 / M_PI;
    int64_t nterms = ((df - 1) / 2) - 1;
    for (int i = 1; i <= nterms; i++) {
      double temp = 2 * i + 2;
      c0 = (c0 * temp) / (temp - 1);
    }
  }

  //  double front = Square(pow(1 - xval, b));
  double front = pow(1 - xval, b)*pow(xval,a);  
  double tempval = c0;
  double logOld = log(c0);
  if (xval == 0) {
    tempval = 0;
  } else {
    for(int j = 1; j <= numTerms; j++) {
      double log1 = log((j - 1 + a + b) / (j + a));
      double log2 = logOld;
      double log4 = log1 + log2 + j * log(xval);
      logOld = log1 + log2;
      tempval = tempval + exp(log4);
    }
  }

  double probVal = 0.5 * (front * tempval + 1);
  return probVal;
}

/*****************************************************
 * Function: DetermineTVal
 *   Calculate statistical tValue given degrees of freedom
 * and specified confidence value example: (80, 90, 95)
 *
 *****************************************************/
void DetermineTVal(int64_t df, double confidenceInterval, double *result) {

  int maxIter = 1000;
  double eps = 0.00000000000001;
  double a = 0.5;
  double b = df / 2.0;
  double tval, tvalLast, cumProb,newProb;//, lowProb, highProb, newProb;
  double lowVal, highVal;

  
  lowVal = 0;
  highVal = 4;
  cumProb = confidenceInterval / 200.0 + 0.5; 
  tval=highVal;

    
  for(int iter =1; iter <= maxIter; iter++) {
    tvalLast = tval;
    tval = (lowVal + highVal) / 2.0;   
    newProb = FindCumProb(tval, df, a, b);
    
    if( newProb < cumProb) {
      lowVal = tval;
    } else {
      highVal = tval;
    }
    double diff = fabs(tval - tvalLast) - eps;
    if(diff <= 0) {
      *result = tval;
    } else {
      if (iter >= maxIter) {
	DebugString(L"Program was unable to determine a t-value");
	return;
      }
    }
    
  }
}



/*****************************************************
 * Function: Process
 *   Calculate statistics for overall and each strata
 *   for each data type
 *
 *****************************************************/
void Process(Selection *selection) {
  int64_t numStrat = selection->numStrata;
  
  double SEFin=0;
  int64_t degreesFreedom=0;
  double temp80=0;
  double temp90=0;
  double temp95=0;
  VarResults *results;

  //  char asciiMsg[BUFSIZE];  
  //HERE


  for(int loop1 = 0; loop1 <= numStrat; loop1++) {
    results = &selection->results[loop1];

    //---------CALCULATE MEANS --------
    for (int loop2=0;loop2 < 3; loop2++){
      if(results->samp > 0 && results->nonZero[loop2] > 0) {
        results->mean[loop2] = results->sums[loop2] / results->samp;
      }
    }
    
    //----------CALCULATE POINT ESTIMATES------
    for(int loop2= 0;loop2 <3;loop2++) {
      results->pointEst[loop2] = results->mean[loop2] * results->univ;
    }

    //---------CALCULATE CORRECTION FACTORS-------
    if (results->univ > 1) {
      SEFin = sqrt((results->univ - results->samp) / (1.0*(results->univ)));
    }

    //---------CALCULATE DEGREES OF FREEDOM-------
    degreesFreedom = results->samp - 1;

    //----------CALCULATE STANDARD DEVIATION-------
    for (int loop2 = 0; loop2 <3; loop2++) {
      if (results->sums[loop2] != 0 &&  results->samp > 1) {
        double temp1 = Square(results->sums[loop2]) / results->samp;
        if( temp1 < results->sqrs[loop2]) {
          results->stdDev[loop2] = sqrt((results->sqrs[loop2] - temp1) / degreesFreedom);
        } else {
          results->stdDev[loop2] = 0;
        }
      }
    }
  
    //----------CALCULATE STANDARD ERROR----------
    for (int loop2 = 0; loop2 < 3; loop2++) {
      if (results->stdDev[loop2] != 0 && results->samp > 1) {
        results->stdErr[loop2] = (results->stdDev[loop2] / sqrt(results->samp)) * SEFin;
      }
    }

    //---------CALCULATE SAMPLING ERROR---------
    if(degreesFreedom <= 3) {
      if (degreesFreedom == 1) {
        temp80 = 3.077683537175;
        temp90 = 6.313751514675;
        temp95 = 12.706204736175;
      } else if (degreesFreedom == 2) {
        temp80 = 1.885618083164;
        temp90 = 2.919985580354;
        temp95 = 4.30265272975;
      } else if (degreesFreedom == 3) {
        temp80 = 1.637744353696;
        temp90 = 2.353363434802;
        temp95 = 3.182446305284;
      }
    } else {
      DetermineTVal(degreesFreedom, 80, &temp80);
      DetermineTVal(degreesFreedom, 90, &temp90);
      DetermineTVal(degreesFreedom, 95, &temp95);      
    }
    results->tVal[0]=temp80;
    results->tVal[1]=temp90;
    results->tVal[2]=temp95;    
    
    // FindIntervals:
    for(int loop2 =0; loop2 < 3; loop2++) {
      if(results->nonZero[loop2] > 0) {
        results->precision[loop2][0] = temp80 * results->stdErr[loop2]*results->univ;
        results->precision[loop2][1] = temp90 * results->stdErr[loop2]*results->univ;
        results->precision[loop2][2] = temp95 * results->stdErr[loop2]*results->univ;
      }
    }

    //----------CALCULATE LOWER AND UPPER LIMITS-----------
    
    for(int loop2 =0; loop2 < 3; loop2++) {
      if(results->nonZero[loop2] > 0) {
        for(int loop3 =0; loop3<3;loop3++) {
          double temp = results->precision[loop2][loop3];
          results->confLow[loop2][loop3] = (int64_t)round(results->pointEst[loop2] - temp);
          results->confHi[loop2][loop3] = (int64_t)round(results->pointEst[loop2] + temp);  
        }
      }
    }

    //----------CALCULATE SKEWNESS-------------
    for(int loop2 = 0; loop2 < 3; loop2++) {
      results->skew[loop2]=0;
      if(results->samp > 0 && results->nonZero[loop2] > 0) {
        double temp1,temp2;
        temp1 = results->cubes[loop2] / results->samp;
        temp1 = temp1 - (3 * (results->sqrs[loop2] / results->samp) * results->mean[loop2]);
        temp1 = temp1 + 2 * Cube(results->mean[loop2]);
        if(results->sqrs[loop2] / results->samp > Square(results->mean[loop2])) {
          temp2 = sqrt(results->sqrs[loop2] / results->samp - Square(results->mean[loop2]));
        } else {
          temp2 = 0;
        }
        if(temp2 >= 1) {
          results->skew[loop2] = temp1 / Cube(temp2);
        }
      }
    }


    //----------CALCULATE KURTOSIS-------------
    for(int loop2 = 0; loop2 < 3; loop2++) {
      results->kurtosis[loop2]=0;    
      if(results->samp > 0 && results->nonZero[loop2] > 0) {
        double temp1,temp2;
        temp1 = results->quads[loop2] / results->samp;
        temp1 = temp1 - (4 * (results->cubes[loop2] / results->samp) * results->mean[loop2]);
        temp1 = temp1 + (6 * (results->sqrs[loop2] / results->samp) * Square(results->mean[loop2]));
        temp1 = temp1 - 3 * Quad(results->mean[loop2]);
        if(results->sqrs[loop2] / results->samp > Square(results->mean[loop2])) {
          temp2 = sqrt(results->sqrs[loop2] / results->samp - Square(results->mean[loop2]));
        } else {
          temp2 = 0;
        }
        if (temp2 >= 1) {
          results->kurtosis[loop2] = temp1 / Quad(temp2);
        }
      }
    }
  }
}


/*****************************************************
 * Function: ClearResults
 *   
 * Initialize Results Data Structure. Check to make
 * sure no memoory leak
 * 
 *
 *****************************************************/
void ClearResults(VarResults *results) {
  results->univ=0;
  results->samp=0;  
  results->minR=0;
  results->maxR=0;
  results->id = -1;
  for(int i=0;i<3;i++) {
    results->nonZero[i]=0;
    results->mean[i]=0;    
    results->stdDev[i]=0;
    results->stdErr[i]=0;
    results->skew[i]=0;
    results->kurtosis[i]=0;    
    results->pointEst[i]=0;
    results->sums[i]=0;
    results->sqrs[i]=0;
    results->cubes[i]=0;
    results->quads[i]=0;    
    results->tVal[i]=0;
    for(int j=0;j<3;j++) {
      results->confLow[i][j]=0;
      results->confHi[i][j]=0;
      results->precision[i][j]=0;      
    }
  }
  for(int i=0;i<5;i++) {
    results->col[i]=-1;
    results->row[i]=-1;
    results->sheet[i]=-1;
    results->maxRow[i]=0;    
    if(results->sheetContents[i] != NULL) {
      delete [] results->sheetContents[i];
      results->sheetContents[i] = NULL;
    }
  }	
    
}


/*****************************************************
 * Function: ClearSelection
 *   
 * Initialize Selection Data Structure
 * 
 *
 *****************************************************/
void ClearSelection(Selection *selection) {
  if(selection->sheetData != NULL)
    delete [] selection->sheetData;
  selection-> sheetData = NULL;

  for(int i=0;i<MAXSTRAT;i++) {
    ClearResults(&selection->results[i]);
  }
  
  selection->numStrata = 0;
  selection->fFormat = 0;
  selection->fileName[0]=0;
  selection->auditName[0]=0;

}

  
/*****************************************************
 * Function: IsExcelSpreadSheet
 *   
 * Open SpreadSheet (readonly) and see if it is of correct format
 * Will get exception if not
 *
 *****************************************************/
bool IsExcelSpreadSheet(const wchar_t * fileName) {
  ExcelAPIWrapper excel;
  TCHAR msg[BUFSIZE];
  char asciiMsg[BUFSIZE];	      
  char asciiFileName[BUFSIZE];
            
  wcstombs(asciiFileName,fileName,BUFSIZE-1);
  string str(asciiFileName);	    	    
  
  try{
    excel.OpenReadonlySpreadsheet(str.c_str());
  } catch (std::exception const &e) {
    sprintf(asciiMsg, "Caught exception %s",e.what());
    mbstowcs(msg,asciiMsg,BUFSIZE-1);
    DebugString(msg);
    return false;
  }
  excel.CloseSpreadsheet();
  return true;
}


/*****************************************************
 * Function: ProcessSpreadSheet
 *   
 * Open Spreadsheet and then read all of data into Selection
 *
 *****************************************************/
bool ProcessSpreadSheet(const wchar_t *fileName, Selection *selection) {
  TCHAR msg[BUFSIZE];
  char asciiMsg[BUFSIZE];	    

  char asciiFileName[BUFSIZE];
            
  wcstombs(asciiFileName,fileName,BUFSIZE-1);
  string str(asciiFileName);	    	    
  
  ExcelAPIWrapper excel;

  
  try{
    excel.OpenReadonlySpreadsheet(str.c_str());
  } catch (std::exception const &e) {
    sprintf(asciiMsg, "Caught exception %s",e.what());
    mbstowcs(msg,asciiMsg,BUFSIZE-1);
    DebugString(msg);
    return false;
  }
  
	    
  const char** sheetNames = excel.GetSheetNames();
  int numSheets=0;
  // Count sheets
  for(numSheets=0;sheetNames[numSheets] !=0; numSheets++);
  
  SheetData **sheetData = new SheetData*[numSheets+1];
  selection->sheetData = sheetData;
  wcscpy_s(selection->fileName,BUFSIZE,fileName);
  
  sheetData[numSheets]=0;
  int *numCells = new int[numSheets];
  for(int i=0;i<numSheets; i++) {

    const char *** contents=excel.GetContents(sheetNames[i]);	      
    numCells[i]=(int)contents[0];

    sheetData[i]=new SheetData(numCells[i]);
    sheetData[i]->SetName(sheetNames[i]);
    DebugString(TEXT("Processing Cell"));
    CellContents **cells = sheetData[i]->Cells();
    if(cells==NULL) {
      DebugString(TEXT("Null Cells"));
      return false;
    }
    for (int j=1; j<= numCells[i]; j++) {
      if(contents[j] == NULL) {
	DebugString(TEXT("Null contents?"));
      }		
      if(contents[j][0] == NULL) {
	DebugString(TEXT("Null contents string 0?"));
      }
      sheetData[i]->AddCell(contents[j]);		
    }
  }

  excel.CloseSpreadsheet();
  
  return true;
}


/*****************************************************
 * Function: GetTextInputContents
 *   
 * Get data from Text File
 *  This assumes the original RAT-STATS format:
 *
 * Data only, in just a few columns  (max 3 columns)
 * Separated by spaces or tabs
 * Results is vector of vectors of values  (rows of data)
 *
****************************************************/
const std::vector<std::vector<double>> GetTextInputContents(const wchar_t * fileName) {
  TCHAR msg[BUFSIZE];
#define maxString 40
  ifstream inFile;

  char asciiFileName[BUFSIZE];
            
  wcstombs(asciiFileName,fileName,BUFSIZE-1);
  
  inFile.open(asciiFileName,std::fstream::in);

  // Should do something here if fails to open
  if(!inFile.is_open()) {
    wsprintf(msg,L"Failed to open %ls",fileName);
    DebugString (msg);
  }

  int lineCnt=0;
  // count number of items,
  // assuming all separated by white space, and just numbers, max 3 columns

  std::string line;
  while (getline(inFile,line)) {
    lineCnt++;
  }

  std::vector<std::vector<double>> results =
    std::vector<std::vector<double>>(lineCnt+1,std::vector<double>(3,0));

  results[0][0]=lineCnt;

  // clear EOF flag and move back to begining to read data

  inFile.clear();
  inFile.seekg(0, ios::beg);

  int col,row=1;
  while (getline(inFile,line)) {
    istringstream ss(line);
    ss.imbue(std::locale(""));
    string token;
    col=0;
    while(col <3 && ss>>results[row][col++]);
    row++;
  }
  
  inFile.close();
  return results;
}
    
    
    
/*****************************************************
 * Function: ProcessTextInput
 *   
 * Open Text File and then read all of data into Selection
 *
 *****************************************************/  
bool ProcessTextInput(const wchar_t * fileName, Selection *selection) {

  TCHAR msg[BUFSIZE];

  // We treat this like sheets for consistency with Excel part
  
  SheetData **sheetData = new SheetData*[2];
  selection->sheetData = sheetData;
  wcscpy_s(selection->fileName,BUFSIZE,fileName);
  
  sheetData[0]=0;
  
  std::vector<std::vector<double>> contents=GetTextInputContents(fileName);	      
  int numRows=(int)contents[0][0];
  wsprintf(msg,L"Found %d rows",numRows);
  DebugString(msg);
  sheetData[0]=new SheetData(numRows*3);
  sheetData[0]->SetName("Default");

  CellContents **cells = sheetData[0]->Cells();
  if(cells==NULL) {
    DebugString(TEXT("Null Cells"));
    return false;
    }
  
  for(int row=1;row<=numRows;row++)
    for (int col=0; col < 3; col++) {
      sheetData[0]->AddCell(row,col,contents[row][col]);		
  }

  return true;
}



  

  
      
