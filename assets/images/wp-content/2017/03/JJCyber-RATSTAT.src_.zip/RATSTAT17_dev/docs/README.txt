Team Captain: Jim Alves-Foss, jimaf@jjcybersecurity.com   (no other team members)
Identifier: JJCyber


Contents:

This solution contains the following documents (numbers correspond to numbers 
in submission instructions on challenge website)

(1)	JJCyber-RATSTATS.exe.zip	A zip file containing the executable solution 
                                and related DLL files. This solution replicates
								the 4 target RAT-STATS functions: Single Stage of 
								Random Numbers, Unrestricted Attribute Appraisal, 
								Unrestricted Variable Appraisal, and the 
								Stratified Variable Appraisal.
(2)	JJCyber-RATSTATS.src.zip	A zip file containing the source code for the 
                                executable, header files, resource files, 
								makefile and relevant DLLs.
(3)	JJCyber-Overview.docx	    A document providing a detailed discussion of 
                                the submission, including a discussion of 
								differences between the original RAT-STATS and 
								this submission. 
(4)	JJCyber-Devel.docx	        A document describing the overall code structure
                                and design with guidance how to modify the 
								solution to add additional functionality.
(5)	JJCyber-Licenses.docx	    A document listing all software licenses 
                                associated with the source code and libraries
								used as part of the project. 
(6)	JJCyber-Summary.docx	    A document providing summary submission 
                                information as requested on the challenge 
								website.


README.txt                      This document. 