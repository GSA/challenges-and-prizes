#ifndef WICHMANNHILL_H
#define WICHMANNHILL_H

#include <map>
#include <math.h>

void ExcelRand64(int64_t ExcelSeed, int64_t outputmax, int64_t &Step, long double &ExcelOutput, long double &RATSTAT);
int64_t ExcelRandomize64(double startingpoint, int64_t ExcelSeed);

class WichmannHill
{
	private:
        long double seed_a = 0;
        long double seed_b = 0;
        long double seed_c = 0;

	public:
        int generateNumbers(int how_many, int min, int max, std::map<int, int> &randoms);
        int sum(std::map<int, int> &randoms);
        WichmannHill(double seed);
};

#endif
