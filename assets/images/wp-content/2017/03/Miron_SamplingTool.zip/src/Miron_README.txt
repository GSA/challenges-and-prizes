Team members:

1. Murray Miron, Murray.T.Miron@gmail.com



5-digit prefix:

Miron



Submission description:

A redesign of the original RAT-STATS statistical software, meeting all challenge.gov requirements, which is able to be rapidly and easily extended from its current form.  The program is as cross-platform as is practicable, and can be compiled to execute on Windows, Mac, Linux, or Android platforms; note however that the design of the GUI component would make navigating the software difficult on a mobile phone.

The author would like to point out that the current incarnation of the program was produced and designed with almost zero knowledge of how users interact with and rely on the program; the primary requirement of maintaining almost perfect backward compatibility with the original RAT-STATS software was given priority.  The author holds a bachelor's degree in computer science from the Rochester Institute of Technology, and is freely available to customize any or all parts of the program to better suit the workflow of end users.  In short, any aspect of the program can easily be tailored to better suit its user's needs, provided they work with the author to accomplish this.
