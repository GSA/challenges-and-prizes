#include "dialogunrestrictedattributeappraisal.h"
#include "ui_dialogunrestrictedattributeappraisal.h"
#include "samplingtool.h"



DialogUnrestrictedAttributeAppraisal::DialogUnrestrictedAttributeAppraisal(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogUnrestrictedAttributeAppraisal)
{
    ui->setupUi(this);
}

DialogUnrestrictedAttributeAppraisal::~DialogUnrestrictedAttributeAppraisal()
{
    delete ui;
}

// use the Clopper Pearson estimation, and find the true value from there
static uint64_t upper_limit(uint64_t sample_size, uint64_t population_size, uint64_t sample_successes, uint64_t population_successes, double confidence)
{
    uint64_t ret = 0;
    double cdf = 0, C = ((1 - confidence) / 2.0);
    boost::math::hypergeometric_distribution<double> hg_dist(population_successes, sample_size, population_size);
    ret = population_size * boost::math::binomial_distribution<double>::find_upper_bound_on_p(sample_size, sample_successes, C);
    //qDebug() << "Upper bound search for " << confidence << " started at: " << ret;

    for (/* empty */; ret > 0; ret--)
    {
        hg_dist = boost::math::hypergeometric_distribution<double>(ret, sample_size, population_size);
        cdf = boost::math::cdf<double>(hg_dist, sample_successes);
        if ( cdf > C)
            break;
    }
    return ret;
}

/* FIXME: sample_successes -1 ?!? */
static uint64_t lower_limit(uint64_t sample_size, uint64_t population_size, uint64_t sample_successes, uint64_t population_successes, double confidence)
{
    uint64_t ret = 0;
    double cdf = 0, C = ((1 - confidence) / 2.0);
    boost::math::hypergeometric_distribution<double> hg_dist(population_successes, sample_size, population_size);
    ret = population_size * boost::math::binomial_distribution<double>::find_lower_bound_on_p(sample_size, sample_successes, C);
    //qDebug() << "Lower bound search for " << confidence << " started at: " << ret;

    for (/* empty */; ret < population_size; ret++)
    {
        hg_dist = boost::math::hypergeometric_distribution<double>(ret, sample_size, population_size);
        cdf = boost::math::cdf<double>(hg_dist, sample_successes - 1);
        if ( (1 - cdf) > C)
            break;
    }
    return ret;
}

void DialogUnrestrictedAttributeAppraisal::on_buttonBox_accepted()
{
    uint64_t N, n, K, k;
    QStringList out;

    N = ui->spinBox_universeSize->value();
    n = ui->spinBox_sampleSize->value();
    k = ui->spinBox_itemsOfInterest->value();
    K = round(k / (n / (double)N));

    out << "<b><u><big><center>Attribute Appraisal - Unrestricted</center></big></u></b><br/>";
    out << "Audit: " << ui->lineEdit_auditName->text() << "<br/>";
    out << "Date: " << QDateTime::currentDateTime().toString() << "<br/>";
    out << "Universe size: " << QString::asprintf("%'ld", N) << "<br/>";
    out << "Sample size: " << QString::asprintf("%'ld", n) << "<br/>\n";
    out << "Characteristic of interest in sample: " << QString("%1").arg(k) << "<br/>";
    out << QString::asprintf("Projected quantity in universe: %'ld (%'.2f%%)", K, (100 * (K / (double)N))) << "<br/>\n";
    try {
        if (n == 0 || n > N || k > n || N == 0)
            throw std::exception();
        out << QString::asprintf("Lower 95%% confidence limit: %ld<br/>", lower_limit(n, N, k, K, 0.95));
        out << QString::asprintf("Upper 95%% confidence limit: %ld<br/>\n", upper_limit(n, N, k, K, 0.95));
        out << QString::asprintf("Lower 90%% confidence limit: %ld<br/>", lower_limit(n, N, k, K, 0.90));
        out << QString::asprintf("Upper 90%% confidence limit: %ld<br/>\n", upper_limit(n, N, k, K, 0.90));
        out << QString::asprintf("Lower 80%% confidence limit: %ld<br/>", lower_limit(n, N, k, K, 0.80));
        out << QString::asprintf("Upper 80%% confidence limit: %ld<br/>", upper_limit(n, N, k, K, 0.80));
    } catch (...) {
        ST_ERRORBOX("An error occurred; please check your input values.");
        return;
    }

    emit displayHtml(out.join(""));
}

