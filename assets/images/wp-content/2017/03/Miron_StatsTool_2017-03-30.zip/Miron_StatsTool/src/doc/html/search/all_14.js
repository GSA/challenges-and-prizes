var searchData=
[
  ['values',['values',['../dc/d80/Miron__Noncosmetic__Differences_8txt.html#a0501d93d19eff55143e35f0085a1d811',1,'Miron_Noncosmetic_Differences.txt']]],
  ['version',['Version',['../dd/de8/Miron__Licenses_8txt.html#a8b377bc90fdd710b1e428b0384a7e4d2',1,'Miron_Licenses.txt']]]
];
