/*
 * All the logic for the program's main window is found here.  The
 * actual GUI design is found in the .ui file.
 *
 * The design is quite simple: encapsulate all the code as much as is
 * practical, so that even if one of the pieces ends up messy or
 * delicate in the future, it won't interfere with the rest of the
 * program.
 *
 * To accomplish that, modules get their data from the GUI windows,
 * then do whatever calculations they need to do, and execute the
 * appropriate callback provided by the main window (in this file here)
 * to display the results of their calculations.
 */

#include "statstool.h"
#include "ui_statstool.h"
#include "dialogsinglestagerandomnumbers.h"
#include "dialogunrestrictedattributeappraisal.h"
#include "ui_dialogsinglestagerandomnumbers.h"
#include "dialogunrestrictedvariableappraisal.h"
#include "ui_dialogunrestrictedvariableappraisal.h"
#include "dialogstratifiedvariableappraisal.h"
#include "ui_dialogstratifiedvariableappraisal.h"
#include "dialogselectexcelsheet.h"
#include "ui_dialogselectexcelsheet.h"


StatsTool::StatsTool(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::StatsTool)
{
    ui->setupUi(this);
    ui->pushButton_saveToFile->setDisabled(true);
}

StatsTool::~StatsTool()
{
    delete ui;
}

void StatsTool::displayImage(QString file)
{
    ui->textEdit_outputArea->setHtml(QString("<br/><br/><img src='%1'/>").arg(file));
    return;
/*
    QUrl Uri ( QString ( "file://%1" ).arg ( file ) );
    QImage image = QImageReader ( file ).read();

    QTextDocument * textDocument = ui->textEdit_outputArea->document();
    textDocument->addResource( QTextDocument::ImageResource, Uri, QVariant ( image ) );
    QTextCursor cursor = ui->textEdit_outputArea->textCursor();
    QTextImageFormat imageFormat;
    imageFormat.setWidth( image.width() );
    imageFormat.setHeight( image.height() );
    imageFormat.setName( Uri.toString() );
    cursor.insertImage(imageFormat);
*/
}

void StatsTool::setupDisplayArea()
{
    ui->textEdit_outputArea->show();
    ui->textEdit_outputArea->setEnabled(true);
    ui->pushButton_saveToFile->setEnabled(true);
    ui->textEdit_outputArea->setStyleSheet("");
}

void StatsTool::displayHtml(QString str)
{
    ui->textEdit_outputArea->setHtml(QString("%1").arg(str.replace("\n", "<br/>")));
    setupDisplayArea();
}

void StatsTool::displayText(QString str)
{
    ui->textEdit_outputArea->setText(str);
    setupDisplayArea();
}

QString StatsTool::excelFileToPlainText(QString &fileName)
{
    QXlsx::Document excel(fileName);
    QStringList sheetNames = excel.sheetNames();

    if (sheetNames.size() > 1) {
        DialogSelectExcelSheet dialog;
        dialog.addSheetNames(sheetNames);
        int sheetnum = dialog.exec();
        excel.selectSheet(sheetNames.at(sheetnum));
    }
    return excelFileToPlainText(excel);
}

QString StatsTool::excelFileToPlainText(QXlsx::Document &excel)
{
    QStringList ret;
    QString row;

    for (int i = 1; excel.cellAt(i, 1) != 0; i++)
    {
        for (int j = 1; excel.cellAt(i, j) != 0; j++)
        {
            if (QRegExp("[A-z]+").indexIn(excel.read(i, j).toString()) > -1) {
                row.append(QString(" %1").arg(excel.read(i, j).toString().split(QRegExp("\t| "), QString::SkipEmptyParts).join("_")));
            } else {
                row.append(QString::asprintf(" %'.3f", excel.read(i, j).toDouble()).remove(QRegExp("\\.0+\\b")));
            }
        }
        ret << row;
        row.clear();
    }
    return ret.join("\n");
}

double StatsTool::ratstats_kurtosis(matrix_t &matrix, int column, double mean)
{
    double x, x_bar = mean, numerator = 0, denominator = 0;
    uint n = matrix.rows();

    for (uint i = 0; i < n; i++)
    {
        x = matrix(i, column);
        numerator += pow((x - x_bar), 4);
        denominator += pow((x - x_bar), 2);
    }
    numerator /= n;
    denominator /= n;
    denominator = pow(denominator, 2);
    return numerator / denominator;
}

double StatsTool::ratstats_skewness(matrix_t &matrix, int column, double mean)
{
    double x, x_bar = mean, numerator = 0, denominator = 0;
    uint n = matrix.rows();

    for (uint i = 0; i < n; i++)
    {
        x = matrix(i, column);
        numerator += pow((x - x_bar), 3);
        denominator += pow((x - x_bar), 2);
    }
    numerator /= n;
    denominator /= n;
    denominator = pow(denominator, 3/2.0);
    return numerator / denominator;
}

// what to do when the "single stage random number" action is triggered (e.g. by
// selecting that menu option)
void StatsTool::on_actionSingle_Stage_Random_Number_triggered()
{
    static DialogSingleStageRandomNumbers *dialog = NULL;
    if (!dialog) {
        dialog = new DialogSingleStageRandomNumbers(this);
        connect(dialog, SIGNAL(displayText(QString)), this, SLOT(displayText(QString)));
        connect(dialog, SIGNAL(displayHtml(QString)), this, SLOT(displayHtml(QString)));
    }
    dialog->exec();
}

// unrestricted attribute appraisal action
void StatsTool::on_actionUnrestricted_Attribute_Appraisal_triggered()
{
    static DialogUnrestrictedAttributeAppraisal *dialog = NULL;
    if (!dialog) {
        dialog = new DialogUnrestrictedAttributeAppraisal(this);
        connect(dialog, SIGNAL(displayText(QString)), this, SLOT(displayText(QString)));
        connect(dialog, SIGNAL(displayHtml(QString)), this, SLOT(displayHtml(QString)));
    }
    dialog->exec();
}

// stratified variable appraisal action
void StatsTool::on_actionStratified_Variable_Appraisal_triggered()
{
    static DialogStratifiedVariableAppraisal *dialog = NULL;
    if (!dialog) {
        dialog = new DialogStratifiedVariableAppraisal(this);
        connect(dialog, SIGNAL(displayText(QString)), this, SLOT(displayText(QString)));
        connect(dialog, SIGNAL(displayHtml(QString)), this, SLOT(displayHtml(QString)));
    }
    dialog->exec();
}

// unrestricted variable appraisal action
void StatsTool::on_actionUnrestricted_Variable_Appraisal_triggered()
{
    static DialogUnrestrictedVariableAppraisal *dialog = NULL;
    if (!dialog) {
        dialog = new DialogUnrestrictedVariableAppraisal(this);
        connect(dialog, SIGNAL(displayText(QString)), this, SLOT(displayText(QString)));
        connect(dialog, SIGNAL(displayHtml(QString)), this, SLOT(displayHtml(QString)));
    }
    dialog->exec();
}

void StatsTool::dumpToExcelFile(QString filename, QString html)
{
    QRegExp rx("<pre[^>]*>(.*)</.?pre>", Qt::CaseInsensitive);
    QString data;
    QXlsx::Document doc;

    if (rx.indexIn(html) == -1) {
        ST_ERRORBOX("This specific report does not provide enough information to format an Excel file properly.");
        return;
    }

    data = rx.cap(1);
    int x = 1, y = 1;
    foreach(QString line, data.split(QRegExp("\r?\n|</?.?br.?/?>"), QString::SkipEmptyParts))
    {
        foreach(QString cell, line.remove(QRegExp("<[^>]+>")).split(SPLIT_REGEXP, QString::SkipEmptyParts))
        {
            if (QRegExp("[^.0-9]+").indexIn(cell) > -1)
                doc.write(x, y++, cell);
            else if (QRegExp("[0-9]+\\.[0-9]+").indexIn(cell) > -1)
                doc.write(x, y++, atof(cell.toStdString().c_str()));
            else //(QRegExp("[0-9]+").indexIn(cell) > -1)
                doc.write(x, y++, cell.toInt());
        }
        x++;
        y = 1;
    }

    if (doc.saveAs(filename)) {
        ST_ERRORBOX(QString("Saved to %1").arg(filename));
    } else {
        ST_ERRORBOX("An error occurred while saving the file.");
    }
}

void StatsTool::saveToExcelFile(QString filename, QString text)
{
    dumpToExcelFile(filename, QString("<pre>%1</pre>").arg(text));
}

void StatsTool::on_pushButton_saveToFile_clicked()
{
    QString filename = QFileDialog::getSaveFileName(this, tr("Select Output File"), "", tr("*.txt *.html *.xlsx"));
    if (filename.isEmpty())
        return;
    if (QRegExp("xlsx$", Qt::CaseInsensitive).indexIn(filename) > -1) {
        // dump to Excel format and return
        saveToExcelFile(filename, ui->textEdit_outputArea->toPlainText());
        return;
    }
    // write to text or html format
    QFile file(filename);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        ST_ERRORBOX("Error opening file.");
        return;
    }
    QTextStream out(&file);
    if (QRegExp("html$", Qt::CaseInsensitive).indexIn(filename) > -1)
        out << ui->textEdit_outputArea->toHtml();
    else
        out << ui->textEdit_outputArea->toPlainText();
    file.close();

    ST_ERRORBOX("Saved to " + filename);
}

void StatsTool::on_pushButton_quit_clicked()
{
    exit(EXIT_SUCCESS);
}

void StatsTool::on_actionAbout_triggered()
{
    ST_ERRORBOX(PROGRAM_STRING_FULL + tr(", by Murray Miron.\n\n"
                                         "Written for the Department of Health and Human Services within the U.S. Office of Inspector General.\n\n"
                                         "This program uses Qt, Boost, QtXlsx, Scythe, and the C++ Standard Template Library.\n\n"
                                         "Background splash image and program icon made with GIMP."));
}

void StatsTool::on_actionHelp_triggered()
{
    ST_ERRORBOX(tr("For help information about the current program focus (for example, to see help about the current input field being edited), press SHIFT+F1.  Go ahead and try it now."));
}

void StatsTool::on_actionCompliance_triggered()
{
    ST_ERRORBOX(tr(COMPLIANCE_INFORMATION));
}
