var indexSectionsWithContent =
{
  0: "abcdefghilmoprstuw~",
  1: "drsw",
  2: "u",
  3: "dmrsw",
  4: "abcdefgilmoprstuw~",
  5: "disu",
  6: "bm",
  7: "r",
  8: "ht",
  9: "cps",
  10: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "defines",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Macros",
  10: "Pages"
};

