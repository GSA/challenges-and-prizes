var searchData=
[
  ['text',['TEXT',['../da/da8/classReport.html#a9b979064ff74f8488f2201f93c079393ace0f254ad83054b180f2f32efd582ee1',1,'Report']]],
  ['topheader',['topHeader',['../da/da8/classReport.html#ac61817952a016d555934f618a0d0e09b',1,'Report::topHeader(QString source_module)'],['../da/da8/classReport.html#afc40c3429e946bbcd568016721b4f210',1,'Report::topHeader(QString source_module, QStringList extra)']]]
];
