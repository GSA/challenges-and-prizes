var searchData=
[
  ['needs',['needs',['../df/de2/Miron__README_8txt.html#ae785591223632e7b147a96f6e696da03',1,'Miron_README.txt']]],
  ['numbers',['numbers',['../dc/d80/Miron__Noncosmetic__Differences_8txt.html#ad50d336edd03618d598ebbd97875cd2e',1,'Miron_Noncosmetic_Differences.txt']]]
];
