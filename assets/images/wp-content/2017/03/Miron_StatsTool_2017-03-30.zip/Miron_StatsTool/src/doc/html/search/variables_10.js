var searchData=
[
  ['technology',['Technology',['../df/de2/Miron__README_8txt.html#aceac5c1a3da0560457e1f0275af0c490',1,'Miron_README.txt']]],
  ['to',['to',['../dc/d80/Miron__Noncosmetic__Differences_8txt.html#a489cf7e9353c8aaa9da39b8ba4343f1e',1,'Miron_Noncosmetic_Differences.txt']]]
];
