var searchData=
[
  ['build_5freport',['build_report',['../d3/ddf/classDialogStratifiedVariableAppraisal.html#a6872027b6b06db908a35e79a2e6cf5ef',1,'DialogStratifiedVariableAppraisal::build_report()'],['../db/da5/classDialogUnrestrictedVariableAppraisal.html#aa6084c32b63750507f82974c6dca8e0b',1,'DialogUnrestrictedVariableAppraisal::build_report()']]]
];
