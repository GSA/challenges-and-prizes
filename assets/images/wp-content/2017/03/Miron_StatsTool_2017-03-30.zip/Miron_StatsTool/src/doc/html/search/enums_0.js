var searchData=
[
  ['report_5ftype',['report_type',['../da/da8/classReport.html#a9b979064ff74f8488f2201f93c079393',1,'Report']]]
];
