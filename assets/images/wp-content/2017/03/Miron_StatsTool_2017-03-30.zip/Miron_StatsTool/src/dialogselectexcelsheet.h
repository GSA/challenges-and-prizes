#ifndef DIALOGSELECTEXCELSHEET_H
#define DIALOGSELECTEXCELSHEET_H

#include <QDialog>

namespace Ui {
class DialogSelectExcelSheet;
}

/**
 * @brief A trivial class to allow the user to select a sheet within an Excel file
 */
class DialogSelectExcelSheet : public QDialog
{
    Q_OBJECT

public:
    explicit DialogSelectExcelSheet(QWidget *parent = 0);
    ~DialogSelectExcelSheet();
    void addSheetNames(QStringList sheetNames);

private slots:
    void on_buttonBox_accepted();

private:
    Ui::DialogSelectExcelSheet *ui;
};

#endif // DIALOGSELECTEXCELSHEET_H
