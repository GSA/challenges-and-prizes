var searchData=
[
  ['datafilename',['dataFileName',['../d3/ddf/classDialogStratifiedVariableAppraisal.html#a4ac9cf73a4b861c056e8c0182f8d9c11',1,'DialogStratifiedVariableAppraisal']]]
];
