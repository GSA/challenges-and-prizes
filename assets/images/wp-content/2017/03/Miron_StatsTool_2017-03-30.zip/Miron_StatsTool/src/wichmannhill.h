#ifndef WICHMANNHILL_H
#define WICHMANNHILL_H

#include <unordered_map>
#include <map>
#include <math.h>

/**
 * @brief An implementation of the Wichmann-Hill pseudo-random number generator
 *
 * Designed and coded to mimic the original RAT-STATS software
 */
class WichmannHill
{
	private:
        /**
         * @brief ExcelRand64
         * @param ExcelSeed
         * @param outputmax
         * @param Step
         * @param ExcelOutput
         * @param RATSTAT
         *
         * A C++ implementation (of an R version provided by the OIG) of the Visual Basic function used by RAT-STATS
         */
        void ExcelRand64(int64_t ExcelSeed, int64_t outputmax, int64_t &Step, long double &ExcelOutput, long double &RATSTAT);

        /**
         * @brief ExcelRandomize64
         * @param startingpoint
         * @param ExcelSeed
         * @return
         *
         * C++ implementation (of an R version provided by the OIG) of the Visual Basic function used by RAT-STATS
         */
        int64_t ExcelRandomize64(double startingpoint, int64_t ExcelSeed);

        long double seed_a = 0;
        long double seed_b = 0;
        long double seed_c = 0;
        /**
         * @brief check_duplicate
         * @param hashmap
         * @param temp
         * @return
         *
         * This is executed for every number generated; since it's much faster to use hash buckets than to
         * iterate through an array, a std::unordered_map (implemented with hash buckets) is used
         */
        bool check_duplicate(std::unordered_map<int64_t, int64_t> &hashmap, int64_t temp);

	public:
        /**
         * @brief generateNumbers
         * @param how_many
         * @param min
         * @param max
         * @param randoms
         * @return
         *
         * Generate random numbers using the same algorithm as RAT-STATS
         */
        int generateNumbers(int how_many, int64_t min, int64_t max, std::map<int64_t, int64_t> &randoms);
        /**
         * @brief sum
         * @param randoms
         * @return
         *
         * Compute the sum of a set of random numbers
         */
        int64_t sum(std::map<int64_t, int64_t> &randoms);
        /**
         * @brief WichmannHill
         * @param seed
         *
         * Construct a Wichmann-Hill PRNG with the given seed
         */
        WichmannHill(double seed);
};

#endif
