var searchData=
[
  ['requirements',['requirements',['../df/de2/Miron__README_8txt.html#ae3b0a67bb278b1b1602c61f70ee11955',1,'Miron_README.txt']]]
];
