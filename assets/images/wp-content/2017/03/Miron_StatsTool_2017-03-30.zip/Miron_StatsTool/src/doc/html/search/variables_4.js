var searchData=
[
  ['practical',['practical',['../df/de2/Miron__README_8txt.html#af0fe3b8c6626bf86c0921d5d3628f1d3',1,'Miron_README.txt']]],
  ['prefix',['prefix',['../df/de2/Miron__README_8txt.html#a7f372df3e4120d35ea3a267ff88939f6',1,'Miron_README.txt']]],
  ['program',['program',['../df/de2/Miron__README_8txt.html#a9ed7afe5d84c22dd55eaa119f870e991',1,'Miron_README.txt']]]
];
