var searchData=
[
  ['part',['part',['../dd/de8/Miron__Licenses_8txt.html#a11803ed8491565ef1f2ec8956592b6c9',1,'Miron_Licenses.txt']]],
  ['platforms',['platforms',['../df/de2/Miron__README_8txt.html#a94685bf46dee164ab5aadd9a6a9fd2aa',1,'Miron_README.txt']]],
  ['practical',['practical',['../df/de2/Miron__README_8txt.html#af0fe3b8c6626bf86c0921d5d3628f1d3',1,'Miron_README.txt']]],
  ['practices',['practices',['../d8/d9a/Miron__Additional__Function__Procedure_8txt.html#a8d4e76a1d19babb72e0b6f40de633632',1,'Miron_Additional_Function_Procedure.txt']]],
  ['prefix',['prefix',['../df/de2/Miron__README_8txt.html#a7f372df3e4120d35ea3a267ff88939f6',1,'Miron_README.txt']]],
  ['process',['process',['../d8/d9a/Miron__Additional__Function__Procedure_8txt.html#a49b621d6d258d4d07b8923b1c5bd6862',1,'Miron_Additional_Function_Procedure.txt']]],
  ['program',['program',['../d8/d9a/Miron__Additional__Function__Procedure_8txt.html#abd737154f8fb8853c40038a66031141a',1,'program():&#160;Miron_Additional_Function_Procedure.txt'],['../df/de2/Miron__README_8txt.html#a76edd78ec761351774581794159f94b1',1,'program():&#160;Miron_README.txt']]],
  ['purpose',['PURPOSE',['../dd/de8/Miron__Licenses_8txt.html#a470e4c4c45105ac31406770b0fbc1b17',1,'Miron_Licenses.txt']]],
  ['purposes',['purposes',['../d8/d9a/Miron__Additional__Function__Procedure_8txt.html#af3d32a98a308148f0ae1f19883afe352',1,'Miron_Additional_Function_Procedure.txt']]]
];
