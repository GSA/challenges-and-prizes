var searchData=
[
  ['program_5fstring_5ffull',['PROGRAM_STRING_FULL',['../d3/dbd/statstool_8h.html#af7b4886f8db9d3a3e251c641031640fa',1,'statstool.h']]],
  ['program_5ftitle',['PROGRAM_TITLE',['../d3/dbd/statstool_8h.html#a959462b59a4b8326fcdec34c1d5a4a00',1,'statstool.h']]],
  ['program_5fversion_5fmajor',['PROGRAM_VERSION_MAJOR',['../d3/dbd/statstool_8h.html#a9730e0b602fdbcb160581546ffabf71c',1,'statstool.h']]],
  ['program_5fversion_5fminor',['PROGRAM_VERSION_MINOR',['../d3/dbd/statstool_8h.html#a5b77305c35c59a2951263db646f3bb52',1,'statstool.h']]],
  ['program_5fversion_5fstring',['PROGRAM_VERSION_STRING',['../d3/dbd/statstool_8h.html#a57d58a8d5582cb4bf9f9c6bd40b2d015',1,'statstool.h']]]
];
