#ifndef REPORT_H
#define REPORT_H

#include "statstool.h"

/**
 * @brief Stub class for more elegantly-designed reports
 */
class Report
{
public:
    Report();

    QString topHeader(QString source_module);
    QString topHeader(QString source_module, QStringList extra);

    typedef enum {
        HTML,
        TEXT,
    } report_type;
};


#endif // REPORT_H
