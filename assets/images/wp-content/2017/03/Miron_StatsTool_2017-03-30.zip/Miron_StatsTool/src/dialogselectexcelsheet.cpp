/*
 * A trivial little class that shows a popup box for
 * the user to select which sheet to read data from
 * when opening an Excel file.
 */

#include "dialogselectexcelsheet.h"
#include "ui_dialogselectexcelsheet.h"

DialogSelectExcelSheet::DialogSelectExcelSheet(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogSelectExcelSheet)
{
    ui->setupUi(this);
}

DialogSelectExcelSheet::~DialogSelectExcelSheet()
{
    delete ui;
}

void DialogSelectExcelSheet::addSheetNames(QStringList sheetNames)
{
    ui->comboBox_sheetName->addItems(sheetNames);
}

void DialogSelectExcelSheet::on_buttonBox_accepted()
{
    done(ui->comboBox_sheetName->currentIndex());
}
