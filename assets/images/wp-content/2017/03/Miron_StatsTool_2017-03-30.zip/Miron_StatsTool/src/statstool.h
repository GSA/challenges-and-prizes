/*
 * The "main" program header file.
 *
 * In brief, GUI (Graphical User Interface) programs are event-driven: they
 * generally sit dormant until an event triggers an action (e.g. the user
 * clicking on a button.)  Usually that amounts to just calling a function.
 *
 * The Qt framework (which is a cross-platform toolkit that's primary aim
 * is to provide cross-platform GUI functionality) is no exception to this.  To
 * accomplish it's primary goal, it features its own objects, the point of which
 * is to leave the job of making sure everything behaves the same regardless of
 * what platform you're executing the program on, up to the Qt folks.
 *
 * So, throughout the program source code, you'll see classes that encapsulate
 * pieces of functionality.  Most of the GUI itself was designed as Qt Forms
 * in QtCreator (that's what all of the .ui files are), and when the project
 * is built, those .ui files are compiled into C++ code by Qt's "uic" program.
 *
 * The C++ code generated from the .ui files is then used by the rest of the
 * C++ source code throughout the project.
 *
 * Note that this is a high-level overview of how the source code ends up
 * as an executable file, and is meant only to give a reader unfamiliar with
 * Qt or traditional GUI programming some idea of what's going on.
 */

#ifndef SAMPLINGTOOL_H
#define SAMPLINGTOOL_H

#define COMPLIANCE_INFORMATION "508 compliance dictates many details of a program; for example: " \
    "the order in which the tab button moves focus from field to field; all entry fields must " \
    "work properly with assistive technology like screen readers; and so on.  Some aspects of " \
    "the program are designed and implemented with considerations like 508 compliance in mind."

#include <QDebug>

/**
 * scythestat is a little library that provides arbitrarily sized 2-d matrices,
 * along with a few useful functions to perform calculations on them (like the
 * standard deviation of a column or the entire matrix, etc.)
 */
#include "scythestat/stat.h"

// some statistics functions from the Boost::Math library that are very useful
#include <boost/math/distributions/students_t.hpp>
#include <boost/math/distributions/hypergeometric.hpp>
#include <boost/math/distributions/binomial.hpp>
#include <boost/math/policies/policy.hpp>

// math.h provides stuff like "sqrt()" and "pow()"
#include <math.h>
#include <stdlib.h>

// a bunch of Qt libraries for basic functionality
#include <QtXlsx/QtXlsx>
#include <QDropEvent>
#include <QMimeData>
#include <QRegExp>
#include <QMainWindow>
#include <QMessageBox>
#include <QFile>
#include <QFileDialog>
#include <QTextStream>
#include <QDateTime>
#include <QTextEdit>
#include <QString>
#include <QStringList>
#include <QTableView>
#include <QStandardItemModel>
#include <QStandardItem>
#include <QtAccessibilitySupport/QtAccessibilitySupport>
#include <QAccessibleWidget>

#define PROGRAM_TITLE QString("Stats Tool")
#define PROGRAM_VERSION_MAJOR 1
#define PROGRAM_VERSION_MINOR 1
#define PROGRAM_VERSION_STRING (QString("v") + QString("%1").arg(PROGRAM_VERSION_MAJOR) + "." + QString("%1").arg(PROGRAM_VERSION_MINOR))
#define PROGRAM_STRING_FULL PROGRAM_TITLE + " " + PROGRAM_VERSION_STRING

#define ST_ERRORBOX(str) { QMessageBox errBox; errBox.setWindowTitle(PROGRAM_TITLE); errBox.setText(str); errBox.setWhatsThis(tr("Click this button to close the message box.")); errBox.exec(); }

#define STRIP_REGEXP QRegExp("\\$|,|\\(|\\)")
#define SPLIT_REGEXP QRegExp("\t| ")

typedef scythe::Matrix<long double, scythe::Row, scythe::Concrete> matrix_t;

/**
 * In order to mimic the behavior of the original RAT-STATS software,
 * it's necessary to relax the error checking of the BOOST library;
 * since RAT-STATS is well-validated, this is assumed to be mathematically
 * sound (i.e. the output matches given specific inputs.)
 *
 * This error policy causes BOOST to silently return a "best guess," even
 * if calculations are not strictly irrefutable (the details of why output
 * that's been well-validated in RAT-STATS since the 1970's is a "best guess"
 * are not known by the author.)
 */
typedef boost::math::policies::policy<
    boost::math::policies::domain_error<boost::math::policies::errno_on_error>,
    boost::math::policies::pole_error<boost::math::policies::errno_on_error>,
    boost::math::policies::overflow_error<boost::math::policies::errno_on_error>,
    boost::math::policies::evaluation_error<boost::math::policies::errno_on_error>
> boost_error_policy;

namespace Ui {
class StatsTool;
}

/**
 * @brief The program's main window
 *
 * This class serves as the main window.
 */
class StatsTool : public QMainWindow
{
    Q_OBJECT

public:
    explicit StatsTool(QWidget *parent = 0);
    ~StatsTool();
    /** Open an Excel file by name and return the contents as a QString */
    static QString excelFileToPlainText(QString &fileName);
    /** Return the contents of an already-open Excel document as a QString */
    static QString excelFileToPlainText(QXlsx::Document &excel);
    /** Calculate the skewness of a matrix column using the same formula as RAT-STATS */
    static double ratstats_skewness(matrix_t &matrix, int column, double mean);
    /** Calculate the kurtosis of a matrix column using the same formula as RAT-STATS */
    static double ratstats_kurtosis(matrix_t &matrix, int column, double mean);
    /** Dump preformatted text to an Excel format file */
    void dumpToExcelFile(QString filename, QString html);
    /** Dump all text to an Excel format file */
    void saveToExcelFile(QString filename, QString text);

public slots:
     /** Display the passed QString in the main window as plain, unformatted text */
    void displayText(QString str);
    /** Display the passed QString in the main window as rich text (HTML) */
    void displayHtml(QString str);

private slots:
    /** Display the Single Stage Random Number dialog */
    void on_actionSingle_Stage_Random_Number_triggered();
    /** Display the Unrestricted Attribute Appraisal dialog */
    void on_actionUnrestricted_Attribute_Appraisal_triggered();
    /** Display the Unrestricted Variable Appraisal dialog */
    void on_actionUnrestricted_Variable_Appraisal_triggered();
    /** Display the Stratified Variable Appraisal dialog */
    void on_actionStratified_Variable_Appraisal_triggered();
    /** Save the currently displayed report to a file */
    void on_pushButton_saveToFile_clicked();
    /** Quit the program */
    void on_pushButton_quit_clicked();
    /** Display the About dialog */
    void on_actionAbout_triggered();
    /** Display the Help dialog */
    void on_actionHelp_triggered();
    /** Display the Compliance dialog */
    void on_actionCompliance_triggered();

private:
    Ui::StatsTool *ui;
    /** Go from splash-style main window display to report-style */
    void setupDisplayArea();
    /** Display an arbitrary image in the report window */
    void displayImage(QString file);
};

#endif // SAMPLINGTOOL_H
