/*
 * All the code for the "Single Stage Random Numbers" module
 * logic is in here; the actual GUI design is in the .ui file.
 *
 * The Wichmann-Hill code is found in that file and not this one,
 * as well.
 */

#include "dialogsinglestagerandomnumbers.h"
#include "ui_dialogsinglestagerandomnumbers.h"
#include "statstool.h"
#include "ui_statstool.h"
#include "wichmannhill.h"

DialogSingleStageRandomNumbers::DialogSingleStageRandomNumbers(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogSingleStageRandomNumbers)
{
    static QValidator *validator = new QIntValidator(0, INT_MAX, this);
    static QValidator *double_validator = new QDoubleValidator(-INT_MAX, INT_MAX, 17);
    ui->setupUi(this);
    ui->lineEdit_numbersToGenerate->setValidator(validator);
    ui->lineEdit_spareNumbersToGenerate->setValidator(validator);
    ui->lineEdit_maximumValue->setValidator(validator);
    ui->lineEdit_minimumValue->setValidator(validator);
    ui->lineEdit_seed->setValidator(double_validator);
}

DialogSingleStageRandomNumbers::~DialogSingleStageRandomNumbers()
{
    delete ui;
}

static void insert_ratstats_compliant_number_list(std::map<int64_t, int64_t> &randoms, QStringList &out, int n_sorted)
{
    std::map<int64_t, int64_t> sorted_randoms;

    if (n_sorted > 0) {
        // sort by value (std::map objects are sorted by key)
        for (std::map<int64_t, int64_t>::iterator it = randoms.begin(); it != randoms.end(); it++)
        {
            sorted_randoms.insert(std::pair<int64_t, int64_t>(it->second, it->first));
            if (it->first == n_sorted)
                break;
        }
        // insert strings for sorted-by-value numbers
        for (std::map<int64_t, int64_t>::iterator it = sorted_randoms.begin(); it != sorted_randoms.end(); it++)
        {
            out << QString::asprintf("%6ld  %6ld\n", it->second, it->first);
        }
    }
    // insert strings for sorted-by-generation-order numbers
    for (std::map<int64_t, int64_t>::iterator it = randoms.find(n_sorted + 1); it != randoms.end(); it++)
    {
        out << QString::asprintf("%6ld  %6ld\n", it->first, it->second);
    }
}

// Qt doesn't like exceptions, so provide an exception-safe wrapper
void DialogSingleStageRandomNumbers::on_buttonBox_accepted()
{
    try {
        on_buttonBox_accepted_unsafe();
    } catch (std::exception &e) {
        qDebug() << e.what();
        ST_ERRORBOX("An error occurred; please check your input values and try again.");
    }
}

void DialogSingleStageRandomNumbers::on_buttonBox_accepted_unsafe()
{
    double seed = atof(ui->lineEdit_seed->text().toStdString().c_str());
    int numbers = ui->lineEdit_numbersToGenerate->text().toInt();
    int spares = ui->lineEdit_spareNumbersToGenerate->text().toInt();
    int min = ui->lineEdit_minimumValue->text().toInt();
    int max = ui->lineEdit_maximumValue->text().toInt();
    std::map<int64_t, int64_t> randoms;

    // generate a random seed via the system clock
    if (seed == 0.00) {
        seed = QDateTime::currentMSecsSinceEpoch() % 10000;
    }
    WichmannHill rng(seed);

    // sanity check on requested values
    if (max - min + 1 < numbers + spares) {
        ST_ERRORBOX("Not enough unique values in your universe to generate that many numbers.");
        return;
    }

    // generate numbers and handle general RNG failure (return value < 0) just in case
    if (rng.generateNumbers(numbers + spares, min, max, randoms) < 0) {
        ST_ERRORBOX("The Wichmann-Hill RNG failed; please check the input values.");
        return;
    }

    // build output
    QStringList out;
    out << "<b><u><big><center>Random Numbers - Single Stage</center></big></u></b>" << "\n";
    out << "Audit: " << ui->lineEdit_auditName->text() << "\n";
    out << "Time: " << QDateTime::currentDateTime().toString() << "\n\n";
    out << "Seed: " << QString::asprintf("%.10lf", seed) << "\n";
    out << "Frame size: " << QString::asprintf("%'d", max - min + 1) << "\n";
    out << QString::asprintf("Sum of all %d random numbers: %'ld\n", numbers + spares, rng.sum(randoms));
    out << "<pre>";
    out << "Selection\n  Order   Value\n\n";
    insert_ratstats_compliant_number_list(randoms, out, numbers);
    out << "</pre>";

    emit displayHtml(out.join(""));
    this->reject();
}

