/**
 * All the code that implements the logic for the Unrestricted
 * Variable Appraisal is found in this file; as is the case elsewhere
 * however, the actual GUI design is in the corresponding .ui file.
 */

#include "dialogunrestrictedvariableappraisal.h"
#include "ui_dialogunrestrictedvariableappraisal.h"
#include "statstool.h"

DialogUnrestrictedVariableAppraisal::DialogUnrestrictedVariableAppraisal(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogUnrestrictedVariableAppraisal)
{
    static QValidator *validator = new QIntValidator(0, INT_MAX, this);
    ui->setupUi(this);
    // we need to override the "dropEvent()" function of the text edit, so by disabling it
    // in that object, it propagates up to us (where we implement it below)
    ui->plainTextEdit->setAcceptDrops(false);
    setAcceptDrops(true);

    ui->lineEdit_sampleSize->hide();
    ui->label_sampleSize->hide();

    ui->lineEdit_universeSize->setValidator(validator);
    ui->lineEdit_sampleSize->setValidator(validator);
}

DialogUnrestrictedVariableAppraisal::~DialogUnrestrictedVariableAppraisal()
{
    delete ui;
}

// this is called when something is dragged into our area: we need to say we want to accept the drop
void DialogUnrestrictedVariableAppraisal::dragEnterEvent(QDragEnterEvent *event)
{
    if (event->mimeData()->hasFormat("text/uri-list"))
        event->acceptProposedAction();
}

// called when something is actually dropped on us
void DialogUnrestrictedVariableAppraisal::dropEvent(QDropEvent *event)
{
    if (event->mimeData()->urls().isEmpty())
        return;
    else
        readFromFile(event->mimeData()->urls().first().toLocalFile());
}

// fill the preview area by reading from a file
void DialogUnrestrictedVariableAppraisal::readFromFile(QString inputFileName)
{
    QMimeDatabase db;
    QString plainText;
    QMimeType type = db.mimeTypeForFile(inputFileName);

    qDebug() << "MIME type of file: " << type.name();
    if (QRegExp("spreadsheet").indexIn(type.name()) > -1) {
        plainText = StatsTool::excelFileToPlainText(inputFileName);
        ui->plainTextEdit->document()->setPlainText(plainText);
        return;
    } else {
        QFile inputfile(inputFileName);
        if (!inputfile.open(QIODevice::ReadOnly | QIODevice::Text)) {
            ST_ERRORBOX("Error opening file.");
            return;
        }
        QTextStream in(&inputfile);
        ui->plainTextEdit->document()->setPlainText(in.readAll());
        inputfile.close();
    }
}

void DialogUnrestrictedVariableAppraisal::on_pushButton_chooseInputFile_clicked()
{
    // Get input file
    inputFileName = QFileDialog::getOpenFileName(this, tr("Input File"), "", tr("*.txt *.xlsx"));
    if (inputFileName.isEmpty())
        return;
    else
        readFromFile(inputFileName);
}

bool DialogUnrestrictedVariableAppraisal::first_column_is_examined(QString str)
{
    QRegExp rx("[Ee]xamined");

    return rx.indexIn(str) > -1;
}

bool DialogUnrestrictedVariableAppraisal::second_column_is_difference(QString str)
{
    QRegExp rx(" [Dd]ifference");

    return rx.indexIn(str) > -1;
}

bool DialogUnrestrictedVariableAppraisal::first_column_is_audited(QString str)
{
    QRegExp rx("[Aa]udited");

    return (rx.indexIn(str) > -1 && !first_column_is_examined(str));
}

bool DialogUnrestrictedVariableAppraisal::first_column_is_difference(QString str)
{
    QRegExp rx("[Dd]ifference");

    return (rx.indexIn(str) > -1);
}

void DialogUnrestrictedVariableAppraisal::fill_in_column(matrix_t &mat, int examined_column, int audited_column, int difference_column, int n_rows)
{
    matrix_t sums = scythe::sumc(mat);

    if (sums(0, difference_column) == 0)
        for (int i = 0; i < n_rows; i++)
            mat(i, difference_column) = mat(i, examined_column) - mat(i, audited_column);
    if (sums(0, examined_column) == 0)
        for (int i = 0; i < n_rows; i++)
            mat(i, examined_column) = mat(i, audited_column) + mat(i, difference_column);
    if (sums(0, audited_column) == 0)
        for (int i = 0; i < n_rows; i++)
            mat(i, audited_column) = mat(i, examined_column) - mat(i, difference_column);
}

double DialogUnrestrictedVariableAppraisal::ratstats_kurtosis(matrix_t &matrix, int column, double mean)
{
    return StatsTool::ratstats_kurtosis(matrix, column, mean);
}

double DialogUnrestrictedVariableAppraisal::ratstats_skewness(matrix_t &matrix, int column, double mean)
{
    return StatsTool::ratstats_skewness(matrix, column, mean);
}

// build the output report; the column values are either -1 (data does not exist), or equal the column index into the matrix for which data to
// label as that category (examined, audited, or difference)
void DialogUnrestrictedVariableAppraisal::build_report(matrix_t &mat, QStringList &report, QString &inputFileName, int universeSize, int exa_col, int aud_col, int dif_col)
{
    int n_nonzero_diffs = 0;
    uint sampleSize = mat.rows();
    double t_value;
    matrix_t means = scythe::meanc(mat);
    matrix_t sums = scythe::sumc(mat);
    matrix_t std_devs = scythe::sdc(mat);
    matrix_t pnt_ests(1, 3);
    matrix_t sd_means(1, 3);
    matrix_t sd_totals(1, 3);
    boost::math::students_t dist(sampleSize - 1);

    // calculate values to use in the report
    if (exa_col > -1) {
        pnt_ests(0, exa_col) = means(exa_col) * universeSize;
        sd_means(0, exa_col) = std_devs(exa_col) * sqrt((universeSize - sampleSize) / (double)(sampleSize * universeSize));
        sd_totals(0, exa_col) = sd_means(0, exa_col) * universeSize;
    }
    if (aud_col > -1) {
        pnt_ests(0, aud_col) = means(aud_col) * universeSize;
        sd_means(0, aud_col) = std_devs(aud_col) * sqrt((universeSize - sampleSize) / (double)(sampleSize * universeSize));
        sd_totals(0, aud_col) = sd_means(0, aud_col) * universeSize;
    }
    if (dif_col > -1) {
        pnt_ests(0, dif_col) = means(dif_col) * universeSize;
        sd_means(0, dif_col) = std_devs(dif_col) * sqrt((universeSize - sampleSize) / (double)(sampleSize * universeSize));
        sd_totals(0, dif_col) = sd_means(0, dif_col) * universeSize;
        for (uint i = 0; i < mat.rows(); i++)
            if (mat(i, dif_col) != 0)
                n_nonzero_diffs++;
    }

    // build the report output
    report << "<b><center><u><big>Variable Appraisal - Unrestricted</big></u></center></b>\n";
    report << "Audit: " << ui->lineEdit->text() << "\n";
    report << "Date: " << QDateTime::currentDateTime().toString() << "\n";
    report << "Input file: " << inputFileName << "\n";
    report << "Sample size: " << QString::asprintf("%'d", mat.rows()) << "\n";
    report << "Universe size: " << QString::asprintf("%'d", universeSize) << "\n";
    if (dif_col > -1) report << "Nonzero difference values: " << QString::asprintf("%'d", n_nonzero_diffs) << "\n";

    int order[3] = { exa_col, aud_col, dif_col };
    for (int i = 0; i < 3; i++)
    {
        int column = order[i];
        if (column > -1) {
            if (column == exa_col) report << "<u><center>Examined values</center></u>" << "\n";
            else if (column == aud_col) report << "<u><center>Audited values</center></u>" << "\n";
            else if (column == dif_col) report << "<u><center>Difference values</center></u>" << "\n";
            report << "Sum: " << QString::asprintf("<b>%'.02Lf</b>", sums(0, column)) << "\n";
            report << "Mean: " << QString::asprintf("<b>%'.02Lf</b>", means(0, column)) << "\n";
            report << "Standard deviation: " << QString::asprintf("<b>%'.02Lf</b>\n", std_devs(0, column));
            report << "Skewness: " << QString::asprintf("<b>%'.02f</b>", ratstats_skewness(mat, column, means(0, column))) << "\n";
            report << "Kurtosis: " << QString::asprintf("<b>%'.02f</b>", ratstats_kurtosis(mat, column, means(0, column))) << "\n";
            report << "Standard error (mean): " << QString::asprintf("<b>%'.02Lf</b>\n", sd_means(0, column));
            report << "Standard error (total): " << QString::asprintf("<b>%'.02Lf</b>\n", sd_totals(0, column));
            report << "Point estimate: " << QString::asprintf("<b>%'.02Lf</b>\n", pnt_ests(0, column));
            for (double C = 0.20; C >= 0.05; C /= 2)
            {
                report << "\n";
                t_value = boost::math::quantile(boost::math::complement(dist, C / 2));
                report << QString::asprintf("Lower <b>%d%%</b> confidence limit: <b>%'.02Lf</b>\n", (int)((1 - C) * 100), pnt_ests(0, column) - (sd_totals(0, column) * t_value));
                report << QString::asprintf("Upper <b>%d%%</b> confidence limit: <b>%'.02Lf</b>\n", (int)((1 - C) * 100), pnt_ests(0, column) + (sd_totals(0, column) * t_value));
                report << QString::asprintf("Precision amount: %'.02Lf\n", sd_totals(0, column) * t_value);
                report << QString::asprintf("Precision percent: %.02Lf%%\n", pnt_ests(0, column) < 0 ? 0 : 100 * ((sd_totals(0, column) * t_value) / pnt_ests(0, column)));
                report << QString::asprintf("t-Value used: %'.12f\n", t_value);
            }
        }
    }
}

// Qt doesn't like exceptions, so provide an exception-safe wrapper
void DialogUnrestrictedVariableAppraisal::on_buttonBox_accepted()
{
    QApplication::setOverrideCursor(Qt::WaitCursor);
    qint64 start_msecs = QDateTime::currentMSecsSinceEpoch();
    try {
        on_buttonBox_accepted_unsafe();
    } catch (std::exception &e) {
        qDebug() << e.what();
        ST_ERRORBOX("An error occurred; please check your input values and try again.");
    }
    QApplication::restoreOverrideCursor();
    qDebug() << QString("Finished in %1 seconds").arg( (QDateTime::currentMSecsSinceEpoch() - start_msecs) / 1000.0);
}

void DialogUnrestrictedVariableAppraisal::on_buttonBox_accepted_unsafe()
{
    QString buf = ui->plainTextEdit->document()->toPlainText();
    QStringList report;
    QStringList lines = buf.split(QRegExp("\r?\n"), QString::SkipEmptyParts);
    QStringList line_tokens;
    // the index into the matrix of each data column
    int examined_column = -1, audited_column = -1, difference_column = -1;
    // flag indicating if the first row contains data or labels
    int row_start = ui->checkBox_firstRowContainsData->isChecked() ? 1 : 0;
    // flag indicating if the first column contains data or labels
    int col_start = ui->checkBox_firstColumnContainsData->isChecked() ? 1 : 0;
    int n_rows = lines.size() - row_start;
    int n_cols, n_cols_expected;
    matrix_t matrix(n_rows, 3);

    // sanity checking
    if (n_rows <= row_start) {
        ST_ERRORBOX("Not enough data.");
        return;
    }

    // If the universe size wasn't set, make it the sample size
    if (ui->lineEdit_universeSize->text().toInt() < n_rows) {
        ui->lineEdit_universeSize->setText(QString("%1").arg(n_rows));
        ST_ERRORBOX("The entered universe size was smaller than the amount of data entered; it has been set to equal the sample size automatically.");
    }

    // if the first column isn't data (e.g. labels), we expect an extra column in the input
    n_cols_expected = 1 + col_start;
    // if the user selected a multiple column input format (e.g. "examined and audited"), we expect an extra column
    if (ui->comboBox_dataContains->currentText().indexOf(" and ") > -1)
        n_cols_expected++;
    n_cols = lines.at(row_start).split(SPLIT_REGEXP, QString::SkipEmptyParts).size();
    if (n_cols > n_cols_expected || n_cols < n_cols_expected) {
        ST_ERRORBOX(tr("Data is not properly formatted; the selected options mean the program expected ") + QString("%1").arg(n_cols_expected)
                    + tr(" columns (including any non-data, e.g. label, column.)"));
        return;
    }

    // fill the scythe::matrix
    for (int i = row_start; i < lines.size(); i++)
    {
        line_tokens = lines.at(i).split(SPLIT_REGEXP, QString::SkipEmptyParts);
        for (int j = col_start; j < n_cols; j++)
        {
            if (line_tokens.size() < n_cols || line_tokens.size() > n_cols) {
                ST_ERRORBOX(tr("Data is not properly formatted; error at line ") + QString("%1").arg(i + 1));
                return;
            }
            buf = line_tokens.at(j);
            buf.remove(STRIP_REGEXP);
            matrix(i - row_start, j - col_start) = buf.toDouble();
        }
    }

    // determine column indexes and fill in missing column if necessary
    if (n_cols - col_start > 1) {
        if (second_column_is_difference(ui->comboBox_dataContains->currentText())) {
            if (first_column_is_examined(ui->comboBox_dataContains->currentText())) {
                examined_column = 0;
                audited_column = 2;
            } else {
                examined_column = 2;
                audited_column = 0;
            }
            difference_column = 1;
        } else {
            examined_column = 0;
            audited_column = 1;
            difference_column = 2;
        }
        fill_in_column(matrix, examined_column, audited_column, difference_column, n_rows);
    } else {
        if (first_column_is_examined(ui->comboBox_dataContains->currentText())) {
            examined_column = 0;
        } else if (first_column_is_difference(ui->comboBox_dataContains->currentText())) {
            difference_column = 0;
        } else {
            audited_column = 0;
        }
    }

    // build the report and display it
    try {
        build_report(matrix, report, inputFileName, ui->lineEdit_universeSize->text().toInt(), examined_column, audited_column, difference_column);
    } catch (std::exception &e) {
        qDebug() << e.what();
        ST_ERRORBOX("Calculations failed; please check the input data.");
        return;
    }

    emit displayHtml(report.join(""));
    this->reject();
}

void DialogUnrestrictedVariableAppraisal::on_checkBox_enableEditing_toggled(bool checked)
{
    ui->plainTextEdit->setReadOnly(!checked);
}
