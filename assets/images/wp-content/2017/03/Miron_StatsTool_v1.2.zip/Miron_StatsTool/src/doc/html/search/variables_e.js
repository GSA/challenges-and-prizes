var searchData=
[
  ['report',['report',['../dc/d80/Miron__Noncosmetic__Differences_8txt.html#acb99fc2d2a69c250893fad0967466cd6',1,'Miron_Noncosmetic_Differences.txt']]],
  ['reproduce',['reproduce',['../dd/de8/Miron__Licenses_8txt.html#a758fd709bf1aa53b74a70841504c34f8',1,'Miron_Licenses.txt']]],
  ['requirements',['requirements',['../df/de2/Miron__README_8txt.html#ae3b0a67bb278b1b1602c61f70ee11955',1,'Miron_README.txt']]],
  ['requires',['requires',['../d8/d9a/Miron__Additional__Function__Procedure_8txt.html#a4273d97a8ed2a3a68aa9b17de7820f26',1,'Miron_Additional_Function_Procedure.txt']]]
];
