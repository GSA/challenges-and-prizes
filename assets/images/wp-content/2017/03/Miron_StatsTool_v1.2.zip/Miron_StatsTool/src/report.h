#ifndef REPORT_H
#define REPORT_H

#include "statstool.h"

/**
 * @brief Stub class for more elegantly designed reports
 */
class Report : public QTextDocument, public QStringList
{
public:
    Report();
    Report(QTextEdit &textEdit);
    ~Report();

    QDateTime generationTime;
    QString auditName;
    QString sourceModule;
    QString inputFile;
    QString inputFile2;

    QString join(QString string);

    QString getText();
    QString getHtml();
    QString getExcel();

    Report &addText(QString text);
    QString addTextLine(QString line);
    Report &addHtml(QString html);
    QString addHtmlLine(QString html);

    QString topHeader(QString source_module);
    QString topHeader(QString source_module, QStringList extra);

    void appendBlock(QString text);
    void appendText(QString text);

    Report &operator<<(const QString string);

private:
    QTextCursor *cursor;
    QString textData;
    QString htmlData;
};


#endif // REPORT_H
