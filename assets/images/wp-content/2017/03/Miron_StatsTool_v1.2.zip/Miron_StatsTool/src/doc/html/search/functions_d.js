var searchData=
[
  ['ratstats_5fkurtosis',['ratstats_kurtosis',['../db/da5/classDialogUnrestrictedVariableAppraisal.html#a8bfbf018ebfe6327bae209a0c038927f',1,'DialogUnrestrictedVariableAppraisal::ratstats_kurtosis()'],['../d7/d2e/classStatsTool.html#a2c137ecefb33960a514ac0bf650a14e1',1,'StatsTool::ratstats_kurtosis()']]],
  ['ratstats_5fskewness',['ratstats_skewness',['../db/da5/classDialogUnrestrictedVariableAppraisal.html#affd0d23fc4f3e94c6a6f528063ec7ea4',1,'DialogUnrestrictedVariableAppraisal::ratstats_skewness()'],['../d7/d2e/classStatsTool.html#ab6d3684165b251b1c070610215cdb905',1,'StatsTool::ratstats_skewness()']]],
  ['readfromfile',['readFromFile',['../db/da5/classDialogUnrestrictedVariableAppraisal.html#a862c68b5e7998a1b2b336691d097dd57',1,'DialogUnrestrictedVariableAppraisal']]],
  ['report',['Report',['../da/da8/classReport.html#ae3150817fcf4ebf814358baf5bd72e8f',1,'Report::Report()'],['../da/da8/classReport.html#ad6e004f19c57cad269617b0ee3fd937f',1,'Report::Report(QTextEdit &amp;textEdit)']]]
];
