#ifndef DIALOGSINGLESTAGERANDOMNUMBERS_H
#define DIALOGSINGLESTAGERANDOMNUMBERS_H

#include <QDialog>
#include <QFileDialog>

namespace Ui {
class DialogSingleStageRandomNumbers;
}

/**
 * @brief Encapsulates the Single Stage Random Numbers module
 */
class DialogSingleStageRandomNumbers : public QDialog
{
    Q_OBJECT

public:
    explicit DialogSingleStageRandomNumbers(QWidget *parent = 0);
    ~DialogSingleStageRandomNumbers();

    QString auditName;
    QString generationTime;
    double seed;
    int framesize;
    int64_t sum;
    int min;
    int max;
    int numRandoms;
    int numSpares;

    /**
     * @brief Perform this module's calculations and store the data in public member variables
     * @param name The name of the audit
     * @param numRandoms How many sorted-by-value numbers to generate
     * @param numSpares How many sorted-by-generation-order numbers to generate
     * @param seed Value to initialize the RNG with
     * @param min Minimum value of random numbers
     * @param max Maximum value of random numbers
     * @param randoms The map object to store the generated numbers in
     *
     * This function takes all the data provided by this module's window and implements
     * the logic.  Can be used by instantiating an object of this dialog's class and
     * providing the same input as the GUI window would have; the results are then
     * available in member variables of the object and the _randoms_ parameter.
     */
    void calculate(QString name, int numRandoms, int numSpares, double seed, int min, int max, std::map<int64_t, int64_t> &randoms);

    /**
     * @brief Generate a report from previously performed calculations
     * @param out Used as the return value
     * @param randoms The randomly generated numbers
     *
     * Uses previously calculated values to build a report for display to the user
     */
    void buildHtmlReport(QStringList &out, std::map<int64_t, int64_t> &randoms);


signals:
    void displayText(QString str);
    void displayHtml(QString str);


private slots:
    void on_buttonBox_accepted();


private:
    Ui::DialogSingleStageRandomNumbers *ui;
    void on_buttonBox_accepted_unsafe();
};

#endif // DIALOGSINGLESTAGERANDOMNUMBERS_H
