var searchData=
[
  ['textdata',['textData',['../da/da8/classReport.html#a538ce5581ee095e8b2f9e01a7c2a2230',1,'Report']]],
  ['topheader',['topHeader',['../da/da8/classReport.html#ac61817952a016d555934f618a0d0e09b',1,'Report::topHeader(QString source_module)'],['../da/da8/classReport.html#afc40c3429e946bbcd568016721b4f210',1,'Report::topHeader(QString source_module, QStringList extra)']]]
];
