var searchData=
[
  ['windows',['Windows',['../df/de2/Miron__README_8txt.html#acc36773d646f0b5fc24d32079ec3989d',1,'Miron_README.txt']]]
];
