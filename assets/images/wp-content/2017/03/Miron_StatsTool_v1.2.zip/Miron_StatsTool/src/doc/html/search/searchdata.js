var indexSectionsWithContent =
{
  0: "abcdefghijlmnoprstuw~",
  1: "drsw",
  2: "u",
  3: "dmrsw",
  4: "abcdefgijlmoprstuw~",
  5: "acdfghimnstu",
  6: "bm",
  7: "cps",
  8: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Macros",
  8: "Pages"
};

