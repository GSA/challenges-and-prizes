var searchData=
[
  ['auditname',['auditName',['../d7/da5/classDialogSingleStageRandomNumbers.html#a6a23845244561d4c8a7c2a9aa47a1349',1,'DialogSingleStageRandomNumbers::auditName()'],['../da/da8/classReport.html#ae23847ef3278e63a3e0fd68cae33ac9d',1,'Report::auditName()'],['../d7/d2e/classStatsTool.html#a9603b73b0a54778ee2964623c33207cf',1,'StatsTool::auditName()']]]
];
