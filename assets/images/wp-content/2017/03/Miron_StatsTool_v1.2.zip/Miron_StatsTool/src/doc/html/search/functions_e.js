var searchData=
[
  ['savetoexcelfile',['saveToExcelFile',['../d7/d2e/classStatsTool.html#aba43759358c66681e743cea2f253c3f3',1,'StatsTool']]],
  ['second_5fcolumn_5fis_5fdifference',['second_column_is_difference',['../db/da5/classDialogUnrestrictedVariableAppraisal.html#a28f49db0cf29d64d9cfa7f1fc6e0f4e4',1,'DialogUnrestrictedVariableAppraisal']]],
  ['setupdisplayarea',['setupDisplayArea',['../d7/d2e/classStatsTool.html#a09755778ea7ac3ad9820f946871ef055',1,'StatsTool']]],
  ['statstool',['StatsTool',['../d7/d2e/classStatsTool.html#af7d04e4802130facbae6843f8f04cdbf',1,'StatsTool']]],
  ['sum',['sum',['../dd/d12/classWichmannHill.html#a723a1fcebe1dac24e3226272280e9b07',1,'WichmannHill']]]
];
