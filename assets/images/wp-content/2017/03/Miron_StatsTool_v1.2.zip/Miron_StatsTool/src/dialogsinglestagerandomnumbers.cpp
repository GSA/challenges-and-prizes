/*
 * All the code for the "Single Stage Random Numbers" module
 * logic is in here; the actual GUI design is in the .ui file.
 *
 * The Wichmann-Hill code is found in that file and not this one,
 * as well.
 */

#include "dialogsinglestagerandomnumbers.h"
#include "ui_dialogsinglestagerandomnumbers.h"
#include "statstool.h"
#include "ui_statstool.h"
#include "wichmannhill.h"
#include "report.h"


DialogSingleStageRandomNumbers::DialogSingleStageRandomNumbers(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogSingleStageRandomNumbers)
{
    static QValidator *validator = new QIntValidator(0, INT_MAX, this);
    static QValidator *double_validator = new QDoubleValidator(-INT_MAX, INT_MAX, 17);
    ui->setupUi(this);
    ui->lineEdit_numbersToGenerate->setValidator(validator);
    ui->lineEdit_spareNumbersToGenerate->setValidator(validator);
    ui->lineEdit_maximumValue->setValidator(validator);
    ui->lineEdit_minimumValue->setValidator(validator);
    ui->lineEdit_seed->setValidator(double_validator);
}

DialogSingleStageRandomNumbers::~DialogSingleStageRandomNumbers()
{
    delete ui;
}

static void insert_ratstats_compliant_number_list(std::map<int64_t, int64_t> &randoms, QStringList &out, int n_sorted)
{
    std::map<int64_t, int64_t> sorted_randoms;

    if (n_sorted > 0) {
        // sort by value (std::map objects are sorted by key)
        for (std::map<int64_t, int64_t>::iterator it = randoms.begin(); it != randoms.end(); it++)
        {
            sorted_randoms.insert(std::pair<int64_t, int64_t>(it->second, it->first));
            if (it->first == n_sorted)
                break;
        }
        // insert strings for sorted-by-value numbers
        for (std::map<int64_t, int64_t>::iterator it = sorted_randoms.begin(); it != sorted_randoms.end(); it++)
        {
            out << QString::asprintf("%6ld  %6ld\n", it->second, it->first);
        }
    }
    // insert strings for sorted-by-generation-order numbers
    for (std::map<int64_t, int64_t>::iterator it = randoms.find(n_sorted + 1); it != randoms.end(); it++)
    {
        out << QString::asprintf("%6ld  %6ld\n", it->first, it->second);
    }
}

// Qt doesn't like exceptions, so provide an exception-safe wrapper
void DialogSingleStageRandomNumbers::on_buttonBox_accepted()
{
    QApplication::setOverrideCursor(Qt::WaitCursor);
    qint64 start_msecs = QDateTime::currentMSecsSinceEpoch();
    try {
        on_buttonBox_accepted_unsafe();
    } catch (std::exception &e) {
        qDebug() << e.what();
        ST_ERRORBOX("An error occurred; please check your input values and try again.");
    }
    QApplication::restoreOverrideCursor();
    qDebug() << QString("Finished in %1 seconds").arg( (QDateTime::currentMSecsSinceEpoch() - start_msecs) / 1000.0);
}

void DialogSingleStageRandomNumbers::calculate(QString name, int numRandoms, int numSpares, double seed, int min, int max, std::map<int64_t, int64_t> &randoms)
{
    this->auditName = name;
    this->generationTime = QDateTime::currentDateTime().toString();
    this->seed = seed;
    this->framesize = max - min + 1;
    this->max = max;
    this->min = min;
    this->numRandoms = numRandoms;
    this->numSpares = numSpares;

    if (this->seed == 0.00) {
        this->seed = QDateTime::currentMSecsSinceEpoch() % 100000;
    }
    if (max - min + 1 < numRandoms + numSpares)
        return;

    WichmannHill rng(this->seed);
    rng.generateNumbers(numRandoms + numSpares, min, max, randoms);
    this->sum = rng.sum(randoms);
}

void DialogSingleStageRandomNumbers::buildHtmlReport(QStringList &out, std::map<int64_t, int64_t> &randoms)
{
    out << "<b><u><big><center>Random Numbers - Single Stage</center></big></u></b>" << "\n";
    out << "Audit: " << this->auditName << "\n";
    out << "Time: " << this->generationTime << "\n\n";
    out << "Seed: " << QString::asprintf("%.10f", this->seed).remove(QRegExp("[.0]+$")) << "\n";
    out << "Frame size: " << QString::asprintf("%'d (%'d - %'d)", this->framesize, this->min, this->max) << "\n";
    out << QString::asprintf("Sum of all %d random numbers: %'lld\n", this->numRandoms + this->numSpares, this->sum);
    out << "<pre>";
    out << "Selection\n  Order   Value\n\n";
    insert_ratstats_compliant_number_list(randoms, out, this->numRandoms);
    out << "</pre>";
}

void DialogSingleStageRandomNumbers::on_buttonBox_accepted_unsafe()
{
    QStringList out;
    double seed = atof(ui->lineEdit_seed->text().toStdString().c_str());
    int numbers = ui->lineEdit_numbersToGenerate->text().toInt();
    int spares = ui->lineEdit_spareNumbersToGenerate->text().toInt();
    int min = ui->lineEdit_minimumValue->text().toInt();
    int max = ui->lineEdit_maximumValue->text().toInt();
    std::map<int64_t, int64_t> randoms;

    // sanity check on requested values
    if (max - min + 1 < numbers + spares) {
        ST_ERRORBOX("Not enough unique values in your universe to generate that many numbers.");
        return;
    }

    // perform the calculations and store the results in member variables
    calculate(ui->lineEdit_auditName->text(), numbers, spares, seed, min, max, randoms);
    buildHtmlReport(out, randoms);

    emit displayHtml(out.join(""));
    this->reject();
}
