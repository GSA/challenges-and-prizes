var searchData=
[
  ['cursor',['cursor',['../da/da8/classReport.html#a0cbec144fb0b1aff6ec65d57111a80cd',1,'Report']]]
];
