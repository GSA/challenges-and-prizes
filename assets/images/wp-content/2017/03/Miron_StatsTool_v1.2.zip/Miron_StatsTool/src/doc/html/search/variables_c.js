var searchData=
[
  ['otherwise',['OTHERWISE',['../dd/de8/Miron__Licenses_8txt.html#adafb5aa3239fa5c9c643123fdb2c8d08',1,'Miron_Licenses.txt']]]
];
