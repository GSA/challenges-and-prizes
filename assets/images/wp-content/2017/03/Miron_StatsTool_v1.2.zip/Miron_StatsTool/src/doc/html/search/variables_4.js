var searchData=
[
  ['generationtime',['generationTime',['../d7/da5/classDialogSingleStageRandomNumbers.html#a19749ad139c3b82eb968b170c764f3c1',1,'DialogSingleStageRandomNumbers::generationTime()'],['../da/da8/classReport.html#a5d1236b963344a8d870eae0c4fcdfdd9',1,'Report::generationTime()']]]
];
