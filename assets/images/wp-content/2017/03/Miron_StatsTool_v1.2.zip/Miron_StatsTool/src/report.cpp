#include "report.h"
#include "statstool.h"


Report::Report()
{
    cursor = NULL;
}

Report::Report(QTextEdit &textEdit) : QTextDocument("", &textEdit)
{
    textEdit.setDocument(this);
    cursor = new QTextCursor(this);
}

Report::~Report()
{
    if (cursor)
        delete cursor;
}

Report &Report::addText(QString text)
{
    textData += text;
    return *this;
}

Report &Report::addHtml(QString html)
{
    htmlData += html;
    return *this;
}

Report &Report::operator<<(QString string)
{
    addHtml(string);
    return *this;
}

QString Report::join(QString string)
{
    return htmlData;
}
