var searchData=
[
  ['framesize',['framesize',['../d7/da5/classDialogSingleStageRandomNumbers.html#a31f6d612654b5c04f83be2d2b38de4c4',1,'DialogSingleStageRandomNumbers']]]
];
