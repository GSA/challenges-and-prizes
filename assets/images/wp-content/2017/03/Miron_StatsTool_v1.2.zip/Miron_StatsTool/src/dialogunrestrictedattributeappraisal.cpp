/**
 * All the code that implements the logic for the Unrestricted
 * Attribute Appraisal module is found in this file.  As is the
 * case elsewhere, however, the actual GUI design is in the .ui
 * file.
 */

#include "dialogunrestrictedattributeappraisal.h"
#include "ui_dialogunrestrictedattributeappraisal.h"
#include "statstool.h"
#include <boost/math/special_functions/binomial.hpp>


DialogUnrestrictedAttributeAppraisal::DialogUnrestrictedAttributeAppraisal(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogUnrestrictedAttributeAppraisal)
{
    static QValidator *validator = new QIntValidator(0, INT_MAX, this);
    ui->setupUi(this);
    ui->lineEdit_universeSize->setValidator(validator);
    ui->lineEdit_sampleSize->setValidator(validator);
    ui->lineEdit_itemsOfInterest->setValidator(validator);
}

DialogUnrestrictedAttributeAppraisal::~DialogUnrestrictedAttributeAppraisal()
{
    delete ui;
}

static double pdf_binomial(uint64_t n, uint64_t N, uint64_t x, uint64_t k)
{
    return (boost::math::binomial_coefficient<double>(k, x) *
            boost::math::binomial_coefficient<double>(N - k, n - x)) /
            boost::math::binomial_coefficient<double>(N, n);
}

static uint64_t upper_limit_binomial(uint64_t sample_size, uint64_t population_size, uint64_t sample_successes, uint64_t population_successes, double confidence)
{
    uint64_t n = sample_size, N = population_size, x = sample_successes, k = population_successes;
    double cdf = 0, C = (1 - confidence) / 2.0;

    for (cdf = 0; k < N; k++)
    {
        for (uint i = 0; i < x; i++)
        {
            cdf += pdf_binomial(n, N, i, k);
        }
        if (cdf <= C)
            return k - 1;
        else
            cdf = 0;
    }
    return 0;
}

static uint64_t lower_limit_binomial(uint64_t sample_size, uint64_t population_size, uint64_t sample_successes, uint64_t population_successes, double confidence)
{
    uint64_t n = sample_size, N = population_size, x = sample_successes, k = population_successes;
    double cdf = 0, C = (1 - confidence) / 2.0;

    for (cdf = 0; k > 0; k--)
    {
        for (uint i = x; i < n; i++)
        {
            cdf += pdf_binomial(n, N, i, k);
        }
        if (cdf <= C)
            return k + 1;
        else
            cdf = 0;
    }
    return 0;
}

// calculate the upper limit for a given confidence level
uint64_t DialogUnrestrictedAttributeAppraisal::upper_limit(uint64_t sample_size, uint64_t population_size, uint64_t sample_successes, double confidence, bool double_sided)
{
    uint64_t ret = 0;
    double cdf = 0, C = ((1 - confidence) / (double_sided ? 2.0 : 1.0));
    ret = population_size * boost::math::binomial_distribution<double, boost_error_policy>::find_upper_bound_on_p(sample_size, sample_successes, C);
    boost::math::hypergeometric_distribution<double, boost_error_policy> hg_dist(ret, sample_size, population_size);


    for (/* empty */; ret > 0; ret--)
    {
        hg_dist = boost::math::hypergeometric_distribution<double, boost_error_policy>(ret, sample_size, population_size);
        cdf = boost::math::cdf<double>(hg_dist, sample_successes);

        if ( cdf > C)
            break;
    }
    return ret;
}

// calculate the lower limit for a given confidence level
uint64_t DialogUnrestrictedAttributeAppraisal::lower_limit(uint64_t sample_size, uint64_t population_size, uint64_t sample_successes, double confidence, bool double_sided)
{
    uint64_t ret = 0;
    double cdf = 0, C = ((1 - confidence) / (double_sided ? 2.0 : 1.0));
    ret = population_size * boost::math::binomial_distribution<double, boost_error_policy>::find_lower_bound_on_p(sample_size, sample_successes, C);
    boost::math::hypergeometric_distribution<double, boost_error_policy> hg_dist(ret, sample_size, population_size);

    if (sample_successes == 0)
        return 0;
    for (/* empty */; ret < population_size; ret++)
    {
        hg_dist = boost::math::hypergeometric_distribution<double, boost_error_policy>(ret, sample_size, population_size);
        cdf = boost::math::cdf<double>(boost::math::complement(hg_dist, sample_successes - 1));

        if (cdf > C)
            break;
    }
    return ret;
}

// Qt doesn't like exceptions, so provide an exception-safe wrapper
void DialogUnrestrictedAttributeAppraisal::on_buttonBox_accepted()
{
    QApplication::setOverrideCursor(Qt::WaitCursor);
    qint64 start_msecs = QDateTime::currentMSecsSinceEpoch();
    try {
        on_buttonBox_accepted_unsafe();
    } catch (std::exception &e) {
        qDebug() << e.what();
        ST_ERRORBOX("An error occurred; please check your input values and try again.");
    }
    QApplication::restoreOverrideCursor();
    qDebug() << QString("Finished in %1 seconds").arg( (QDateTime::currentMSecsSinceEpoch() - start_msecs) / 1000.0);
}

void DialogUnrestrictedAttributeAppraisal::on_buttonBox_accepted_unsafe()
{
    uint64_t N = 0, n = 0, K = 0, k = 0;
    QStringList out;
    uint64_t upper = 0;
    uint64_t lower = 0;

    N = ui->lineEdit_universeSize->text().toInt();
    n = ui->lineEdit_sampleSize->text().toInt();
    k = ui->lineEdit_itemsOfInterest->text().toInt();
    K = round(k / (n / (double)N));

    out << "<b><u><big><center>Attribute Appraisal - Unrestricted</center></big></u></b><br/>";
    out << "Audit: " << ui->lineEdit_auditName->text() << "<br/>";
    out << "Date: " << QDateTime::currentDateTime().toString() << "<br/>";
    out << "Universe size: " << QString::asprintf("%'ld", N) << "<br/>";
    out << "Sample size: " << QString::asprintf("%'ld", n) << "<br/>\n";
    out << QString::asprintf("Characteristic of interest in sample: %'ld<br/>", k);
    out << QString::asprintf("Projected quantity in universe: %'ld (%'.3f%%)", K, (100 * (K / (double)N))) << "<br/>\n";
    try {
        if (n == 0 || n > N || k > n || N == 0)
            throw std::exception();
        for (double C = 0.20; C >= 0.05; C /= 2)
        {
            if (ui->checkBox_lowerLimit->isChecked()) {
                if (n == N)
                    lower = k;
                else
                    lower = lower_limit(n, N, k, 1 - C, ui->checkBox_upperLimit->isChecked());
                out << QString::asprintf("Lower <b>%d%%</b> confidence limit: <b>%'ld</b> (%'.3f%%)<br/>", (int)(100 * (1 - C)), lower, (100 * (lower / (double)N)));
            }
            if (ui->checkBox_upperLimit->isChecked()) {
                upper = upper_limit(n, N, k, 1 - C, ui->checkBox_lowerLimit->isChecked());
                out << QString::asprintf("Upper <b>%d%%</b> confidence limit: <b>%'ld</b> (%'.3f%%)<br/>\n", (int)(100 * (1 - C)), upper, (100 * (upper / (double)N)));
            }
        }
    } catch (std::exception &e) {
        qDebug() << e.what();
        qDebug() << QString::asprintf("n: %ld  N: %ld  k: %ld  K: %ld  upper: %ld  lower:  %ld", n, N, k, K, upper, lower);
        ST_ERRORBOX("An error occurred; please check your input values.");
        return;
    }

    emit displayHtml(out.join(""));
    this->reject();
}
