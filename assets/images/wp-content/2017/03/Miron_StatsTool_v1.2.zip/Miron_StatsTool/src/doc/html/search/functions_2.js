var searchData=
[
  ['calculate',['calculate',['../d7/da5/classDialogSingleStageRandomNumbers.html#a33ac2b0602cb21236e9bf7dfebada2b0',1,'DialogSingleStageRandomNumbers']]],
  ['check_5fduplicate',['check_duplicate',['../dd/d12/classWichmannHill.html#aba7ab5ea18a72bf24f2afce502607113',1,'WichmannHill']]],
  ['confirmationbox',['confirmationBox',['../d7/d2e/classStatsTool.html#a99568790ae103a256d0f9f22ec6afc89',1,'StatsTool']]]
];
