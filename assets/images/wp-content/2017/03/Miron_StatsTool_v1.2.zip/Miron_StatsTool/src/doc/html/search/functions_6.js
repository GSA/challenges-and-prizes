var searchData=
[
  ['generatenumbers',['generateNumbers',['../dd/d12/classWichmannHill.html#a909c5d264df92476ceda01c52275426b',1,'WichmannHill']]],
  ['getexcel',['getExcel',['../da/da8/classReport.html#a6107a5e67b599010abd1ce35980d492a',1,'Report']]],
  ['gethtml',['getHtml',['../da/da8/classReport.html#a1905841f65a715b2924f0ad47fc5ef10',1,'Report']]],
  ['gettext',['getText',['../da/da8/classReport.html#a7329b1102c11e53f03f20c13d515f467',1,'Report']]]
];
