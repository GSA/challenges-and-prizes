var searchData=
[
  ['excelfiletoplaintext',['excelFileToPlainText',['../d7/d2e/classStatsTool.html#acf65a728d0842a59c2aef4558e331560',1,'StatsTool::excelFileToPlainText(QString &amp;fileName)'],['../d7/d2e/classStatsTool.html#a6c49683909d41fedec795cd81b1c1ac0',1,'StatsTool::excelFileToPlainText(QXlsx::Document &amp;excel)']]],
  ['excelrand64',['ExcelRand64',['../dd/d12/classWichmannHill.html#a308f2a466cb8b15cb42942581ad35e96',1,'WichmannHill']]],
  ['excelrandomize64',['ExcelRandomize64',['../dd/d12/classWichmannHill.html#a82b958ef15529f91471a37bbc4969873',1,'WichmannHill']]]
];
