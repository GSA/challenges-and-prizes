#ifndef DIALOGUNRESTRICTEDVARIABLEAPPRAISAL_H
#define DIALOGUNRESTRICTEDVARIABLEAPPRAISAL_H

#include <QDialog>
#include "statstool.h"


namespace Ui {
class DialogUnrestrictedVariableAppraisal;
}

/**
 * @brief Encapsulates the Unrestricted Variable Appraisal module
 */
class DialogUnrestrictedVariableAppraisal : public QDialog
{
    Q_OBJECT

public:
    explicit DialogUnrestrictedVariableAppraisal(QWidget *parent = 0);
    ~DialogUnrestrictedVariableAppraisal();

    static bool first_column_is_examined(QString str);
    static bool second_column_is_difference(QString str);
    static bool first_column_is_audited(QString str);
    static bool first_column_is_difference(QString str);

    static void fill_in_column(matrix_t &mat, int examined_column, int audited_column, int difference_column, int n_rows);
    static double ratstats_kurtosis(matrix_t &matrix, int column, double mean);
    static double ratstats_skewness(matrix_t &matrix, int column, double mean);
    void build_report(matrix_t &mat, QStringList &report, QString &inputFileName, int universeSize, int exa_col, int aud_col, int dif_col);

signals:
    void displayHtml(QString str);
    void displayText(QString str);

private slots:
    /**
     * @brief Display a dialog to the user for selecting an input file
     */
    void on_pushButton_chooseInputFile_clicked();
    /**
     * @brief Run the computations and display the report
     */
    void on_buttonBox_accepted();
    /**
     * @brief Whether to allow editing of the data preview area
     * @param checked The state of the checkbox
     */
    void on_checkBox_enableEditing_toggled(bool checked);
    /**
     * @brief Fill the data preview area with the contents of a file
     * @param inputFileName The name of the file to read from
     */
    void readFromFile(QString inputFileName);
    /**
     * @brief Called if something is dropped by the cursor on to our window
     * @param event
     */
    void dropEvent(QDropEvent *event);
    /**
     * @brief Called if something is dragged over our window
     * @param event
     */
    void dragEnterEvent(QDragEnterEvent *event);

private:
    Ui::DialogUnrestrictedVariableAppraisal *ui;
    QString inputFileName;
    void on_buttonBox_accepted_unsafe();
};

#endif // DIALOGUNRESTRICTEDVARIABLEAPPRAISAL_H
