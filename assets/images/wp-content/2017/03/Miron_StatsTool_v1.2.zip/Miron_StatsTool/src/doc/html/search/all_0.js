var searchData=
[
  ['addhtml',['addHtml',['../da/da8/classReport.html#ae17adeb800c2005931a852234acf9ca9',1,'Report']]],
  ['addhtmlline',['addHtmlLine',['../da/da8/classReport.html#ab5c88f78e5963f0832660073c0bb79d4',1,'Report']]],
  ['addsheetnames',['addSheetNames',['../d7/de1/classDialogSelectExcelSheet.html#a63bf27d4c1b4521a328d160bd5d7b188',1,'DialogSelectExcelSheet']]],
  ['addtext',['addText',['../da/da8/classReport.html#ae5c31811f33d89bf76671a56c299e052',1,'Report']]],
  ['addtextline',['addTextLine',['../da/da8/classReport.html#a6db075cb3a2faf76bb0fa88a09ef684b',1,'Report']]],
  ['appendblock',['appendBlock',['../da/da8/classReport.html#a799f4d3bad8226653332e9c6af15cb66',1,'Report']]],
  ['appendtext',['appendText',['../da/da8/classReport.html#a78cf5b9e2b154abd9b40f18e53742e75',1,'Report']]],
  ['auditname',['auditName',['../d7/da5/classDialogSingleStageRandomNumbers.html#a6a23845244561d4c8a7c2a9aa47a1349',1,'DialogSingleStageRandomNumbers::auditName()'],['../da/da8/classReport.html#ae23847ef3278e63a3e0fd68cae33ac9d',1,'Report::auditName()'],['../d7/d2e/classStatsTool.html#a9603b73b0a54778ee2964623c33207cf',1,'StatsTool::auditName()']]]
];
