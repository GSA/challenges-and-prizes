#include "statstool.h"
#include <QApplication>


/*
 * Program entry point (technically there are many other places where the program enters,
 * but all of that is just generic setup.)  From here, we create a StatsTool object
 * (inherits from QMainWindow), and execute it, which kicks off the entire application.
 */
int main(int argc, char *argv[])
{
    //Q_IMPORT_PLUGIN(qtaccessiblewidgets);

    QApplication a(argc, argv);
    StatsTool w;
    QCommandLineParser parser;

    QCoreApplication::setApplicationName(PROGRAM_TITLE);
    QCoreApplication::setApplicationVersion(PROGRAM_VERSION_STRING);

    parser.setApplicationDescription(QCoreApplication::applicationName());
    parser.addHelpOption();
    parser.addVersionOption();
    parser.process(a);

#ifndef ST_WIN32
    w.setWindowIcon(QIcon("icon.xpm"));
#endif
    w.setWindowTitle(PROGRAM_TITLE);
    w.show();
    return a.exec();
}
