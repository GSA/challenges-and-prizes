var searchData=
[
  ['matrix_5ft',['matrix_t',['../d3/dbd/statstool_8h.html#aa048a7712a04fbbdc529b0c7a5be9d98',1,'statstool.h']]]
];
