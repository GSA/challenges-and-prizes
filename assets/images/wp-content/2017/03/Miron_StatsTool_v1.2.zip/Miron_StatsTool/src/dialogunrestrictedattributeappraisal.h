#ifndef DIALOGUNRESTRICTEDATTRIBUTEAPPRAISAL_H
#define DIALOGUNRESTRICTEDATTRIBUTEAPPRAISAL_H

#include <QDialog>

namespace Ui {
class DialogUnrestrictedAttributeAppraisal;
}

/**
 * @brief Encapsulates the Unrestricted Attribute Appraisal module
 */
class DialogUnrestrictedAttributeAppraisal : public QDialog
{
    Q_OBJECT

public:
    explicit DialogUnrestrictedAttributeAppraisal(QWidget *parent = 0);
    ~DialogUnrestrictedAttributeAppraisal();
    /**
     * @brief upper_limit
     * @param sample_size The number of items in the sample
     * @param population_size The universe size
     * @param sample_successes The number of items within the sample possessing the characteristic of interest
     * @param confidence The confidence level
     * @param double_sided Whether to divide the confidence level by 2 or not (compute both tails of the bell curve or only one)
     * @return
     *
     * Compute the upper limit of a confidence interval
     */
    uint64_t upper_limit(uint64_t sample_size, uint64_t population_size, uint64_t sample_successes, double confidence, bool double_sided = true);

    /**
     * @brief lower_limit
     * @param sample_size The number of items in the sample
     * @param population_size The universe size
     * @param sample_successes The number of items within the sample possessing the characteristic of interest
     * @param confidence The confidence level
     * @param double_sided Whether to divide the confidence level by 2 or not (compute both tails of the bell curve or only one)
     * @return
     *
     * Compute the lower limit of a confidence interval
     */
    uint64_t lower_limit(uint64_t sample_size, uint64_t population_size, uint64_t sample_successes, double confidence, bool double_sided = true);

signals:
    void displayText(QString str);
    void displayHtml(QString str);

private slots:
    void on_buttonBox_accepted();

private:
    Ui::DialogUnrestrictedAttributeAppraisal *ui;
    void on_buttonBox_accepted_unsafe();
};

#endif // DIALOGUNRESTRICTEDATTRIBUTEAPPRAISAL_H
