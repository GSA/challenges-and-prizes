#include "dialogstratifiedvariableappraisal.h"
#include "ui_dialogstratifiedvariableappraisal.h"
#include "statstool.h"

#define CONFIDENCE_LEVEL_95_Z_VALUE 1.959963984540
#define CONFIDENCE_LEVEL_90_Z_VALUE 1.644853626951
#define CONFIDENCE_LEVEL_80_Z_VALUE 1.281551565545


DialogStratifiedVariableAppraisal::DialogStratifiedVariableAppraisal(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogStratifiedVariableAppraisal)
{
    ui->setupUi(this);
    unres = new DialogUnrestrictedVariableAppraisal(this);
}

DialogStratifiedVariableAppraisal::~DialogStratifiedVariableAppraisal()
{
    delete ui;
    delete unres;
}

void DialogStratifiedVariableAppraisal::on_pushButton_openDataFile_clicked()
{
    QMimeDatabase db;
    QString plainText;
    QMimeType type;

    QString inputFileName = QFileDialog::getOpenFileName(this, tr("Input File"), "", tr("*.txt *.xlsx"));
    if (inputFileName.isEmpty())
        return;
    else
        dataFileName = inputFileName;

    type = db.mimeTypeForFile(inputFileName);
    if (QRegExp("spreadsheet").indexIn(type.name()) > -1) {
        plainText = StatsTool::excelFileToPlainText(inputFileName);
    } else {
        QFile inputfile(inputFileName);
        if (!inputfile.open(QIODevice::ReadOnly | QIODevice::Text)) {
            ST_ERRORBOX("Error opening file.");
            return;
        }
        QTextStream in(&inputfile);
        plainText = in.readAll();
        inputfile.close();
    }

    ui->plainTextEdit_data->setPlainText(plainText);
}

void DialogStratifiedVariableAppraisal::on_pushButton_openStrataFile_clicked()
{
    QMimeDatabase db;
    QString plainText;
    QMimeType type;

    QString inputFileName = QFileDialog::getOpenFileName(this, tr("Input File"), "", tr("*.txt *.xlsx"));
    if (inputFileName.isEmpty())
        return;
    else
        strataFileName = inputFileName;

    type = db.mimeTypeForFile(inputFileName);
    if (QRegExp("spreadsheet").indexIn(type.name()) > -1) {
        plainText = StatsTool::excelFileToPlainText(inputFileName);
    } else {
        QFile inputfile(inputFileName);
        if (!inputfile.open(QIODevice::ReadOnly | QIODevice::Text)) {
            ST_ERRORBOX("Error opening file.");
            return;
        }
        QTextStream in(&inputfile);
        plainText = in.readAll();
        inputfile.close();
    }

    ui->plainTextEdit_strata->setPlainText(plainText);
}

void DialogStratifiedVariableAppraisal::build_report(matrix_t &mat, QStringList &report, int universeSize)
{
    uint sampleSize = mat.rows();
    double t_value;
    matrix_t means = scythe::meanc(mat);
    matrix_t sums = scythe::sumc(mat);
    matrix_t std_devs = scythe::sdc(mat);
    matrix_t pnt_ests(1, mat.cols());
    matrix_t sd_means(1, mat.cols());
    matrix_t sd_totals(1, mat.cols());
    boost::math::students_t_distribution<double, boost_error_policy> dist(sampleSize - 1);

    for (uint column = 0; column < mat.cols(); column++)
    {
        pnt_ests(0, column) = means(column) * universeSize;
        sd_means(0, column) = std_devs(column) * sqrt((universeSize - sampleSize) / (double)(sampleSize * universeSize));
        sd_totals(0, column) = sd_means(0, column) * universeSize;
        double skewness = StatsTool::ratstats_skewness(mat, column, means(0, column));
        double kurtosis = StatsTool::ratstats_kurtosis(mat, column, means(0, column));

        report << QString::asprintf("\n<center><u>Column %d</u></center>", column + 1);
        report << "Sum: " << QString::asprintf("<b>%'.02f</b>", sums(0, column)) << "\n";
        report << "Mean: " << QString::asprintf("<b>%'.02f</b>", means(0, column)) << "\n";
        report << "Standard deviation: " << (isnormal(std_devs(0, column)) ? QString::asprintf("<b>%'.02f</b>\n", std_devs(0, column)) : "0\n");
        report << "Skewness: " << QString::asprintf("<b>%'.02f</b>", isnormal(skewness) ? skewness : 0.0) << "\n";
        report << "Kurtosis: " << QString::asprintf("<b>%'.02f</b>", isnormal(kurtosis) ? kurtosis : 0.0) << "\n";
        report << "Standard error (mean): " << (isnormal(sd_means(0, column)) ? QString::asprintf("<b>%'.02f</b>\n", sd_means(0, column)) : "0\n");
        report << "Standard error (total): " << (isnormal(sd_totals(0, column)) ? QString::asprintf("<b>%'.02f</b>\n", sd_totals(0, column)) : "0\n");
        report << "Point estimate: " << QString::asprintf("%'.02f\n", pnt_ests(0, column));
        for (double C = 0.20; C >= 0.05; C /= 2)
        {
            t_value = boost::math::quantile(boost::math::complement(dist, C / 2));
            double lower_limit = pnt_ests(0, column) - (sd_totals(0, column) * t_value);
            double upper_limit = pnt_ests(0, column) + (sd_totals(0, column) * t_value);
            double precision = sd_totals(0, column) * t_value;
            double precision_percent = pnt_ests(0, column) < 0 ? 0 : 100 * ((sd_totals(0, column) * t_value) / pnt_ests(0, column));

            report << "\n";
            report << QString::asprintf("<b>%d%%</b> lower limit: <b>%'.02f</b>\n", (int)((1 - C) * 100), isnormal(lower_limit) ? lower_limit : 0.0);
            report << QString::asprintf("<b>%d%%</b> upper limit: <b>%'.02f</b>\n", (int)((1 - C) * 100), isnormal(upper_limit) ? upper_limit : 0.0);
            report << QString::asprintf("Precision amount: %'.02f\n", isnormal(precision) ? precision : 0.0);
            report << QString::asprintf("Precision percent: %.02f%%\n", isnormal(precision_percent) ? precision_percent : 0.0);
            report << QString::asprintf("t-Value used: %'.12f\n", isnormal(t_value) ? t_value : 0.0);
        }
    }
    report << "\n";
}

void DialogStratifiedVariableAppraisal::on_buttonBox_accepted()
{
    QString data = ui->plainTextEdit_data->toPlainText();
    QString strata = ui->plainTextEdit_strata->toPlainText();
    QStringList report;
    QStringList data_lines = data.remove(QRegExp("\\$|,")).split(QRegExp("\r?\n"), QString::SkipEmptyParts);
    QStringList strata_lines = strata.split(QRegExp("\r?\n"), QString::SkipEmptyParts);
    int n_cols;

    if (data_lines.size() < 1 || strata_lines.size() < 1) {
        ST_ERRORBOX("Malformed data.");
        return;
    }
    n_cols = data_lines.at(0).split(QRegExp("\t| "), QString::SkipEmptyParts).size();
    matrix_t full_matrix(data_lines.size(), n_cols);
    matrix_t strata_matrix(strata_lines.size(), 2);

    // build strata matrix
    for (int i = 0; i < strata_lines.size(); i++)
    {
        int c;
        QStringList tokens = strata_lines.at(i).split(QRegExp("\t| "), QString::SkipEmptyParts);
        // ignore stratum number
        if (tokens.size() == 3)
            c = 1;
        else if (tokens.size() == 2)
            c = 0;
        else {
            ST_ERRORBOX(QString("Malformed strata definition; error on line %1").arg(i + 1));
            return;
        }
        // since it's impossible for the sample size to be larger than the universe size,
        // use whichever value is bigger for the universe size (accept both UNIVERSE_SIZE SAMPLE_SIZE
        // and SAMPLE_SIZE UNIVERSE_SIZE formatted columns)
        if (tokens.at(0 + c).toDouble() > tokens.at(1 + c).toDouble()) {
            strata_matrix(i, 0) = tokens.at(0 + c).toDouble();
            strata_matrix(i, 1) = tokens.at(1 + c).toDouble();
        } else {
            strata_matrix(i, 0) = tokens.at(1 + c).toDouble();
            strata_matrix(i, 1) = tokens.at(0 + c).toDouble();
        }
    }
    // build data matrix
    for (int i = 0; i < data_lines.size(); i++)
    {
        QStringList tokens = data_lines.at(i).split(QRegExp("\t| "), QString::SkipEmptyParts);
        if (tokens.size() != n_cols) {
            ST_ERRORBOX(QString("Malformed data file; error on line %1").arg(i + 1));
            return;
        }
        for (int j = 0; j < tokens.size(); j++)
        {
            full_matrix(i, j) = tokens.at(j).toDouble();
        }
    }

    report << "<big><b><u><center>Variable Appraisal - Stratified</center></u></b></big>";
    report << QString("Audit: %1\n").arg(ui->lineEdit_auditName->text());
    report << QString("Date: %1\n").arg(QDateTime::currentDateTime().toString());
    report << QString("Data file: %1\n").arg(dataFileName);
    report << QString("Strata file: %1\n\n").arg(strataFileName);

    // iterate over the strata, building a data matrix for each
    matrix_t means(strata_matrix.rows(), n_cols);
    matrix_t sd(strata_matrix.rows(), n_cols);
    uint current_stratum = 0;
    for (int i = 0; i < data_lines.size(); )
    {
        matrix_t temp_mat((uint)strata_matrix(current_stratum, 1), n_cols);
        for (uint j = 0; j < (uint)strata_matrix(current_stratum, 1); j++)
        {
            if (i + j >= full_matrix.rows()) {
                ST_ERRORBOX("The data has fewer values than the strata sample sizes say there should be.");
                return;
            }
            for (int k = 0; k < n_cols; k++)
            {
                temp_mat(j, k) = full_matrix(i + j, k);
            }
        }
        report << QString::asprintf("<b>Stratum %d</b> - %'d / %'d (universe size / sample size)\n", current_stratum + 1, (int)strata_matrix(current_stratum, 0), (int)strata_matrix(current_stratum, 1));
        try {
            build_report(temp_mat, report, (int)strata_matrix(current_stratum, 0));
        } catch (std::exception &e) {
            qDebug() << e.what();
            ST_ERRORBOX("The calculations failed; please check your input values (possible causes include stratum sample sizes that are too small for the equations.)");
            return;
        }

        matrix_t tmp_means = scythe::meanc(temp_mat);
        matrix_t tmp_sd = scythe::sdc(temp_mat);
        for (uint z = 0; z < tmp_means.cols(); z++) {
            means(current_stratum, z) = tmp_means(z);
            sd(current_stratum, z) = tmp_sd(z);
        }
        i += strata_matrix(current_stratum, 1);
        if (++current_stratum >= strata_matrix.rows())
            break;
    }

    // overall calculations
    matrix_t totals(1, n_cols);
    matrix_t variances(1, n_cols);
    matrix_t std_errors(1, n_cols);
    // sanity checks
    int sampleSize = 0;
    for (uint i = 0; i < strata_matrix.rows(); i++)
        sampleSize += strata_matrix(i, 1);
    if (sampleSize != data_lines.size())
        ST_ERRORBOX("WARNING: your strata sample sizes do not add up to the amount of data provided!  Excess data has been ignored.  This warning will appear in the report.");
    int universeSize = 0;
    for (uint i = 0; i < strata_matrix.rows(); i++) {
        universeSize += strata_matrix(i, 0);
        for (int j = 0; j < n_cols; j++) {
            totals(j) += means(i, j) * strata_matrix(i, 0);
        }
    }
    for (uint i = 0; i < strata_matrix.rows(); i++)
        for (int j = 0; j < n_cols; j++)
        {
            double stratum_val = pow(strata_matrix(i, 0), 2) *
                    ((strata_matrix(i, 0) - strata_matrix(i, 1)) / strata_matrix(i, 0)) *
                    (pow(sd(i, j), 2) / strata_matrix(i, 1));
            if (!isnan(stratum_val))
                variances(j) += stratum_val;
        }
    //    for (uint i = 0; i < strata_matrix.rows(); i++)
    for (int j = 0; j < n_cols; j++)
        std_errors(j) = sqrt(variances(j));

    report << QString::asprintf("<b>Overall</b> - %'d / %'d (universe size / sample size)\n",
                                universeSize, sampleSize);
    if (sampleSize != data_lines.size())
        report << QString("<b><big>WARNING: some of the input data was ignored due to not being included in any stratum definition.</big></b>");
    double z_value = 0;
    for (int i = 0; i < n_cols; i++)
    {
        report << QString::asprintf("<u><center>Column %d</center></u>", i + 1);
        report << QString::asprintf("Point estimate: %'.2f\n", (isnormal(totals(i)) ? totals(i) : 0.0));
        report << QString::asprintf("Standard error: %'.2f\n", (isnormal(std_errors(i)) ? std_errors(i) : 0.0));
        for (double C = 0.20; C >= 0.05; C /= 2)
        {
            if (C == 0.05) z_value = CONFIDENCE_LEVEL_95_Z_VALUE;
            else if (C == 0.10) z_value = CONFIDENCE_LEVEL_90_Z_VALUE;
            else if (C == 0.20) z_value = CONFIDENCE_LEVEL_80_Z_VALUE;
            report << "\n";
            report << QString::asprintf("<b>%d%%</b> lower limit: <b>%'.02f</b>\n", (int)((1 - C) * 100), (isnormal(totals(i)) ? totals(i) - (std_errors(i) * z_value) : 0.0));
            report << QString::asprintf("<b>%d%%</b> upper limit: <b>%'.02f</b>\n", (int)((1 - C) * 100), (isnormal(totals(i)) ? totals(i) + (std_errors(i) * z_value) : 0.0));
            report << QString::asprintf("Precision amount: %'.02f\n", (isnormal(std_errors(i)) ? std_errors(i) * z_value : 0.0));
            report << QString::asprintf("Precision percent: %.02f%%\n", (!isnormal(totals(i)) || totals(i) < 0) ? 0 : 100 * ((std_errors(i) * z_value) / totals(i)));
            report << QString::asprintf("z-Value used: %'.12f\n", isnormal(z_value) ? z_value : 0.0);
        }
    }

    emit displayHtml(report.join(""));
}

void DialogStratifiedVariableAppraisal::on_checkBox_enableStrataEditing_toggled(bool checked)
{
    ui->plainTextEdit_strata->setReadOnly(!checked);
}

void DialogStratifiedVariableAppraisal::on_checkBox_enableDataEditing_toggled(bool checked)
{
    ui->plainTextEdit_data->setReadOnly(!checked);
}
