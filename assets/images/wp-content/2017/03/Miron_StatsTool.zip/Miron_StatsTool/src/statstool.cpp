#include "statstool.h"
#include "ui_statstool.h"
#include "dialogsinglestagerandomnumbers.h"
#include "dialogunrestrictedattributeappraisal.h"
#include "ui_dialogsinglestagerandomnumbers.h"
#include "dialogunrestrictedvariableappraisal.h"
#include "ui_dialogunrestrictedvariableappraisal.h"
#include "dialogstratifiedvariableappraisal.h"
#include "ui_dialogstratifiedvariableappraisal.h"


StatsTool::StatsTool(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::StatsTool)
{
    ui->setupUi(this);
    ui->textEdit_outputArea->hide();
    ui->pushButton_saveToFile->setDisabled(true);
    //displaySplashImage("ratstats-image.png");
}

StatsTool::~StatsTool()
{
    delete ui;
}

void StatsTool::displaySplashImage(QString file)
{
    ui->textEdit_outputArea->setHtml("<br/><br/><img src='ratstats-image.png'/>");
    return;
    QUrl Uri ( QString ( "file://%1" ).arg ( file ) );
    QImage image = QImageReader ( file ).read();

    QTextDocument * textDocument = ui->textEdit_outputArea->document();
    textDocument->addResource( QTextDocument::ImageResource, Uri, QVariant ( image ) );
    QTextCursor cursor = ui->textEdit_outputArea->textCursor();
    QTextImageFormat imageFormat;
    imageFormat.setWidth( image.width() );
    imageFormat.setHeight( image.height() );
    imageFormat.setName( Uri.toString() );
    cursor.insertImage(imageFormat);
}

void StatsTool::setupDisplayArea()
{
    ui->textEdit_outputArea->show();
    ui->pushButton_saveToFile->setEnabled(true);
}

void StatsTool::displayHtml(QString str)
{
    ui->textEdit_outputArea->setHtml(str.replace("\n", "<br/>"));
    setupDisplayArea();
}

void StatsTool::displayText(QString str)
{
    ui->textEdit_outputArea->setText(str);
    setupDisplayArea();
}

QString StatsTool::excelFileToPlainText(QString &fileName)
{
    QXlsx::Document excel(fileName);
    return excelFileToPlainText(excel);
}

QString StatsTool::excelFileToPlainText(QXlsx::Document &excel)
{
    QStringList ret;
    QString row;

    for (int i = 1; excel.cellAt(i, 1) != 0; i++)
    {
        for (int j = 1; excel.cellAt(i, j) != 0; j++)
        {
            row.append(QString::asprintf(" %'.2f", excel.read(i, j).toDouble()));
        }
        ret << row;
        row.clear();
    }
    return ret.join("\n");
}

double StatsTool::ratstats_kurtosis(matrix_t &matrix, int column, double mean)
{
    double x, x_bar = mean, numerator, denominator;
    uint n = matrix.rows();

    for (uint i = 0; i < n; i++)
    {
        x = matrix(i, column);
        numerator += pow((x - x_bar), 4);
        denominator += pow((x - x_bar), 2);
    }
    numerator /= n;
    denominator /= n;
    denominator = pow(denominator, 2);
    return numerator / denominator;
}

double StatsTool::ratstats_skewness(matrix_t &matrix, int column, double mean)
{
    double x, x_bar = mean, numerator, denominator;
    uint n = matrix.rows();

    for (uint i = 0; i < n; i++)
    {
        x = matrix(i, column);
        numerator += pow((x - x_bar), 3);
        denominator += pow((x - x_bar), 2);
    }
    numerator /= n;
    denominator /= n;
    denominator = pow(denominator, 3/2.0);
    return numerator / denominator;
}

void StatsTool::on_actionSingle_Stage_Random_Number_triggered()
{
    DialogSingleStageRandomNumbers *dialog = new DialogSingleStageRandomNumbers(this);
    connect(dialog, SIGNAL(displayText(QString)), this, SLOT(displayText(QString)));
    connect(dialog, SIGNAL(displayHtml(QString)), this, SLOT(displayHtml(QString)));
    try {
        dialog->exec();
    } catch(std::exception &e) {
        qDebug() << e.what();
        ST_ERRORBOX("An unknown error occurred; please check your input values.");
    }
}

void StatsTool::on_actionUnrestricted_Attribute_Appraisal_triggered()
{
    DialogUnrestrictedAttributeAppraisal *dialog = new DialogUnrestrictedAttributeAppraisal(this);
    connect(dialog, SIGNAL(displayText(QString)), this, SLOT(displayText(QString)));
    connect(dialog, SIGNAL(displayHtml(QString)), this, SLOT(displayHtml(QString)));
    try {
        dialog->exec();
    } catch(std::exception &e) {
        qDebug() << e.what();
        ST_ERRORBOX("An unknown error occurred; please check your input values.");
        return;
    }
}

void StatsTool::on_pushButton_saveToFile_clicked()
{
    // Get file to save to
    QString filename = QFileDialog::getSaveFileName(this, tr("Select Output File"), "", tr("*.txt"));
    if (filename.isEmpty())
        return;
    QFile file(filename);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        ST_ERRORBOX("Error opening file.");
        return;
    }
    QTextStream out(&file);
    out << PROGRAM_STRING_FULL << ": ";
    out << ui->textEdit_outputArea->toPlainText();
    file.close();

    ST_ERRORBOX("Saved to " + filename);
}

void StatsTool::on_pushButton_quit_clicked()
{
    exit(0);
}

void StatsTool::on_actionUnrestricted_Variable_Appraisal_triggered()
{
    DialogUnrestrictedVariableAppraisal *dialog = new DialogUnrestrictedVariableAppraisal(this);
    connect(dialog, SIGNAL(displayText(QString)), this, SLOT(displayText(QString)));
    connect(dialog, SIGNAL(displayHtml(QString)), this, SLOT(displayHtml(QString)));
    try {
        dialog->exec();
    } catch (std::exception &e) {
        qDebug() << e.what();
        ST_ERRORBOX("An unknown error occurred; please check your input values.");
        return;
    }
}

void StatsTool::on_actionAbout_triggered()
{
    ST_ERRORBOX(PROGRAM_STRING_FULL + ", by Murray Miron.");
}

void StatsTool::on_actionStratified_Variable_Appraisal_triggered()
{
    DialogStratifiedVariableAppraisal *dialog = new DialogStratifiedVariableAppraisal(this);
    connect(dialog, SIGNAL(displayText(QString)), this, SLOT(displayText(QString)));
    connect(dialog, SIGNAL(displayHtml(QString)), this, SLOT(displayHtml(QString)));
    try {
        dialog->exec();
    } catch (std::exception &e) {
        qDebug() << e.what();
        ST_ERRORBOX("An unknown error occurred; please check your input values.");
        return;
    }
}
