﻿using System.Windows.Input;
using Prism.Mvvm;
using Prism.Commands;
using Prism.Regions;
using RatStatsChallenge.Module.Infastructure.Enums;
using System;
using RatStatsChallenge.Module.Infastructure;
using RatStatsChallenge.Module.Infastructure.Reports.RandomNumber;
using System.Collections.Generic;
using Microsoft.Win32;
using System.Linq;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
namespace RatStatsChallenge.Module.Interface.ViewModels.RandomNumbers
{
    /*****************************************************************************************************
    *   SingleStageViewModel
    *   - View model for the Random Numbers Single Stage View. Provides bindings and manages navigation requests
    *
    ******************************************************************************************************/
    public class SingleStageViewModel :  BindableBase, INavigationAware
    {

        private readonly IRegionManager MyRegionManager;

        public SingleStageViewModel(IRegionManager regionManager)
        {
            //Primary Display Region Manager of the application
            this.MyRegionManager = regionManager;
        }

        public virtual bool IsNavigationTarget(NavigationContext navigationContext)
        {
            return true;
        }

        public virtual void OnNavigatedFrom(NavigationContext navigationContext)
        {

        }

        //Handler for OnNavigateTo event that is fired when the view is loaded
        public virtual void OnNavigatedTo(NavigationContext navigationContext)
        {
            string SourceViewName = "";
            if (navigationContext.Parameters != null && navigationContext.Parameters["SourceViewName"] != null)
            {
                SourceViewName = navigationContext.Parameters["SourceViewName"].ToString();
                if (SourceViewName == "RandomNumbers.SingleStageReportView")
                    return;
            }
            ResetFields();

        }

        //ResetFields() -  Clears the values that the user entered into the form 
        public void ResetFields()
        {
            SelectedSeedGenerationType = SeedGenerationType.Unknown;
            UserProvidedSeed = null;
            AuditReviewTitle = "";
            SequentialNumberCount = 0;
            SparesNumberCount = 0;
            SamplingFrameLow = 0;
            SamplingFrameHigh = 0;
            if (TextFileOutput)
                TextFileOutput = false;
            if (CSVFileOutput)
                CSVFileOutput = false;
            if (ExcelFileOutput)
                ExcelFileOutput = false;
            Errors = new List<ReadyToProceedError>();
        }

       
        public void GoHome()
        {
            ResetFields();
            MyRegionManager.RequestNavigate("PrimaryPageRegion", "HomePageView");
        }

        //Selected Seed Generation Type Binding
        private SeedGenerationType _SelectedSeedGenerationType = SeedGenerationType.Unknown;
        public SeedGenerationType  SelectedSeedGenerationType
        {
            set
            {
                SetProperty(ref _SelectedSeedGenerationType, value);
                if (_SelectedSeedGenerationType == SeedGenerationType.Automatic)
                    UserProvidedSeed = null;
                OnPropertyChanged("UserProvidedSeedEnabled");
            }

            get
            {
                return _SelectedSeedGenerationType;
            }
        }

        //User Provided Seed Enabled Property
        public bool UserProvidedSeedEnabled
        {
            get
            {
                if (SelectedSeedGenerationType == SeedGenerationType.UserProvided)
                    return true;
                else
                    return false;
            }
        }

        //User Provided Seed Property
        private double? _UserProvidedSeed;
        public double? UserProvidedSeed
        {
            get { return _UserProvidedSeed; }
            set { SetProperty(ref _UserProvidedSeed, value); }
        }

        //Audit Review Title Binding
        private string _AuditReviewTitle = "";
        public string AuditReviewTitle
        {
            get { return _AuditReviewTitle; }
            set { SetProperty(ref _AuditReviewTitle, value); }
        }

        //Sequential Number Count Binding
        private int _SequentialNumberCount;
        public int SequentialNumberCount
        {
            get { return _SequentialNumberCount; }
            set {     
                SetProperty(ref _SequentialNumberCount, value); }
        }

        //Spares Number Count Binding
        private int _SparesNumberCount;
        public int SparesNumberCount
        {
            get { return _SparesNumberCount; }
            set {
                SetProperty(ref _SparesNumberCount, value); }
        }

        //Sampling Frame Low Binding
        private int _SamplingFrameLow;
        public int SamplingFrameLow
        {
            get { return _SamplingFrameLow; }
            set {
                SetProperty(ref _SamplingFrameLow, value);
            }
        }

        //Sampling FrameH igh Binding
        private int _SamplingFrameHigh;
        public int SamplingFrameHigh
        {
            get { return _SamplingFrameHigh; }
            set {
                SetProperty(ref _SamplingFrameHigh, value); }
        }

        //Errors Binding
        private List<ReadyToProceedError> _Errors = new List<ReadyToProceedError>();
        public List<ReadyToProceedError> Errors
        {
            get { return _Errors; }
            set { SetProperty(ref _Errors, value);
            }
        }

        //Errors With Text Binding
        public List<ReadyToProceedError> ErrorsWithText
        {
            get { return _Errors.Where(e => e.ErrorContent.Length > 0).ToList(); }
        }

        //CSV File Output Path Binding
        private string _CSVFileOutputPath = "";
        public string CSVFileOutputPath
        {
            get { return _CSVFileOutputPath; }
            set { SetProperty(ref _CSVFileOutputPath, value); }
        }

        //CSV File Ouput Binding
        private bool _CSVFileOutput = false;
        public bool CSVFileOutput
        {
            get { return _CSVFileOutput; }
            set
            {
                if (!_CSVFileOutput)
                {
                    SaveFileDialog FileDialog = new SaveFileDialog();
                    FileDialog.DefaultExt = ".csv";
                    FileDialog.AddExtension = true;
                    FileDialog.Filter = "Comma-separated values (*.csv)|*csv";
                    if (FileDialog.ShowDialog() == true)
                    {
                        CSVFileOutputPath = FileDialog.FileName;
                    }
                    else
                    {
                        CSVFileOutputPath = "";
                        return;
                    }
                }
                else
                    CSVFileOutputPath = "";
                SetProperty(ref _CSVFileOutput, value);
            }
        }

        //Excel FileO utput Path Binding
        private string _ExcelFileOutputPath = "";
        public string ExcelFileOutputPath
        {
            get { return _ExcelFileOutputPath; }
            set { SetProperty(ref _ExcelFileOutputPath, value); }
        }

        //Excel File Output Binding
        private bool _ExcelFileOutput = false;
        public bool ExcelFileOutput
        {
            get { return _ExcelFileOutput; }
            set
            {
                if (!_ExcelFileOutput)
                {
                    SaveFileDialog FileDialog = new SaveFileDialog();
                    FileDialog.DefaultExt = ".xlsx";
                    FileDialog.AddExtension = true;
                    FileDialog.Filter = "Excel (.xlsx) |*.xlsx| Excel 97-2003 (.xls) |*.xls";
                    if (FileDialog.ShowDialog() == true)
                    {
                        ExcelFileOutputPath = FileDialog.FileName;
                    }
                    else
                    {
                        ExcelFileOutputPath = "";
                        return;
                    }
                }
                else
                    ExcelFileOutputPath = "";
                SetProperty(ref _ExcelFileOutput, value);
            }
        }

        //Text File Output Path Binding
        private string _TextFileOutputPath = "";
        public string TextFileOutputPath
        {
            get { return _TextFileOutputPath; }
            set { SetProperty(ref _TextFileOutputPath, value); }
        }

        //Text File Output Binding
        private bool _TextFileOutput = false;
        public bool TextFileOutput
        {
            get { return _TextFileOutput; }
            set {
                 if(!_TextFileOutput)
                 {
                    SaveFileDialog FileDialog = new SaveFileDialog();
                    FileDialog.DefaultExt = ".txt";
                    FileDialog.AddExtension = true;
                    FileDialog.Filter = "Text File (*.txt)|*txt";
                    if (FileDialog.ShowDialog() == true)
                    {
                        TextFileOutputPath = FileDialog.FileName;
                    }
                    else
                    {
                        TextFileOutputPath = "";
                        return;
                    }
                }
                else
                    TextFileOutputPath = "";
                SetProperty(ref _TextFileOutput, value);
            }
        }

        //ReadyToProceed() - Verifies that all of the bindings have valid values and populates the error list with any issues that were found
        public bool ReadyToProceed()
        {
            
            _Errors = new List<ReadyToProceedError>();
            bool result = true;
            if(SelectedSeedGenerationType == SeedGenerationType.Unknown)
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("NoSeedRadio", "You must select either Yes or No for seed selection"));
                _Errors.Add(new ReadyToProceedError("YesSeedRadio", ""));
            }
            else if(SelectedSeedGenerationType == SeedGenerationType.UserProvided && UserProvidedSeed.ToString().Length == 0)
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("UserSeedTextBox", "You must provide a seed number."));
            }
            if(UserProvidedSeed > Math.Pow(10,15))
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("UserSeedTextBox", "Provided seed number must be less than 10^15."));
            }

            if (_SequentialNumberCount < 0)
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("SequentialNumberCount", "Sequential number count cannot be less than 0."));
            }
            if (_SparesNumberCount < 0)
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("SparesNumberCount", "Spare number count cannot be less than 0."));
            }
            if ((_SparesNumberCount + _SequentialNumberCount) == 0)
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("SparesNumberCount", "Total number of Sequential and Spare numbers must be greater than zero"));
                _Errors.Add(new ReadyToProceedError("SequentialNumberCount", ""));
            }
            else if ((_SparesNumberCount + _SequentialNumberCount) > 10000)
            {
                result  = false;
                _Errors.Add(new ReadyToProceedError("SparesNumberCount", "Total number of Sequential and Spare numbers may not exceed 10,000"));
                _Errors.Add(new ReadyToProceedError("SequentialNumberCount", ""));

            }
            if(_SamplingFrameHigh < 0)
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("SamplingFrameHigh", "High sampling frame may not be less than 0."));
            }
            if (_SamplingFrameLow < 0)
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("SamplingFrameLow", "Low sampling frame may not be less than 0."));
            }
            if (_SamplingFrameHigh < _SamplingFrameLow)
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("SamplingFrameHigh", "High sampling frame may not be less than Low sampling frame."));
                _Errors.Add(new ReadyToProceedError("SamplingFrameLow", ""));
            }
            if (_SamplingFrameHigh + _SamplingFrameLow == 0)
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("SamplingFrameHigh", "High and Low sampling frame numbers cannot both be zero."));
                _Errors.Add(new ReadyToProceedError("SamplingFrameLow", ""));
            }
            if ((_SamplingFrameHigh - _SamplingFrameLow + 1) < (_SparesNumberCount + _SequentialNumberCount))
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("SamplingFrameHigh", "The frame size is less than the requested number of random numbers and spares."));
                _Errors.Add(new ReadyToProceedError("SamplingFrameLow", ""));
            }
            if (!TextFileOutput && !CSVFileOutput && !ExcelFileOutput)
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("TextOutputCheckBox", "You must select a File Output Option"));
                _Errors.Add(new ReadyToProceedError("CSVOutputCheckBox", ""));
                _Errors.Add(new ReadyToProceedError("ExcelOutputCheckBox", ""));
            }
            //Notify the view that the errors objects have been updated
            OnPropertyChanged("Errors");
            OnPropertyChanged("ErrorsWithText");
            return result;
        }

        public void CalculateSeeds()
        {
            //Detailed Specification - Step One
            Int32 x = 3758214;
            byte[] x_32_bytes = BitConverter.GetBytes(x);

            //Detailed Specification - Step Two
            Double y;
            if (SelectedSeedGenerationType == SeedGenerationType.UserProvided)
                y = (double)UserProvidedSeed;
            else
            {
                y = DateTime.Now.Ticks & 0x0000FFFF;
            }

            byte[] test2 = BitConverter.GetBytes(y);
            //Detailed Specification - Step Four
            short y_first1 = BitConverter.ToInt16(test2, 6);
            short y_last1 = BitConverter.ToInt16(test2, 4);
            int y_xor = (int)y_first1 ^ (int)y_last1;

            byte[] y_xor_bytes = BitConverter.GetBytes(y_xor);
            short y_xor_16 = BitConverter.ToInt16(y_xor_bytes, 0);
            byte[] y_xor_16_bytes = BitConverter.GetBytes(y_xor_16);
            //Detailed Specification - Step Five
            byte[] test = new byte[4];
            System.Buffer.BlockCopy(y_xor_16_bytes, 0, test, 1, 2);
            System.Buffer.BlockCopy(x_32_bytes, 0, test, 0, 1);

            Int32 w = BitConverter.ToInt32(test, 0);
            RandomSample.RatStatSeed RSS_A = RandomSample.CalculateSeed((long)w, 30269.0);
            RandomSample.RatStatSeed RSS_B = RandomSample.CalculateSeed(RSS_A.TrackingSeed, 30307.0);
            RandomSample.RatStatSeed RSS_C = RandomSample.CalculateSeed(RSS_B.TrackingSeed, 30323.0);

            //Wichmann-Hill algorithm
            double SeedA = Math.Floor(RSS_A.ResultSeed);
            double SeedB = Math.Floor(RSS_B.ResultSeed);
            double SeedC = Math.Floor(RSS_C.ResultSeed);
            int LowNumber = SamplingFrameLow;
            int HighNumber = SamplingFrameHigh;
            int NumberOfSeqOrder = SequentialNumberCount;
            int NumberOfSpares = SparesNumberCount;
            int samsiz = NumberOfSeqOrder + NumberOfSpares;
            int Universe = HighNumber - LowNumber + 1;
            List<RandomSample.RatStatRandomNumber> RandomNumber = new List<RandomSample.RatStatRandomNumber>();

            bool DuplicateFlag;
            double Term1, Term2, Term3, TempRandom;
            for (int z = 0; z < samsiz; z++)
            {
                DuplicateFlag = false;
                do
                {
                    Term1 = Math.Floor(SeedA / 177.0);
                    Term2 = SeedA - (177.0 * Term1);
                    SeedA = 171.0 * Term2 - 2 * Term1;
                    if (SeedA <= 0)
                        SeedA += 30269;
                    Term1 = Math.Floor(SeedB / 176.0);
                    Term2 = SeedB - (176.0 * Term1);
                    SeedB = 172.0 * Term2 - 35 * Term1;
                    if (SeedB <= 0)
                        SeedB += 30307;
                    Term1 = Math.Floor(SeedC / 178.0);
                    Term2 = SeedC - (178.0 * Term1);
                    SeedC = 170 * Term2 - 63 * Term1;
                    if (SeedC <= 0)
                        SeedC = SeedC + 30323;
                    Term3 = SeedA / 30269 + SeedB / 30307 + SeedC / 30323;

                    TempRandom = Math.Floor((Term3 - Math.Floor(Term3)) * Universe) + LowNumber;
                    DuplicateFlag = RandomNumber.Any(a => a.Value == TempRandom);
                    if (!DuplicateFlag)
                        RandomNumber.Add(new RandomSample.RatStatRandomNumber(z + 1, (int)TempRandom));

                } while (DuplicateFlag);
            }
            //Populate the report data object
            RandomSample.ReportData RD = new RandomSample.ReportData();
            RD.SequentialArray = RandomNumber.Take(NumberOfSeqOrder).OrderBy(a => a.Value).ToArray();
            RD.SpareArray = RandomNumber.Skip(NumberOfSeqOrder).ToArray();
            RD.SummedValues = RandomNumber.Sum(a => (long)a.Value);
            RD.AuditTitle = AuditReviewTitle;
            RD.SeedNumber = y;
            RD.FrameSize = Universe;
            RD.Total = NumberOfSeqOrder + NumberOfSpares;
            RD.LogTime = DateTime.Now;
            //if the user opted for text output then run the TT text report generator
            if (TextFileOutput)
            {
                RD.TextFileOutput = true;
                RD.TextFileOutputPath = TextFileOutputPath;
                SingleStage_TXT page = new SingleStage_TXT(RD);
                String pageContent = page.TransformText();
                System.IO.File.WriteAllText(TextFileOutputPath, pageContent);
            }
            else
            {
                RD.TextFileOutput = false;
                RD.TextFileOutputPath = "";
            }
            //if the user opted for CSV output then run the TT csv report generator
            if (CSVFileOutput)
            {
                RD.CSVFileOutput = true;
                RD.CSVFileOutputPath = CSVFileOutputPath;
                SingleStage_CSV csv_page = new SingleStage_CSV(RD);
                String csv_pageContent = csv_page.TransformText();
                System.IO.File.WriteAllText(CSVFileOutputPath, csv_pageContent);
            }
            else
            {
                RD.CSVFileOutput = false;
                RD.CSVFileOutputPath = "";
            }
            //if the user opted for Excel output then export the data
            if (ExcelFileOutput)
            {
                RD.ExcelFileOutput = true;
                RD.ExcelFileOutputPath = ExcelFileOutputPath;
                try
                {
                    ExportToExcel(RD);
                }
                catch (Exception Ex)
                {
                    throw new Exception("Export to Excel Error", Ex);
                }

            }
            else
            {
                RD.ExcelFileOutput = false;
                RD.ExcelFileOutputPath = "";
            }
            //Calculations and Outputs are complete so navigate to the report view
            var parameters = new NavigationParameters();
            parameters.Add("ReportData", RD);
            this.MyRegionManager.RequestNavigate("PrimaryPageRegion", "RandomNumbers.SingleStageReportView",parameters);
        }

        //Load the excel template, populate the cells with data and then write the file to the drive in the location specified by the user
        public void ExportToExcel(RandomSample.ReportData RD)
        {
            Excel.Workbook workbook = ExcelAppInterface.excelApp.Workbooks.Open(System.AppDomain.CurrentDomain.BaseDirectory + @"\Templates\RandomNumberTemplate.xlsx", null, true) ;
            try
            {
                //Switch to SPARES Sheet
                Excel.Worksheet workSheet = workbook.Worksheets[1];

                Excel.Range ARangeTop = workSheet.Cells[2, 1];
                Excel.Range BRangeBottom = workSheet.Cells[2 + RD.SpareArray.Length - 1, 2];

                Excel.Range SpareRange = workSheet.get_Range(ARangeTop, BRangeBottom);

                object[,] SpareValues = new object[RD.SpareArray.Length, 2];
                for (int i = 0; i < RD.SpareArray.Length; i++)
                {
                    SpareValues[i, 0] = RD.SpareArray[i].SelectionOrder;
                    SpareValues[i, 1] = RD.SpareArray[i].Value;
                }

                SpareRange.Value = SpareValues;

                //Switch to VALUES Sheet
                workSheet = workbook.Worksheets[2];

                //Output Log Date and Time
                workSheet.Cells[4, "B"] = RD.LogTime.ToShortDateString();
                workSheet.Cells[4, "D"] = RD.LogTime.ToShortTimeString();
                //Output Audit Title
                workSheet.Cells[5, "B"] = RD.AuditTitle;
                //Output Seed Number
                workSheet.Cells[7, "C"] = RD.SeedNumber;
                //Output Frame Size
                workSheet.Cells[7, "D"] = RD.FrameSize;
                //Output VALUES

                ARangeTop = workSheet.Cells[7, 1];
                BRangeBottom = workSheet.Cells[7 + RD.SequentialArray.Length - 1, 2];
                Excel.Range SequentialRange = workSheet.get_Range(ARangeTop, BRangeBottom);
                object[,] SequentialValues = new object[RD.SequentialArray.Length, 2];
                for (int i = 0; i < RD.SequentialArray.Length; i++)
                {
                    SequentialValues[i, 0] = RD.SequentialArray[i].SelectionOrder;
                    SequentialValues[i, 1] = RD.SequentialArray[i].Value;
                }

                SequentialRange.Value = SequentialValues;

                ((Excel.Worksheet)ExcelAppInterface.excelApp.ActiveWorkbook.Sheets[1]).Select();

                if (Path.GetExtension(RD.ExcelFileOutputPath) == ".xls")
                    ExcelAppInterface.excelApp.ActiveWorkbook.SaveAs(ExcelFileOutputPath, Excel.XlFileFormat.xlWorkbookNormal);
                else
                    ExcelAppInterface.excelApp.ActiveWorkbook.SaveAs(ExcelFileOutputPath, Excel.XlFileFormat.xlOpenXMLWorkbook);
            }
            finally
            {
                workbook.Close();
            } 
        }

    }
}
