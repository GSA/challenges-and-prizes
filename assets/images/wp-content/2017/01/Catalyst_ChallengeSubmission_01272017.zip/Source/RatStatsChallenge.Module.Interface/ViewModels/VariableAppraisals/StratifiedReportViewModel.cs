﻿using System.Windows.Input;
using Prism.Mvvm;
using Prism.Commands;
using Prism.Regions;
using RatStatsChallenge.Module.Infastructure;
using System.Diagnostics;
using RatStatsChallenge.Module.Infastructure.Enums;
using System.Collections.Generic;
namespace RatStatsChallenge.Module.Interface.ViewModels.VariableAppraisals
{
    /*****************************************************************************************************
    *   StratifiedReportViewModel
    *   - View model for the Variable Appraisals Stratified Report View. Provides bindings and manages navigation requests
    *
    ******************************************************************************************************/
    public class StratifiedReportViewModel : BindableBase, INavigationAware
    {
        private readonly IRegionManager MyRegionManager;
        private StratifiedVariableAppraisal RD = new StratifiedVariableAppraisal();
        public StratifiedReportViewModel(IRegionManager regionManager)
        {
            //Primary Display Region Manager of the application
            this.MyRegionManager = regionManager;
            this.GoHomeCommand = new DelegateCommand<object>(this.OnGoHomeCommand);
            this.GoBackCommand = new DelegateCommand<object>(this.OnGoBackCommand);
            this.ViewTextCommand = new DelegateCommand<object>(this.OnViewTextCommand);
            this.ViewExcelCommand = new DelegateCommand<object>(this.OnViewExcelCommand);
        }
        //Handler for the GoHomeCommand
        public ICommand GoHomeCommand { get; private set; }
        private void OnGoHomeCommand(object arg)
        {
            MyRegionManager.RequestNavigate("PrimaryPageRegion", "HomePageView");
        }
        //Handler for the GoBackCommand
        public ICommand GoBackCommand { get; private set; }
        private void OnGoBackCommand(object arg)
        {
            var parameters = new NavigationParameters();
            parameters.Add("SourceViewName", "VariableAppraisals.StratifiedReportView");
            this.MyRegionManager.RequestNavigate("PrimaryPageRegion", "VariableAppraisals.StratifiedView" + parameters);
        }

        public virtual bool IsNavigationTarget(NavigationContext navigationContext)
        {
            return true;
        }

        public virtual void OnNavigatedFrom(NavigationContext navigationContext)
        {

        }
        //Handler for OnNavigateTo event that is fired when the view is loaded
        public virtual void OnNavigatedTo(NavigationContext navigationContext)
        {
            //The Stratified View Model passes the report data as a parameter of the navigation object
            if (navigationContext.Parameters != null && navigationContext.Parameters["ReportData"] != null)
            {
                //Initialize bindings based on the passed data
                RD = (StratifiedVariableAppraisal)navigationContext.Parameters["ReportData"];
                AuditReviewTitle = RD.AuditReviewName;
                DataFileInputPath = RD.DataFileInputPath;
                UniverseFileInputPath = RD.UniverseFileInputPath;
                TextFileOutput = RD.TextFileOutput;
                TextFileOutputPath = RD.TextFileOutputPath;
                ExcelFileOutput = RD.ExcelFileOutput;
                ExcelFileOutputPath = RD.ExcelFileOutputPath;
                SumOfExaminedValues = RD.OverallExaminedGroup.Group_Sum;
                SumOfAuditedValues = RD.OverallAuditedGroup.Group_Sum;
                SumOfDifferenceValues = RD.OverallDifferenceGroup.Group_Sum;
                //Tab Visibility Defaults to Hidden
                ExaminedTabVisibility = ControlVisibility.Hidden;
                AuditedTabVisibility = ControlVisibility.Hidden;
                DifferenceTabVisibility = ControlVisibility.Hidden;

                LogDate = "Date: " + RD.LogTime.ToShortDateString();
                LogTime = "Time: " + RD.LogTime.ToShortTimeString();
                switch (RD.SelectedDataFileFormat)
                {
                    case DataFileFormatType.Examined:
                        SelectedTabIndex = 0;
                        ExaminedTabVisibility = ControlVisibility.Visible;
                        NonZeroDifferences = RD.OverallExaminedGroup.Group_NonZero;
                        break;
                    case DataFileFormatType.Audited:
                        SelectedTabIndex = 1;
                        AuditedTabVisibility = ControlVisibility.Visible;
                        NonZeroDifferences = RD.OverallAuditedGroup.Group_NonZero;
                        break;
                    case DataFileFormatType.Difference:
                        SelectedTabIndex = 2;
                        DifferenceTabVisibility = ControlVisibility.Visible;
                        NonZeroDifferences = RD.OverallDifferenceGroup.Group_NonZero;
                        break;
                    default:
                        SelectedTabIndex = 0;
                        ExaminedTabVisibility = ControlVisibility.Visible;
                        AuditedTabVisibility = ControlVisibility.Visible;
                        DifferenceTabVisibility = ControlVisibility.Visible;
                        NonZeroDifferences = RD.OverallDifferenceGroup.Group_NonZero;
                        break;
                }

                //Populate Stratum Combo Box
                List<string> StratIDs = new List<string>();
                foreach (StratifiedVariableAppraisalDataset SAD in RD.Strata)
                {
                    StratIDs.Add(SAD.StratumID);
                }
                StratumIDs = StratIDs;
                if(_StratumIDs.Count > 0)
                {
                    //Auto Select the First Stratum
                    UserSelectedStratumIndex = 0;
                    UserStratumSelectionType = StratumSelectionType.Specific;
                }
                else
                    UserStratumSelectionType = StratumSelectionType.Overall;
                NumberOfStrata = _StratumIDs.Count;
                OverallSampleSize = RD.OverallSampleSize;
            }

        }

        //DisplayOverall() - Based on the data file format selected populate the bindings with data that was passed from the Stratified view
        public void DisplayOverall()
        {
            if (ExaminedTabVisibility == ControlVisibility.Visible)
            {
                ExaminedUniverseSize = RD.OverallUniverseSize;
                ExaminedSampleSize = RD.OverallSampleSize;
                ExaminedGroupData_Mean = RD.OverallExaminedGroup.Group_Mean;
                ExaminedGroupData_Skewness = RD.OverallExaminedGroup.Group_SkewAmt;
                ExaminedGroupData_StdDeviation = RD.OverallExaminedGroup.Group_StandardDeviation;
                ExaminedGroupData_Kurtosis = RD.OverallExaminedGroup.Group_KurtAmt;
                ExaminedGroupData_StdErrorMean = RD.OverallExaminedGroup.Group_StandardError;
                ExaminedGroupData_StdErrorTotal = 0;
                ExaminedGroupData_PointEst = RD.OverallExaminedGroup.Group_PointEstimate;

                ExaminedGroupData_EightyPercent_CI_LowerLimit = RD.OverallExaminedGroup.EightyPercent_Confidence.LowerLimit;
                ExaminedGroupData_EightyPercent_CI_UpperLimit = RD.OverallExaminedGroup.EightyPercent_Confidence.UpperLimit;
                ExaminedGroupData_EightyPercent_CI_PercisionAmount = RD.OverallExaminedGroup.EightyPercent_Confidence.PrecisionAmount;
                ExaminedGroupData_EightyPercent_CI_PercisionPercent = RD.OverallExaminedGroup.EightyPercent_Confidence.PrecisionPercent * 100;
                ExaminedGroupData_EightyPercent_CI_TValueUsed = RD.ZVAL80;
                ExaminedGroupData_NinetyPercent_CI_LowerLimit = RD.OverallExaminedGroup.NinetyPercent_Confidence.LowerLimit;
                ExaminedGroupData_NinetyPercent_CI_UpperLimit = RD.OverallExaminedGroup.NinetyPercent_Confidence.UpperLimit;
                ExaminedGroupData_NinetyPercent_CI_PercisionAmount = RD.OverallExaminedGroup.NinetyPercent_Confidence.PrecisionAmount;
                ExaminedGroupData_NinetyPercent_CI_PercisionPercent = RD.OverallExaminedGroup.NinetyPercent_Confidence.PrecisionPercent * 100;
                ExaminedGroupData_NinetyPercent_CI_TValueUsed = RD.ZVAL90;
                ExaminedGroupData_NinetyFivePercent_CI_LowerLimit = RD.OverallExaminedGroup.NinetyFivePercent_Confidence.LowerLimit;
                ExaminedGroupData_NinetyFivePercent_CI_UpperLimit = RD.OverallExaminedGroup.NinetyFivePercent_Confidence.UpperLimit;
                ExaminedGroupData_NinetyFivePercent_CI_PercisionAmount = RD.OverallExaminedGroup.NinetyFivePercent_Confidence.PrecisionAmount;
                ExaminedGroupData_NinetyFivePercent_CI_PercisionPercent = RD.OverallExaminedGroup.NinetyFivePercent_Confidence.PrecisionPercent * 100;
                ExaminedGroupData_NinetyFivePercent_CI_TValueUsed = RD.ZVAL95;
            }

            if (AuditedTabVisibility == ControlVisibility.Visible)
            {
                AuditedUniverseSize = RD.OverallUniverseSize;
                AuditedSampleSize = RD.OverallSampleSize;
                AuditedGroupData_Mean = RD.OverallAuditedGroup.Group_Mean;
                AuditedGroupData_Skewness = RD.OverallAuditedGroup.Group_SkewAmt;
                AuditedGroupData_StdDeviation = RD.OverallAuditedGroup.Group_StandardDeviation;
                AuditedGroupData_Kurtosis = RD.OverallAuditedGroup.Group_KurtAmt;
                AuditedGroupData_StdErrorMean = RD.OverallAuditedGroup.Group_StandardError;
                AuditedGroupData_StdErrorTotal = 0;
                AuditedGroupData_PointEst = RD.OverallAuditedGroup.Group_PointEstimate;

                AuditedGroupData_EightyPercent_CI_LowerLimit = RD.OverallAuditedGroup.EightyPercent_Confidence.LowerLimit;
                AuditedGroupData_EightyPercent_CI_UpperLimit = RD.OverallAuditedGroup.EightyPercent_Confidence.UpperLimit;
                AuditedGroupData_EightyPercent_CI_PercisionAmount = RD.OverallAuditedGroup.EightyPercent_Confidence.PrecisionAmount;
                AuditedGroupData_EightyPercent_CI_PercisionPercent = RD.OverallAuditedGroup.EightyPercent_Confidence.PrecisionPercent * 100;
                AuditedGroupData_EightyPercent_CI_TValueUsed = RD.ZVAL80;
                AuditedGroupData_NinetyPercent_CI_LowerLimit = RD.OverallAuditedGroup.NinetyPercent_Confidence.LowerLimit;
                AuditedGroupData_NinetyPercent_CI_UpperLimit = RD.OverallAuditedGroup.NinetyPercent_Confidence.UpperLimit;
                AuditedGroupData_NinetyPercent_CI_PercisionAmount = RD.OverallAuditedGroup.NinetyPercent_Confidence.PrecisionAmount;
                AuditedGroupData_NinetyPercent_CI_PercisionPercent = RD.OverallAuditedGroup.NinetyPercent_Confidence.PrecisionPercent * 100;
                AuditedGroupData_NinetyPercent_CI_TValueUsed = RD.ZVAL90;
                AuditedGroupData_NinetyFivePercent_CI_LowerLimit = RD.OverallAuditedGroup.NinetyFivePercent_Confidence.LowerLimit;
                AuditedGroupData_NinetyFivePercent_CI_UpperLimit = RD.OverallAuditedGroup.NinetyFivePercent_Confidence.UpperLimit;
                AuditedGroupData_NinetyFivePercent_CI_PercisionAmount = RD.OverallAuditedGroup.NinetyFivePercent_Confidence.PrecisionAmount;
                AuditedGroupData_NinetyFivePercent_CI_PercisionPercent = RD.OverallAuditedGroup.NinetyFivePercent_Confidence.PrecisionPercent * 100;
                AuditedGroupData_NinetyFivePercent_CI_TValueUsed = RD.ZVAL95;
            }
            if (DifferenceTabVisibility == ControlVisibility.Visible)
            {
                DifferenceUniverseSize = RD.OverallUniverseSize;
                DifferenceSampleSize = RD.OverallSampleSize;
                DifferenceGroupData_Mean = RD.OverallDifferenceGroup.Group_Mean;
                DifferenceGroupData_Skewness = RD.OverallDifferenceGroup.Group_SkewAmt;
                DifferenceGroupData_StdDeviation = RD.OverallDifferenceGroup.Group_StandardDeviation;
                DifferenceGroupData_Kurtosis = RD.OverallDifferenceGroup.Group_KurtAmt;
                DifferenceGroupData_StdErrorMean = RD.OverallDifferenceGroup.Group_StandardError;
                DifferenceGroupData_StdErrorTotal = 0;
                DifferenceGroupData_PointEst = RD.OverallDifferenceGroup.Group_PointEstimate;

                DifferenceGroupData_EightyPercent_CI_LowerLimit = RD.OverallDifferenceGroup.EightyPercent_Confidence.LowerLimit;
                DifferenceGroupData_EightyPercent_CI_UpperLimit = RD.OverallDifferenceGroup.EightyPercent_Confidence.UpperLimit;
                DifferenceGroupData_EightyPercent_CI_PercisionAmount = RD.OverallDifferenceGroup.EightyPercent_Confidence.PrecisionAmount;
                DifferenceGroupData_EightyPercent_CI_PercisionPercent = RD.OverallDifferenceGroup.EightyPercent_Confidence.PrecisionPercent * 100;
                DifferenceGroupData_EightyPercent_CI_TValueUsed = RD.ZVAL80;
                DifferenceGroupData_NinetyPercent_CI_LowerLimit = RD.OverallDifferenceGroup.NinetyPercent_Confidence.LowerLimit;
                DifferenceGroupData_NinetyPercent_CI_UpperLimit = RD.OverallDifferenceGroup.NinetyPercent_Confidence.UpperLimit;
                DifferenceGroupData_NinetyPercent_CI_PercisionAmount = RD.OverallDifferenceGroup.NinetyPercent_Confidence.PrecisionAmount;
                DifferenceGroupData_NinetyPercent_CI_PercisionPercent = RD.OverallDifferenceGroup.NinetyPercent_Confidence.PrecisionPercent * 100;
                DifferenceGroupData_NinetyPercent_CI_TValueUsed = RD.ZVAL90;
                DifferenceGroupData_NinetyFivePercent_CI_LowerLimit = RD.OverallDifferenceGroup.NinetyFivePercent_Confidence.LowerLimit;
                DifferenceGroupData_NinetyFivePercent_CI_UpperLimit = RD.OverallDifferenceGroup.NinetyFivePercent_Confidence.UpperLimit;
                DifferenceGroupData_NinetyFivePercent_CI_PercisionAmount = RD.OverallDifferenceGroup.NinetyFivePercent_Confidence.PrecisionAmount;
                DifferenceGroupData_NinetyFivePercent_CI_PercisionPercent = RD.OverallDifferenceGroup.NinetyFivePercent_Confidence.PrecisionPercent * 100;
                DifferenceGroupData_NinetyFivePercent_CI_TValueUsed = RD.ZVAL95;
            }

        }

        //DisplaySpecificStratum() - Based on the data file format and stratum selected populate the bindings with data that was passed from the Stratified view
        public void DisplaySpecificStratum()
        {
            if (_UserSelectedStratumIndex == -1)
                return;
            if (_UserSelectedStratumIndex < 0 || _UserSelectedStratumIndex >= RD.Strata.Count)
                throw new System.Exception("Statum Index out of range");
            if (ExaminedTabVisibility == ControlVisibility.Visible)
            {
                ExaminedUniverseSize = RD.Strata[_UserSelectedStratumIndex].UniverseSize;
                ExaminedSampleSize = RD.Strata[_UserSelectedStratumIndex].SampleSize;
                ExaminedGroupData_Mean = RD.Strata[_UserSelectedStratumIndex].ExaminedGroup.Group_Mean;
                ExaminedGroupData_Skewness = RD.Strata[_UserSelectedStratumIndex].ExaminedGroup.Group_SkewAmt;
                ExaminedGroupData_StdDeviation = RD.Strata[_UserSelectedStratumIndex].ExaminedGroup.Group_StandardDeviation;
                ExaminedGroupData_Kurtosis = RD.Strata[_UserSelectedStratumIndex].ExaminedGroup.Group_KurtAmt;
                ExaminedGroupData_StdErrorMean = RD.Strata[_UserSelectedStratumIndex].ExaminedGroup.Group_StandardError;
                ExaminedGroupData_StdErrorTotal = RD.Strata[_UserSelectedStratumIndex].ExaminedGroup.Group_StandardError * RD.Strata[_UserSelectedStratumIndex].UniverseSize;
                ExaminedGroupData_PointEst = RD.Strata[_UserSelectedStratumIndex].ExaminedGroup.Group_PointEstimate;

                ExaminedGroupData_EightyPercent_CI_LowerLimit = RD.Strata[_UserSelectedStratumIndex].ExaminedGroup.EightyPercent_Confidence.LowerLimit;
                ExaminedGroupData_EightyPercent_CI_UpperLimit = RD.Strata[_UserSelectedStratumIndex].ExaminedGroup.EightyPercent_Confidence.UpperLimit;
                ExaminedGroupData_EightyPercent_CI_PercisionAmount = RD.Strata[_UserSelectedStratumIndex].ExaminedGroup.EightyPercent_Confidence.PrecisionAmount * RD.Strata[_UserSelectedStratumIndex].UniverseSize;
                ExaminedGroupData_EightyPercent_CI_PercisionPercent = RD.Strata[_UserSelectedStratumIndex].ExaminedGroup.EightyPercent_Confidence.PrecisionPercent * 100;
                ExaminedGroupData_EightyPercent_CI_TValueUsed = RD.Strata[_UserSelectedStratumIndex].ExaminedGroup.EightyPercent_Confidence.T_Value;
                ExaminedGroupData_NinetyPercent_CI_LowerLimit = RD.Strata[_UserSelectedStratumIndex].ExaminedGroup.NinetyPercent_Confidence.LowerLimit;
                ExaminedGroupData_NinetyPercent_CI_UpperLimit = RD.Strata[_UserSelectedStratumIndex].ExaminedGroup.NinetyPercent_Confidence.UpperLimit;
                ExaminedGroupData_NinetyPercent_CI_PercisionAmount = RD.Strata[_UserSelectedStratumIndex].ExaminedGroup.NinetyPercent_Confidence.PrecisionAmount * RD.Strata[_UserSelectedStratumIndex].UniverseSize;
                ExaminedGroupData_NinetyPercent_CI_PercisionPercent = RD.Strata[_UserSelectedStratumIndex].ExaminedGroup.NinetyPercent_Confidence.PrecisionPercent * 100;
                ExaminedGroupData_NinetyPercent_CI_TValueUsed = RD.Strata[_UserSelectedStratumIndex].ExaminedGroup.NinetyPercent_Confidence.T_Value;
                ExaminedGroupData_NinetyFivePercent_CI_LowerLimit = RD.Strata[_UserSelectedStratumIndex].ExaminedGroup.NinetyFivePercent_Confidence.LowerLimit;
                ExaminedGroupData_NinetyFivePercent_CI_UpperLimit = RD.Strata[_UserSelectedStratumIndex].ExaminedGroup.NinetyFivePercent_Confidence.UpperLimit;
                ExaminedGroupData_NinetyFivePercent_CI_PercisionAmount = RD.Strata[_UserSelectedStratumIndex].ExaminedGroup.NinetyFivePercent_Confidence.PrecisionAmount * RD.Strata[_UserSelectedStratumIndex].UniverseSize;
                ExaminedGroupData_NinetyFivePercent_CI_PercisionPercent = RD.Strata[_UserSelectedStratumIndex].ExaminedGroup.NinetyFivePercent_Confidence.PrecisionPercent * 100;
                ExaminedGroupData_NinetyFivePercent_CI_TValueUsed = RD.Strata[_UserSelectedStratumIndex].ExaminedGroup.NinetyFivePercent_Confidence.T_Value;
            }

            if (AuditedTabVisibility == ControlVisibility.Visible)
            {
                AuditedUniverseSize = RD.Strata[_UserSelectedStratumIndex].UniverseSize;
                AuditedSampleSize = RD.Strata[_UserSelectedStratumIndex].SampleSize;
                AuditedGroupData_Mean = RD.Strata[_UserSelectedStratumIndex].AuditedGroup.Group_Mean;
                AuditedGroupData_Skewness = RD.Strata[_UserSelectedStratumIndex].AuditedGroup.Group_SkewAmt;
                AuditedGroupData_StdDeviation = RD.Strata[_UserSelectedStratumIndex].AuditedGroup.Group_StandardDeviation;
                AuditedGroupData_Kurtosis = RD.Strata[_UserSelectedStratumIndex].AuditedGroup.Group_KurtAmt;
                AuditedGroupData_StdErrorMean = RD.Strata[_UserSelectedStratumIndex].AuditedGroup.Group_StandardError;
                AuditedGroupData_StdErrorTotal = RD.Strata[_UserSelectedStratumIndex].AuditedGroup.Group_StandardError * RD.Strata[_UserSelectedStratumIndex].UniverseSize;
                AuditedGroupData_PointEst = RD.Strata[_UserSelectedStratumIndex].AuditedGroup.Group_PointEstimate;

                AuditedGroupData_EightyPercent_CI_LowerLimit = RD.Strata[_UserSelectedStratumIndex].AuditedGroup.EightyPercent_Confidence.LowerLimit;
                AuditedGroupData_EightyPercent_CI_UpperLimit = RD.Strata[_UserSelectedStratumIndex].AuditedGroup.EightyPercent_Confidence.UpperLimit;
                AuditedGroupData_EightyPercent_CI_PercisionAmount = RD.Strata[_UserSelectedStratumIndex].AuditedGroup.EightyPercent_Confidence.PrecisionAmount * RD.Strata[_UserSelectedStratumIndex].UniverseSize;
                AuditedGroupData_EightyPercent_CI_PercisionPercent = RD.Strata[_UserSelectedStratumIndex].AuditedGroup.EightyPercent_Confidence.PrecisionPercent * 100;
                AuditedGroupData_EightyPercent_CI_TValueUsed = RD.Strata[_UserSelectedStratumIndex].AuditedGroup.EightyPercent_Confidence.T_Value;
                AuditedGroupData_NinetyPercent_CI_LowerLimit = RD.Strata[_UserSelectedStratumIndex].AuditedGroup.NinetyPercent_Confidence.LowerLimit;
                AuditedGroupData_NinetyPercent_CI_UpperLimit = RD.Strata[_UserSelectedStratumIndex].AuditedGroup.NinetyPercent_Confidence.UpperLimit;
                AuditedGroupData_NinetyPercent_CI_PercisionAmount = RD.Strata[_UserSelectedStratumIndex].AuditedGroup.NinetyPercent_Confidence.PrecisionAmount * RD.Strata[_UserSelectedStratumIndex].UniverseSize;
                AuditedGroupData_NinetyPercent_CI_PercisionPercent = RD.Strata[_UserSelectedStratumIndex].AuditedGroup.NinetyPercent_Confidence.PrecisionPercent * 100;
                AuditedGroupData_NinetyPercent_CI_TValueUsed = RD.Strata[_UserSelectedStratumIndex].AuditedGroup.NinetyPercent_Confidence.T_Value;
                AuditedGroupData_NinetyFivePercent_CI_LowerLimit = RD.Strata[_UserSelectedStratumIndex].AuditedGroup.NinetyFivePercent_Confidence.LowerLimit;
                AuditedGroupData_NinetyFivePercent_CI_UpperLimit = RD.Strata[_UserSelectedStratumIndex].AuditedGroup.NinetyFivePercent_Confidence.UpperLimit;
                AuditedGroupData_NinetyFivePercent_CI_PercisionAmount = RD.Strata[_UserSelectedStratumIndex].AuditedGroup.NinetyFivePercent_Confidence.PrecisionAmount * RD.Strata[_UserSelectedStratumIndex].UniverseSize;
                AuditedGroupData_NinetyFivePercent_CI_PercisionPercent = RD.Strata[_UserSelectedStratumIndex].AuditedGroup.NinetyFivePercent_Confidence.PrecisionPercent * 100;
                AuditedGroupData_NinetyFivePercent_CI_TValueUsed = RD.Strata[_UserSelectedStratumIndex].AuditedGroup.NinetyFivePercent_Confidence.T_Value;
            }
            if (DifferenceTabVisibility == ControlVisibility.Visible)
            {
                DifferenceUniverseSize = RD.Strata[_UserSelectedStratumIndex].UniverseSize;
                DifferenceSampleSize = RD.Strata[_UserSelectedStratumIndex].SampleSize;
                DifferenceGroupData_Mean = RD.Strata[_UserSelectedStratumIndex].DifferenceGroup.Group_Mean;
                DifferenceGroupData_Skewness = RD.Strata[_UserSelectedStratumIndex].DifferenceGroup.Group_SkewAmt;
                DifferenceGroupData_StdDeviation = RD.Strata[_UserSelectedStratumIndex].DifferenceGroup.Group_StandardDeviation;
                DifferenceGroupData_Kurtosis = RD.Strata[_UserSelectedStratumIndex].DifferenceGroup.Group_KurtAmt;
                DifferenceGroupData_StdErrorMean = RD.Strata[_UserSelectedStratumIndex].DifferenceGroup.Group_StandardError;
                DifferenceGroupData_StdErrorTotal = RD.Strata[_UserSelectedStratumIndex].DifferenceGroup.Group_StandardError * RD.Strata[_UserSelectedStratumIndex].UniverseSize;
                DifferenceGroupData_PointEst = RD.Strata[_UserSelectedStratumIndex].DifferenceGroup.Group_PointEstimate;

                DifferenceGroupData_EightyPercent_CI_LowerLimit = RD.Strata[_UserSelectedStratumIndex].DifferenceGroup.EightyPercent_Confidence.LowerLimit;
                DifferenceGroupData_EightyPercent_CI_UpperLimit = RD.Strata[_UserSelectedStratumIndex].DifferenceGroup.EightyPercent_Confidence.UpperLimit;
                DifferenceGroupData_EightyPercent_CI_PercisionAmount = RD.Strata[_UserSelectedStratumIndex].DifferenceGroup.EightyPercent_Confidence.PrecisionAmount * RD.Strata[_UserSelectedStratumIndex].UniverseSize;
                DifferenceGroupData_EightyPercent_CI_PercisionPercent = RD.Strata[_UserSelectedStratumIndex].DifferenceGroup.EightyPercent_Confidence.PrecisionPercent * 100;
                DifferenceGroupData_EightyPercent_CI_TValueUsed = RD.Strata[_UserSelectedStratumIndex].DifferenceGroup.EightyPercent_Confidence.T_Value;
                DifferenceGroupData_NinetyPercent_CI_LowerLimit = RD.Strata[_UserSelectedStratumIndex].DifferenceGroup.NinetyPercent_Confidence.LowerLimit;
                DifferenceGroupData_NinetyPercent_CI_UpperLimit = RD.Strata[_UserSelectedStratumIndex].DifferenceGroup.NinetyPercent_Confidence.UpperLimit;
                DifferenceGroupData_NinetyPercent_CI_PercisionAmount = RD.Strata[_UserSelectedStratumIndex].DifferenceGroup.NinetyPercent_Confidence.PrecisionAmount * RD.Strata[_UserSelectedStratumIndex].UniverseSize;
                DifferenceGroupData_NinetyPercent_CI_PercisionPercent = RD.Strata[_UserSelectedStratumIndex].DifferenceGroup.NinetyPercent_Confidence.PrecisionPercent * 100;
                DifferenceGroupData_NinetyPercent_CI_TValueUsed = RD.Strata[_UserSelectedStratumIndex].DifferenceGroup.NinetyPercent_Confidence.T_Value;
                DifferenceGroupData_NinetyFivePercent_CI_LowerLimit = RD.Strata[_UserSelectedStratumIndex].DifferenceGroup.NinetyFivePercent_Confidence.LowerLimit;
                DifferenceGroupData_NinetyFivePercent_CI_UpperLimit = RD.Strata[_UserSelectedStratumIndex].DifferenceGroup.NinetyFivePercent_Confidence.UpperLimit;
                DifferenceGroupData_NinetyFivePercent_CI_PercisionAmount = RD.Strata[_UserSelectedStratumIndex].DifferenceGroup.NinetyFivePercent_Confidence.PrecisionAmount * RD.Strata[_UserSelectedStratumIndex].UniverseSize;
                DifferenceGroupData_NinetyFivePercent_CI_PercisionPercent = RD.Strata[_UserSelectedStratumIndex].DifferenceGroup.NinetyFivePercent_Confidence.PrecisionPercent * 100;
                DifferenceGroupData_NinetyFivePercent_CI_TValueUsed = RD.Strata[_UserSelectedStratumIndex].DifferenceGroup.NinetyFivePercent_Confidence.T_Value;
            }
        }

        //StratumIDs binding
        private List<string> _StratumIDs = new List<string>();
        public List<string> StratumIDs
        {
            get { return _StratumIDs;}
            set { SetProperty(ref _StratumIDs, value); }
        }

        //Handler for the ViewExcelCommand
        public ICommand ViewExcelCommand { get; private set; }
        private void OnViewExcelCommand(object arg)
        {
            if (System.IO.File.Exists(ExcelFileOutputPath))
            {
                ProcessStartInfo SI = new ProcessStartInfo();
                SI.FileName = "EXCEL.EXE";
                SI.Arguments = @"/r """ + ExcelFileOutputPath + @"""";
                var res = Process.Start(SI);
            }
        }

        //Handler for the ViewTextCommand
        public ICommand ViewTextCommand { get; private set; }
        private void OnViewTextCommand(object arg)
        {
            if(System.IO.File.Exists(TextFileOutputPath))
                Process.Start(TextFileOutputPath);
        }

        //User Selected Stratum Index Binding
        private int _UserSelectedStratumIndex = -1;
        public int UserSelectedStratumIndex
        {
            get { return _UserSelectedStratumIndex; }
            set { SetProperty(ref _UserSelectedStratumIndex, value);

                if (_UserStratumSelectionType == StratumSelectionType.Specific)
                {
                    DisplaySpecificStratum();
                }

            }
        }

        //Log Data Binding
        private string _LogDate = "";
        public string LogDate
        {
            get { return _LogDate; }
            set { SetProperty(ref _LogDate, value); }
        }

        //Log Time Binding
        private string _LogTime = "";
        public string LogTime
        {
            get { return _LogTime; }
            set { SetProperty(ref _LogTime, value); }
        }

        //Audit Review Title Binding
        private string _AuditReviewTitle = "";
        public string AuditReviewTitle
        {
            get { return _AuditReviewTitle; }
            set { SetProperty(ref _AuditReviewTitle, value); }
        }

        //Data File Input Path Binding
        private string _DataFileInputPath = "";
        public string DataFileInputPath
        {
            get { return _DataFileInputPath; }
            set { SetProperty(ref _DataFileInputPath, value); }
        }

        //Universe File Input Path Binding
        private string _UniverseFileInputPath = "";
        public string UniverseFileInputPath
        {
            get { return _UniverseFileInputPath; }
            set { SetProperty(ref _UniverseFileInputPath, value); }
        }

        //Text File Output Binding
        private bool _TextFileOutput = false;
        public bool TextFileOutput
        {
            get { return _TextFileOutput; }
            set
            {
                SetProperty(ref _TextFileOutput, value);
            }
        }

        //Text File Output Path Binding
        private string _TextFileOutputPath = "";
        public string TextFileOutputPath
        {
            get { return _TextFileOutputPath; }
            set { SetProperty(ref _TextFileOutputPath, value); }
        }

        //Excel File Output Binding
        private bool _ExcelFileOutput = false;
        public bool ExcelFileOutput
        {
            get { return _ExcelFileOutput; }
            set
            {
                SetProperty(ref _ExcelFileOutput, value);
            }
        }

        //Excel File Output Path Binding
        private string _ExcelFileOutputPath = "";
        public string ExcelFileOutputPath
        {
            get { return _ExcelFileOutputPath; }
            set { SetProperty(ref _ExcelFileOutputPath, value); }
        }

        //Examined Universe Size Binding
        private long _ExaminedUniverseSize;
        public long ExaminedUniverseSize
        {
            get { return _ExaminedUniverseSize; }
            set { SetProperty(ref _ExaminedUniverseSize, value); }
        }

        //Examined Sample Size Binding
        private int _ExaminedSampleSize;
        public int ExaminedSampleSize
        {
            get { return _ExaminedSampleSize; }
            set { SetProperty(ref _ExaminedSampleSize, value); }
        }

        //Audited Universe Size Binding
        private long _AuditedUniverseSize;
        public long AuditedUniverseSize
        {
            get { return _AuditedUniverseSize; }
            set { SetProperty(ref _AuditedUniverseSize, value); }
        }

        //Audited Sample Size Binding
        private int _AuditedSampleSize;
        public int AuditedSampleSize
        {
            get { return _AuditedSampleSize; }
            set { SetProperty(ref _AuditedSampleSize, value); }
        }

        //Difference Universe Size Binding
        private long _DifferenceUniverseSize;
        public long DifferenceUniverseSize
        {
            get { return _DifferenceUniverseSize; }
            set { SetProperty(ref _DifferenceUniverseSize, value); }
        }

        //Difference Sample Size Binding
        private int _DifferenceSampleSize;
        public int DifferenceSampleSize
        {
            get { return _DifferenceSampleSize; }
            set { SetProperty(ref _DifferenceSampleSize, value); }
        }

        //Number Of Strata Binding
        public int _NumberOfStrata;
        public int NumberOfStrata
        {
            get { return _NumberOfStrata; }
            set { SetProperty(ref _NumberOfStrata, value); }
        }

        //Overall SampleSize Binding
        public int _OverallSampleSize;
        public int OverallSampleSize
        {
            get { return _OverallSampleSize; }
            set { SetProperty(ref _OverallSampleSize, value); }
        }

        //Non Zero Differences Binding
        private int _NonZeroDifferences = 0;
        public int NonZeroDifferences
        {
            get { return _NonZeroDifferences; }
            set { SetProperty(ref _NonZeroDifferences, value); }
        }

        //Sum of Examined Values Binding
        private double _SumOfExaminedValues = 0;
        public double SumOfExaminedValues
        {
            get { return _SumOfExaminedValues; }
            set { SetProperty(ref _SumOfExaminedValues, value); }
        }

        //Sum of Audited Values Binding
        private double _SumOfAuditedValues = 0;
        public double SumOfAuditedValues
        {
            get { return _SumOfAuditedValues; }
            set { SetProperty(ref _SumOfAuditedValues, value); }
        }

        //Sum of Difference Values Binding
        private double _SumOfDifferenceValues = 0;
        public double SumOfDifferenceValues
        {
            get { return _SumOfDifferenceValues; }
            set { SetProperty(ref _SumOfDifferenceValues, value); }
        }

        //Selected Tab Index Binding
        private int _SelectedTabIndex = 0;
        public int SelectedTabIndex
        {
            get { return _SelectedTabIndex; }
            set { SetProperty(ref _SelectedTabIndex, value); }
        }

        //Examined Tab Visibility Binding
        private ControlVisibility _ExaminedTabVisibility = ControlVisibility.Hidden;
        public ControlVisibility ExaminedTabVisibility
        {
            get { return _ExaminedTabVisibility; }
            set { SetProperty(ref _ExaminedTabVisibility, value); }
        }

        //Audited Tab Visibility Binding
        private ControlVisibility _AuditedTabVisibility = ControlVisibility.Hidden;
        public ControlVisibility AuditedTabVisibility
        {
            get { return _AuditedTabVisibility; }
            set { SetProperty(ref _AuditedTabVisibility, value); }
        }

        //Difference Tab Visibility Binding
        private ControlVisibility _DifferenceTabVisibility = ControlVisibility.Hidden;
        public ControlVisibility DifferenceTabVisibility
        {
            get { return _DifferenceTabVisibility; }
            set { SetProperty(ref _DifferenceTabVisibility, value); }
        }

        //User Stratum Selection Type Binding
        private StratumSelectionType _UserStratumSelectionType = StratumSelectionType.Unknown;
        public StratumSelectionType UserStratumSelectionType
        {
            get { return _UserStratumSelectionType; }
            set { SetProperty(ref _UserStratumSelectionType, value);
                if (value == StratumSelectionType.Overall)
                    DisplayOverall();
                else if(value == StratumSelectionType.Specific)
                {
                    DisplaySpecificStratum();
                }
            }
        }

        //Selected Data File Format Type Binding
        private DataFileFormatType _SelectedDataFileFormatType = DataFileFormatType.Unknown;
        public DataFileFormatType SelectedDataFileFormatType
        {
            get { return _SelectedDataFileFormatType; }
            set { SetProperty(ref _SelectedDataFileFormatType, value); }
        }

        //Examined Group Data_Mean Binding
        private double _ExaminedGroupData_Mean = 0;
        public double ExaminedGroupData_Mean
        {
            get { return _ExaminedGroupData_Mean; }
            set { SetProperty(ref _ExaminedGroupData_Mean, value); }
        }

        //Examined Group Data Skewness Binding
        private double _ExaminedGroupData_Skewness = 0;
        public double ExaminedGroupData_Skewness
        {
            get { return _ExaminedGroupData_Skewness; }
            set { SetProperty(ref _ExaminedGroupData_Skewness, value); }
        }

        //Examined Group Data Standard Deviation Binding
        private double _ExaminedGroupData_StdDeviation = 0;
        public double ExaminedGroupData_StdDeviation
        {
            get { return _ExaminedGroupData_StdDeviation; }
            set { SetProperty(ref _ExaminedGroupData_StdDeviation, value); }
        }

        //Examined Group Data Kurtosis Binding
        private double _ExaminedGroupData_Kurtosis = 0;
        public double ExaminedGroupData_Kurtosis
        {
            get { return _ExaminedGroupData_Kurtosis; }
            set { SetProperty(ref _ExaminedGroupData_Kurtosis, value); }
        }

        //Examined Group Data Standard Error Mean Binding
        private double _ExaminedGroupData_StdErrorMean = 0;
        public double ExaminedGroupData_StdErrorMean
        {
            get { return _ExaminedGroupData_StdErrorMean; }
            set { SetProperty(ref _ExaminedGroupData_StdErrorMean, value); }
        }

        //Examined Group Data Standard Error Total Binding
        private double _ExaminedGroupData_StdErrorTotal = 0;
        public double ExaminedGroupData_StdErrorTotal
        {
            get { return _ExaminedGroupData_StdErrorTotal; }
            set { SetProperty(ref _ExaminedGroupData_StdErrorTotal, value); }
        }

        //Examined Group Data Point Estimate Binding
        private double _ExaminedGroupData_PointEst = 0;
        public double ExaminedGroupData_PointEst
        {
            get { return _ExaminedGroupData_PointEst; }
            set { SetProperty(ref _ExaminedGroupData_PointEst, value); }
        }

        //Examined Group 80% Confidence Interval Lower Limit Binding
        private double _ExaminedGroupData_EightyPercent_CI_LowerLimit = 0;
        public double ExaminedGroupData_EightyPercent_CI_LowerLimit
        {
            get { return _ExaminedGroupData_EightyPercent_CI_LowerLimit; }
            set { SetProperty(ref _ExaminedGroupData_EightyPercent_CI_LowerLimit, value); }
        }

        //Examined Group 90% Confidence Interval Lower Limit Binding
        private double _ExaminedGroupData_NinetyPercent_CI_LowerLimit = 0;
        public double ExaminedGroupData_NinetyPercent_CI_LowerLimit
        {
            get { return _ExaminedGroupData_NinetyPercent_CI_LowerLimit; }
            set { SetProperty(ref _ExaminedGroupData_NinetyPercent_CI_LowerLimit, value); }
        }

        //Examined Group 95% Confidence Interval Lower Limit Binding
        private double _ExaminedGroupData_NinetyFivePercent_CI_LowerLimit = 0;
        public double ExaminedGroupData_NinetyFivePercent_CI_LowerLimit
        {
            get { return _ExaminedGroupData_NinetyFivePercent_CI_LowerLimit; }
            set { SetProperty(ref _ExaminedGroupData_NinetyFivePercent_CI_LowerLimit, value); }
        }

        //Examined Group 80% Confidence Interval Upper Limit Binding
        private double _ExaminedGroupData_EightyPercent_CI_UpperLimit = 0;
        public double ExaminedGroupData_EightyPercent_CI_UpperLimit
        {
            get { return _ExaminedGroupData_EightyPercent_CI_UpperLimit; }
            set { SetProperty(ref _ExaminedGroupData_EightyPercent_CI_UpperLimit, value); }
        }

        //Examined Group 90% Confidence Interval Upper Limit Binding
        private double _ExaminedGroupData_NinetyPercent_CI_UpperLimit = 0;
        public double ExaminedGroupData_NinetyPercent_CI_UpperLimit
        {
            get { return _ExaminedGroupData_NinetyPercent_CI_UpperLimit; }
            set { SetProperty(ref _ExaminedGroupData_NinetyPercent_CI_UpperLimit, value); }
        }

        //Examined Group 95% Confidence Interval Upper Limit Binding
        private double _ExaminedGroupData_NinetyFivePercent_CI_UpperLimit = 0;
        public double ExaminedGroupData_NinetyFivePercent_CI_UpperLimit
        {
            get { return _ExaminedGroupData_NinetyFivePercent_CI_UpperLimit; }
            set { SetProperty(ref _ExaminedGroupData_NinetyFivePercent_CI_UpperLimit, value); }
        }

        //Examined Group 80% Confidence Interval Percision Amount Binding
        private double _ExaminedGroupData_EightyPercent_CI_PercisionAmount = 0;
        public double ExaminedGroupData_EightyPercent_CI_PercisionAmount
        {
            get { return _ExaminedGroupData_EightyPercent_CI_PercisionAmount; }
            set { SetProperty(ref _ExaminedGroupData_EightyPercent_CI_PercisionAmount, value); }
        }

        //Examined Group 90% Confidence Interval Percision Amount Binding
        private double _ExaminedGroupData_NinetyPercent_CI_PercisionAmount = 0;
        public double ExaminedGroupData_NinetyPercent_CI_PercisionAmount
        {
            get { return _ExaminedGroupData_NinetyPercent_CI_PercisionAmount; }
            set { SetProperty(ref _ExaminedGroupData_NinetyPercent_CI_PercisionAmount, value); }
        }

        //Examined Group 95% Confidence Interval Percision Amount Binding
        private double _ExaminedGroupData_NinetyFivePercent_CI_PercisionAmount = 0;
        public double ExaminedGroupData_NinetyFivePercent_CI_PercisionAmount
        {
            get { return _ExaminedGroupData_NinetyFivePercent_CI_PercisionAmount; }
            set { SetProperty(ref _ExaminedGroupData_NinetyFivePercent_CI_PercisionAmount, value); }
        }

        //Examined Group 80% Confidence Interval Percision Percent Binding
        private double _ExaminedGroupData_EightyPercent_CI_PercisionPercent = 0;
        public double ExaminedGroupData_EightyPercent_CI_PercisionPercent
        {
            get { return _ExaminedGroupData_EightyPercent_CI_PercisionPercent; }
            set { SetProperty(ref _ExaminedGroupData_EightyPercent_CI_PercisionPercent, value); }
        }

        //Examined Group 90% Confidence Interval Percision Percent Binding
        private double _ExaminedGroupData_NinetyPercent_CI_PercisionPercent = 0;
        public double ExaminedGroupData_NinetyPercent_CI_PercisionPercent
        {
            get { return _ExaminedGroupData_NinetyPercent_CI_PercisionPercent; }
            set { SetProperty(ref _ExaminedGroupData_NinetyPercent_CI_PercisionPercent, value); }
        }

        //Examined Group 95% Confidence Interval Percision Percent Binding
        private double _ExaminedGroupData_NinetyFivePercent_CI_PercisionPercent = 0;
        public double ExaminedGroupData_NinetyFivePercent_CI_PercisionPercent
        {
            get { return _ExaminedGroupData_NinetyFivePercent_CI_PercisionPercent; }
            set { SetProperty(ref _ExaminedGroupData_NinetyFivePercent_CI_PercisionPercent, value); }
        }

        //Examined Group 80% Confidence Interval T-Value Binding
        private double _ExaminedGroupData_EightyPercent_CI_TValueUsed = 0;
        public double ExaminedGroupData_EightyPercent_CI_TValueUsed
        {
            get { return _ExaminedGroupData_EightyPercent_CI_TValueUsed; }
            set { SetProperty(ref _ExaminedGroupData_EightyPercent_CI_TValueUsed, value); }
        }

        //Examined Group 90% Confidence Interval T-Value Binding
        private double _ExaminedGroupData_NinetyPercent_CI_TValueUsed = 0;
        public double ExaminedGroupData_NinetyPercent_CI_TValueUsed
        {
            get { return _ExaminedGroupData_NinetyPercent_CI_TValueUsed; }
            set { SetProperty(ref _ExaminedGroupData_NinetyPercent_CI_TValueUsed, value); }
        }

        //Examined Group 95% Confidence Interval T-Value Binding
        private double _ExaminedGroupData_NinetyFivePercent_CI_TValueUsed = 0;
        public double ExaminedGroupData_NinetyFivePercent_CI_TValueUsed
        {
            get { return _ExaminedGroupData_NinetyFivePercent_CI_TValueUsed; }
            set { SetProperty(ref _ExaminedGroupData_NinetyFivePercent_CI_TValueUsed, value); }
        }

        //Audited Group Data Mean Binding
        private double _AuditedGroupData_Mean = 0;
        public double AuditedGroupData_Mean
        {
            get { return _AuditedGroupData_Mean; }
            set { SetProperty(ref _AuditedGroupData_Mean, value); }
        }

        //Audited Group Data Skewness Binding
        private double _AuditedGroupData_Skewness = 0;
        public double AuditedGroupData_Skewness
        {
            get { return _AuditedGroupData_Skewness; }
            set { SetProperty(ref _AuditedGroupData_Skewness, value); }
        }

        //Audited Group Data Standard Deviation Binding
        private double _AuditedGroupData_StdDeviation = 0;
        public double AuditedGroupData_StdDeviation
        {
            get { return _AuditedGroupData_StdDeviation; }
            set { SetProperty(ref _AuditedGroupData_StdDeviation, value); }
        }

        //Audited Group Data Kurtosis Binding
        private double _AuditedGroupData_Kurtosis = 0;
        public double AuditedGroupData_Kurtosis
        {
            get { return _AuditedGroupData_Kurtosis; }
            set { SetProperty(ref _AuditedGroupData_Kurtosis, value); }
        }

        //Audited Group Data Standard Errror Mean Binding
        private double _AuditedGroupData_StdErrorMean = 0;
        public double AuditedGroupData_StdErrorMean
        {
            get { return _AuditedGroupData_StdErrorMean; }
            set { SetProperty(ref _AuditedGroupData_StdErrorMean, value); }
        }

        //Audited Group Data Standard Error Total Binding
        private double _AuditedGroupData_StdErrorTotal = 0;
        public double AuditedGroupData_StdErrorTotal
        {
            get { return _AuditedGroupData_StdErrorTotal; }
            set { SetProperty(ref _AuditedGroupData_StdErrorTotal, value); }
        }

        //Audited Group Data Point Estimate Binding
        private double _AuditedGroupData_PointEst = 0;
        public double AuditedGroupData_PointEst
        {
            get { return _AuditedGroupData_PointEst; }
            set { SetProperty(ref _AuditedGroupData_PointEst, value); }
        }

        //Audited Group Data 80% Confidence Interval Lower Limit Binding
        private double _AuditedGroupData_EightyPercent_CI_LowerLimit = 0;
        public double AuditedGroupData_EightyPercent_CI_LowerLimit
        {
            get { return _AuditedGroupData_EightyPercent_CI_LowerLimit; }
            set { SetProperty(ref _AuditedGroupData_EightyPercent_CI_LowerLimit, value); }
        }

        //Audited Group Data 90% Confidence Interval Lower Limit Binding
        private double _AuditedGroupData_NinetyPercent_CI_LowerLimit = 0;
        public double AuditedGroupData_NinetyPercent_CI_LowerLimit
        {
            get { return _AuditedGroupData_NinetyPercent_CI_LowerLimit; }
            set { SetProperty(ref _AuditedGroupData_NinetyPercent_CI_LowerLimit, value); }
        }

        //Audited Group Data 95% Confidence Interval Lower Limit Binding
        private double _AuditedGroupData_NinetyFivePercent_CI_LowerLimit = 0;
        public double AuditedGroupData_NinetyFivePercent_CI_LowerLimit
        {
            get { return _AuditedGroupData_NinetyFivePercent_CI_LowerLimit; }
            set { SetProperty(ref _AuditedGroupData_NinetyFivePercent_CI_LowerLimit, value); }
        }

        //Audited Group Data 80% Confidence Interval Upper Limit Binding
        private double _AuditedGroupData_EightyPercent_CI_UpperLimit = 0;
        public double AuditedGroupData_EightyPercent_CI_UpperLimit
        {
            get { return _AuditedGroupData_EightyPercent_CI_UpperLimit; }
            set { SetProperty(ref _AuditedGroupData_EightyPercent_CI_UpperLimit, value); }
        }

        //Audited Group Data 90% Confidence Interval Upper Limit Binding
        private double _AuditedGroupData_NinetyPercent_CI_UpperLimit = 0;
        public double AuditedGroupData_NinetyPercent_CI_UpperLimit
        {
            get { return _AuditedGroupData_NinetyPercent_CI_UpperLimit; }
            set { SetProperty(ref _AuditedGroupData_NinetyPercent_CI_UpperLimit, value); }
        }

        //Audited Group Data 95% Confidence Interval Upper Limit Binding
        private double _AuditedGroupData_NinetyFivePercent_CI_UpperLimit = 0;
        public double AuditedGroupData_NinetyFivePercent_CI_UpperLimit
        {
            get { return _AuditedGroupData_NinetyFivePercent_CI_UpperLimit; }
            set { SetProperty(ref _AuditedGroupData_NinetyFivePercent_CI_UpperLimit, value); }
        }

        //Audited Group Data 80% Confidence Interval Percision Amount Binding
        private double _AuditedGroupData_EightyPercent_CI_PercisionAmount = 0;
        public double AuditedGroupData_EightyPercent_CI_PercisionAmount
        {
            get { return _AuditedGroupData_EightyPercent_CI_PercisionAmount; }
            set { SetProperty(ref _AuditedGroupData_EightyPercent_CI_PercisionAmount, value); }
        }

        //Audited Group Data 90% Confidence Interval Percision Amount Binding
        private double _AuditedGroupData_NinetyPercent_CI_PercisionAmount = 0;
        public double AuditedGroupData_NinetyPercent_CI_PercisionAmount
        {
            get { return _AuditedGroupData_NinetyPercent_CI_PercisionAmount; }
            set { SetProperty(ref _AuditedGroupData_NinetyPercent_CI_PercisionAmount, value); }
        }

        //Audited Group Data 95% Confidence Interval Percision Amount Binding
        private double _AuditedGroupData_NinetyFivePercent_CI_PercisionAmount = 0;
        public double AuditedGroupData_NinetyFivePercent_CI_PercisionAmount
        {
            get { return _AuditedGroupData_NinetyFivePercent_CI_PercisionAmount; }
            set { SetProperty(ref _AuditedGroupData_NinetyFivePercent_CI_PercisionAmount, value); }
        }

        //Audited Group Data 80% Confidence Interval Percision Percent Binding
        private double _AuditedGroupData_EightyPercent_CI_PercisionPercent = 0;
        public double AuditedGroupData_EightyPercent_CI_PercisionPercent
        {
            get { return _AuditedGroupData_EightyPercent_CI_PercisionPercent; }
            set { SetProperty(ref _AuditedGroupData_EightyPercent_CI_PercisionPercent, value); }
        }

        //Audited Group Data 90% Confidence Interval Percision Percent Binding
        private double _AuditedGroupData_NinetyPercent_CI_PercisionPercent = 0;
        public double AuditedGroupData_NinetyPercent_CI_PercisionPercent
        {
            get { return _AuditedGroupData_NinetyPercent_CI_PercisionPercent; }
            set { SetProperty(ref _AuditedGroupData_NinetyPercent_CI_PercisionPercent, value); }
        }

        //Audited Group Data 95% Confidence Interval Percision Percent Binding
        private double _AuditedGroupData_NinetyFivePercent_CI_PercisionPercent = 0;
        public double AuditedGroupData_NinetyFivePercent_CI_PercisionPercent
        {
            get { return _AuditedGroupData_NinetyFivePercent_CI_PercisionPercent; }
            set { SetProperty(ref _AuditedGroupData_NinetyFivePercent_CI_PercisionPercent, value); }
        }

        //Audited Group Data 80% Confidence Interval t-value Binding
        private double _AuditedGroupData_EightyPercent_CI_TValueUsed = 0;
        public double AuditedGroupData_EightyPercent_CI_TValueUsed
        {
            get { return _AuditedGroupData_EightyPercent_CI_TValueUsed; }
            set { SetProperty(ref _AuditedGroupData_EightyPercent_CI_TValueUsed, value); }
        }

        //Audited Group Data 90% Confidence Interval t-value Binding
        private double _AuditedGroupData_NinetyPercent_CI_TValueUsed = 0;
        public double AuditedGroupData_NinetyPercent_CI_TValueUsed
        {
            get { return _AuditedGroupData_NinetyPercent_CI_TValueUsed; }
            set { SetProperty(ref _AuditedGroupData_NinetyPercent_CI_TValueUsed, value); }
        }

        //Audited Group Data 95% Confidence Interval t-value Binding
        private double _AuditedGroupData_NinetyFivePercent_CI_TValueUsed = 0;
        public double AuditedGroupData_NinetyFivePercent_CI_TValueUsed
        {
            get { return _AuditedGroupData_NinetyFivePercent_CI_TValueUsed; }
            set { SetProperty(ref _AuditedGroupData_NinetyFivePercent_CI_TValueUsed, value); }
        }

        //Difference Group Data Mean Binding
        private double _DifferenceGroupData_Mean = 0;
        public double DifferenceGroupData_Mean
        {
            get { return _DifferenceGroupData_Mean; }
            set { SetProperty(ref _DifferenceGroupData_Mean, value); }
        }

        //Difference Group Data Skewness Binding
        private double _DifferenceGroupData_Skewness = 0;
        public double DifferenceGroupData_Skewness
        {
            get { return _DifferenceGroupData_Skewness; }
            set { SetProperty(ref _DifferenceGroupData_Skewness, value); }
        }

        //Difference Group Data Standard Deviation Binding
        private double _DifferenceGroupData_StdDeviation = 0;
        public double DifferenceGroupData_StdDeviation
        {
            get { return _DifferenceGroupData_StdDeviation; }
            set { SetProperty(ref _DifferenceGroupData_StdDeviation, value); }
        }

        //Difference Group Data Kurtosis Binding
        private double _DifferenceGroupData_Kurtosis = 0;
        public double DifferenceGroupData_Kurtosis
        {
            get { return _DifferenceGroupData_Kurtosis; }
            set { SetProperty(ref _DifferenceGroupData_Kurtosis, value); }
        }

        //Difference Group Data Standard Error Mean Binding
        private double _DifferenceGroupData_StdErrorMean = 0;
        public double DifferenceGroupData_StdErrorMean
        {
            get { return _DifferenceGroupData_StdErrorMean; }
            set { SetProperty(ref _DifferenceGroupData_StdErrorMean, value); }
        }

        //Difference Group Data Standard Error Total Binding
        private double _DifferenceGroupData_StdErrorTotal = 0;
        public double DifferenceGroupData_StdErrorTotal
        {
            get { return _DifferenceGroupData_StdErrorTotal; }
            set { SetProperty(ref _DifferenceGroupData_StdErrorTotal, value); }
        }

        //Difference Group Data Point Estimate Binding
        private double _DifferenceGroupData_PointEst = 0;
        public double DifferenceGroupData_PointEst
        {
            get { return _DifferenceGroupData_PointEst; }
            set { SetProperty(ref _DifferenceGroupData_PointEst, value); }
        }

        //Difference Group Data 80% Confidence Interval Lower Limit Binding
        private double _DifferenceGroupData_EightyPercent_CI_LowerLimit = 0;
        public double DifferenceGroupData_EightyPercent_CI_LowerLimit
        {
            get { return _DifferenceGroupData_EightyPercent_CI_LowerLimit; }
            set { SetProperty(ref _DifferenceGroupData_EightyPercent_CI_LowerLimit, value); }
        }

        //Difference Group Data 90% Confidence Interval Lower Limit Binding
        private double _DifferenceGroupData_NinetyPercent_CI_LowerLimit = 0;
        public double DifferenceGroupData_NinetyPercent_CI_LowerLimit
        {
            get { return _DifferenceGroupData_NinetyPercent_CI_LowerLimit; }
            set { SetProperty(ref _DifferenceGroupData_NinetyPercent_CI_LowerLimit, value); }
        }

        //Difference Group Data 95% Confidence Interval Lower Limit Binding
        private double _DifferenceGroupData_NinetyFivePercent_CI_LowerLimit = 0;
        public double DifferenceGroupData_NinetyFivePercent_CI_LowerLimit
        {
            get { return _DifferenceGroupData_NinetyFivePercent_CI_LowerLimit; }
            set { SetProperty(ref _DifferenceGroupData_NinetyFivePercent_CI_LowerLimit, value); }
        }

        //Difference Group Data 80% Confidence Interval Upper Limit Binding
        private double _DifferenceGroupData_EightyPercent_CI_UpperLimit = 0;
        public double DifferenceGroupData_EightyPercent_CI_UpperLimit
        {
            get { return _DifferenceGroupData_EightyPercent_CI_UpperLimit; }
            set { SetProperty(ref _DifferenceGroupData_EightyPercent_CI_UpperLimit, value); }
        }

        //Difference Group Data 90% Confidence Interval Upper Limit Binding
        private double _DifferenceGroupData_NinetyPercent_CI_UpperLimit = 0;
        public double DifferenceGroupData_NinetyPercent_CI_UpperLimit
        {
            get { return _DifferenceGroupData_NinetyPercent_CI_UpperLimit; }
            set { SetProperty(ref _DifferenceGroupData_NinetyPercent_CI_UpperLimit, value); }
        }

        //Difference Group Data 95% Confidence Interval Upper Limit Binding
        private double _DifferenceGroupData_NinetyFivePercent_CI_UpperLimit = 0;
        public double DifferenceGroupData_NinetyFivePercent_CI_UpperLimit
        {
            get { return _DifferenceGroupData_NinetyFivePercent_CI_UpperLimit; }
            set { SetProperty(ref _DifferenceGroupData_NinetyFivePercent_CI_UpperLimit, value); }
        }

        //Difference Group Data 80% Confidence Interval Percision Amount Binding
        private double _DifferenceGroupData_EightyPercent_CI_PercisionAmount = 0;
        public double DifferenceGroupData_EightyPercent_CI_PercisionAmount
        {
            get { return _DifferenceGroupData_EightyPercent_CI_PercisionAmount; }
            set { SetProperty(ref _DifferenceGroupData_EightyPercent_CI_PercisionAmount, value); }
        }

        //Difference Group Data 90% Confidence Interval Percision Amount Binding
        private double _DifferenceGroupData_NinetyPercent_CI_PercisionAmount = 0;
        public double DifferenceGroupData_NinetyPercent_CI_PercisionAmount
        {
            get { return _DifferenceGroupData_NinetyPercent_CI_PercisionAmount; }
            set { SetProperty(ref _DifferenceGroupData_NinetyPercent_CI_PercisionAmount, value); }
        }

        //Difference Group Data 95% Confidence Interval Percision Amount Binding
        private double _DifferenceGroupData_NinetyFivePercent_CI_PercisionAmount = 0;
        public double DifferenceGroupData_NinetyFivePercent_CI_PercisionAmount
        {
            get { return _DifferenceGroupData_NinetyFivePercent_CI_PercisionAmount; }
            set { SetProperty(ref _DifferenceGroupData_NinetyFivePercent_CI_PercisionAmount, value); }
        }

        //Difference Group Data 80% Confidence Interval Percision Percent Binding
        private double _DifferenceGroupData_EightyPercent_CI_PercisionPercent = 0;
        public double DifferenceGroupData_EightyPercent_CI_PercisionPercent
        {
            get { return _DifferenceGroupData_EightyPercent_CI_PercisionPercent; }
            set { SetProperty(ref _DifferenceGroupData_EightyPercent_CI_PercisionPercent, value); }
        }

        //Difference Group Data 90% Confidence Interval Percision Percent Binding
        private double _DifferenceGroupData_NinetyPercent_CI_PercisionPercent = 0;
        public double DifferenceGroupData_NinetyPercent_CI_PercisionPercent
        {
            get { return _DifferenceGroupData_NinetyPercent_CI_PercisionPercent; }
            set { SetProperty(ref _DifferenceGroupData_NinetyPercent_CI_PercisionPercent, value); }
        }

        //Difference Group Data 95% Confidence Interval Percision Amount Binding
        private double _DifferenceGroupData_NinetyFivePercent_CI_PercisionPercent = 0;
        public double DifferenceGroupData_NinetyFivePercent_CI_PercisionPercent
        {
            get { return _DifferenceGroupData_NinetyFivePercent_CI_PercisionPercent; }
            set { SetProperty(ref _DifferenceGroupData_NinetyFivePercent_CI_PercisionPercent, value); }
        }

        //Difference Group Data 80% Confidence Interval t-value Binding
        private double _DifferenceGroupData_EightyPercent_CI_TValueUsed = 0;
        public double DifferenceGroupData_EightyPercent_CI_TValueUsed
        {
            get { return _DifferenceGroupData_EightyPercent_CI_TValueUsed; }
            set { SetProperty(ref _DifferenceGroupData_EightyPercent_CI_TValueUsed, value); }
        }

        //Difference Group Data 90% Confidence Interval t-value Binding
        private double _DifferenceGroupData_NinetyPercent_CI_TValueUsed = 0;
        public double DifferenceGroupData_NinetyPercent_CI_TValueUsed
        {
            get { return _DifferenceGroupData_NinetyPercent_CI_TValueUsed; }
            set { SetProperty(ref _DifferenceGroupData_NinetyPercent_CI_TValueUsed, value); }
        }

        //Difference Group Data 95% Confidence Interval t-value Binding
        private double _DifferenceGroupData_NinetyFivePercent_CI_TValueUsed = 0;
        public double DifferenceGroupData_NinetyFivePercent_CI_TValueUsed
        {
            get { return _DifferenceGroupData_NinetyFivePercent_CI_TValueUsed; }
            set { SetProperty(ref _DifferenceGroupData_NinetyFivePercent_CI_TValueUsed, value); }
        }
    }
}
