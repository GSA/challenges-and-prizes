﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using RatStatsChallenge.Module.Infastructure;
using RatStatsChallenge.Module.Interface.ViewModels.VariableAppraisals;
namespace RatStatsChallenge.Module.Interface.Views.VariableAppraisals
{
    /// <summary>
    /// Interaction logic for StratifiedView.xaml
    /// </summary>
    public partial class StratifiedView : UserControl
    {
        public StratifiedView(StratifiedViewModel viewModel)
        {
            //Set the view model as the view's data context
            this.DataContext = viewModel;
            InitializeComponent();
        }
        private void Clear_Fields_Button_Click(object sender, RoutedEventArgs e)
        {
            ClearFields();
        }

        private void Cancel_Button_Click(object sender, RoutedEventArgs e)
        {
            ClearFields();
            ((StratifiedViewModel)this.DataContext).GoHome();
        }

        //ClearFields() - removes validation errors from the controls and resets the binding values in the view model to their defaults
        private void ClearFields()
        {
            NumberOfStrataTextBox.Text = "0";
            Validation.ClearInvalid(NumberOfStrataTextBox.GetBindingExpression(TextBox.TextProperty));
            //Reset Error Indicators
            NumberOfStrataTextBox.ClearValue(TextBox.BorderBrushProperty);
            NumberOfStrataTextBox.BorderThickness = new Thickness(1);
            DataFileFormatBorder.BorderBrush = Brushes.Gray;
            DataFileFormatBorder.BorderThickness = new Thickness(1);
            DataFileInputPathTextBox.ClearValue(TextBox.BorderBrushProperty);
            DataFileInputPathTextBox.BorderThickness = new Thickness(1);
            UniverseFileFormatBorder.BorderBrush = Brushes.Gray;
            UniverseFileFormatBorder.BorderThickness = new Thickness(1);
            UniverseFileInputPathTextBox.ClearValue(TextBox.BorderBrushProperty);
            UniverseFileInputPathTextBox.BorderThickness = new Thickness(1);
            ((StratifiedViewModel)this.DataContext).ResetFields();
        }

        //Process_Button_Click() - Checks for validation errors at the view layer and then the view model layer. If no issues are found then the data processing is run.
        private void Process_Button_Click(object sender, RoutedEventArgs e)
        {
            //Check for Validation Errors in the Controls
            if (Validation.GetErrors(NumberOfStrataTextBox).Count > 0)
                return;

            if (((StratifiedViewModel)this.DataContext).DataFileSelectedFileType != Infastructure.Enums.SupportedFileType.EXCEL && ((StratifiedViewModel)this.DataContext).DataFileSelectedFileType != Infastructure.Enums.SupportedFileType.Unknown)
            {
                //VERIFY THE DATA FILE TEXT FORMAT CONTROLS DONT HAVE VALIDATION ERRORS
                if (Validation.GetErrors(DataFirstColumnTextBox).Count > 0)
                    return;
                if (Validation.GetErrors(DataSecondColumnTextBox).Count > 0)
                    return;
            }


            if (((StratifiedViewModel)this.DataContext).UniverseFileSelectedFileType != Infastructure.Enums.SupportedFileType.EXCEL && ((StratifiedViewModel)this.DataContext).UniverseFileSelectedFileType != Infastructure.Enums.SupportedFileType.Unknown)
            {
                //VERIFY THE UNIVERSE FILE TEXT FORMAT CONTROLS DONT HAVE VALIDATION ERRORS
                if (Validation.GetErrors(StratumCounterColumnTextBox).Count > 0 && !((StratifiedViewModel)this.DataContext).SystemAssignedStratumCounter)
                    return;
                if (Validation.GetErrors(UniverseSizeColumnTextBox).Count > 0)
                    return;
                if (Validation.GetErrors(SampleSizeColumnTextBox).Count > 0)
                    return;
            }
            //Reset Visual Error Indicators
            DataFirstColumnTextBox.ClearValue(TextBox.BorderBrushProperty);
            DataFirstColumnTextBox.BorderThickness = new Thickness(1);
            DataSecondColumnTextBox.ClearValue(TextBox.BorderBrushProperty);
            DataSecondColumnTextBox.BorderThickness = new Thickness(1);
            DataFirstCellTextBox.ClearValue(TextBox.BorderBrushProperty);
            DataFirstCellTextBox.BorderThickness = new Thickness(1);
            DataSecondCellTextBox.ClearValue(TextBox.BorderBrushProperty);
            DataSecondCellTextBox.BorderThickness = new Thickness(1);
            StratumCounterColumnTextBox.ClearValue(TextBox.BorderBrushProperty);
            StratumCounterColumnTextBox.BorderThickness = new Thickness(1);
            StratumCounterCellTextBox.ClearValue(TextBox.BorderBrushProperty);
            StratumCounterCellTextBox.BorderThickness = new Thickness(1);
            UniverseSizeColumnTextBox.ClearValue(TextBox.BorderBrushProperty);
            UniverseSizeColumnTextBox.BorderThickness = new Thickness(1);
            UniverseSizeCellTextBox.ClearValue(TextBox.BorderBrushProperty);
            UniverseSizeCellTextBox.BorderThickness = new Thickness(1);
            SampleSizeColumnTextBox.ClearValue(TextBox.BorderBrushProperty);
            SampleSizeColumnTextBox.BorderThickness = new Thickness(1);
            SampleSizeCellTextBox.BorderThickness = new Thickness(1);
            SampleSizeCellTextBox.ClearValue(TextBox.BorderBrushProperty);
            UniverseSizeColumnTextBox.BorderThickness = new Thickness(1);
            UniverseSizeColumnTextBox.ClearValue(TextBox.BorderBrushProperty);
            SampleSizeColumnTextBox.BorderThickness = new Thickness(1);
            SampleSizeColumnTextBox.ClearValue(TextBox.BorderBrushProperty);
            NumberOfStrataTextBox.BorderThickness = new Thickness(1);
            NumberOfStrataTextBox.ClearValue(TextBox.BorderBrushProperty);
            DataFileFormatBorder.BorderThickness = new Thickness(1);
            DataFileFormatBorder.ClearValue(TextBox.BorderBrushProperty);
            DataFileInputPathTextBox.BorderThickness = new Thickness(1);
            DataFileInputPathTextBox.ClearValue(TextBox.BorderBrushProperty);
            UniverseFileInputPathTextBox.BorderThickness = new Thickness(1);
            UniverseFileInputPathTextBox.ClearValue(TextBox.BorderBrushProperty);
            //Check for View Model Errors
            bool result = ((StratifiedViewModel)this.DataContext).ReadyToProceed();
            if (!result)
            {
                //View Model Errors were found so set visual error indicators
                foreach (ReadyToProceedError BR in ((StratifiedViewModel)this.DataContext).Errors)
                {
                    switch (BR.BindingName)
                    {
                        case "DataFirstColumnTextBox":
                            DataFirstColumnTextBox.BorderBrush = Brushes.Red;
                            DataFirstColumnTextBox.BorderThickness = new Thickness(2);
                            break;
                        case "DataSecondColumnTextBox":
                            DataSecondColumnTextBox.BorderBrush = Brushes.Red;
                            DataSecondColumnTextBox.BorderThickness = new Thickness(2);
                            break;
                        case "DataFirstCell":
                            DataFirstCellTextBox.BorderBrush = Brushes.Red;
                            DataFirstCellTextBox.BorderThickness = new Thickness(2);
                            break;
                        case "DataSecondCell":
                            DataSecondCellTextBox.BorderBrush = Brushes.Red;
                            DataSecondCellTextBox.BorderThickness = new Thickness(2);
                            break;
                        case "StratumCounterColumnTextBox":
                            StratumCounterColumnTextBox.BorderBrush = Brushes.Red;
                            StratumCounterColumnTextBox.BorderThickness = new Thickness(2);
                            break;
                        case "StratumCounterCell":
                            StratumCounterCellTextBox.BorderBrush = Brushes.Red;
                            StratumCounterCellTextBox.BorderThickness = new Thickness(2);
                            break;
                        case "UniverseSizeColumnTextBox":
                            UniverseSizeColumnTextBox.BorderBrush = Brushes.Red;
                            UniverseSizeColumnTextBox.BorderThickness = new Thickness(2);
                            break;
                        case "UniverseSizeCell":
                            UniverseSizeCellTextBox.BorderBrush = Brushes.Red;
                            UniverseSizeCellTextBox.BorderThickness = new Thickness(2);
                            break;
                        case "SampleSizeColumnTextBox":
                            SampleSizeColumnTextBox.BorderBrush = Brushes.Red;
                            SampleSizeColumnTextBox.BorderThickness = new Thickness(2);
                            break;
                        case "SampleSizeCell":
                            SampleSizeCellTextBox.BorderBrush = Brushes.Red;
                            SampleSizeCellTextBox.BorderThickness = new Thickness(2);
                            break;
                        case "UniverseSizeColumn":
                            UniverseSizeColumnTextBox.BorderBrush = Brushes.Red;
                            UniverseSizeColumnTextBox.BorderThickness = new Thickness(2);
                            break;
                        case "SampleSizeColumn":
                            SampleSizeColumnTextBox.BorderBrush = Brushes.Red;
                            SampleSizeColumnTextBox.BorderThickness = new Thickness(2);
                            break;
                        case "NumberOfStrata":
                            NumberOfStrataTextBox.BorderBrush = Brushes.Red;
                            NumberOfStrataTextBox.BorderThickness = new Thickness(2);
                            break;
                        case "SelectedDataFileFormatType":
                            DataFileFormatBorder.BorderBrush = Brushes.Red;
                            DataFileFormatBorder.BorderThickness = new Thickness(2);
                            break;
                        case "DataFileInputPath":
                            DataFileInputPathTextBox.BorderBrush = Brushes.Red;
                            DataFileInputPathTextBox.BorderThickness = new Thickness(2);
                            break;
                        case "UniverseFileInputPath":
                            UniverseFileInputPathTextBox.BorderBrush = Brushes.Red;
                            UniverseFileInputPathTextBox.BorderThickness = new Thickness(2);
                            break;
                    }
                }
            }
            else
            {
                //Check if an Excel file has been selected for Universe or Data File
                //if(((StratifiedViewModel)this.DataContext).UniverseFileSelectedFileType == Infastructure.Enums.SupportedFileType.XLSX || ((StratifiedViewModel)this.DataContext).DataFileSelectedFileType == Infastructure.Enums.SupportedFileType.XLSX)
                //{
                //    //Display the Excel Options form
                //    StratifiedExcelOptionsDialog EOD = new StratifiedExcelOptionsDialog((StratifiedViewModel)this.DataContext);
                //    EOD.Owner = Window.GetWindow(this);
                //    if (EOD.ShowDialog() != true)
                //        return;
                //}


            //_ViewModel.Excel_UniverseSpreadsheet = ((StratifiedExcelOptionsDialogModel)this.DataContext).SelectedUniverseSpreadsheet;
            //_ViewModel.Excel_UniverseSize = ((StratifiedExcelOptionsDialogModel)this.DataContext).UniverseSizeCell;
            //_ViewModel.Excel_SampleSize = ((StratifiedExcelOptionsDialogModel)this.DataContext).SampleSizeCell;
            //_ViewModel.Excel_DataSpreadsheet = ((StratifiedExcelOptionsDialogModel)this.DataContext).SelectedDataSpreadsheet;
            //_ViewModel.Excel_DataFirstCell = ((StratifiedExcelOptionsDialogModel)this.DataContext).DataFirstCell;
            //_ViewModel.Excel_DataSecondCell = ((StratifiedExcelOptionsDialogModel)this.DataContext).DataSecondCell;
            //_ViewModel.Excel_StratumCounter = ((StratifiedExcelOptionsDialogModel)this.DataContext).StratumCounterCell;
            //_ViewModel.SystemAssignedStratumCounter = ((StratifiedExcelOptionsDialogModel)this.DataContext).SystemAssignedCounter;


                try
                {
                    this.Cursor = Cursors.Wait;
                    ((StratifiedViewModel)this.DataContext).Process();
                    this.Cursor = Cursors.Arrow;
                }
                catch (Exception ex)
                {
                    this.Cursor = Cursors.Arrow;
                    if(!ex.Message.StartsWith("Exception from HRESULT:"))
                        MessageBox.Show(ex.Message, "Processing Data File Error");
                }
                return;
            }
        }
    }
}
