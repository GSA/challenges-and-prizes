﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using RatStatsChallenge.Module.Interface.ViewModels;
using System.ComponentModel;
namespace RatStatsChallenge.Module.Interface.Views
{
    /// <summary>
    /// Interaction logic for HomePageView.xaml
    /// </summary>
    public partial class HomePageView : UserControl
    {
        public HomePageView(HomePageViewModel viewModel)
        {
            //Set the view model as the view's data context
            this.DataContext = viewModel;
            InitializeComponent();
            BackgroundWorker bw = new BackgroundWorker();
            //Load Excel Assembly in background process
            bw.DoWork += new DoWorkEventHandler(
            delegate (object o, DoWorkEventArgs args)
            {
                BackgroundWorker b = o as BackgroundWorker;
                Microsoft.Office.Interop.Excel.Application excelApp = RatStatsChallenge.Module.Infastructure.ExcelAppInterface.excelApp;
            });
            bw.RunWorkerAsync();
        }
    }
}
