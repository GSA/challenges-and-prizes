﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RatStatsChallenge.Module.Infastructure.Enums
{
    public enum DataFileFormatType
    {
        Unknown = 0,
        Examined,
        Audited,
        Difference,
        ExaminedAudited,
        ExaminedDifference,
        AuditedDifference
    }
}
