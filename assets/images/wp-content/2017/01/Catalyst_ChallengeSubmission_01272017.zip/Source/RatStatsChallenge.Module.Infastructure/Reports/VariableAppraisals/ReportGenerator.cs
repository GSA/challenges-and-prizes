﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RatStatsChallenge.Module.Infastructure;
namespace RatStatsChallenge.Module.Infastructure.Reports.VariableAppraisals
{
    /*****************************************************************************************************
    *   Unrestricted_TXT
    *   - Report data class that is passed to the TT Template generator. It contains all of the data needed
    *   to fill out the fields in the Unrestricted Variable Appraisals Text Report.
    *
    ******************************************************************************************************/
    public partial class Unrestricted_TXT
    {
        private UnrestrictedVariableAppraisal.ReportData m_RD;
        public Unrestricted_TXT(UnrestrictedVariableAppraisal.ReportData RD)
        {
            this.m_RD = RD;
        }
    }
    /*****************************************************************************************************
    *   Stratified_TXT
    *   - Report data class that is passed to the TT Template generator. It contains all of the data needed
    *   to fill out the fields in the Stratified Variable Appraisals Text Report.
    *
    ******************************************************************************************************/
    public partial class Stratified_TXT
    {
        private StratifiedVariableAppraisal m_RD;
        public Stratified_TXT(StratifiedVariableAppraisal RD)
        {
            this.m_RD = RD;
        }
    }
}
