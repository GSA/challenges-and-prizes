﻿using System.Windows.Input;
using Prism.Mvvm;
using Prism.Commands;
using Prism.Regions;
using RatStatsChallenge.Module.Infastructure.Enums;
using System;
using RatStatsChallenge.Module.Infastructure;
using RatStatsChallenge.Module.Infastructure.Reports;
using System.Collections.Generic;
using Microsoft.Win32;
using System.Linq;
using RatStatsChallenge.Module.Infastructure.Reports.AttributeAppraisals;
using System.Windows.Forms.DataVisualization.Charting;
namespace RatStatsChallenge.Module.Interface.ViewModels.AttributeAppraisals
{
    /*****************************************************************************************************
    *   UnrestrictedViewModel
    *   - View model for the Attribute Appraisal Unrestricted View. Provides bindings and manages navigation requests
    *
    ******************************************************************************************************/
    public class UnrestrictedViewModel : BindableBase, INavigationAware
    {
        private int Iter;
        private long  NumberItems, NItems, NBRINSAMPLE;
        private Double Max, Min, Ratio, RatioVal, ZValue, Tail, Phat, Term, SSUM, SSUM1;
        private long Kold, KTop, KBOT, K, Kst, KAdd;
        private double CUMPROBY, KUPPER, KLOWER, LWRQTY80, UPRQTY80, LWRQTY90, UPRQTY90, LWRQTY95, UPRQTY95, LWRQTYCustom, UPRQTYCustom;
        private readonly IRegionManager MyRegionManager;

        public UnrestrictedViewModel(IRegionManager regionManager)
        {
            //Primary Display Region Manager of the application
            this.MyRegionManager = regionManager;
        }

        public virtual bool IsNavigationTarget(NavigationContext navigationContext)
        {
            return true;
        }

        public virtual void OnNavigatedFrom(NavigationContext navigationContext)
        {

        }
        //Handler for OnNavigateTo event that is fired when the view is loaded
        public virtual void OnNavigatedTo(NavigationContext navigationContext)
        {
            //If the user is navigating back to this form from the report view then we want to retain their selections
            string SourceViewName = "";
            if (navigationContext.Parameters != null && navigationContext.Parameters["SourceViewName"] != null)
            {
                SourceViewName = navigationContext.Parameters["SourceViewName"].ToString();
                if (SourceViewName == "AttributeAppraisals.UnrestrictedReportView")
                    return;
            }
            ResetFields();
        }
        //ResetFields() -  Clears the values that the user entered into the form 
        public void ResetFields()
        {
            AuditReviewTitle = "";
            UniverseSize = 0;
            SampleSize = 0;
            SamplesOfInterestSize = 0;
            SelectedConfidenceIntervalType = ConfidenceIntervalType.Unknown;
            Errors = new List<ReadyToProceedError>();
        }

        public void GoHome()
        {
            ResetFields();
            MyRegionManager.RequestNavigate("PrimaryPageRegion", "HomePageView");
        }

        private List<ReadyToProceedError> _Errors = new List<ReadyToProceedError>();
        public List<ReadyToProceedError> Errors
        {
            get { return _Errors; }
            set { SetProperty(ref _Errors, value); }
        }

        public List<ReadyToProceedError> ErrorsWithText
        {
            get { return _Errors.Where(e => e.ErrorContent.Length > 0).ToList(); }
        }

        //Audit Review Title Binding
        private string _AuditReviewTitle = "";
        public string AuditReviewTitle
        {
            get { return _AuditReviewTitle; }
            set { SetProperty(ref _AuditReviewTitle, value); }
        }

        //Universe Size Binding
        private int _UniverseSize;
        public int UniverseSize
        {
            get { return _UniverseSize; }
            set { SetProperty(ref _UniverseSize, value);}
        }

        //Sample Size Binding
        private int _SampleSize;
        public int SampleSize
        {
            get { return _SampleSize; }
            set { SetProperty(ref _SampleSize, value);
                if (value == _SamplesOfInterestSize || _SamplesOfInterestSize == 0)
                {
                    OneSidedConfidenceEnabled = true;
                }
                else
                {
                    OneSidedConfidenceEnabled = false;
                    SelectedConfidenceIntervalType = ConfidenceIntervalType.TwoSided;
                }

            }
        }

        //Custom Confidence Level Binding
        private double _CustomConfidenceLevel = 80; //Default
        public double CustomConfidenceLevel
        {
            get { return _CustomConfidenceLevel;}
            set { SetProperty(ref _CustomConfidenceLevel, value); }
        }

        //One Sided Confidence Enabled Binding
        private bool _OneSidedConfidenceEnabled = true;
        public bool OneSidedConfidenceEnabled
        {
            get { return _OneSidedConfidenceEnabled; }
            set { SetProperty(ref _OneSidedConfidenceEnabled, value); }
        }

        //Samples of Interest Size Binding
        private int _SamplesOfInterestSize;
        public int SamplesOfInterestSize
        {
            get { return _SamplesOfInterestSize; }
            set { SetProperty(ref _SamplesOfInterestSize, value);
                if (value == 0 || value == _SampleSize)
                {
                    OneSidedConfidenceEnabled = true;
                }
                else
                {
                    OneSidedConfidenceEnabled = false;
                    SelectedConfidenceIntervalType = ConfidenceIntervalType.TwoSided;
                }
            }
        }

        //Selected Confidence Interval Type Binding
        private ConfidenceIntervalType _SelectedConfidenceIntervalType = ConfidenceIntervalType.Unknown;
        public ConfidenceIntervalType SelectedConfidenceIntervalType
        {
            get { return _SelectedConfidenceIntervalType; }
            set { SetProperty(ref _SelectedConfidenceIntervalType, value); }
        }

        //Selected Confidence Level Type Binding
        private ConfidenceLevelType _SelectedConfidenceLevelType = ConfidenceLevelType.Default;
        public ConfidenceLevelType SelectedConfidenceLevelType
        {
            get { return _SelectedConfidenceLevelType; }
            set { SetProperty(ref _SelectedConfidenceLevelType, value); }
        }

        //ReadyToProceed() - Verifies that all of the bindings have valid values and populates the error list with any issues that were found
        public bool ReadyToProceed()
        {

            _Errors = new List<ReadyToProceedError>();
            bool result = true;
            if (_SelectedConfidenceIntervalType == ConfidenceIntervalType.Unknown)
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("SelectedConfidenceIntervalType", "You must select a Confidence Interval Option"));
            }
            if (_UniverseSize <= 0)
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("UniverseSize", "The universe size must be greater than zero"));
            }
            if (_SampleSize <= 0)
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("SampleSize", "The sample size must be greater than zero"));
            }
            if (_SamplesOfInterestSize < 0)
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("SamplesOfInterestSize", "The samples of interest size cannot be less than zero"));
            }
            if (_SampleSize > _UniverseSize)
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("SampleSize", "The sample size must be less than universe size"));
            }
            if (_SamplesOfInterestSize > _SampleSize)
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("SamplesOfInterestSize", "The number of items with characteristic of interest cannot be greater than the sample size"));
            }
            if(SelectedConfidenceLevelType == ConfidenceLevelType.Custom && (CustomConfidenceLevel < 0 || CustomConfidenceLevel > 100))
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("CustomConfidenceLevel", "The custom confidence level must be between 0 and 100 percent"));
            }
            OnPropertyChanged("Errors");
            OnPropertyChanged("ErrorsWithText");
            return result;
        }

        //Text File Output Path Binding
        private string _TextFileOutputPath = "";
        public string TextFileOutputPath
        {
            get { return _TextFileOutputPath; }
            set { SetProperty(ref _TextFileOutputPath, value); }
        }

        //Text File Output Binding
        private bool _TextFileOutput = false;
        public bool TextFileOutput
        {
            get { return _TextFileOutput; }
            set
            {
                if (!_TextFileOutput)
                {
                    SaveFileDialog FileDialog = new SaveFileDialog();
                    FileDialog.DefaultExt = ".txt";
                    FileDialog.AddExtension = true;
                    FileDialog.Filter = "Text File (*.txt)|*txt";
                    if (FileDialog.ShowDialog() == true)
                    {
                        TextFileOutputPath = FileDialog.FileName;
                    }
                    else
                    {
                        TextFileOutputPath = "";
                        return;
                    }
                }
                else
                    TextFileOutputPath = "";
                SetProperty(ref _TextFileOutput, value);
            }
        }

        //Calculation code below is a C# version of the visual basic code that was provided with the challenge documentation
        public void Calculate()
        {
            bool CalculateLower;
            NItems = (long)_SamplesOfInterestSize;
            double d_UniverseSize = Double.Parse(_UniverseSize.ToString());
            double d_SampleSize = Double.Parse(_SampleSize.ToString());
            double d_NItems = Double.Parse(NItems.ToString());
            NBRINSAMPLE = NItems;

            Max = 1000000000000;
            Min = 1 / Max;
            NumberItems = NItems;
            Ratio = d_NItems / d_SampleSize;
            RatioVal = Ratio;
            for (int ConvLevel = 1; ConvLevel <= 4; ConvLevel++)
            {
                CalculateLower = true;
                NItems = NumberItems;
                if (ConvLevel == 1)
                {
                    ZValue = 1.28155;
                    if (NItems == 0 || NItems == _SampleSize)
                    {
                        if (SelectedConfidenceIntervalType == ConfidenceIntervalType.OneSided)
                            Tail = 0.2;
                        else
                            Tail = 0.1;
                    }
                    else
                        Tail = 0.1;
                }
                else if (ConvLevel == 2)
                {
                    ZValue = 1.64485;
                    if (NItems == 0 || NItems == _SampleSize)
                    {
                        if (SelectedConfidenceIntervalType == ConfidenceIntervalType.OneSided)
                            Tail = 0.1;
                        else
                            Tail = 0.05;
                    }
                    else
                        Tail = 0.05;
                }
                else if (ConvLevel == 3)
                {
                    ZValue = 1.95996;
                    if (NItems == 0 || NItems == _SampleSize)
                    {
                        if (SelectedConfidenceIntervalType == ConfidenceIntervalType.OneSided)
                            Tail = 0.05;
                        else
                            Tail = 0.025;
                    }
                    else
                        Tail = 0.025;
                }
                else if(SelectedConfidenceLevelType == ConfidenceLevelType.Custom)
                {
                    if (NItems == 0 || NItems == _SampleSize)
                    {
                        if (SelectedConfidenceIntervalType == ConfidenceIntervalType.OneSided)
                            Tail = 1 - (CustomConfidenceLevel / 100);
                        else
                            Tail = (1 - (CustomConfidenceLevel / 100)) / 2;
                    }
                    else
                        Tail = (1 - (CustomConfidenceLevel / 100)) / 2;
                    Chart ChartObj = new Chart();
                    ZValue = ChartObj.DataManipulator.Statistics.InverseNormalDistribution(1 - (1 - (CustomConfidenceLevel / 100)) / 2);
                    ChartObj = null;
                }

                Phat = d_NItems / d_SampleSize;
                Term = Phat * (1.0 - Phat) * d_UniverseSize * (d_UniverseSize - d_SampleSize) / (d_SampleSize - 1);
                Kold = 0;
                Iter = 1;
                //**************************
                //  FIND UPPER LIMIT
                //**************************
                if (NumberItems == _SampleSize)
                {
                    KUPPER = _UniverseSize;
                }
                else
                {
                    Kst = long.Parse(Math.Round((_UniverseSize * Phat) + ZValue * Math.Sqrt(Term)).ToString());
                    if (Kst > (0.95 * _UniverseSize))
                        Kst = _UniverseSize;
                    for (int i = 1; i <= 11; i++)
                    {
                        KAdd = long.Parse(Math.Round((_UniverseSize - Kst) * 0.1 * (i - 1)).ToString());
                        if (NItems == 0 || NItems == _SampleSize)
                            KAdd = long.Parse(Math.Round(_UniverseSize * 0.1 * (i - 1)).ToString());
                        K = Kst + KAdd;
                        if (K > _UniverseSize)
                            K = _UniverseSize;
                        CUMPROBY = SUMHYP();
                        if (CUMPROBY < 0.00001)
                            CUMPROBY = 0;
                        SSUM = CUMPROBY - Tail;
                        if (SSUM < 0)
                            break;
                    }
                    FindBottomUpper();
                    if (!CloseInUpper())
                        return;
                    CalculateLower = FinalUpper();
                }
                if (CalculateLower)
                {
                    //FIND LOWER
                    FindLower();
                    FindBottomLower();
                    if (!CloseInLower())
                        return;
                    FinalLower();
                }
                Results(ConvLevel);
            }
            double d_Ratio = Double.Parse(Ratio.ToString());
            double FRAC = d_SampleSize / d_UniverseSize;
            double Variance = d_SampleSize * d_Ratio * (1.0 - d_Ratio) * (1.0 - FRAC);
            double StanErr = Math.Sqrt(Variance);
            double PrintVar1 = StanErr * Math.Sqrt(d_SampleSize / (d_SampleSize - 1.0)) / FRAC;
            double PrintVar2 = StanErr / Math.Sqrt(d_SampleSize * (d_SampleSize - 1.0));

            UnrestrictedAttributeAppraisal.ReportData RD = new UnrestrictedAttributeAppraisal.ReportData();
            RD.AuditTitle = AuditReviewTitle;
            RD.UniverseSize = _UniverseSize;
            RD.SampleSize = _SampleSize;
            RD.UserSelectedConfidenceIntervalType = _SelectedConfidenceIntervalType;
            RD.UserSelectedConfidenceLevelType = _SelectedConfidenceLevelType;
            RD.CI_ProjectedQuantity = (d_Ratio * _UniverseSize);
            RD.CI_Percent = d_Ratio * 100;
            RD.CI_QuantityIdentified = _SamplesOfInterestSize;
            RD.SE_ProjectedQuantity = PrintVar1;
            RD.SE_Percent = PrintVar2 * 100;
            RD.CustomConfidenceLevel = CustomConfidenceLevel;
            RD.LogTime = DateTime.Now;
            if (SelectedConfidenceIntervalType == ConfidenceIntervalType.OneSided && NItems == 0)
            {
                RD.EightyPercent_ConfidenceInterval.LowerLimitQuantity = null;
                RD.EightyPercent_ConfidenceInterval.LowerLimitPercent = null;
                RD.NinetyPercent_ConfidenceInterval.LowerLimitQuantity = null;
                RD.NinetyPercent_ConfidenceInterval.LowerLimitPercent = null;
                RD.NinetyFivePercent_ConfidenceInterval.LowerLimitQuantity = null;
                RD.NinetyFivePercent_ConfidenceInterval.LowerLimitPercent = null;
                RD.CustomPercent_ConfidenceInterval.LowerLimitQuantity = null;
                RD.CustomPercent_ConfidenceInterval.LowerLimitPercent = null;
            }
            else
            {

                RD.EightyPercent_ConfidenceInterval.LowerLimitQuantity = LWRQTY80;
                RD.NinetyPercent_ConfidenceInterval.LowerLimitQuantity = LWRQTY90;
                RD.NinetyFivePercent_ConfidenceInterval.LowerLimitQuantity = LWRQTY95;
                RD.CustomPercent_ConfidenceInterval.LowerLimitQuantity = LWRQTYCustom;

                RD.EightyPercent_ConfidenceInterval.LowerLimitPercent = (LWRQTY80 / d_UniverseSize) * 100;
                RD.NinetyPercent_ConfidenceInterval.LowerLimitPercent = (LWRQTY90 / d_UniverseSize) * 100;
                RD.NinetyFivePercent_ConfidenceInterval.LowerLimitPercent = (LWRQTY95 / d_UniverseSize) * 100;
                RD.CustomPercent_ConfidenceInterval.LowerLimitPercent = (LWRQTYCustom / d_UniverseSize) * 100;
            }

            if (SelectedConfidenceIntervalType == ConfidenceIntervalType.OneSided && NumberItems == _SampleSize)
            {
                RD.EightyPercent_ConfidenceInterval.UpperLimitQuantity = null;
                RD.EightyPercent_ConfidenceInterval.UpperLimitPercent = null;
                RD.NinetyPercent_ConfidenceInterval.UpperLimitQuantity = null;
                RD.NinetyPercent_ConfidenceInterval.UpperLimitPercent = null;
                RD.NinetyFivePercent_ConfidenceInterval.UpperLimitQuantity = null;
                RD.NinetyFivePercent_ConfidenceInterval.UpperLimitPercent = null;
                RD.CustomPercent_ConfidenceInterval.UpperLimitQuantity = null;
                RD.CustomPercent_ConfidenceInterval.UpperLimitPercent = null;
            }
            else
            {
                RD.EightyPercent_ConfidenceInterval.UpperLimitQuantity = UPRQTY80;
                RD.EightyPercent_ConfidenceInterval.UpperLimitPercent = (UPRQTY80 / d_UniverseSize) * 100;
                RD.NinetyPercent_ConfidenceInterval.UpperLimitQuantity = UPRQTY90;
                RD.NinetyPercent_ConfidenceInterval.UpperLimitPercent = (UPRQTY90 / d_UniverseSize) * 100;
                RD.NinetyFivePercent_ConfidenceInterval.UpperLimitQuantity = UPRQTY95;
                RD.NinetyFivePercent_ConfidenceInterval.UpperLimitPercent = (UPRQTY95 / d_UniverseSize) * 100; 
                RD.CustomPercent_ConfidenceInterval.UpperLimitQuantity = UPRQTYCustom;
                RD.CustomPercent_ConfidenceInterval.UpperLimitPercent = (UPRQTYCustom / d_UniverseSize) * 100;
            }
            if (TextFileOutput)
            {
                RD.TextFileOutput = true;
                RD.TextFileOutputPath = TextFileOutputPath;
                Unrestricted_TXT page = new Unrestricted_TXT(RD);
                String pageContent = page.TransformText();
                System.IO.File.WriteAllText(TextFileOutputPath, pageContent);
            }
            else
            {
                RD.TextFileOutput = false;
                RD.TextFileOutputPath = "";
            }
            //Load Report
            var parameters = new NavigationParameters();
            parameters.Add("ReportData", RD);
            this.MyRegionManager.RequestNavigate("PrimaryPageRegion", "AttributeAppraisals.UnrestrictedReportView", parameters);
        }

        private double SUMHYP()
        {
            long EXPNTZ = 0;
            double PopGood = _UniverseSize - K;
            double MinBad = _SampleSize - PopGood, Z;
            double _CUMPROBY;
            if (NItems < MinBad)
            {
                return 0;
            }
            if (MinBad < 0)
                MinBad = 0;
            Z = 1;
            if (MinBad > 0)
            {
                for (int J = 0; J < _SampleSize; J++)
                {
                    if (J < MinBad)
                        Z = Z * (K - J) / (_UniverseSize - J);
                    else
                        Z = Z * (J + 1) / (_UniverseSize - J);
                    if (Z < Min)
                    {
                        Z = Z * Max;
                        EXPNTZ = EXPNTZ - 1;
                    }
                    if (Z >= Max)
                    {
                        Z = Z * Min;
                        EXPNTZ = EXPNTZ + 1;
                    }
                }
            }
            else
            {
                for (int J = 0; J < _SampleSize; J++)
                {
                    Z = Z * (PopGood - J) / (_UniverseSize - J);
                    if (Z < Min)
                    {
                        Z = Z * Max;
                        EXPNTZ = EXPNTZ - 1;
                    }
                }
            }
            if (EXPNTZ < -1)
                _CUMPROBY = 0;
            else
                _CUMPROBY = (Z * Math.Pow(Max, EXPNTZ));

            //  COMPUTE PROB OF MINBAD TO X ERRORS IN THE SAMPLE
            double PB, PG, SS, SB;
            if (MinBad > 0)
            {
                PB = K - MinBad;
                PG = PopGood + MinBad;
                SS = _SampleSize - MinBad;
                SB = NItems - MinBad;
            }
            else
            {
                PB = K;
                PG = PopGood;
                SS = _SampleSize;
                SB = NItems;
            }
            for (int J = 1; J <= SB; J++)
            {
                Z = Z * (PB - J + 1) * (SS - J + 1);
                Z = Z / ((J + MinBad) * (PG - _SampleSize + J));
                if (Z > Max)
                {
                    Z = Z / Max;
                    EXPNTZ = EXPNTZ + 1;
                }
                if (Math.Abs(EXPNTZ) < 2)
                {
                    _CUMPROBY = _CUMPROBY + Z * Math.Pow(Max, EXPNTZ);
                }
            }
            return _CUMPROBY;
        }

        private void FindBottomUpper()
        {
            long KSUB;
            KTop = K;
            Kst = long.Parse(Math.Round((_UniverseSize * Phat) + ZValue * Math.Sqrt(Term)).ToString());
            if (Kst > (0.95 * _UniverseSize))
                Kst = _UniverseSize;
            for (int i = 1; i <= 11; i++)
            {
                KSUB = long.Parse(Math.Round((Kst - _UniverseSize * Phat) * 0.1 * (i - 1)).ToString());
                K = Kst - KSUB;
                CUMPROBY = SUMHYP();
                if (CUMPROBY < 0.00001)
                {
                    CUMPROBY = 0;
                }
                SSUM = CUMPROBY - Tail;
                if (SSUM > 0)
                {
                    KBOT = K;
                    Kold = K;
                    break;
                }
            }
            return;
        }
        private bool CloseInUpper()
        {
            double SUMNew;
            Iter = 1;
            while (true)
            {
                if ((KTop - KBOT) == 1)
                    return true;
                K = KBOT + (KTop - KBOT) / 2;
                CUMPROBY = SUMHYP();
                SSUM = CUMPROBY - Tail;
                if (SSUM <= 0)
                    KTop = K;
                else
                    KBOT = K;
                Iter = Iter + 1;
                if (Iter > 100)
                {
                    return false;
                }
                Kold = K;
                SUMNew = SSUM;
            }
        }

        private bool FinalUpper()
        {
            if (NItems == 0)
            {
                KUPPER = KBOT;
                KLOWER = 0;
                return false;
            }
            KUPPER = KBOT;
            if (KUPPER > (_UniverseSize - _SampleSize + NItems))
                KUPPER = (_UniverseSize - _SampleSize + NItems);
            return true;
        }

        private void FindLower()
        {
            NItems = NItems - 1;
            Iter = 1;
            Kst = long.Parse(Math.Round((_UniverseSize * Phat) - ZValue * Math.Sqrt(Term)).ToString());
            if (Kst < NItems)
            {
                Kst = NItems;
            }
            K = Kst;
            for (int I = 1; I <= 11; I++)
            {
                KAdd = long.Parse(Math.Round((_UniverseSize * Phat - Kst) * 0.1 * (I - 1)).ToString());
                if (NItems == 0 || NItems == _SampleSize)
                {
                    KAdd = long.Parse(Math.Round(_UniverseSize * 0.1 * (I - 1)).ToString());
                }
                K = Kst + KAdd;
                if (K > _UniverseSize)
                {
                    K = _UniverseSize;
                }
                CUMPROBY = SUMHYP();
                if (CUMPROBY < 0.00001)
                {
                    CUMPROBY = 0;
                }
                SSUM1 = 1 - CUMPROBY - Tail;
                if (SSUM1 > 0)
                {
                    break;
                }
            }
            return;
        }

        private void FindBottomLower()
        {
            long KSub;
            KTop = K;
            Kst = long.Parse(Math.Round((_UniverseSize * Phat) - ZValue * Math.Sqrt(Term)).ToString());
            if (Kst < 0)
                Kst = 0;
            K = Kst;
            for (int i = 1; i <= 11; i++)
            {
                KSub = long.Parse(Math.Round(Kst * 0.1 * (i - 1)).ToString());
                K = Kst - KSub;
                if (K < 0)
                    K = 0;
                CUMPROBY = SUMHYP();
                if (CUMPROBY < 0.00001)
                    CUMPROBY = 0;
                SSUM1 = 1 - CUMPROBY - Tail;
                if (SSUM1 < 0)
                {
                    KBOT = K;
                    break;
                }
            }
            return;
        }

        private bool CloseInLower()
        {
            Double SSUM1New;
            Iter = 1;
            while (true)
            {
                if ((KTop - KBOT) == 1)
                    break;
                K = KBOT + (KTop - KBOT) / 2;
                CUMPROBY = SUMHYP();
                if (CUMPROBY < 0.00001)
                    CUMPROBY = 0;
                SSUM1 = 1 - CUMPROBY - Tail;
                if (SSUM1 <= 0)
                    KBOT = K;
                else
                    KTop = K;
                Iter = Iter + 1;
                if (Iter > 100)
                {
                    return false;
                }
                Kold = K;
                SSUM1New = SSUM1;
            }
            return true;
        }

        private void FinalLower()
        {
            if (NItems == _SampleSize)
            {
                KLOWER = KTop;
                return;
            }
            KLOWER = KTop;
            if (KLOWER < NItems)
                KLOWER = NItems;
            return;
        }

        private void Results(int ConvLevel)
        {
            if (ConvLevel == 1)
            {
                LWRQTY80 = KLOWER;
                UPRQTY80 = KUPPER;
            }
            else if (ConvLevel == 2)
            {
                LWRQTY90 = KLOWER;
                UPRQTY90 = KUPPER;
            }
            else if (ConvLevel == 3)
            {
                LWRQTY95 = KLOWER;
                UPRQTY95 = KUPPER;
            }
            else if (ConvLevel == 4)
            {
                LWRQTYCustom = KLOWER;
                UPRQTYCustom = KUPPER;
            }

        }

    }

}
