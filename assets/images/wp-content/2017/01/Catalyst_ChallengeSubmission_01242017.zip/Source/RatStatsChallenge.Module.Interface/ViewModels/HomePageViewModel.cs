﻿using System.Windows.Input;
using Prism.Mvvm;
using Prism.Commands;
using Prism.Regions;
using Prism.Events;
using Microsoft.Win32;
using System.Windows;

namespace RatStatsChallenge.Module.Interface.ViewModels
{
    public class HomePageViewModel : BindableBase
    {
        private readonly IRegionManager MyRegionManager;
        public HomePageViewModel(IRegionManager regionManager)
        {
            this.MyRegionManager = regionManager;
            this.SingleStageRandomNumbersCommand = new DelegateCommand<object>(this.OnSingleStageRandomNumbersCommand);
            this.UnrestrictedAttributeAppraisalsCommand = new DelegateCommand<object>(this.OnUnrestrictedAttributeAppraisalsCommand);
            this.UnrestrictedVariableAppraisalsCommand = new DelegateCommand<object>(this.OnUnrestrictedVariableAppraisalsCommand);
            this.StratifiedVariableAppraisalsCommand = new DelegateCommand<object>(this.OnStratifiedVariableAppraisalsCommand);
        }

        //Handle for the Single Stage Random Number Command
        public ICommand SingleStageRandomNumbersCommand { get; private set; }
        private void OnSingleStageRandomNumbersCommand(object arg)
        {
            var parameters = new NavigationParameters();
            parameters.Add("SourceViewName", "HomePageView");
            this.MyRegionManager.RequestNavigate("PrimaryPageRegion", "RandomNumbers.SingleStageView" + parameters);
            return;
        }

        //Handle for the Unrestricted Attribute Appraisal Command
        public ICommand UnrestrictedAttributeAppraisalsCommand { get; private set; }
        private void OnUnrestrictedAttributeAppraisalsCommand(object arg)
        {
            var parameters = new NavigationParameters();
            parameters.Add("SourceViewName", "HomePageView");
            this.MyRegionManager.RequestNavigate("PrimaryPageRegion", "AttributeAppraisals.UnrestrictedView" + parameters);
            return;
        }

        //Handle for the Unrestricted Variable Appraisal Command
        public ICommand UnrestrictedVariableAppraisalsCommand { get; private set; }
        private void OnUnrestrictedVariableAppraisalsCommand(object arg)
        {
            var parameters = new NavigationParameters();
            parameters.Add("SourceViewName", "HomePageView");
            this.MyRegionManager.RequestNavigate("PrimaryPageRegion", "VariableAppraisals.UnrestrictedView" + parameters);
            return;
        }

        //Handle for the Stratfieid Varaible Appraisals Command
        public ICommand StratifiedVariableAppraisalsCommand { get; private set; }
        private void OnStratifiedVariableAppraisalsCommand(object arg)
        {
            var parameters = new NavigationParameters();
            parameters.Add("SourceViewName", "HomePageView");
            this.MyRegionManager.RequestNavigate("PrimaryPageRegion", "VariableAppraisals.StratifiedView" + parameters);
            return;
        }
    }
}
