﻿using System.Windows.Input;
using Prism.Mvvm;
using Prism.Commands;
using Prism.Regions;
using RatStatsChallenge.Module.Infastructure;
using System.Diagnostics;
namespace RatStatsChallenge.Module.Interface.ViewModels.RandomNumbers
{
    /*****************************************************************************************************
    *   SingleStageReportViewModel
    *   - View model for the Random Numbers Single Stage Report View. Provides bindings and manages navigation requests
    *
    ******************************************************************************************************/
    public class SingleStageReportViewModel : BindableBase, INavigationAware
    {
        private readonly IRegionManager MyRegionManager;
        private RandomSample.ReportData RD = new RandomSample.ReportData();
        public SingleStageReportViewModel(IRegionManager regionManager)
        {
            //Primary Display Region Manager of the application
            this.MyRegionManager = regionManager;
            this.GoHomeCommand = new DelegateCommand<object>(this.OnGoHomeCommand);
            this.GoBackCommand = new DelegateCommand<object>(this.OnGoBackCommand);
            this.ViewTextCommand = new DelegateCommand<object>(this.OnViewTextCommand);
            this.ViewCSVCommand = new DelegateCommand<object>(this.OnViewCSVCommand);
            this.ViewExcelCommand = new DelegateCommand<object>(this.OnViewExcelCommand);
        }
        //Handler for the GoHomeCommand
        public ICommand GoHomeCommand { get; private set; }
        private void OnGoHomeCommand(object arg)
        {
            MyRegionManager.RequestNavigate("PrimaryPageRegion", "HomePageView");
        }
        //Handler for the GoBackCommand
        public ICommand GoBackCommand { get; private set; }
        private void OnGoBackCommand(object arg)
        {
            var parameters = new NavigationParameters();
            parameters.Add("SourceViewName", "RandomNumbers.SingleStageReportView");
            this.MyRegionManager.RequestNavigate("PrimaryPageRegion", "RandomNumbers.SingleStageView" + parameters);
        }
        //Handler for the ViewTextCommand
        public ICommand ViewTextCommand { get; private set; }
        private void OnViewTextCommand(object arg)
        {
            if (System.IO.File.Exists(TextFileOutputPath))
                Process.Start(TextFileOutputPath);
        }
        //Handler for the ViewCSVCommand
        public ICommand ViewCSVCommand { get; private set; }
        private void OnViewCSVCommand(object arg)
        {
            Process.Start(CSVFileOutputPath);
        }
        //Handler for the ViewExcelCommand
        public ICommand ViewExcelCommand { get; private set; }
        private void OnViewExcelCommand(object arg)
        {
            //Launch a process to view the file if it exists on the drive
            if (System.IO.File.Exists(ExcelFileOutputPath))
            {
                ProcessStartInfo SI = new ProcessStartInfo();
                SI.FileName = "EXCEL.EXE";
                SI.Arguments = @"/r """ + ExcelFileOutputPath + @"""";
                var res = Process.Start(SI);
            }
        }

        public virtual bool IsNavigationTarget(NavigationContext navigationContext)
        {
            return true;
        }

        public virtual void OnNavigatedFrom(NavigationContext navigationContext)
        {

        }
        //Handler for OnNavigateTo event that is fired when the view is loaded
        public virtual void OnNavigatedTo(NavigationContext navigationContext)
        {
            //The Single Stage View Model passes the report data as a parameter of the navigation object
            if (navigationContext.Parameters != null && navigationContext.Parameters["ReportData"] != null)
            {
                //Initialize bindings based on the passed data
                RD = (RandomSample.ReportData)navigationContext.Parameters["ReportData"];
                AuditReviewTitle = RD.AuditTitle;
                SeedNumber = RD.SeedNumber;
                FrameSize = RD.FrameSize;
                TextFileOutput = RD.TextFileOutput;
                TextFileOutputPath = RD.TextFileOutputPath;
                CSVFileOutput = RD.CSVFileOutput;
                CSVFileOutputPath = RD.CSVFileOutputPath;
                ExcelFileOutput = RD.ExcelFileOutput;
                ExcelFileOutputPath = RD.ExcelFileOutputPath;
                TotalRandomNumbers = RD.Total;
                SumOfRandomNumbers = RD.SummedValues;
                LogDate = "Date: " + RD.LogTime.ToShortDateString();
                LogTime = "Time: " + RD.LogTime.ToShortTimeString();
            }

        }

        //Log Date Binding
        private string _LogDate = "";
        public string LogDate
        {
            get { return _LogDate; }
            set { SetProperty(ref _LogDate, value); }
        }

        //Log Time Binding
        private string _LogTime = "";
        public string LogTime
        {
            get { return _LogTime; }
            set { SetProperty(ref _LogTime, value); }
        }

        //Audit Review Title Binding
        private string _AuditReviewTitle = "";
        public string AuditReviewTitle
        {
            get { return _AuditReviewTitle; }
            set { SetProperty(ref _AuditReviewTitle, value); }
        }

        //Seed Number Binding
        private double? _SeedNumber;
        public double? SeedNumber
        {
            get { return _SeedNumber; }
            set { SetProperty(ref _SeedNumber, value); }
        }

        //Frame Size Binding
        private int _FrameSize;
        public int FrameSize
        {
            get { return _FrameSize; }
            set { SetProperty(ref _FrameSize, value); }
        }

        //CSV File Output Binding
        private bool _CSVFileOutput = false;
        public bool CSVFileOutput
        {
            get { return _CSVFileOutput; }
            set
            {
                SetProperty(ref _CSVFileOutput, value);
            }
        }

        //Text File Output Binding
        private bool _TextFileOutput = false;
        public bool TextFileOutput
        {
            get { return _TextFileOutput; }
            set
            {
                SetProperty(ref _TextFileOutput, value);
            }
        }

        //Text File Output Path Binding
        private string _TextFileOutputPath = "";
        public string TextFileOutputPath
        {
            get { return _TextFileOutputPath; }
            set { SetProperty(ref _TextFileOutputPath, value); }
        }

        //CSV File Output Path Binding
        private string _CSVFileOutputPath = "";
        public string CSVFileOutputPath
        {
            get { return _CSVFileOutputPath; }
            set { SetProperty(ref _CSVFileOutputPath, value); }
        }

        //Excel File Output Binding
        private bool _ExcelFileOutput = false;
        public bool ExcelFileOutput
        {
            get { return _ExcelFileOutput; }
            set
            {
                SetProperty(ref _ExcelFileOutput, value);
            }
        }

        //Excel File Output Path Binding
        private string _ExcelFileOutputPath = "";
        public string ExcelFileOutputPath
        {
            get { return _ExcelFileOutputPath; }
            set { SetProperty(ref _ExcelFileOutputPath, value); }
        }

        //Total Random Numbers Binding
        private int _TotalRandomNumbers = 0;
        public int TotalRandomNumbers
        {
            get { return _TotalRandomNumbers; }
            set { SetProperty(ref _TotalRandomNumbers, value); }
        }

        //Sum of Random Numbers Binding
        private long _SumOfRandomNumbers = 0;
        public long SumOfRandomNumbers
        {
            get { return _SumOfRandomNumbers; }
            set { SetProperty(ref _SumOfRandomNumbers, value); }
        }
    }
}
