﻿using System.Windows.Input;
using Prism.Mvvm;
using Prism.Commands;
using Prism.Regions;
using RatStatsChallenge.Module.Infastructure.Enums;
using System;
using RatStatsChallenge.Module.Infastructure;
using RatStatsChallenge.Module.Infastructure.Reports;
using System.Collections.Generic;
using Microsoft.Win32;
using System.Linq;
using Microsoft.VisualBasic.FileIO;
using RatStatsChallenge.Module.Infastructure.Reports.VariableAppraisals;
using Excel = Microsoft.Office.Interop.Excel;

namespace RatStatsChallenge.Module.Interface.ViewModels.VariableAppraisals
{
    /*****************************************************************************************************
    *   UnrestrictedViewModel
    *   - View model for the Variable Appraisals Unrestricted View. Provides bindings and manages navigation requests
    *
    ******************************************************************************************************/
    public class UnrestrictedViewModel : BindableBase, INavigationAware
    {
        private readonly IRegionManager MyRegionManager;
        private UnrestrictedVariableAppraisal DS = new UnrestrictedVariableAppraisal();
        public UnrestrictedViewModel(IRegionManager regionManager)
        {
            //Primary Display Region Manager of the application
            this.MyRegionManager = regionManager;
            this.SelectDataFileCommand = new DelegateCommand<object>(this.OnSelectDataFileCommand);
        }
        public virtual bool IsNavigationTarget(NavigationContext navigationContext)
        {
            return true;
        }

        public virtual void OnNavigatedFrom(NavigationContext navigationContext)
        {

        }

        //Handler for OnNavigateTo event that is fired when the view is loaded
        public virtual void OnNavigatedTo(NavigationContext navigationContext)
        {
            string SourceViewName = "";
            if (navigationContext.Parameters != null && navigationContext.Parameters["SourceViewName"] != null)
            {
                SourceViewName = navigationContext.Parameters["SourceViewName"].ToString();
                if (SourceViewName == "VariableAppraisals.UnrestrictedReportView")
                    return;
            }
            ResetFields();
        }

        //ResetFields() -  Clears the values that the user entered into the form 
        public void ResetFields()
        {
            AuditReviewTitle = "";
            UniverseSize = 0;
            SelectedDataFileFormatType = DataFileFormatType.Unknown;
            DataFileSelectedFileType = SupportedFileType.Unknown;
            DataFileInputPath = "";
            DataFileHasHeaders = false;
            FirstColumnHasRowID = true;
            TextFileOutputPath = "";
            TextFileOutput = false;
            SecondDataCellVisible = false;
            Errors = new List<ReadyToProceedError>();
        }

        public void GoHome()
        {
            ResetFields();
            MyRegionManager.RequestNavigate("PrimaryPageRegion", "HomePageView");
        }

        private int PrevDataFilterIndex = 1;

        //Handler for the Select Data File Command
        public ICommand SelectDataFileCommand { get; private set; }
        private void OnSelectDataFileCommand(object arg)
        {
            OpenFileDialog FileDialog = new OpenFileDialog();
            FileDialog.DefaultExt = ".csv";
            FileDialog.AddExtension = true;
            FileDialog.FilterIndex = PrevDataFilterIndex;
            FileDialog.Filter = "Text File (.txt)|*.txt|Dat File (*.dat)|*dat|Comma Delimited (.csv)|*.csv|Excel (.xlsx) |*.xlsx|Excel 97-2003 (.xls) |*.xls";
            if (FileDialog.ShowDialog() == true)
            {
                PrevDataFilterIndex = FileDialog.FilterIndex;
                DataFileInputPath = FileDialog.FileName;
                switch (System.IO.Path.GetExtension(DataFileInputPath))
                {
                    case ".txt":
                        DataFileSelectedFileType = SupportedFileType.TXT;
                        break;
                    case ".dat":
                        DataFileSelectedFileType = SupportedFileType.DAT;
                        break;
                    case ".csv":
                        DataFileSelectedFileType = SupportedFileType.CSV;
                        break;
                    case ".xlsx":
                    case ".xls":
                        DataFileSelectedFileType = SupportedFileType.EXCEL;
                        DataFileLoadExcelSheets();
                        break;           
                    default:
                        DataFileSelectedFileType = SupportedFileType.Unknown;
                        break;
                }
            }
            else
            {
                DataFileInputPath = "";
                DataFileSelectedFileType = SupportedFileType.Unknown;
                return;
            }
        }

        //Data File Text Options Visible Binding
        private bool _Data_File_Text_Options_Visible = false;
        public bool Data_File_Text_Options_Visible
        {
            get { return _Data_File_Text_Options_Visible; }
            set { SetProperty(ref _Data_File_Text_Options_Visible, value); }
        }

        //Data File Excel Options Visible Binding
        private bool _Data_File_Excel_Options_Visible = false;
        public bool Data_File_Excel_Options_Visible
        {
            get { return _Data_File_Excel_Options_Visible; }
            set { SetProperty(ref _Data_File_Excel_Options_Visible, value); }
        }

        //Data File Selected File Type Binding
        private SupportedFileType _DataFileSelectedFileType = SupportedFileType.Unknown;
        public SupportedFileType DataFileSelectedFileType
        {
            get { return _DataFileSelectedFileType; }
            set { SetProperty(ref _DataFileSelectedFileType, value);
                switch(DataFileSelectedFileType)
                {
                    case SupportedFileType.TXT:
                    case SupportedFileType.CSV:
                    case SupportedFileType.DAT:
                        Data_File_Text_Options_Visible = true;
                        Data_File_Excel_Options_Visible = false;
                        break;
                    case SupportedFileType.EXCEL:
                        Data_File_Text_Options_Visible = false;
                        Data_File_Excel_Options_Visible = true;
                        break;
                    default:
                        Data_File_Text_Options_Visible = false;
                        Data_File_Excel_Options_Visible = false;
                        break;
                }
            }
        }

        //Errors Binding
        private List<ReadyToProceedError> _Errors = new List<ReadyToProceedError>();
        public List<ReadyToProceedError> Errors
        {
            get { return _Errors; }
            set { SetProperty(ref _Errors, value); }
        }

        //Errors With Text Binding
        public List<ReadyToProceedError> ErrorsWithText
        {
            get { return _Errors.Where(e => e.ErrorContent.Length > 0).ToList(); }
        }

        //Audit Review Title Binding
        private string _AuditReviewTitle = "";
        public string AuditReviewTitle
        {
            get { return _AuditReviewTitle; }
            set { SetProperty(ref _AuditReviewTitle, value); }
        }

        //Universe Size Binding
        private int _UniverseSize;
        public int UniverseSize
        {
            get { return _UniverseSize; }
            set { SetProperty(ref _UniverseSize, value); }
        }

        //Sample Size Binding
        private int _SampleSize;
        public int SampleSize
        {
            get { return _SampleSize; }
            set { SetProperty(ref _SampleSize, value); }
        }

        //Include All Sample Records Binding
        private bool _IncludeAllSampleRecords = true;
        public bool IncludeAllSampleRecords
        {
            get { return _IncludeAllSampleRecords; }
            set { SetProperty(ref _IncludeAllSampleRecords, value); }
        }

        //Selected Data File Format Type Binding
        private DataFileFormatType _SelectedDataFileFormatType = DataFileFormatType.Unknown;
        public DataFileFormatType SelectedDataFileFormatType
        {
            get { return _SelectedDataFileFormatType; }
            set { SetProperty(ref _SelectedDataFileFormatType, value);
                switch(value)
                {
                    case DataFileFormatType.Examined:
                        DataFirstCellText = "Examined Cell";
                        SecondDataCellVisible = false;
                        break;
                    case DataFileFormatType.Audited:
                        DataFirstCellText = "Audited Cell";
                        SecondDataCellVisible = false;
                        break;
                    case DataFileFormatType.Difference:
                        DataFirstCellText = "Difference Cell";
                        SecondDataCellVisible = false;
                        break;
                    case DataFileFormatType.AuditedDifference:
                        DataFirstCellText = "Audited Cell";
                        DataSecondCellText = "Difference Cell";
                        SecondDataCellVisible = true;
                        break;
                    case DataFileFormatType.ExaminedAudited:
                        DataFirstCellText = "Examined Cell";
                        DataSecondCellText = "Audited Cell";
                        SecondDataCellVisible = true;
                        break;
                    case DataFileFormatType.ExaminedDifference:
                        DataFirstCellText = "Examined Cell";
                        DataSecondCellText = "Difference Cell";
                        SecondDataCellVisible = true;
                        break;
                }
            }
        }

        //Data File Input Path Binding
        private string _DataFileInputPath = "";
        public string DataFileInputPath
        {
            get { return _DataFileInputPath; }
            set { SetProperty(ref _DataFileInputPath, value); }
        }

        //Data File Has Headers Binding
        private bool _DataFileHasHeaders = false;
        public bool DataFileHasHeaders
        {
            get { return _DataFileHasHeaders; }
            set { SetProperty(ref _DataFileHasHeaders, value); }
        }

        //First Column Has Row ID Binding
        private bool _FirstColumnHasRowID = true;
        public bool FirstColumnHasRowID
        {
            get { return _FirstColumnHasRowID; }
            set
            {
                SetProperty(ref _FirstColumnHasRowID, value);
            }
        }

        //Text File Ouput Path Binding
        private string _TextFileOutputPath = "";
        public string TextFileOutputPath
        {
            get { return _TextFileOutputPath; }
            set { SetProperty(ref _TextFileOutputPath, value); }
        }

        //Text File Ouput Binding
        private bool _TextFileOutput = false;
        public bool TextFileOutput
        {
            get { return _TextFileOutput; }
            set
            {
                if (!_TextFileOutput && value)
                {
                    SaveFileDialog FileDialog = new SaveFileDialog();
                    FileDialog.DefaultExt = ".txt";
                    FileDialog.AddExtension = true;
                    FileDialog.Filter = "Text File (*.txt)|*txt";
                    if (FileDialog.ShowDialog() == true)
                    {
                        TextFileOutputPath = FileDialog.FileName;
                    }
                    else
                    {
                        TextFileOutputPath = "";
                        return;
                    }
                }
                else
                    TextFileOutputPath = "";
                SetProperty(ref _TextFileOutput, value);
            }
        }

        //ReadyToProceed() - Verifies that all of the bindings have valid values and populates the error list with any issues that were found
        public bool ReadyToProceed()
        {

            _Errors = new List<ReadyToProceedError>();
            bool result = true;
            if(_UniverseSize <= 0)
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("Universe", "Universe size must be greater than zero"));
            }
            if (!IncludeAllSampleRecords && _SampleSize <= 0)
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("SampleSize", "Sample size smust be greater than zero"));
            }
            if (SelectedDataFileFormatType == DataFileFormatType.Unknown)
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("SelectedDataFileFormatType", "You must select a data file format"));
            }
            if(DataFileInputPath.Length == 0)
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("DataFileInputPath", "You must select a data file"));
            }
            if (DataFileSelectedFileType == SupportedFileType.EXCEL)
            {
                //Verify Excel File Selections
                Excel.Workbook workbook = ExcelAppInterface.excelApp.Workbooks.Open(_DataFileInputPath, null, true);
                Excel.Worksheet worksheet = workbook.Worksheets[_SelectedDataSpreadsheet];
                Excel.Range UsedCells = worksheet.UsedRange.Columns;
                Excel.Range FDCell = null, SDCell = null;
                int FDCellRow = -1, SDCellRow = -1;

                bool ValidFDCell = false;
                try
                {
                    FDCell = worksheet.Range[_DataFirstCell];
                    Excel.Range InRange = UsedCells.Application.Intersect(UsedCells, FDCell);

                    if (InRange == null)
                    {

                        switch (SelectedDataFileFormatType)
                        {
                            case DataFileFormatType.Examined:
                            case DataFileFormatType.ExaminedAudited:
                            case DataFileFormatType.ExaminedDifference:
                                _Errors.Add(new ReadyToProceedError("DataFirstCell", "Examined Cell is not within the range of data in spreadsheet"));
                                break;
                            case DataFileFormatType.Audited:
                            case DataFileFormatType.AuditedDifference:
                                _Errors.Add(new ReadyToProceedError("DataFirstCell", "Audited Cell is not within the range of data in spreadsheet"));
                                break;
                            case DataFileFormatType.Difference:
                                _Errors.Add(new ReadyToProceedError("DataFirstCell", "Difference Cell is not within the range of data in spreadsheet"));
                                break;
                        }
                        result = false;
                    }
                    ValidFDCell = true;
                    FDCellRow = FDCell.Row;
                }
                catch (Exception)
                {
                    //Invalid Cell Identifier
                    switch (SelectedDataFileFormatType)
                    {
                        case DataFileFormatType.Examined:
                        case DataFileFormatType.ExaminedAudited:
                        case DataFileFormatType.ExaminedDifference:
                            _Errors.Add(new ReadyToProceedError("DataFirstCell", "Invalid Examined Cell"));
                            break;
                        case DataFileFormatType.Audited:
                        case DataFileFormatType.AuditedDifference:
                            _Errors.Add(new ReadyToProceedError("DataFirstCell", "Invalid Audited Cell"));
                            break;
                        case DataFileFormatType.Difference:
                            _Errors.Add(new ReadyToProceedError("DataFirstCell", "Invalid Difference Cell"));
                            break;
                    }
                    result = false;
                }
                if (SecondDataCellVisible)
                {
                    try
                    {
                        SDCell = worksheet.Range[_DataSecondCell];
                        Excel.Range InRange = UsedCells.Application.Intersect(UsedCells, SDCell);
                        if (InRange == null)
                        {
                            switch (SelectedDataFileFormatType)
                            {
                                case DataFileFormatType.ExaminedAudited:
                                    _Errors.Add(new ReadyToProceedError("DataSecondCell", "Audited Cell is not within the range of data in spreadsheet"));
                                    break;
                                case DataFileFormatType.AuditedDifference:
                                case DataFileFormatType.ExaminedDifference:
                                    _Errors.Add(new ReadyToProceedError("DataSecondCell", "Difference Cell is not within the range of data in spreadsheet"));
                                    break;
                            }
                            result = false;
                        }
 
                        SDCellRow = SDCell.Row;
                        if (FDCell != null && _DataFirstCell == _DataSecondCell)
                        {
                            switch (SelectedDataFileFormatType)
                            {
                                case DataFileFormatType.ExaminedAudited:
                                    _Errors.Add(new ReadyToProceedError("DataFirstCell", "The Examined Cell and Audited Cell cannot be the same cell."));
                                    _Errors.Add(new ReadyToProceedError("DataSecondCell", ""));
                                    break;
                                case DataFileFormatType.AuditedDifference:
                                    _Errors.Add(new ReadyToProceedError("DataFirstCell", "The Audited Cell and Difference Cell cannot be the same cell."));
                                    break;
                                case DataFileFormatType.ExaminedDifference:
                                    _Errors.Add(new ReadyToProceedError("DataFirstCell", "The Examined Cell and Difference Cell cannot be the same cell."));
                                    break;
                            }

                            result = false;
                        }
                        if (ValidFDCell && FDCellRow != SDCellRow)
                        {
                            switch (SelectedDataFileFormatType)
                            {
                                case DataFileFormatType.ExaminedAudited:
                                    _Errors.Add(new ReadyToProceedError("DataFirstCell", "The Examined Cell and Audited Cell must be on the same row."));
                                    _Errors.Add(new ReadyToProceedError("DataSecondCell", ""));
                                    break;
                                case DataFileFormatType.AuditedDifference:
                                    _Errors.Add(new ReadyToProceedError("DataFirstCell", "The Audited Cell and Difference Cell must be on the same row."));
                                    _Errors.Add(new ReadyToProceedError("DataSecondCell", ""));
                                    break;
                                case DataFileFormatType.ExaminedDifference:
                                    _Errors.Add(new ReadyToProceedError("DataFirstCell", "The Examined Cell and Difference Cell must be on the same row."));
                                    _Errors.Add(new ReadyToProceedError("DataSecondCell", ""));
                                    break;
                            }
                            result = false;
                        }
                    }
                    catch (Exception)
                    {
                        //Invalid Cell Identifier
                        switch (SelectedDataFileFormatType)
                        {
                            case DataFileFormatType.ExaminedAudited:
                                _Errors.Add(new ReadyToProceedError("DataSecondCell", "Invalid Audited Cell"));
                                break;

                            case DataFileFormatType.AuditedDifference:
                            case DataFileFormatType.ExaminedDifference:
                                _Errors.Add(new ReadyToProceedError("DataSecondCell", "Invalid Difference Cell"));
                                break;
                        }
                        result = false;
                    }
                }
                worksheet = null;
                workbook.Close();
            }
            OnPropertyChanged("Errors");
            OnPropertyChanged("ErrorsWithText");
            return result;
        }

        //Process() - Loads data from the text, csv, dat, or excel files for the data selection,
        //            processes it, outputs it based on user selections, and navigates to the report view

        public void Process()
        {
            try
            {
                DS = new UnrestrictedVariableAppraisal();
                switch (DataFileSelectedFileType)
                {
                    case SupportedFileType.TXT:
                    case SupportedFileType.CSV:
                    case SupportedFileType.DAT:
                        ProcessTextFile();
                        break;
                    case SupportedFileType.EXCEL:
                        ProcessExcelFile();
                        break;
                }


                DS.CalculateGroupStats();

                DS.MyReportData.AuditTitle = _AuditReviewTitle;
                DS.MyReportData.DataFileInputPath = _DataFileInputPath;
                DS.MyReportData.UniverseSize = DS.UniverseSize;
                DS.MyReportData.SampleSize = DS.SampleSize;
                DS.MyReportData.SelectedDataFileFormatType = _SelectedDataFileFormatType;
                DS.MyReportData.ExaminedGroup = DS.ExaminedGroup;
                DS.MyReportData.AuditedGroup = DS.AuditedGroup;
                DS.MyReportData.DifferenceGroup = DS.DifferenceGroup;
                DS.MyReportData.LogTime = DateTime.Now;
                if (TextFileOutput)
                {
                    DS.MyReportData.TextFileOutput = true;
                    DS.MyReportData.TextFileOutputPath = TextFileOutputPath;
                    Unrestricted_TXT page = new Unrestricted_TXT(DS.MyReportData);
                    String pageContent = page.TransformText();
                    System.IO.File.WriteAllText(TextFileOutputPath, pageContent);
                }
                else
                {
                    DS.MyReportData.TextFileOutput = false;
                    DS.MyReportData.TextFileOutputPath = "";
                }


                var parameters = new NavigationParameters();
                parameters.Add("ReportData", DS.MyReportData);
                this.MyRegionManager.RequestNavigate("PrimaryPageRegion", "VariableAppraisals.UnrestrictedReportView", parameters);
            }
            catch(Exception Ex)
            {
                throw new Exception(Ex.Message, Ex);
            }

        }

        //Data File Spreadsheet Binding
        private List<string> _DataFileSpreadsheets = new List<string>();
        public List<string> DataFileSpreadsheets
        {
            get { return _DataFileSpreadsheets; }
            set { SetProperty(ref _DataFileSpreadsheets, value); }
        }

        //Data File Load Excel Sheet Binding
        public void DataFileLoadExcelSheets()
        {
            Excel.Workbook workbook = ExcelAppInterface.excelApp.Workbooks.Open(_DataFileInputPath, null, true);
            List<string> SpreadsheetList = new List<string>();
            foreach (Excel.Worksheet displayWorksheet in workbook.Worksheets)
            {
                SpreadsheetList.Add(displayWorksheet.Name);
            }
            DataFileSpreadsheets = SpreadsheetList;
            if (_DataFileSpreadsheets.Count > 0)
                SelectedDataSpreadsheet = _DataFileSpreadsheets[0];
            workbook.Close();
        }

        //Selected Data Spreadsheet Binding
        private string _SelectedDataSpreadsheet = "";
        public string SelectedDataSpreadsheet
        {
            get { return _SelectedDataSpreadsheet; }
            set { SetProperty(ref _SelectedDataSpreadsheet, value); }
        }

        //Second Data Cell Visible Binding
        private bool _SecondDataCellVisible = false;
        public bool SecondDataCellVisible
        {
            get { return _SecondDataCellVisible; }
            set { SetProperty(ref _SecondDataCellVisible, value); }
        }

        //Data First Cell Binding
        private string _DataFirstCell = "";
        public string DataFirstCell
        {
            get { return _DataFirstCell; }
            set { SetProperty(ref _DataFirstCell, value); }

        }

        //Data Second Cell Binding
        private string _DataSecondCell = "";
        public string DataSecondCell
        {
            get { return _DataSecondCell; }
            set { SetProperty(ref _DataSecondCell, value); }

        }

        //Data First Cell Text Binding
        private string _DataFirstCellText = "";
        public string DataFirstCellText
        {
            get { return _DataFirstCellText; }
            set { SetProperty(ref _DataFirstCellText, value); }
        }

        //Data Second Cell Text Binding
        private string _DataSecondCellText = "";
        public string DataSecondCellText
        {
            get { return _DataSecondCellText; }
            set { SetProperty(ref _DataSecondCellText, value); }
        }

        //ProcessExcelFile() - Reads data from an excel file and populates a unrestricted variable appraisal dataset with the individual data rows
        public void ProcessExcelFile()
        {
            //Open excel workbook specified by the user
            Excel.Workbook workbook = ExcelAppInterface.excelApp.Workbooks.Open(_DataFileInputPath, null, true);
            //Select the spreadsheet that the user specified
            Excel.Worksheet workSheet = workbook.Sheets[SelectedDataSpreadsheet];
            workSheet.Select(Type.Missing);
            //Create excel range objects
            Excel.Range DataFirstRange = workSheet.get_Range(DataFirstCell, System.Type.Missing);
            Excel.Range DataSecondRange = SecondDataCellVisible == true ? workSheet.get_Range(DataSecondCell, System.Type.Missing) : null;
            //Pull all the data from the spreadsheet
            Excel.Range excelRange = workSheet.UsedRange;
            object[,] valueArray = (object[,])excelRange.get_Value(Excel.XlRangeValueDataType.xlRangeValueDefault);
            
            DS.UniverseSize = _UniverseSize;
            int RowCount = 0;
            int SampleCount = 0;
            bool ExitFor = false;
            //Loop through the pulled rows
            for (int z = DataFirstRange.Row; z <= excelRange.Rows.Count; z++)
            {
                try
                {
                    //Create a new unrestricted variable appraisal data row object
                    UnrestrictedVariableAppraisalDataRow DR = new UnrestrictedVariableAppraisalDataRow();
                    string value;
                    //The selected data file format type determines how the excel file is processed
                    switch (SelectedDataFileFormatType)
                    {
                        case DataFileFormatType.Examined:
                            //Check if the cell value is null which would indicate an end of the data
                            if (valueArray[z, DataFirstRange.Column] == null)
                            {
                                ExitFor = true;
                                break;
                            }
                            value = valueArray[z, DataFirstRange.Column].ToString();
                            if (value == "$-")
                                value = "$0";
                            DR.ExaminedValue = double.Parse(value, System.Globalization.NumberStyles.Any);
                            DS.ExaminedGroup.Group_Sum += DR.ExaminedValue;
                            DS.ExaminedGroup.Group_Sqr += Math.Pow(DR.ExaminedValue, 2.0);
                            DS.ExaminedGroup.Group_Cube += Math.Pow(DR.ExaminedValue, 3.0);
                            DS.ExaminedGroup.Group_Quad += Math.Pow(DR.ExaminedValue, 4.0);
                            if (DR.ExaminedValue != 0)
                                DS.ExaminedGroup.Group_NonZero++;
                            break;
                        case DataFileFormatType.Audited:
                            //Check if the cell value is null which would indicate an end of the data
                            if (valueArray[z, DataFirstRange.Column] == null)
                            {
                                ExitFor = true;
                                break;
                            }
                            value = valueArray[z, DataFirstRange.Column].ToString();
                            if (value == "$-")
                                value = "$0";
                            DR.AuditedValue = double.Parse(value, System.Globalization.NumberStyles.Any);
                            DS.AuditedGroup.Group_Sum += DR.AuditedValue;
                            DS.AuditedGroup.Group_Sqr += Math.Pow(DR.AuditedValue, 2.0);
                            DS.AuditedGroup.Group_Cube += Math.Pow(DR.AuditedValue, 3.0);
                            DS.AuditedGroup.Group_Quad += Math.Pow(DR.AuditedValue, 4.0);
                            if (DR.AuditedValue != 0)
                                DS.AuditedGroup.Group_NonZero++;
                            break;
                        case DataFileFormatType.Difference:
                            //Check if the cell value is null which would indicate an end of the data
                            if (valueArray[z, DataFirstRange.Column] == null)
                            {
                                ExitFor = true;
                                break;
                            }
                            value = valueArray[z, DataFirstRange.Column].ToString();
                            if (value == "$-")
                                value = "$0";
                            DR.DifferenceValue = double.Parse(value, System.Globalization.NumberStyles.Any);
                            DS.DifferenceGroup.Group_Sum += DR.DifferenceValue;
                            DS.DifferenceGroup.Group_Sqr += Math.Pow(DR.DifferenceValue, 2.0);
                            DS.DifferenceGroup.Group_Cube += Math.Pow(DR.DifferenceValue, 3.0);
                            DS.DifferenceGroup.Group_Quad += Math.Pow(DR.DifferenceValue, 4.0);
                            if (DR.DifferenceValue != 0)
                                DS.DifferenceGroup.Group_NonZero++;
                            break;
                        case DataFileFormatType.ExaminedAudited:
                            //Check if the cell value is null which would indicate an end of the data
                            if (valueArray[z, DataFirstRange.Column] == null)
                            {
                                ExitFor = true;
                                break;
                            }
                            value = valueArray[z, DataFirstRange.Column].ToString();
                            if (value == "$-")
                                value = "$0";
                            DR.ExaminedValue = double.Parse(value, System.Globalization.NumberStyles.Any);
                            DS.ExaminedGroup.Group_Sum += DR.ExaminedValue;
                            DS.ExaminedGroup.Group_Sqr += Math.Pow(DR.ExaminedValue, 2.0);
                            DS.ExaminedGroup.Group_Cube += Math.Pow(DR.ExaminedValue, 3.0);
                            DS.ExaminedGroup.Group_Quad += Math.Pow(DR.ExaminedValue, 4.0);
                            if (DR.ExaminedValue != 0)
                                DS.ExaminedGroup.Group_NonZero++;
                            if (valueArray[z, DataSecondRange.Column] == null)
                            {
                                throw new FormatException();
                            }
                            value = valueArray[z, DataSecondRange.Column].ToString();
                            if (value == "$-")
                                value = "$0";
                            DR.AuditedValue = double.Parse(value, System.Globalization.NumberStyles.Any);
                            DS.AuditedGroup.Group_Sum += DR.AuditedValue;
                            DS.AuditedGroup.Group_Sqr += Math.Pow(DR.AuditedValue, 2.0);
                            DS.AuditedGroup.Group_Cube += Math.Pow(DR.AuditedValue, 3.0);
                            DS.AuditedGroup.Group_Quad += Math.Pow(DR.AuditedValue, 4.0);
                            if (DR.AuditedValue != 0)
                                DS.AuditedGroup.Group_NonZero++;
                            DR.DifferenceValue = DR.ExaminedValue - DR.AuditedValue;
                            DS.DifferenceGroup.Group_Sum += DR.DifferenceValue;
                            DS.DifferenceGroup.Group_Sqr += Math.Pow(DR.DifferenceValue, 2.0);
                            DS.DifferenceGroup.Group_Cube += Math.Pow(DR.DifferenceValue, 3.0);
                            DS.DifferenceGroup.Group_Quad += Math.Pow(DR.DifferenceValue, 4.0);
                            if (DR.DifferenceValue != 0)
                                DS.DifferenceGroup.Group_NonZero++;
                            break;
                        case DataFileFormatType.ExaminedDifference:
                            if (valueArray[z, DataFirstRange.Column] == null)
                            {
                                ExitFor = true;
                                break;
                            }
                            value = valueArray[z, DataFirstRange.Column].ToString();
                            if (value == "$-")
                                value = "$0";
                            DR.ExaminedValue = double.Parse(value, System.Globalization.NumberStyles.Any);
                            DS.ExaminedGroup.Group_Sum += DR.ExaminedValue;
                            DS.ExaminedGroup.Group_Sqr += Math.Pow(DR.ExaminedValue, 2.0);
                            DS.ExaminedGroup.Group_Cube += Math.Pow(DR.ExaminedValue, 3.0);
                            DS.ExaminedGroup.Group_Quad += Math.Pow(DR.ExaminedValue, 4.0);
                            if (DR.ExaminedValue != 0)
                                DS.ExaminedGroup.Group_NonZero++;
                            if (valueArray[z, DataSecondRange.Column] == null)
                            {
                                throw new FormatException();
                            }
                            value = valueArray[z, DataSecondRange.Column].ToString();
                            if (value == "$-")
                                value = "$0";
                            DR.DifferenceValue = double.Parse(value, System.Globalization.NumberStyles.Any);
                            DS.DifferenceGroup.Group_Sum += DR.DifferenceValue;
                            DS.DifferenceGroup.Group_Sqr += Math.Pow(DR.DifferenceValue, 2.0);
                            DS.DifferenceGroup.Group_Cube += Math.Pow(DR.DifferenceValue, 3.0);
                            DS.DifferenceGroup.Group_Quad += Math.Pow(DR.DifferenceValue, 4.0);
                            if (DR.DifferenceValue != 0)
                                DS.DifferenceGroup.Group_NonZero++;
                            DR.AuditedValue = DR.ExaminedValue - DR.DifferenceValue;
                            DS.AuditedGroup.Group_Sum += DR.AuditedValue;
                            DS.AuditedGroup.Group_Sqr += Math.Pow(DR.AuditedValue, 2.0);
                            DS.AuditedGroup.Group_Cube += Math.Pow(DR.AuditedValue, 3.0);
                            DS.AuditedGroup.Group_Quad += Math.Pow(DR.AuditedValue, 4.0);
                            if (DR.AuditedValue != 0)
                                DS.AuditedGroup.Group_NonZero++;
                            break;
                        case DataFileFormatType.AuditedDifference:
                            if (valueArray[z, DataFirstRange.Column] == null)
                            {
                                ExitFor = true;
                                break;
                            }
                            value = valueArray[z, DataFirstRange.Column].ToString();
                            if (value == "$-")
                                value = "$0";
                            DR.AuditedValue = double.Parse(value, System.Globalization.NumberStyles.Any);
                            DS.AuditedGroup.Group_Sum += DR.AuditedValue;
                            DS.AuditedGroup.Group_Sqr += Math.Pow(DR.AuditedValue, 2.0);
                            DS.AuditedGroup.Group_Cube += Math.Pow(DR.AuditedValue, 3.0);
                            DS.AuditedGroup.Group_Quad += Math.Pow(DR.AuditedValue, 4.0);
                            if (DR.AuditedValue != 0)
                                DS.AuditedGroup.Group_NonZero++;
                            if (valueArray[z, DataSecondRange.Column] == null)
                            {
                                throw new FormatException();
                            }
                            value = valueArray[z, DataSecondRange.Column].ToString();
                            if (value == "$-")
                                value = "$0";
                            DR.DifferenceValue = double.Parse(value, System.Globalization.NumberStyles.Any);
                            DS.DifferenceGroup.Group_Sum += DR.DifferenceValue;
                            DS.DifferenceGroup.Group_Sqr += Math.Pow(DR.DifferenceValue, 2.0);
                            DS.DifferenceGroup.Group_Cube += Math.Pow(DR.DifferenceValue, 3.0);
                            DS.DifferenceGroup.Group_Quad += Math.Pow(DR.DifferenceValue, 4.0);
                            if (DR.DifferenceValue != 0)
                                DS.DifferenceGroup.Group_NonZero++;
                            DR.ExaminedValue = DR.AuditedValue + DR.DifferenceValue;
                            DS.ExaminedGroup.Group_Sum += DR.ExaminedValue;
                            DS.ExaminedGroup.Group_Sqr += Math.Pow(DR.ExaminedValue, 2.0);
                            DS.ExaminedGroup.Group_Cube += Math.Pow(DR.ExaminedValue, 3.0);
                            DS.ExaminedGroup.Group_Quad += Math.Pow(DR.ExaminedValue, 4.0);
                            if (DR.ExaminedValue != 0)
                                DS.ExaminedGroup.Group_NonZero++;
                            break;
                    }
                    if (ExitFor)
                        break;
                    DS.DataRows.Add(DR);

                }
                catch (FormatException)
                {
                    workbook.Close();
                    throw new Exception("Invalid Number in Row " + z + " of the data file. Correct the issue and try processing the data file again.");
                }
                catch (IndexOutOfRangeException)
                {
                    workbook.Close();
                    throw new Exception("Missing Data in Row " + z + " of the data file. Correct the issue and try processing the data file again.");
                }
                catch (Exception ex)
                {
                    workbook.Close();
                    throw new Exception(ex.Message);
                }
                if (!IncludeAllSampleRecords && SampleSize == SampleCount)
                {
                    break;
                }
                RowCount++;
                SampleCount++;
                if (z == _SampleSize)
                    break;
            }
            DS.SampleSize = RowCount;
            if (DS.SampleSize > 10000)
            {
                throw new Exception("Sample sizes in excess of 10,000 are not allowed.");
            }
            if (DS.SampleSize > DS.UniverseSize)
            {
                throw new Exception("Your sample size exceeds the universe size.");
            }
            if (!IncludeAllSampleRecords && SampleSize > SampleCount)
            {
                throw new Exception("Your requested sample size (" + SampleSize.ToString() + " Rows) exceeds the sample size in the file (" + SampleCount.ToString() + " Rows).");
            }
            workbook.Close();
        }

        //ProcessTextFile() - Reads data from a text file and populates a unrestricted variable appraisal dataset with the individual data rows
        public void ProcessTextFile()
        {
            DS.UniverseSize = _UniverseSize;
            //Load the user specified text file into the text parser object
            TextFieldParser TFP = new TextFieldParser(_DataFileInputPath);
            TFP.TextFieldType = FieldType.Delimited;
            if(DataFileSelectedFileType == SupportedFileType.CSV)
                TFP.Delimiters = new string[] { "," };
            else
                TFP.Delimiters = new string[] { " ", "\t" };

            string[] Fields;
            int RowIndex = 1;
            int SampleCount = 0;
            int ColumnIndex = _FirstColumnHasRowID == true ? 1 : 0;
            //Loop through the rows in the file
            while (!TFP.EndOfData)
            {
                try
                {
                    TFP.TrimWhiteSpace = true;
                    //Get all the fields in the row
                    Fields = TFP.ReadFields();
                    //Remove Any Empty Fields
                    Fields = Fields.Where(a => a != "").ToArray();
                    if (RowIndex > 1 || !_DataFileHasHeaders)
                    {
                            string value;
                            UnrestrictedVariableAppraisalDataRow DR = new UnrestrictedVariableAppraisalDataRow();
                            //The selected data file format type determines how the file is processed
                            switch (SelectedDataFileFormatType)
                            {
                                case DataFileFormatType.Examined:
                                    value = Fields[ColumnIndex];
                                    if (value == "$-")
                                        value = "$0";
                                    DR.ExaminedValue = double.Parse(value, System.Globalization.NumberStyles.Any);
                                    DS.ExaminedGroup.Group_Sum += DR.ExaminedValue;
                                    DS.ExaminedGroup.Group_Sqr += Math.Pow(DR.ExaminedValue, 2.0);
                                    DS.ExaminedGroup.Group_Cube += Math.Pow(DR.ExaminedValue, 3.0);
                                    DS.ExaminedGroup.Group_Quad += Math.Pow(DR.ExaminedValue, 4.0);
                                    if (DR.ExaminedValue != 0)
                                        DS.ExaminedGroup.Group_NonZero++;
                                    break;
                                case DataFileFormatType.Audited:
                                    value = Fields[ColumnIndex];
                                    if (value == "$-")
                                        value = "$0";
                                    DR.AuditedValue = double.Parse(value, System.Globalization.NumberStyles.Any);
                                    DS.AuditedGroup.Group_Sum += DR.AuditedValue;
                                    DS.AuditedGroup.Group_Sqr += Math.Pow(DR.AuditedValue, 2.0);
                                    DS.AuditedGroup.Group_Cube += Math.Pow(DR.AuditedValue, 3.0);
                                    DS.AuditedGroup.Group_Quad += Math.Pow(DR.AuditedValue, 4.0);
                                    if (DR.AuditedValue != 0)
                                        DS.AuditedGroup.Group_NonZero++;
                                    break;
                                case DataFileFormatType.Difference:
                                    value = Fields[ColumnIndex];
                                    if (value == "$-")
                                        value = "$0";
                                    DR.DifferenceValue = double.Parse(value, System.Globalization.NumberStyles.Any);
                                    DS.DifferenceGroup.Group_Sum += DR.DifferenceValue;
                                    DS.DifferenceGroup.Group_Sqr += Math.Pow(DR.DifferenceValue, 2.0);
                                    DS.DifferenceGroup.Group_Cube += Math.Pow(DR.DifferenceValue, 3.0);
                                    DS.DifferenceGroup.Group_Quad += Math.Pow(DR.DifferenceValue, 4.0);
                                    if (DR.DifferenceValue != 0)
                                        DS.DifferenceGroup.Group_NonZero++;
                                    break;
                                case DataFileFormatType.ExaminedAudited:
                                    value = Fields[ColumnIndex];
                                    if (value == "$-")
                                        value = "$0";
                                    DR.ExaminedValue = double.Parse(value, System.Globalization.NumberStyles.Any);
                                    DS.ExaminedGroup.Group_Sum += DR.ExaminedValue;
                                    DS.ExaminedGroup.Group_Sqr += Math.Pow(DR.ExaminedValue, 2.0);
                                    DS.ExaminedGroup.Group_Cube += Math.Pow(DR.ExaminedValue, 3.0);
                                    DS.ExaminedGroup.Group_Quad += Math.Pow(DR.ExaminedValue, 4.0);
                                    if (DR.ExaminedValue != 0)
                                        DS.ExaminedGroup.Group_NonZero++;
                                    value = Fields[ColumnIndex + 1];
                                    if (value == "$-")
                                        value = "$0";
                                    DR.AuditedValue = double.Parse(value, System.Globalization.NumberStyles.Any);
                                    DS.AuditedGroup.Group_Sum += DR.AuditedValue;
                                    DS.AuditedGroup.Group_Sqr += Math.Pow(DR.AuditedValue, 2.0);
                                    DS.AuditedGroup.Group_Cube += Math.Pow(DR.AuditedValue, 3.0);
                                    DS.AuditedGroup.Group_Quad += Math.Pow(DR.AuditedValue, 4.0);
                                    if (DR.AuditedValue != 0)
                                        DS.AuditedGroup.Group_NonZero++;
                                    DR.DifferenceValue = DR.ExaminedValue - DR.AuditedValue;
                                    DS.DifferenceGroup.Group_Sum += DR.DifferenceValue;
                                    DS.DifferenceGroup.Group_Sqr += Math.Pow(DR.DifferenceValue, 2.0);
                                    DS.DifferenceGroup.Group_Cube += Math.Pow(DR.DifferenceValue, 3.0);
                                    DS.DifferenceGroup.Group_Quad += Math.Pow(DR.DifferenceValue, 4.0);
                                    if (DR.DifferenceValue != 0)
                                        DS.DifferenceGroup.Group_NonZero++;
                                    break;
                                case DataFileFormatType.ExaminedDifference:
                                    value = Fields[ColumnIndex];
                                    if (value == "$-")
                                        value = "$0";
                                    DR.ExaminedValue = double.Parse(value, System.Globalization.NumberStyles.Any);
                                    DS.ExaminedGroup.Group_Sum += DR.ExaminedValue;
                                    DS.ExaminedGroup.Group_Sqr += Math.Pow(DR.ExaminedValue, 2.0);
                                    DS.ExaminedGroup.Group_Cube += Math.Pow(DR.ExaminedValue, 3.0);
                                    DS.ExaminedGroup.Group_Quad += Math.Pow(DR.ExaminedValue, 4.0);
                                    if (DR.ExaminedValue != 0)
                                        DS.ExaminedGroup.Group_NonZero++;
                                    value = Fields[ColumnIndex + 1];
                                    if (value == "$-")
                                        value = "$0";
                                    DR.DifferenceValue = double.Parse(value, System.Globalization.NumberStyles.Any);
                                    DS.DifferenceGroup.Group_Sum += DR.DifferenceValue;
                                    DS.DifferenceGroup.Group_Sqr += Math.Pow(DR.DifferenceValue, 2.0);
                                    DS.DifferenceGroup.Group_Cube += Math.Pow(DR.DifferenceValue, 3.0);
                                    DS.DifferenceGroup.Group_Quad += Math.Pow(DR.DifferenceValue, 4.0);
                                    if (DR.DifferenceValue != 0)
                                        DS.DifferenceGroup.Group_NonZero++;
                                    DR.AuditedValue = DR.ExaminedValue - DR.DifferenceValue;
                                    DS.AuditedGroup.Group_Sum += DR.AuditedValue;
                                    DS.AuditedGroup.Group_Sqr += Math.Pow(DR.AuditedValue, 2.0);
                                    DS.AuditedGroup.Group_Cube += Math.Pow(DR.AuditedValue, 3.0);
                                    DS.AuditedGroup.Group_Quad += Math.Pow(DR.AuditedValue, 4.0);
                                    if (DR.AuditedValue != 0)
                                        DS.AuditedGroup.Group_NonZero++;
                                    break;
                                case DataFileFormatType.AuditedDifference:
                                    value = Fields[ColumnIndex];
                                    if (value == "$-")
                                        value = "$0";
                                    DR.AuditedValue = double.Parse(value, System.Globalization.NumberStyles.Any);
                                    DS.AuditedGroup.Group_Sum += DR.AuditedValue;
                                    DS.AuditedGroup.Group_Sqr += Math.Pow(DR.AuditedValue, 2.0);
                                    DS.AuditedGroup.Group_Cube += Math.Pow(DR.AuditedValue, 3.0);
                                    DS.AuditedGroup.Group_Quad += Math.Pow(DR.AuditedValue, 4.0);
                                    if (DR.AuditedValue != 0)
                                        DS.AuditedGroup.Group_NonZero++;
                                    value = Fields[ColumnIndex + 1];
                                    if (value == "$-")
                                        value = "$0";
                                    DR.DifferenceValue = double.Parse(value, System.Globalization.NumberStyles.Any);
                                    DS.DifferenceGroup.Group_Sum += DR.DifferenceValue;
                                    DS.DifferenceGroup.Group_Sqr += Math.Pow(DR.DifferenceValue, 2.0);
                                    DS.DifferenceGroup.Group_Cube += Math.Pow(DR.DifferenceValue, 3.0);
                                    DS.DifferenceGroup.Group_Quad += Math.Pow(DR.DifferenceValue, 4.0);
                                    if (DR.DifferenceValue != 0)
                                        DS.DifferenceGroup.Group_NonZero++;
                                    DR.ExaminedValue = DR.AuditedValue + DR.DifferenceValue;
                                    DS.ExaminedGroup.Group_Sum += DR.ExaminedValue;
                                    DS.ExaminedGroup.Group_Sqr += Math.Pow(DR.ExaminedValue, 2.0);
                                    DS.ExaminedGroup.Group_Cube += Math.Pow(DR.ExaminedValue, 3.0);
                                    DS.ExaminedGroup.Group_Quad += Math.Pow(DR.ExaminedValue, 4.0);
                                    if (DR.ExaminedValue != 0)
                                        DS.ExaminedGroup.Group_NonZero++;
                                    break;
                            }
                        //Add data row object to the dataset data rows object
                            DS.DataRows.Add(DR);
                           
                    }
                    if(!IncludeAllSampleRecords && SampleSize == SampleCount)
                    {
                        break;
                    }
                    if (RowIndex > 1 || !_DataFileHasHeaders)
                        SampleCount++;
                    RowIndex++;
                }
                catch (FormatException)
                {
                    throw new Exception("Invalid Number in Row " + RowIndex + " of the data file. Correct the issue and try processing the data file again.");
                }
                catch (IndexOutOfRangeException)
                {
                    throw new Exception("Missing Data in Row " + RowIndex + " of the data file. Correct the issue and try processing the data file again.");
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }

            }
            DS.SampleSize = _DataFileHasHeaders != true ? RowIndex - 1 : RowIndex - 2;
            if (DS.SampleSize > 10000)
            {
                throw new Exception("Sample sizes in excess of 10,000 are not allowed.");
            }
            if (DS.SampleSize > DS.UniverseSize)
            {
                throw new Exception("Your sample size exceeds the universe size.");
            }
            if (!IncludeAllSampleRecords && SampleSize > SampleCount)
            {
                throw new Exception("Your requested sample size (" + SampleSize.ToString() + " Rows) exceeds the sample size in the file (" + SampleCount.ToString() + " Rows).");
            }


            return;
        }
    }
}
