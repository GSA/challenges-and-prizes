﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using RatStatsChallenge.Module.Infastructure;
using RatStatsChallenge.Module.Interface.ViewModels.VariableAppraisals;
namespace RatStatsChallenge.Module.Interface.Views.VariableAppraisals
{
    /// <summary>
    /// Interaction logic for UnrestrictedView.xaml
    /// </summary>
    public partial class UnrestrictedView : UserControl
    {
        public UnrestrictedView(UnrestrictedViewModel viewModel)
        {
            //Set the view model as the view's data context
            this.DataContext = viewModel;
            InitializeComponent();
        }

        private void Clear_Fields_Button_Click(object sender, RoutedEventArgs e)
        {
            ClearFields();
        }

        private void Cancel_Button_Click(object sender, RoutedEventArgs e)
        {
            ClearFields();
            ((UnrestrictedViewModel)this.DataContext).GoHome();
        }

        //ClearFields() - removes validation errors from the controls and resets the binding values in the view model to their defaults
        private void ClearFields()
        {
            UniverseSizeTextBox.Text = "0";
            Validation.ClearInvalid(UniverseSizeTextBox.GetBindingExpression(TextBox.TextProperty));   
            //Reset Error Indicators
            UniverseSizeTextBox.ClearValue(TextBox.BorderBrushProperty);
            UniverseSizeTextBox.BorderThickness = new Thickness(1);
            SampleSizeTextBox.Text = "0";
            SampleSizeTextBox.ClearValue(TextBox.BorderBrushProperty);
            SampleSizeTextBox.BorderThickness = new Thickness(1);
            DataFileFormatBorder.BorderBrush = Brushes.Gray;
            DataFileFormatBorder.BorderThickness = new Thickness(1);
            DataFileInputPathTextBox.ClearValue(TextBox.BorderBrushProperty);
            DataFileInputPathTextBox.BorderThickness = new Thickness(1);
            ((UnrestrictedViewModel)this.DataContext).ResetFields();
        }

        //Process_Button_Click() - Checks for validation errors at the view layer and then the view model layer. If no issues are found then the data processing is run.
        private void Process_Button_Click(object sender, RoutedEventArgs e)
        {
            if (Validation.GetErrors(UniverseSizeTextBox).Count > 0)
                return;
            //Clear Control Error Indicators
            UniverseSizeTextBox.ClearValue(TextBox.BorderBrushProperty);
            UniverseSizeTextBox.BorderThickness = new Thickness(1);
            SampleSizeTextBox.ClearValue(TextBox.BorderBrushProperty);
            SampleSizeTextBox.BorderThickness = new Thickness(1);
            DataFileFormatBorder.BorderBrush = Brushes.Gray;
            DataFileFormatBorder.BorderThickness = new Thickness(1);
            DataFileInputPathTextBox.ClearValue(TextBox.BorderBrushProperty);
            DataFileInputPathTextBox.BorderThickness = new Thickness(1);
            DataFirstCellTextBox.ClearValue(TextBox.BorderBrushProperty);
            DataFirstCellTextBox.BorderThickness = new Thickness(1);
            DataSecondCellTextBox.ClearValue(TextBox.BorderBrushProperty);
            DataSecondCellTextBox.BorderThickness = new Thickness(1);
            //Check for ViewModel Errors
            bool result = ((UnrestrictedViewModel)this.DataContext).ReadyToProceed();
            if(!result)
            {
                //View Model Errors were found so set visual error indicators
                foreach (ReadyToProceedError BR in ((UnrestrictedViewModel)this.DataContext).Errors)
                {
                    switch (BR.BindingName)
                    {
                        case "Universe":
                            UniverseSizeTextBox.BorderBrush = Brushes.Red;
                            UniverseSizeTextBox.BorderThickness = new Thickness(2);
                            break;
                        case "SampleSize":
                            SampleSizeTextBox.BorderBrush = Brushes.Red;
                            SampleSizeTextBox.BorderThickness = new Thickness(2);
                            break;
                        case "SelectedDataFileFormatType":
                            DataFileFormatBorder.BorderBrush = Brushes.Red;
                            DataFileFormatBorder.BorderThickness = new Thickness(2);
                            break;
                        case "DataFileInputPath":
                            DataFileInputPathTextBox.BorderBrush = Brushes.Red;
                            DataFileInputPathTextBox.BorderThickness = new Thickness(2);
                            break;
                        case "DataFirstCell":
                            DataFirstCellTextBox.BorderBrush = Brushes.Red;
                            DataFirstCellTextBox.BorderThickness = new Thickness(2);
                            break;
                        case "DataSecondCell":
                            DataSecondCellTextBox.BorderBrush = Brushes.Red;
                            DataSecondCellTextBox.BorderThickness = new Thickness(2);
                            break;
                    }
                }
            }
            else
            {
                try
                {
                    this.Cursor = Cursors.Wait;
                    ((UnrestrictedViewModel)this.DataContext).Process();
                    this.Cursor = Cursors.Arrow;

                }
                catch(Exception ex)
                {
                    this.Cursor = Cursors.Arrow;
                    MessageBox.Show(ex.Message,"Processing Data File Error");
                }
                
                return;
            }
        }
    }
}
