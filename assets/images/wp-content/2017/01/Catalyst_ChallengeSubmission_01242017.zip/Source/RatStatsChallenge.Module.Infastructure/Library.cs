﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RatStatsChallenge.Module.Infastructure.Enums;
using System.Windows.Forms.DataVisualization.Charting;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;

namespace RatStatsChallenge.Module.Infastructure
{

    /*****************************************************************************************************
    *   ExcelAppInterface
    *   - Provides a global Interop Excel App object. A single instance of excel is used throughout the app
    *   to provide all spreadsheet support vs. launching excel processes on demand when the user interacts with
    *   the interface.
    *
    ******************************************************************************************************/
    public class ExcelAppInterface
    {
        public static Microsoft.Office.Interop.Excel.Application excelApp = new Excel.Application();
    }

    /*****************************************************************************************************
    *   ReadyToProceedResult
    *   - This class is returned to a View by its View Model. It provides support for the View to determine if
    *   the data validation checks in the View Model layer passed successfully or errors were found
    *
    ******************************************************************************************************/

    public class ReadyToProceedResult
    {
        public bool IsReady = false;
        //List of detailed errors from the View Model
        public List<ReadyToProceedError> Errors = new List<ReadyToProceedError>();
    }

    /*****************************************************************************************************
    *   ReadyToProceedError
    *   - This class is returned to a View by its View Model if an error was found in the data validation check
    *   at the View Model layer. 
    *
    ******************************************************************************************************/
    public class ReadyToProceedError
    {  
        public ReadyToProceedError(string BindingName,string ErrorContent)
        {
            this._BindingName = BindingName;
            this._ErrorContent = ErrorContent;
        }

        //The binding of the control that has the error. The View layer will use this to determine
        //which control on the interface should be highlighted
        private string _BindingName = "";
        public string BindingName
        {
            get { return _BindingName; }
        }

        //Detailed description of the error. The View layer will use this to populate the "Fix the Following Error(s)"  
        private string _ErrorContent = "";
        public string ErrorContent
        {
            get { return _ErrorContent; }
        }
        
        //Added to support screen readers for Section 508 support. 
        public override string ToString()
        {
            return "Fix the following error. " + _ErrorContent;
        }

    }

    /*****************************************************************************************************
    *   RandomSample
    *   - Contains classes for supporting the Random Number Single Stage view model, providing data to Single Stage Report view and TT report generator.
    *
    ******************************************************************************************************/
    public class RandomSample
    {
        //Container for report data. This is passed to the Single Stage Report View and also the TT Report Generators
        public class ReportData
        {
            public RandomSample.RatStatRandomNumber[] SequentialArray;
            public RandomSample.RatStatRandomNumber[] SpareArray;
            public long SummedValues;
            public string AuditTitle;
            public double SeedNumber;
            public int FrameSize;
            public int Total;
            public DateTime LogTime;

            public bool TextFileOutput = false;
            public string TextFileOutputPath;
            public bool CSVFileOutput = false;
            public bool ExcelFileOutput = false;
            public string CSVFileOutputPath;
            public string ExcelFileOutputPath;
        }
        //Container for a random number
        public class RatStatRandomNumber
        {
            public int SelectionOrder;
            public int Value;

            public RatStatRandomNumber(int SelectionOrder, int Value)
            {
                this.SelectionOrder = SelectionOrder;
                this.Value = Value;
            }

        }
        //Container for a seed
        public class RatStatSeed
        {
            public long TrackingSeed;
            public double ExcelOutput;
            public double ResultSeed;
        }
        //CalculateSeed implements the calculations described in the detailed Specification: Seed Generation Steps 6 - 15
        public static RatStatSeed CalculateSeed(long TrackingSeed, double multiplier)
        {
            RatStatSeed RSS = new RatStatSeed();
            long test_64;
            double result;
            do
            {
                test_64 = TrackingSeed;
                test_64 *= 1140671485;
                test_64 += 12820163;
                TrackingSeed = test_64 % 16777216;
                result = (multiplier * (TrackingSeed / 16777216.0)) + 1.0;
            } while (result >= multiplier);
            RSS.TrackingSeed = TrackingSeed;
            RSS.ResultSeed = result;
            return RSS;
        }
    }

    /*****************************************************************************************************
    *   UnrestrictedAttributeAppraisal
    *   - Contains classes for supporting the Attribute Appraisals Unrestricted view model, providing data to the Unrestricted report view and TT report generator.
    *
    ******************************************************************************************************/
    public class UnrestrictedAttributeAppraisal
    {
        //Container for report data. This is passed to the Unrestricted Report View and also the TT Report Generators
        public class ReportData
        {
            public string AuditTitle;
            public int UniverseSize;
            public int SampleSize;
            public int CI_QuantityIdentified;
            public double CI_ProjectedQuantity;
            public double CI_Percent;
            public double SE_ProjectedQuantity;
            public double SE_Percent;
            public double CustomConfidenceLevel;
            public ConfidenceIntervalType UserSelectedConfidenceIntervalType = ConfidenceIntervalType.Unknown;
            public ConfidenceLevelType UserSelectedConfidenceLevelType = ConfidenceLevelType.Default;
            public ConfidenceInterval EightyPercent_ConfidenceInterval = new ConfidenceInterval();
            public ConfidenceInterval NinetyPercent_ConfidenceInterval = new ConfidenceInterval();
            public ConfidenceInterval NinetyFivePercent_ConfidenceInterval = new ConfidenceInterval();
            public ConfidenceInterval CustomPercent_ConfidenceInterval = new ConfidenceInterval();

            public bool TextFileOutput = false;
            public string TextFileOutputPath;
            public DateTime LogTime;
        }

        public class ConfidenceInterval
        {
            public double? LowerLimitQuantity;
            public double? LowerLimitPercent;
            public double? UpperLimitQuantity;
            public double? UpperLimitPercent;
        }

    }

    /*****************************************************************************************************
    *   UnrestrictedVariableAppraisalGroupData
    *   - Container for group data associated with Unrestricted Variable Appraisals
    *
    ******************************************************************************************************/
    public class UnrestrictedVariableAppraisalGroupData
    {
        public double Group_Sum { get; set; }
        public double Group_Sqr { get; set; }
        public double Group_Cube { get; set; }
        public double Group_Quad { get; set; }
        public int Group_NonZero { get; set; }
        public double Group_Mean { get; set; }
        public double Group_AvgMean { get; set; }
        public double Group_PointEstimate { get; set; }
        public double Group_StandardDeviation { get; set; }
        public double Group_StandardError { get; set; }
        public double Group_SkewAmt { get; set; }
        public double Group_KurtAmt { get; set; }

        public UnrestrictedVariableAppraisalConfidenceLimit EightyPercent_Confidence = new UnrestrictedVariableAppraisalConfidenceLimit();
        public UnrestrictedVariableAppraisalConfidenceLimit NinetyPercent_Confidence = new UnrestrictedVariableAppraisalConfidenceLimit();
        public UnrestrictedVariableAppraisalConfidenceLimit NinetyFivePercent_Confidence = new UnrestrictedVariableAppraisalConfidenceLimit();
    }
    /*****************************************************************************************************
    *   UnrestrictedVariableAppraisalConfidenceLimit
    *   - Container for confidence limit data
    *
    ******************************************************************************************************/
    public class UnrestrictedVariableAppraisalConfidenceLimit
    {
        public double LowerLimit { get; set; }
        public double UpperLimit { get; set; }
        public double PrecisionAmount { get; set; }
        public double PrecisionPercent { get; set; }
        public double T_Value { get; set; }
    }

    /*****************************************************************************************************
    *   UnrestrictedVariableAppraisalDataRow
    *   - Container for data associated with a single row of Unrestricted Variable Appraisal Data
    *
    ******************************************************************************************************/
    public class UnrestrictedVariableAppraisalDataRow
    {
        public double ExaminedValue { get; set; }
        public double AuditedValue { get; set; }
        public double DifferenceValue { get; set; }
    }

    /*****************************************************************************************************
     *   UnrestrictedVariableAppraisal
     *   - Contains a class for supporting the Variable Appraisals Unrestricted view model, providing data to the Unrestricted report view and TT report generator.
     *
     ******************************************************************************************************/
    public class UnrestrictedVariableAppraisal : VariableAppraisalDataSet
    {
        public ReportData MyReportData = new ReportData();
        public class ReportData
        {
            public string AuditTitle = "";
            public long UniverseSize = 0;
            public int SampleSize = 0;
            public string DataFileInputPath = "";
            public DataFileFormatType SelectedDataFileFormatType = DataFileFormatType.Unknown;
            public bool TextFileOutput = false;
            public string TextFileOutputPath;
            public DateTime LogTime;
            public UnrestrictedVariableAppraisalGroupData ExaminedGroup = new UnrestrictedVariableAppraisalGroupData();
            public UnrestrictedVariableAppraisalGroupData AuditedGroup = new UnrestrictedVariableAppraisalGroupData();
            public UnrestrictedVariableAppraisalGroupData DifferenceGroup = new UnrestrictedVariableAppraisalGroupData();
        }
    }

    /*****************************************************************************************************
     *   VariableAppraisalDataSet
     *   - Container for all of the data rows, group data, sample size, universe size, etc associated with
     *     a Variable Appraisal.
     *
     ******************************************************************************************************/
    public class VariableAppraisalDataSet
    {
        public List<UnrestrictedVariableAppraisalDataRow> DataRows = new List<UnrestrictedVariableAppraisalDataRow>();
        //Group Data
        public UnrestrictedVariableAppraisalGroupData ExaminedGroup = new UnrestrictedVariableAppraisalGroupData();
        public UnrestrictedVariableAppraisalGroupData AuditedGroup = new UnrestrictedVariableAppraisalGroupData();
        public UnrestrictedVariableAppraisalGroupData DifferenceGroup = new UnrestrictedVariableAppraisalGroupData();

        //Sample Size
        public int SampleSize { get; set; }
        //Universe Size
        public long UniverseSize { get; set; }
        public double CorrectionFactor { get; set; }
        public int DegreesOfFreedom { get; set; }

        public void CalculateGroupStats()
        {
            double dbl_SampleSize = (double)SampleSize;
            //CALCULATE MEANS
            if (SampleSize > 0)
            {
                if (ExaminedGroup.Group_NonZero > 0)
                    ExaminedGroup.Group_Mean = ExaminedGroup.Group_Sum / dbl_SampleSize;
                if (AuditedGroup.Group_NonZero > 0)
                    AuditedGroup.Group_Mean = AuditedGroup.Group_Sum / dbl_SampleSize;
                if (DifferenceGroup.Group_NonZero > 0)
                    DifferenceGroup.Group_Mean = DifferenceGroup.Group_Sum / dbl_SampleSize;
            }
            //CALCULATE POINT ESTIMATES
            ExaminedGroup.Group_PointEstimate = ExaminedGroup.Group_Mean * UniverseSize;
            AuditedGroup.Group_PointEstimate = AuditedGroup.Group_Mean * UniverseSize;
            DifferenceGroup.Group_PointEstimate = DifferenceGroup.Group_Mean * UniverseSize;
            //CALCULATE CORRECTION FACTOR
            if (UniverseSize > 1)
            {
                CorrectionFactor = Math.Sqrt((UniverseSize - dbl_SampleSize) / UniverseSize);
            }
            //Calculate Degrees of Freedom
            DegreesOfFreedom = SampleSize - 1;
            if (SampleSize > 1)
            {
                //Calculate Standard Deviation
                if (ExaminedGroup.Group_Sum != 0)
                {
                    double x = Math.Pow(ExaminedGroup.Group_Sum, 2.0) / dbl_SampleSize;
                    if (x < ExaminedGroup.Group_Sqr)
                        ExaminedGroup.Group_StandardDeviation = Math.Sqrt((ExaminedGroup.Group_Sqr - x) / (double)DegreesOfFreedom);
                    else
                        ExaminedGroup.Group_StandardDeviation = 0;
                }
                if (AuditedGroup.Group_Sum != 0)
                {
                    double x = Math.Pow(AuditedGroup.Group_Sum, 2.0) / dbl_SampleSize;
                    if (x < AuditedGroup.Group_Sqr)
                        AuditedGroup.Group_StandardDeviation = Math.Sqrt((AuditedGroup.Group_Sqr - x) / (double)DegreesOfFreedom);
                    else
                        AuditedGroup.Group_StandardDeviation = 0;
                }
                if (DifferenceGroup.Group_Sum != 0)
                {
                    double x = Math.Pow(DifferenceGroup.Group_Sum, 2.0) / dbl_SampleSize;
                    if (x < DifferenceGroup.Group_Sqr)
                        DifferenceGroup.Group_StandardDeviation = Math.Sqrt((DifferenceGroup.Group_Sqr - x) / (double)DegreesOfFreedom);
                    else
                        DifferenceGroup.Group_StandardDeviation = 0;
                }
                //Calculate Standard Error
                if (ExaminedGroup.Group_StandardDeviation != 0)
                    ExaminedGroup.Group_StandardError = (ExaminedGroup.Group_StandardDeviation / Math.Sqrt(dbl_SampleSize)) * CorrectionFactor;
                if (AuditedGroup.Group_StandardDeviation != 0)
                    AuditedGroup.Group_StandardError = (AuditedGroup.Group_StandardDeviation / Math.Sqrt(dbl_SampleSize)) * CorrectionFactor;
                if (DifferenceGroup.Group_StandardDeviation != 0)
                    DifferenceGroup.Group_StandardError = (DifferenceGroup.Group_StandardDeviation / Math.Sqrt(dbl_SampleSize)) * CorrectionFactor;

            }

            //Caculate T-Values
            //Chart test = new Chart();
            //CALCULATE T-VALUES
            //double T80 = test.DataManipulator.Statistics.InverseTDistribution(0.20, DegreesOfFreedom);
            //double T90 = test.DataManipulator.Statistics.InverseTDistribution(0.10, DegreesOfFreedom);
            //double T95 = test.DataManipulator.Statistics.InverseTDistribution(0.05, DegreesOfFreedom);
            double T80 = 0, T90 = 0, T95 = 0;
            if (DegreesOfFreedom > 3)
            {
                TValue TVAL_T80 = new TValue();
                double? Calculated_T80 = TVAL_T80.CalculateT(80.0, DegreesOfFreedom);
                TVAL_T80 = null;

                TValue TVAL_T90 = new TValue();
                double? Calculated_T90 = TVAL_T90.CalculateT(90.0, DegreesOfFreedom);
                TVAL_T90 = null;

                TValue TVAL_T95 = new TValue();
                double? Calculated_T95 = TVAL_T95.CalculateT(95.0, DegreesOfFreedom);
                TVAL_T95 = null;
                if (Calculated_T80 == null || Calculated_T90 == null || Calculated_T95 == null)
                {
                    throw new Exception("Unable to calculate T-Values");
                }
                T80 = (double)Calculated_T80;
                T90 = (double)Calculated_T90;
                T95 = (double)Calculated_T95;
            }
            else if (DegreesOfFreedom == 1)
            {
                T80 = 3.077683537175;
                T90 = 6.313751514675;
                T95 = 12.706204736175;
            }
            else if (DegreesOfFreedom == 2)
            {
                T80 = 1.885618083164;
                T90 = 2.919985580354;
                T95 = 4.30265272975;
            }
            else if (DegreesOfFreedom == 3)
            {
                T80 = 1.637744353696;
                T90 = 2.353363434802;
                T95 = 3.182446305284;
            }


            if (ExaminedGroup.Group_NonZero > 0)
            {
                //Calculate Precision, Lower Limit, Upper Limit, and Skewness
                ExaminedGroup.EightyPercent_Confidence.PrecisionAmount = T80 * ExaminedGroup.Group_StandardError;
                ExaminedGroup.EightyPercent_Confidence.LowerLimit = ExaminedGroup.Group_PointEstimate - (ExaminedGroup.EightyPercent_Confidence.PrecisionAmount * UniverseSize);
                ExaminedGroup.EightyPercent_Confidence.UpperLimit = ExaminedGroup.Group_PointEstimate + (ExaminedGroup.EightyPercent_Confidence.PrecisionAmount * UniverseSize);
                ExaminedGroup.EightyPercent_Confidence.T_Value = T80;
                ExaminedGroup.NinetyPercent_Confidence.PrecisionAmount = T90 * ExaminedGroup.Group_StandardError;
                ExaminedGroup.NinetyPercent_Confidence.LowerLimit = ExaminedGroup.Group_PointEstimate - (ExaminedGroup.NinetyPercent_Confidence.PrecisionAmount * UniverseSize);
                ExaminedGroup.NinetyPercent_Confidence.UpperLimit = ExaminedGroup.Group_PointEstimate + (ExaminedGroup.NinetyPercent_Confidence.PrecisionAmount * UniverseSize);
                ExaminedGroup.NinetyPercent_Confidence.T_Value = T90;
                ExaminedGroup.NinetyFivePercent_Confidence.PrecisionAmount = T95 * ExaminedGroup.Group_StandardError;
                ExaminedGroup.NinetyFivePercent_Confidence.LowerLimit = ExaminedGroup.Group_PointEstimate - (ExaminedGroup.NinetyFivePercent_Confidence.PrecisionAmount * UniverseSize);
                ExaminedGroup.NinetyFivePercent_Confidence.UpperLimit = ExaminedGroup.Group_PointEstimate + (ExaminedGroup.NinetyFivePercent_Confidence.PrecisionAmount * UniverseSize);
                ExaminedGroup.NinetyFivePercent_Confidence.T_Value = T95;
                if (ExaminedGroup.Group_Mean > 0)
                {
                    ExaminedGroup.EightyPercent_Confidence.PrecisionPercent = (T80 * ExaminedGroup.Group_StandardError) / ExaminedGroup.Group_Mean;
                    ExaminedGroup.NinetyPercent_Confidence.PrecisionPercent = (T90 * ExaminedGroup.Group_StandardError) / ExaminedGroup.Group_Mean;
                    ExaminedGroup.NinetyFivePercent_Confidence.PrecisionPercent = (T95 * ExaminedGroup.Group_StandardError) / ExaminedGroup.Group_Mean;
                }
                if (SampleSize > 0)
                {
                    //Skewness
                    double x, y;
                    x = (ExaminedGroup.Group_Cube / dbl_SampleSize) - (3 * (ExaminedGroup.Group_Sqr / dbl_SampleSize) * ExaminedGroup.Group_Mean) + (2 * Math.Pow(ExaminedGroup.Group_Mean, 3.0));
                    if ((ExaminedGroup.Group_Sqr / dbl_SampleSize) > Math.Pow(ExaminedGroup.Group_Mean, 2.0))
                        y = Math.Sqrt(ExaminedGroup.Group_Sqr / dbl_SampleSize - Math.Pow(ExaminedGroup.Group_Mean, 2.0));
                    else
                        y = 0;
                    if (y >= 1)
                    {
                        ExaminedGroup.Group_SkewAmt = x / Math.Pow(y, 3.0);
                    }
                    //KURTOSIS
                    double k;
                    k = (ExaminedGroup.Group_Quad / dbl_SampleSize) - (4 * (ExaminedGroup.Group_Cube / dbl_SampleSize) * ExaminedGroup.Group_Mean) + (6 * (ExaminedGroup.Group_Sqr / dbl_SampleSize * Math.Pow(ExaminedGroup.Group_Mean, 2))) - (3 * Math.Pow(ExaminedGroup.Group_Mean, 4));
                    if (y >= 1)
                    {
                        ExaminedGroup.Group_KurtAmt = k / Math.Pow(y, 4.0);
                    }
                }
            }
            else
            {
                ExaminedGroup.EightyPercent_Confidence.T_Value = T80;
                ExaminedGroup.NinetyPercent_Confidence.T_Value = T90;
                ExaminedGroup.NinetyFivePercent_Confidence.T_Value = T95;
            }
            if (AuditedGroup.Group_NonZero > 0)
            {
                AuditedGroup.EightyPercent_Confidence.PrecisionAmount = T80 * AuditedGroup.Group_StandardError;
                AuditedGroup.EightyPercent_Confidence.LowerLimit = AuditedGroup.Group_PointEstimate - (AuditedGroup.EightyPercent_Confidence.PrecisionAmount * UniverseSize);
                AuditedGroup.EightyPercent_Confidence.UpperLimit = AuditedGroup.Group_PointEstimate + (AuditedGroup.EightyPercent_Confidence.PrecisionAmount * UniverseSize);
                AuditedGroup.EightyPercent_Confidence.T_Value = T80;
                AuditedGroup.NinetyPercent_Confidence.PrecisionAmount = T90 * AuditedGroup.Group_StandardError;
                AuditedGroup.NinetyPercent_Confidence.LowerLimit = AuditedGroup.Group_PointEstimate - (AuditedGroup.NinetyPercent_Confidence.PrecisionAmount * UniverseSize);
                AuditedGroup.NinetyPercent_Confidence.UpperLimit = AuditedGroup.Group_PointEstimate + (AuditedGroup.NinetyPercent_Confidence.PrecisionAmount * UniverseSize);
                AuditedGroup.NinetyPercent_Confidence.T_Value = T90;
                AuditedGroup.NinetyFivePercent_Confidence.PrecisionAmount = T95 * AuditedGroup.Group_StandardError;
                AuditedGroup.NinetyFivePercent_Confidence.LowerLimit = AuditedGroup.Group_PointEstimate - (AuditedGroup.NinetyFivePercent_Confidence.PrecisionAmount * UniverseSize);
                AuditedGroup.NinetyFivePercent_Confidence.UpperLimit = AuditedGroup.Group_PointEstimate + (AuditedGroup.NinetyFivePercent_Confidence.PrecisionAmount * UniverseSize);
                AuditedGroup.NinetyFivePercent_Confidence.T_Value = T95;
                if (AuditedGroup.Group_Mean > 0)
                {
                    AuditedGroup.EightyPercent_Confidence.PrecisionPercent = (T80 * AuditedGroup.Group_StandardError) / AuditedGroup.Group_Mean;
                    AuditedGroup.NinetyPercent_Confidence.PrecisionPercent = (T90 * AuditedGroup.Group_StandardError) / AuditedGroup.Group_Mean;
                    AuditedGroup.NinetyFivePercent_Confidence.PrecisionPercent = (T95 * AuditedGroup.Group_StandardError) / AuditedGroup.Group_Mean;
                }
                if (SampleSize > 0)
                {
                    //Skewness
                    double x, y;
                    x = (AuditedGroup.Group_Cube / dbl_SampleSize) - (3 * (AuditedGroup.Group_Sqr / dbl_SampleSize) * AuditedGroup.Group_Mean) + (2 * Math.Pow(AuditedGroup.Group_Mean, 3.0));
                    if ((AuditedGroup.Group_Sqr / dbl_SampleSize) > Math.Pow(AuditedGroup.Group_Mean, 2.0))
                        y = Math.Sqrt(AuditedGroup.Group_Sqr / dbl_SampleSize - Math.Pow(AuditedGroup.Group_Mean, 2.0));
                    else
                        y = 0;
                    if (y >= 1)
                    {
                        AuditedGroup.Group_SkewAmt = x / Math.Pow(y, 3.0);
                    }
                    //KURTOSIS
                    double k;
                    k = (AuditedGroup.Group_Quad / dbl_SampleSize) - (4 * (AuditedGroup.Group_Cube / dbl_SampleSize) * AuditedGroup.Group_Mean) + (6 * (AuditedGroup.Group_Sqr / dbl_SampleSize * Math.Pow(AuditedGroup.Group_Mean, 2))) - (3 * Math.Pow(AuditedGroup.Group_Mean, 4));
                    if (y >= 1)
                    {
                        AuditedGroup.Group_KurtAmt = k / Math.Pow(y, 4.0);
                    }
                }
            }
            else
            {
                AuditedGroup.EightyPercent_Confidence.T_Value = T80;
                AuditedGroup.NinetyPercent_Confidence.T_Value = T90;
                AuditedGroup.NinetyFivePercent_Confidence.T_Value = T95;
            }
            if (DifferenceGroup.Group_NonZero > 0)
            {
                DifferenceGroup.EightyPercent_Confidence.PrecisionAmount = T80 * DifferenceGroup.Group_StandardError;
                DifferenceGroup.EightyPercent_Confidence.LowerLimit = DifferenceGroup.Group_PointEstimate - (DifferenceGroup.EightyPercent_Confidence.PrecisionAmount * UniverseSize);
                DifferenceGroup.EightyPercent_Confidence.UpperLimit = DifferenceGroup.Group_PointEstimate + (DifferenceGroup.EightyPercent_Confidence.PrecisionAmount * UniverseSize);
                DifferenceGroup.EightyPercent_Confidence.T_Value = T80;
                DifferenceGroup.NinetyPercent_Confidence.PrecisionAmount = T90 * DifferenceGroup.Group_StandardError;
                DifferenceGroup.NinetyPercent_Confidence.LowerLimit = DifferenceGroup.Group_PointEstimate - (DifferenceGroup.NinetyPercent_Confidence.PrecisionAmount * UniverseSize);
                DifferenceGroup.NinetyPercent_Confidence.UpperLimit = DifferenceGroup.Group_PointEstimate + (DifferenceGroup.NinetyPercent_Confidence.PrecisionAmount * UniverseSize);
                DifferenceGroup.NinetyPercent_Confidence.T_Value = T90;
                DifferenceGroup.NinetyFivePercent_Confidence.PrecisionAmount = T95 * DifferenceGroup.Group_StandardError;
                DifferenceGroup.NinetyFivePercent_Confidence.LowerLimit = DifferenceGroup.Group_PointEstimate - (DifferenceGroup.NinetyFivePercent_Confidence.PrecisionAmount * UniverseSize);
                DifferenceGroup.NinetyFivePercent_Confidence.UpperLimit = DifferenceGroup.Group_PointEstimate + (DifferenceGroup.NinetyFivePercent_Confidence.PrecisionAmount * UniverseSize);
                DifferenceGroup.NinetyFivePercent_Confidence.T_Value = T95;
                if (DifferenceGroup.Group_Mean > 0)
                {
                    DifferenceGroup.EightyPercent_Confidence.PrecisionPercent = (T80 * DifferenceGroup.Group_StandardError) / DifferenceGroup.Group_Mean;
                    DifferenceGroup.NinetyPercent_Confidence.PrecisionPercent = (T90 * DifferenceGroup.Group_StandardError) / DifferenceGroup.Group_Mean;
                    DifferenceGroup.NinetyFivePercent_Confidence.PrecisionPercent = (T95 * DifferenceGroup.Group_StandardError) / DifferenceGroup.Group_Mean;
                }
                if (SampleSize > 0)
                {
                    double x, y;
                    x = (DifferenceGroup.Group_Cube / dbl_SampleSize) - (3 * (DifferenceGroup.Group_Sqr / dbl_SampleSize) * DifferenceGroup.Group_Mean) + (2 * Math.Pow(DifferenceGroup.Group_Mean, 3.0));
                    if ((DifferenceGroup.Group_Sqr / dbl_SampleSize) > Math.Pow(DifferenceGroup.Group_Mean, 2.0))
                        y = Math.Sqrt(DifferenceGroup.Group_Sqr / dbl_SampleSize - Math.Pow(DifferenceGroup.Group_Mean, 2.0));
                    else
                        y = 0;
                    if (y >= 1)
                    {
                        DifferenceGroup.Group_SkewAmt = x / Math.Pow(y, 3.0);
                    }
                    //KURTOSIS
                    double k;
                    k = (DifferenceGroup.Group_Quad / dbl_SampleSize) - (4 * (DifferenceGroup.Group_Cube / dbl_SampleSize) * DifferenceGroup.Group_Mean) + (6 * (DifferenceGroup.Group_Sqr / dbl_SampleSize * Math.Pow(DifferenceGroup.Group_Mean, 2))) - (3 * Math.Pow(DifferenceGroup.Group_Mean, 4));
                    if (y >= 1)
                    {
                        DifferenceGroup.Group_KurtAmt = k / Math.Pow(y, 4.0);
                    }
                }
            }
            else
            {
                DifferenceGroup.EightyPercent_Confidence.T_Value = T80;
                DifferenceGroup.NinetyPercent_Confidence.T_Value = T90;
                DifferenceGroup.NinetyFivePercent_Confidence.T_Value = T95;
            }
            return;

        }
    }
    /*****************************************************************************************************
    *   StratifiedVariableAppraisalDataset
    *   - Container for all of the data rows, group data, sample size, universe size, etc associated with
    *     a single stratum of a Stratified Variable Appraisal. 
    *
    ******************************************************************************************************/
    public class StratifiedVariableAppraisalDataset : VariableAppraisalDataSet
    {
        public string StratumID = "";
    }

    /*****************************************************************************************************
    *   StratifiedVariableAppraisal
    *   - Container for all of the strata, strata group data, etc associated with
    *     a Stratified Variable Appraisal. 
    *
    ******************************************************************************************************/
    public class StratifiedVariableAppraisal
    {
        public List<StratifiedVariableAppraisalDataset> Strata = new List<StratifiedVariableAppraisalDataset>();
        public string AuditReviewName { get; set; }
        public DataFileFormatType SelectedDataFileFormat = DataFileFormatType.Unknown;

        public UnrestrictedVariableAppraisalGroupData OverallExaminedGroup = new UnrestrictedVariableAppraisalGroupData();
        public UnrestrictedVariableAppraisalGroupData OverallAuditedGroup = new UnrestrictedVariableAppraisalGroupData();
        public UnrestrictedVariableAppraisalGroupData OverallDifferenceGroup = new UnrestrictedVariableAppraisalGroupData();

        public string DataFileInputPath = "";
        public string UniverseFileInputPath = "";
        public bool TextFileOutput = false;
        public string TextFileOutputPath;
        public bool ExcelFileOutput = false;
        public string ExcelFileOutputPath;
        public DateTime LogTime;
        public double ZVAL80 { get; set; } = 1.281551565545;
        public double ZVAL90 { get; set; } = 1.644853626951;
        public double ZVAL95 { get; set; } = 1.95996398454;
        //Sample Size
        public int OverallSampleSize { get; set; }
        //Universe Size
        public long OverallUniverseSize { get; set; }

        public double CorrectionFactor { get; set; }
        public int DegreesOfFreedom { get; set; }

        public void CalculateStrataGroupStats()
        {
            foreach (VariableAppraisalDataSet VAS in Strata)
            {
                foreach (UnrestrictedVariableAppraisalDataRow DR in VAS.DataRows)
                {
                    VAS.ExaminedGroup.Group_Sum += DR.ExaminedValue;
                    VAS.ExaminedGroup.Group_Sqr += Math.Pow(DR.ExaminedValue, 2.0);
                    VAS.ExaminedGroup.Group_Cube += Math.Pow(DR.ExaminedValue, 3.0);
                    VAS.ExaminedGroup.Group_Quad += Math.Pow(DR.ExaminedValue, 4.0);
                    if (DR.ExaminedValue != 0)
                        VAS.ExaminedGroup.Group_NonZero++;
                    VAS.AuditedGroup.Group_Sum += DR.AuditedValue;
                    VAS.AuditedGroup.Group_Sqr += Math.Pow(DR.AuditedValue, 2.0);
                    VAS.AuditedGroup.Group_Cube += Math.Pow(DR.AuditedValue, 3.0);
                    VAS.AuditedGroup.Group_Quad += Math.Pow(DR.AuditedValue, 4.0);
                    if (DR.AuditedValue != 0)
                        VAS.AuditedGroup.Group_NonZero++;
                    VAS.DifferenceGroup.Group_Sum += DR.DifferenceValue;
                    VAS.DifferenceGroup.Group_Sqr += Math.Pow(DR.DifferenceValue, 2.0);
                    VAS.DifferenceGroup.Group_Cube += Math.Pow(DR.DifferenceValue, 3.0);
                    VAS.DifferenceGroup.Group_Quad += Math.Pow(DR.DifferenceValue, 4.0);
                    if (DR.DifferenceValue != 0)
                        VAS.DifferenceGroup.Group_NonZero++;
                }
                VAS.CalculateGroupStats();
            }
            //CALCULATE OVERALL GROUP STATS
            double TotalExaminedStandardErrorSquared = 0;
            double TotalAuditedStandardErrorSquared = 0;
            double TotalDifferenceStandardErrorSquared = 0;
 
            OverallExaminedGroup.Group_PointEstimate = 0;
            OverallAuditedGroup.Group_PointEstimate = 0;
            OverallDifferenceGroup.Group_PointEstimate = 0;
            foreach (VariableAppraisalDataSet VAS in Strata)
            {
                TotalExaminedStandardErrorSquared += Math.Pow(VAS.ExaminedGroup.Group_StandardError * VAS.UniverseSize, 2);
                TotalAuditedStandardErrorSquared += Math.Pow(VAS.AuditedGroup.Group_StandardError * VAS.UniverseSize, 2);
                TotalDifferenceStandardErrorSquared += Math.Pow(VAS.DifferenceGroup.Group_StandardError * VAS.UniverseSize, 2);
                OverallExaminedGroup.Group_PointEstimate += VAS.ExaminedGroup.Group_PointEstimate;
                OverallAuditedGroup.Group_PointEstimate += VAS.AuditedGroup.Group_PointEstimate;
                OverallDifferenceGroup.Group_PointEstimate += VAS.DifferenceGroup.Group_PointEstimate;
            }
            OverallExaminedGroup.Group_StandardError = Math.Sqrt(TotalExaminedStandardErrorSquared);
            OverallAuditedGroup.Group_StandardError = Math.Sqrt(TotalAuditedStandardErrorSquared);
            OverallDifferenceGroup.Group_StandardError = Math.Sqrt(TotalDifferenceStandardErrorSquared);

            OverallExaminedGroup.EightyPercent_Confidence.PrecisionAmount = OverallExaminedGroup.Group_StandardError * ZVAL80;
            OverallExaminedGroup.NinetyPercent_Confidence.PrecisionAmount = OverallExaminedGroup.Group_StandardError * ZVAL90;
            OverallExaminedGroup.NinetyFivePercent_Confidence.PrecisionAmount = OverallExaminedGroup.Group_StandardError * ZVAL95;

            OverallExaminedGroup.EightyPercent_Confidence.LowerLimit = OverallExaminedGroup.Group_PointEstimate - OverallExaminedGroup.EightyPercent_Confidence.PrecisionAmount;
            OverallExaminedGroup.EightyPercent_Confidence.UpperLimit = OverallExaminedGroup.Group_PointEstimate + OverallExaminedGroup.EightyPercent_Confidence.PrecisionAmount;
            OverallExaminedGroup.NinetyPercent_Confidence.LowerLimit = OverallExaminedGroup.Group_PointEstimate - OverallExaminedGroup.NinetyPercent_Confidence.PrecisionAmount;
            OverallExaminedGroup.NinetyPercent_Confidence.UpperLimit = OverallExaminedGroup.Group_PointEstimate + OverallExaminedGroup.NinetyPercent_Confidence.PrecisionAmount;
            OverallExaminedGroup.NinetyFivePercent_Confidence.LowerLimit = OverallExaminedGroup.Group_PointEstimate - OverallExaminedGroup.NinetyFivePercent_Confidence.PrecisionAmount;
            OverallExaminedGroup.NinetyFivePercent_Confidence.UpperLimit = OverallExaminedGroup.Group_PointEstimate + OverallExaminedGroup.NinetyFivePercent_Confidence.PrecisionAmount;

            if(OverallExaminedGroup.Group_PointEstimate > 0)
            {
                OverallExaminedGroup.EightyPercent_Confidence.PrecisionPercent = OverallExaminedGroup.EightyPercent_Confidence.PrecisionAmount / OverallExaminedGroup.Group_PointEstimate;
                OverallExaminedGroup.NinetyPercent_Confidence.PrecisionPercent = OverallExaminedGroup.NinetyPercent_Confidence.PrecisionAmount / OverallExaminedGroup.Group_PointEstimate;
                OverallExaminedGroup.NinetyFivePercent_Confidence.PrecisionPercent = OverallExaminedGroup.NinetyFivePercent_Confidence.PrecisionAmount / OverallExaminedGroup.Group_PointEstimate;

            }

            OverallAuditedGroup.EightyPercent_Confidence.PrecisionAmount = OverallAuditedGroup.Group_StandardError * ZVAL80;
            OverallAuditedGroup.NinetyPercent_Confidence.PrecisionAmount = OverallAuditedGroup.Group_StandardError * ZVAL90;
            OverallAuditedGroup.NinetyFivePercent_Confidence.PrecisionAmount = OverallAuditedGroup.Group_StandardError * ZVAL95;

            OverallAuditedGroup.EightyPercent_Confidence.LowerLimit = OverallAuditedGroup.Group_PointEstimate - OverallAuditedGroup.EightyPercent_Confidence.PrecisionAmount;
            OverallAuditedGroup.EightyPercent_Confidence.UpperLimit = OverallAuditedGroup.Group_PointEstimate + OverallAuditedGroup.EightyPercent_Confidence.PrecisionAmount;
            OverallAuditedGroup.NinetyPercent_Confidence.LowerLimit = OverallAuditedGroup.Group_PointEstimate - OverallAuditedGroup.NinetyPercent_Confidence.PrecisionAmount;
            OverallAuditedGroup.NinetyPercent_Confidence.UpperLimit = OverallAuditedGroup.Group_PointEstimate + OverallAuditedGroup.NinetyPercent_Confidence.PrecisionAmount;
            OverallAuditedGroup.NinetyFivePercent_Confidence.LowerLimit = OverallAuditedGroup.Group_PointEstimate - OverallAuditedGroup.NinetyFivePercent_Confidence.PrecisionAmount;
            OverallAuditedGroup.NinetyFivePercent_Confidence.UpperLimit = OverallAuditedGroup.Group_PointEstimate + OverallAuditedGroup.NinetyFivePercent_Confidence.PrecisionAmount;

            if(OverallAuditedGroup.Group_PointEstimate > 0)
            {
                OverallAuditedGroup.EightyPercent_Confidence.PrecisionPercent = OverallAuditedGroup.EightyPercent_Confidence.PrecisionAmount / OverallAuditedGroup.Group_PointEstimate;
                OverallAuditedGroup.NinetyPercent_Confidence.PrecisionPercent = OverallAuditedGroup.NinetyPercent_Confidence.PrecisionAmount / OverallAuditedGroup.Group_PointEstimate;
                OverallAuditedGroup.NinetyFivePercent_Confidence.PrecisionPercent = OverallAuditedGroup.NinetyFivePercent_Confidence.PrecisionAmount / OverallAuditedGroup.Group_PointEstimate;
            }


            OverallDifferenceGroup.EightyPercent_Confidence.PrecisionAmount = OverallDifferenceGroup.Group_StandardError * ZVAL80;
            OverallDifferenceGroup.NinetyPercent_Confidence.PrecisionAmount = OverallDifferenceGroup.Group_StandardError * ZVAL90;
            OverallDifferenceGroup.NinetyFivePercent_Confidence.PrecisionAmount = OverallDifferenceGroup.Group_StandardError * ZVAL95;

            OverallDifferenceGroup.EightyPercent_Confidence.LowerLimit = OverallDifferenceGroup.Group_PointEstimate - OverallDifferenceGroup.EightyPercent_Confidence.PrecisionAmount;
            OverallDifferenceGroup.EightyPercent_Confidence.UpperLimit = OverallDifferenceGroup.Group_PointEstimate + OverallDifferenceGroup.EightyPercent_Confidence.PrecisionAmount;
            OverallDifferenceGroup.NinetyPercent_Confidence.LowerLimit = OverallDifferenceGroup.Group_PointEstimate - OverallDifferenceGroup.NinetyPercent_Confidence.PrecisionAmount;
            OverallDifferenceGroup.NinetyPercent_Confidence.UpperLimit = OverallDifferenceGroup.Group_PointEstimate + OverallDifferenceGroup.NinetyPercent_Confidence.PrecisionAmount;
            OverallDifferenceGroup.NinetyFivePercent_Confidence.LowerLimit = OverallDifferenceGroup.Group_PointEstimate - OverallDifferenceGroup.NinetyFivePercent_Confidence.PrecisionAmount;
            OverallDifferenceGroup.NinetyFivePercent_Confidence.UpperLimit = OverallDifferenceGroup.Group_PointEstimate + OverallDifferenceGroup.NinetyFivePercent_Confidence.PrecisionAmount;

            if(OverallDifferenceGroup.Group_PointEstimate > 0)
            {
                OverallDifferenceGroup.EightyPercent_Confidence.PrecisionPercent = OverallDifferenceGroup.EightyPercent_Confidence.PrecisionAmount / OverallDifferenceGroup.Group_PointEstimate;
                OverallDifferenceGroup.NinetyPercent_Confidence.PrecisionPercent = OverallDifferenceGroup.NinetyPercent_Confidence.PrecisionAmount / OverallDifferenceGroup.Group_PointEstimate;
                OverallDifferenceGroup.NinetyFivePercent_Confidence.PrecisionPercent = OverallDifferenceGroup.NinetyFivePercent_Confidence.PrecisionAmount / OverallDifferenceGroup.Group_PointEstimate;
            }
        }

        //ExportToExcel()
        //Provided support for outputing the data as an excel file. Uses an excel template file, populates the fields, and then saves it where the user specified
        public void ExportToExcel()
        {
            var excelApp = new Excel.Application();
            int OverallExaminedIndex = -1, OverallAuditedIndex = -1, OverallDifferenceIndex = -1;

            Excel.Workbook workbook = excelApp.Workbooks.Open(System.AppDomain.CurrentDomain.BaseDirectory + @"\Templates\StratifiedTemplate.xlsx",null,true);
            ((Excel.Worksheet)excelApp.ActiveWorkbook.Sheets[1]).Select();
            Excel._Worksheet workSheet = (Excel.Worksheet)excelApp.ActiveSheet;
           
            workSheet.Cells[2, "A"] = LogTime.ToShortDateString();
            workSheet.Cells[2, "B"] = LogTime.ToShortTimeString();
            workSheet.Cells[2, "C"] = AuditReviewName;
            workSheet.Cells[2, "D"] = DataFileInputPath;
            workSheet.Cells[2, "E"] = UniverseFileInputPath;
            Excel.Sheets WorkSheets = excelApp.ActiveWorkbook.Sheets;
            excelApp.DisplayAlerts = false;
            switch (SelectedDataFileFormat)
            {
                case DataFileFormatType.Examined:
                    WorkSheets[7].Delete(); //Delete Overall Difference
                    WorkSheets[6].Delete(); //Delete Overall Audited
                    WorkSheets[4].Delete(); //Delete Difference
                    WorkSheets[3].Delete(); //Delete Audited
                    OverallExaminedIndex = 3;
                    break;
                case DataFileFormatType.Audited:
                    WorkSheets[7].Delete(); //Delete Overall Difference
                    WorkSheets[5].Delete(); //Delete Overall Examined
                    WorkSheets[4].Delete(); //Delete Difference
                    WorkSheets[2].Delete(); //Delete Examined
                    OverallAuditedIndex = 3;
                    break;
                case DataFileFormatType.Difference:
                    WorkSheets[6].Delete(); //Delete Overall Audited
                    WorkSheets[5].Delete(); //Delete Overall Examined
                    WorkSheets[3].Delete(); //Delete Audited
                    WorkSheets[2].Delete(); //Delete Examined
                    OverallDifferenceIndex = 3;
                    break;
                default:
                    OverallExaminedIndex = 5;
                    OverallAuditedIndex = 6;
                    OverallDifferenceIndex = 7;
                    break;
            }
            excelApp.DisplayAlerts = true;
            int RowIndex = 2;
            foreach (StratifiedVariableAppraisalDataset Stratum in Strata)
            {
                switch (SelectedDataFileFormat)
                {
                    case DataFileFormatType.Examined:
                        ((Excel.Worksheet)excelApp.ActiveWorkbook.Sheets[2]).Select();
                        workSheet = (Excel.Worksheet)excelApp.ActiveSheet;
                        workSheet.Cells[RowIndex, "A"] = Stratum.StratumID;
                        workSheet.Cells[RowIndex, "B"] = Stratum.UniverseSize;
                        workSheet.Cells[RowIndex, "C"] = Stratum.SampleSize;
                        workSheet.Cells[RowIndex, "D"] = Stratum.ExaminedGroup.Group_StandardDeviation;
                        workSheet.Cells[RowIndex, "E"] = Stratum.ExaminedGroup.Group_StandardError;
                        workSheet.Cells[RowIndex, "F"] = Stratum.ExaminedGroup.Group_PointEstimate;
                        workSheet.Cells[RowIndex, "G"] = Stratum.ExaminedGroup.Group_SkewAmt;
                        workSheet.Cells[RowIndex, "H"] = Stratum.ExaminedGroup.Group_KurtAmt;
                        workSheet.Cells[RowIndex, "I"] = Stratum.ExaminedGroup.Group_StandardError * Stratum.UniverseSize;
                        workSheet.Cells[RowIndex, "J"] = Stratum.ExaminedGroup.EightyPercent_Confidence.LowerLimit;
                        workSheet.Cells[RowIndex, "K"] = Stratum.ExaminedGroup.EightyPercent_Confidence.UpperLimit;
                        workSheet.Cells[RowIndex, "L"] = Stratum.ExaminedGroup.EightyPercent_Confidence.PrecisionAmount;
                        workSheet.Cells[RowIndex, "M"] = Stratum.ExaminedGroup.EightyPercent_Confidence.PrecisionPercent;
                        workSheet.Cells[RowIndex, "N"] = Stratum.ExaminedGroup.EightyPercent_Confidence.T_Value;
                        workSheet.Cells[RowIndex, "O"] = Stratum.ExaminedGroup.NinetyPercent_Confidence.LowerLimit;
                        workSheet.Cells[RowIndex, "P"] = Stratum.ExaminedGroup.NinetyPercent_Confidence.UpperLimit;
                        workSheet.Cells[RowIndex, "Q"] = Stratum.ExaminedGroup.NinetyPercent_Confidence.PrecisionAmount;
                        workSheet.Cells[RowIndex, "R"] = Stratum.ExaminedGroup.NinetyPercent_Confidence.PrecisionPercent;
                        workSheet.Cells[RowIndex, "S"] = Stratum.ExaminedGroup.NinetyPercent_Confidence.T_Value;
                        workSheet.Cells[RowIndex, "T"] = Stratum.ExaminedGroup.NinetyFivePercent_Confidence.LowerLimit;
                        workSheet.Cells[RowIndex, "U"] = Stratum.ExaminedGroup.NinetyFivePercent_Confidence.UpperLimit;
                        workSheet.Cells[RowIndex, "V"] = Stratum.ExaminedGroup.NinetyFivePercent_Confidence.PrecisionAmount;
                        workSheet.Cells[RowIndex, "W"] = Stratum.ExaminedGroup.NinetyFivePercent_Confidence.PrecisionPercent;
                        workSheet.Cells[RowIndex, "X"] = Stratum.ExaminedGroup.NinetyFivePercent_Confidence.T_Value;
                        break;
                    case DataFileFormatType.Audited:
                        ((Excel.Worksheet)excelApp.ActiveWorkbook.Sheets[2]).Select();
                        workSheet = (Excel.Worksheet)excelApp.ActiveSheet;
                        workSheet.Cells[RowIndex, "A"] = Stratum.StratumID;
                        workSheet.Cells[RowIndex, "B"] = Stratum.UniverseSize;
                        workSheet.Cells[RowIndex, "C"] = Stratum.SampleSize;
                        workSheet.Cells[RowIndex, "D"] = Stratum.AuditedGroup.Group_StandardDeviation;
                        workSheet.Cells[RowIndex, "E"] = Stratum.AuditedGroup.Group_StandardError;
                        workSheet.Cells[RowIndex, "F"] = Stratum.AuditedGroup.Group_PointEstimate;
                        workSheet.Cells[RowIndex, "G"] = Stratum.AuditedGroup.Group_SkewAmt;
                        workSheet.Cells[RowIndex, "H"] = Stratum.AuditedGroup.Group_KurtAmt;
                        workSheet.Cells[RowIndex, "I"] = Stratum.AuditedGroup.Group_StandardError * Stratum.UniverseSize;
                        workSheet.Cells[RowIndex, "J"] = Stratum.AuditedGroup.EightyPercent_Confidence.LowerLimit;
                        workSheet.Cells[RowIndex, "K"] = Stratum.AuditedGroup.EightyPercent_Confidence.UpperLimit;
                        workSheet.Cells[RowIndex, "L"] = Stratum.AuditedGroup.EightyPercent_Confidence.PrecisionAmount;
                        workSheet.Cells[RowIndex, "M"] = Stratum.AuditedGroup.EightyPercent_Confidence.PrecisionPercent;
                        workSheet.Cells[RowIndex, "N"] = Stratum.AuditedGroup.EightyPercent_Confidence.T_Value;
                        workSheet.Cells[RowIndex, "O"] = Stratum.AuditedGroup.NinetyPercent_Confidence.LowerLimit;
                        workSheet.Cells[RowIndex, "P"] = Stratum.AuditedGroup.NinetyPercent_Confidence.UpperLimit;
                        workSheet.Cells[RowIndex, "Q"] = Stratum.AuditedGroup.NinetyPercent_Confidence.PrecisionAmount;
                        workSheet.Cells[RowIndex, "R"] = Stratum.AuditedGroup.NinetyPercent_Confidence.PrecisionPercent;
                        workSheet.Cells[RowIndex, "S"] = Stratum.AuditedGroup.NinetyPercent_Confidence.T_Value;
                        workSheet.Cells[RowIndex, "T"] = Stratum.AuditedGroup.NinetyFivePercent_Confidence.LowerLimit;
                        workSheet.Cells[RowIndex, "U"] = Stratum.AuditedGroup.NinetyFivePercent_Confidence.UpperLimit;
                        workSheet.Cells[RowIndex, "V"] = Stratum.AuditedGroup.NinetyFivePercent_Confidence.PrecisionAmount;
                        workSheet.Cells[RowIndex, "W"] = Stratum.AuditedGroup.NinetyFivePercent_Confidence.PrecisionPercent;
                        workSheet.Cells[RowIndex, "X"] = Stratum.AuditedGroup.NinetyFivePercent_Confidence.T_Value;
                        break;
                    case DataFileFormatType.Difference:
                        ((Excel.Worksheet)excelApp.ActiveWorkbook.Sheets[2]).Select();
                        workSheet = (Excel.Worksheet)excelApp.ActiveSheet;
                        workSheet.Cells[RowIndex, "A"] = Stratum.StratumID;
                        workSheet.Cells[RowIndex, "B"] = Stratum.UniverseSize;
                        workSheet.Cells[RowIndex, "C"] = Stratum.SampleSize;
                        workSheet.Cells[RowIndex, "D"] = Stratum.DifferenceGroup.Group_StandardDeviation;
                        workSheet.Cells[RowIndex, "E"] = Stratum.DifferenceGroup.Group_StandardError;
                        workSheet.Cells[RowIndex, "F"] = Stratum.DifferenceGroup.Group_PointEstimate;
                        workSheet.Cells[RowIndex, "G"] = Stratum.DifferenceGroup.Group_SkewAmt;
                        workSheet.Cells[RowIndex, "H"] = Stratum.DifferenceGroup.Group_KurtAmt;
                        workSheet.Cells[RowIndex, "I"] = Stratum.DifferenceGroup.Group_StandardError * Stratum.UniverseSize;
                        workSheet.Cells[RowIndex, "J"] = Stratum.DifferenceGroup.EightyPercent_Confidence.LowerLimit;
                        workSheet.Cells[RowIndex, "K"] = Stratum.DifferenceGroup.EightyPercent_Confidence.UpperLimit;
                        workSheet.Cells[RowIndex, "L"] = Stratum.DifferenceGroup.EightyPercent_Confidence.PrecisionAmount;
                        workSheet.Cells[RowIndex, "M"] = Stratum.DifferenceGroup.EightyPercent_Confidence.PrecisionPercent;
                        workSheet.Cells[RowIndex, "N"] = Stratum.DifferenceGroup.EightyPercent_Confidence.T_Value;
                        workSheet.Cells[RowIndex, "O"] = Stratum.DifferenceGroup.NinetyPercent_Confidence.LowerLimit;
                        workSheet.Cells[RowIndex, "P"] = Stratum.DifferenceGroup.NinetyPercent_Confidence.UpperLimit;
                        workSheet.Cells[RowIndex, "Q"] = Stratum.DifferenceGroup.NinetyPercent_Confidence.PrecisionAmount;
                        workSheet.Cells[RowIndex, "R"] = Stratum.DifferenceGroup.NinetyPercent_Confidence.PrecisionPercent;
                        workSheet.Cells[RowIndex, "S"] = Stratum.DifferenceGroup.NinetyPercent_Confidence.T_Value;
                        workSheet.Cells[RowIndex, "T"] = Stratum.DifferenceGroup.NinetyFivePercent_Confidence.LowerLimit;
                        workSheet.Cells[RowIndex, "U"] = Stratum.DifferenceGroup.NinetyFivePercent_Confidence.UpperLimit;
                        workSheet.Cells[RowIndex, "V"] = Stratum.DifferenceGroup.NinetyFivePercent_Confidence.PrecisionAmount;
                        workSheet.Cells[RowIndex, "W"] = Stratum.DifferenceGroup.NinetyFivePercent_Confidence.PrecisionPercent;
                        workSheet.Cells[RowIndex, "X"] = Stratum.DifferenceGroup.NinetyFivePercent_Confidence.T_Value;
                        break;
                    default:
                        ((Excel.Worksheet)excelApp.ActiveWorkbook.Sheets[2]).Select();
                        workSheet = (Excel.Worksheet)excelApp.ActiveSheet;
                        workSheet.Cells[RowIndex, "A"] = Stratum.StratumID;
                        workSheet.Cells[RowIndex, "B"] = Stratum.UniverseSize;
                        workSheet.Cells[RowIndex, "C"] = Stratum.SampleSize;
                        workSheet.Cells[RowIndex, "D"] = Stratum.ExaminedGroup.Group_StandardDeviation;
                        workSheet.Cells[RowIndex, "E"] = Stratum.ExaminedGroup.Group_StandardError;
                        workSheet.Cells[RowIndex, "F"] = Stratum.ExaminedGroup.Group_PointEstimate;
                        workSheet.Cells[RowIndex, "G"] = Stratum.ExaminedGroup.Group_SkewAmt;
                        workSheet.Cells[RowIndex, "H"] = Stratum.ExaminedGroup.Group_KurtAmt;
                        workSheet.Cells[RowIndex, "I"] = Stratum.ExaminedGroup.Group_StandardError * Stratum.UniverseSize;
                        workSheet.Cells[RowIndex, "J"] = Stratum.ExaminedGroup.EightyPercent_Confidence.LowerLimit;
                        workSheet.Cells[RowIndex, "K"] = Stratum.ExaminedGroup.EightyPercent_Confidence.UpperLimit;
                        workSheet.Cells[RowIndex, "L"] = Stratum.ExaminedGroup.EightyPercent_Confidence.PrecisionAmount;
                        workSheet.Cells[RowIndex, "M"] = Stratum.ExaminedGroup.EightyPercent_Confidence.PrecisionPercent;
                        workSheet.Cells[RowIndex, "N"] = Stratum.ExaminedGroup.EightyPercent_Confidence.T_Value;
                        workSheet.Cells[RowIndex, "O"] = Stratum.ExaminedGroup.NinetyPercent_Confidence.LowerLimit;
                        workSheet.Cells[RowIndex, "P"] = Stratum.ExaminedGroup.NinetyPercent_Confidence.UpperLimit;
                        workSheet.Cells[RowIndex, "Q"] = Stratum.ExaminedGroup.NinetyPercent_Confidence.PrecisionAmount;
                        workSheet.Cells[RowIndex, "R"] = Stratum.ExaminedGroup.NinetyPercent_Confidence.PrecisionPercent;
                        workSheet.Cells[RowIndex, "S"] = Stratum.ExaminedGroup.NinetyPercent_Confidence.T_Value;
                        workSheet.Cells[RowIndex, "T"] = Stratum.ExaminedGroup.NinetyFivePercent_Confidence.LowerLimit;
                        workSheet.Cells[RowIndex, "U"] = Stratum.ExaminedGroup.NinetyFivePercent_Confidence.UpperLimit;
                        workSheet.Cells[RowIndex, "V"] = Stratum.ExaminedGroup.NinetyFivePercent_Confidence.PrecisionAmount;
                        workSheet.Cells[RowIndex, "W"] = Stratum.ExaminedGroup.NinetyFivePercent_Confidence.PrecisionPercent;
                        workSheet.Cells[RowIndex, "X"] = Stratum.ExaminedGroup.NinetyFivePercent_Confidence.T_Value;

                        ((Excel.Worksheet)excelApp.ActiveWorkbook.Sheets[3]).Select();
                        workSheet = (Excel.Worksheet)excelApp.ActiveSheet;
                        workSheet.Cells[RowIndex, "A"] = Stratum.StratumID;
                        workSheet.Cells[RowIndex, "B"] = Stratum.UniverseSize;
                        workSheet.Cells[RowIndex, "C"] = Stratum.SampleSize;
                        workSheet.Cells[RowIndex, "D"] = Stratum.AuditedGroup.Group_StandardDeviation;
                        workSheet.Cells[RowIndex, "E"] = Stratum.AuditedGroup.Group_StandardError;
                        workSheet.Cells[RowIndex, "F"] = Stratum.AuditedGroup.Group_PointEstimate;
                        workSheet.Cells[RowIndex, "G"] = Stratum.AuditedGroup.Group_SkewAmt;
                        workSheet.Cells[RowIndex, "H"] = Stratum.AuditedGroup.Group_KurtAmt;
                        workSheet.Cells[RowIndex, "I"] = Stratum.AuditedGroup.Group_StandardError * Stratum.UniverseSize;
                        workSheet.Cells[RowIndex, "J"] = Stratum.AuditedGroup.EightyPercent_Confidence.LowerLimit;
                        workSheet.Cells[RowIndex, "K"] = Stratum.AuditedGroup.EightyPercent_Confidence.UpperLimit;
                        workSheet.Cells[RowIndex, "L"] = Stratum.AuditedGroup.EightyPercent_Confidence.PrecisionAmount;
                        workSheet.Cells[RowIndex, "M"] = Stratum.AuditedGroup.EightyPercent_Confidence.PrecisionPercent;
                        workSheet.Cells[RowIndex, "N"] = Stratum.AuditedGroup.EightyPercent_Confidence.T_Value;
                        workSheet.Cells[RowIndex, "O"] = Stratum.AuditedGroup.NinetyPercent_Confidence.LowerLimit;
                        workSheet.Cells[RowIndex, "P"] = Stratum.AuditedGroup.NinetyPercent_Confidence.UpperLimit;
                        workSheet.Cells[RowIndex, "Q"] = Stratum.AuditedGroup.NinetyPercent_Confidence.PrecisionAmount;
                        workSheet.Cells[RowIndex, "R"] = Stratum.AuditedGroup.NinetyPercent_Confidence.PrecisionPercent;
                        workSheet.Cells[RowIndex, "S"] = Stratum.AuditedGroup.NinetyPercent_Confidence.T_Value;
                        workSheet.Cells[RowIndex, "T"] = Stratum.AuditedGroup.NinetyFivePercent_Confidence.LowerLimit;
                        workSheet.Cells[RowIndex, "U"] = Stratum.AuditedGroup.NinetyFivePercent_Confidence.UpperLimit;
                        workSheet.Cells[RowIndex, "V"] = Stratum.AuditedGroup.NinetyFivePercent_Confidence.PrecisionAmount;
                        workSheet.Cells[RowIndex, "W"] = Stratum.AuditedGroup.NinetyFivePercent_Confidence.PrecisionPercent;
                        workSheet.Cells[RowIndex, "X"] = Stratum.AuditedGroup.NinetyFivePercent_Confidence.T_Value;

                        ((Excel.Worksheet)excelApp.ActiveWorkbook.Sheets[4]).Select();
                        workSheet = (Excel.Worksheet)excelApp.ActiveSheet;
                        workSheet.Cells[RowIndex, "A"] = Stratum.StratumID;
                        workSheet.Cells[RowIndex, "B"] = Stratum.UniverseSize;
                        workSheet.Cells[RowIndex, "C"] = Stratum.SampleSize;
                        workSheet.Cells[RowIndex, "D"] = Stratum.DifferenceGroup.Group_StandardDeviation;
                        workSheet.Cells[RowIndex, "E"] = Stratum.DifferenceGroup.Group_StandardError;
                        workSheet.Cells[RowIndex, "F"] = Stratum.DifferenceGroup.Group_PointEstimate;
                        workSheet.Cells[RowIndex, "G"] = Stratum.DifferenceGroup.Group_SkewAmt;
                        workSheet.Cells[RowIndex, "H"] = Stratum.DifferenceGroup.Group_KurtAmt;
                        workSheet.Cells[RowIndex, "I"] = Stratum.DifferenceGroup.Group_StandardError * Stratum.UniverseSize;
                        workSheet.Cells[RowIndex, "J"] = Stratum.DifferenceGroup.EightyPercent_Confidence.LowerLimit;
                        workSheet.Cells[RowIndex, "K"] = Stratum.DifferenceGroup.EightyPercent_Confidence.UpperLimit;
                        workSheet.Cells[RowIndex, "L"] = Stratum.DifferenceGroup.EightyPercent_Confidence.PrecisionAmount;
                        workSheet.Cells[RowIndex, "M"] = Stratum.DifferenceGroup.EightyPercent_Confidence.PrecisionPercent;
                        workSheet.Cells[RowIndex, "N"] = Stratum.DifferenceGroup.EightyPercent_Confidence.T_Value;
                        workSheet.Cells[RowIndex, "O"] = Stratum.DifferenceGroup.NinetyPercent_Confidence.LowerLimit;
                        workSheet.Cells[RowIndex, "P"] = Stratum.DifferenceGroup.NinetyPercent_Confidence.UpperLimit;
                        workSheet.Cells[RowIndex, "Q"] = Stratum.DifferenceGroup.NinetyPercent_Confidence.PrecisionAmount;
                        workSheet.Cells[RowIndex, "R"] = Stratum.DifferenceGroup.NinetyPercent_Confidence.PrecisionPercent;
                        workSheet.Cells[RowIndex, "S"] = Stratum.DifferenceGroup.NinetyPercent_Confidence.T_Value;
                        workSheet.Cells[RowIndex, "T"] = Stratum.DifferenceGroup.NinetyFivePercent_Confidence.LowerLimit;
                        workSheet.Cells[RowIndex, "U"] = Stratum.DifferenceGroup.NinetyFivePercent_Confidence.UpperLimit;
                        workSheet.Cells[RowIndex, "V"] = Stratum.DifferenceGroup.NinetyFivePercent_Confidence.PrecisionAmount;
                        workSheet.Cells[RowIndex, "W"] = Stratum.DifferenceGroup.NinetyFivePercent_Confidence.PrecisionPercent;
                        workSheet.Cells[RowIndex, "X"] = Stratum.DifferenceGroup.NinetyFivePercent_Confidence.T_Value;
                        break;
                }

                RowIndex++;
            }
            
            if(OverallExaminedIndex != -1)
            {
                ((Excel.Worksheet)excelApp.ActiveWorkbook.Sheets[OverallExaminedIndex]).Select();
                workSheet = (Excel.Worksheet)excelApp.ActiveSheet;
                workSheet.Cells[2, "A"] = OverallUniverseSize;
                workSheet.Cells[2, "B"] = OverallSampleSize;
                workSheet.Cells[2, "C"] = OverallExaminedGroup.Group_StandardError;
                workSheet.Cells[2, "D"] = OverallExaminedGroup.Group_PointEstimate;

                workSheet.Cells[2, "E"] = OverallExaminedGroup.EightyPercent_Confidence.LowerLimit;
                workSheet.Cells[2, "F"] = OverallExaminedGroup.EightyPercent_Confidence.UpperLimit;
                workSheet.Cells[2, "G"] = OverallExaminedGroup.EightyPercent_Confidence.PrecisionAmount;
                workSheet.Cells[2, "H"] = OverallExaminedGroup.EightyPercent_Confidence.PrecisionPercent;

                workSheet.Cells[2, "I"] = OverallExaminedGroup.EightyPercent_Confidence.T_Value;
                workSheet.Cells[2, "J"] = OverallExaminedGroup.NinetyPercent_Confidence.LowerLimit;
                workSheet.Cells[2, "K"] = OverallExaminedGroup.NinetyPercent_Confidence.UpperLimit;
                workSheet.Cells[2, "L"] = OverallExaminedGroup.NinetyPercent_Confidence.PrecisionAmount;
                workSheet.Cells[2, "M"] = OverallExaminedGroup.NinetyPercent_Confidence.PrecisionPercent;
                workSheet.Cells[2, "N"] = OverallExaminedGroup.NinetyPercent_Confidence.T_Value;
                workSheet.Cells[2, "O"] = OverallExaminedGroup.NinetyFivePercent_Confidence.LowerLimit;
                workSheet.Cells[2, "P"] = OverallExaminedGroup.NinetyFivePercent_Confidence.UpperLimit;
                workSheet.Cells[2, "Q"] = OverallExaminedGroup.NinetyFivePercent_Confidence.PrecisionAmount;
                workSheet.Cells[2, "R"] = OverallExaminedGroup.NinetyFivePercent_Confidence.PrecisionPercent;
                workSheet.Cells[2, "S"] = OverallExaminedGroup.NinetyFivePercent_Confidence.T_Value;
            }

            if(OverallAuditedIndex != -1)
            {
                ((Excel.Worksheet)excelApp.ActiveWorkbook.Sheets[OverallAuditedIndex]).Select();
                workSheet = (Excel.Worksheet)excelApp.ActiveSheet;
                workSheet.Cells[2, "A"] = OverallUniverseSize;
                workSheet.Cells[2, "B"] = OverallSampleSize;
                workSheet.Cells[2, "C"] = OverallAuditedGroup.Group_StandardError;
                workSheet.Cells[2, "D"] = OverallAuditedGroup.Group_PointEstimate;

                workSheet.Cells[2, "E"] = OverallAuditedGroup.EightyPercent_Confidence.LowerLimit;
                workSheet.Cells[2, "F"] = OverallAuditedGroup.EightyPercent_Confidence.UpperLimit;
                workSheet.Cells[2, "G"] = OverallAuditedGroup.EightyPercent_Confidence.PrecisionAmount;
                workSheet.Cells[2, "H"] = OverallAuditedGroup.EightyPercent_Confidence.PrecisionPercent;

                workSheet.Cells[2, "I"] = OverallAuditedGroup.EightyPercent_Confidence.T_Value;
                workSheet.Cells[2, "J"] = OverallAuditedGroup.NinetyPercent_Confidence.LowerLimit;
                workSheet.Cells[2, "K"] = OverallAuditedGroup.NinetyPercent_Confidence.UpperLimit;
                workSheet.Cells[2, "L"] = OverallAuditedGroup.NinetyPercent_Confidence.PrecisionAmount;
                workSheet.Cells[2, "M"] = OverallAuditedGroup.NinetyPercent_Confidence.PrecisionPercent;
                workSheet.Cells[2, "N"] = OverallAuditedGroup.NinetyPercent_Confidence.T_Value;
                workSheet.Cells[2, "O"] = OverallAuditedGroup.NinetyFivePercent_Confidence.LowerLimit;
                workSheet.Cells[2, "P"] = OverallAuditedGroup.NinetyFivePercent_Confidence.UpperLimit;
                workSheet.Cells[2, "Q"] = OverallAuditedGroup.NinetyFivePercent_Confidence.PrecisionAmount;
                workSheet.Cells[2, "R"] = OverallAuditedGroup.NinetyFivePercent_Confidence.PrecisionPercent;
                workSheet.Cells[2, "S"] = OverallAuditedGroup.NinetyFivePercent_Confidence.T_Value;
            }

            if (OverallDifferenceIndex != -1)
            {
                ((Excel.Worksheet)excelApp.ActiveWorkbook.Sheets[OverallDifferenceIndex]).Select();
                workSheet = (Excel.Worksheet)excelApp.ActiveSheet;
                workSheet.Cells[2, "A"] = OverallUniverseSize;
                workSheet.Cells[2, "B"] = OverallSampleSize;
                workSheet.Cells[2, "C"] = OverallDifferenceGroup.Group_StandardError;
                workSheet.Cells[2, "D"] = OverallDifferenceGroup.Group_PointEstimate;

                workSheet.Cells[2, "E"] = OverallDifferenceGroup.EightyPercent_Confidence.LowerLimit;
                workSheet.Cells[2, "F"] = OverallDifferenceGroup.EightyPercent_Confidence.UpperLimit;
                workSheet.Cells[2, "G"] = OverallDifferenceGroup.EightyPercent_Confidence.PrecisionAmount;
                workSheet.Cells[2, "H"] = OverallDifferenceGroup.EightyPercent_Confidence.PrecisionPercent;

                workSheet.Cells[2, "I"] = OverallDifferenceGroup.EightyPercent_Confidence.T_Value;
                workSheet.Cells[2, "J"] = OverallDifferenceGroup.NinetyPercent_Confidence.LowerLimit;
                workSheet.Cells[2, "K"] = OverallDifferenceGroup.NinetyPercent_Confidence.UpperLimit;
                workSheet.Cells[2, "L"] = OverallDifferenceGroup.NinetyPercent_Confidence.PrecisionAmount;
                workSheet.Cells[2, "M"] = OverallDifferenceGroup.NinetyPercent_Confidence.PrecisionPercent;
                workSheet.Cells[2, "N"] = OverallDifferenceGroup.NinetyPercent_Confidence.T_Value;
                workSheet.Cells[2, "O"] = OverallDifferenceGroup.NinetyFivePercent_Confidence.LowerLimit;
                workSheet.Cells[2, "P"] = OverallDifferenceGroup.NinetyFivePercent_Confidence.UpperLimit;
                workSheet.Cells[2, "Q"] = OverallDifferenceGroup.NinetyFivePercent_Confidence.PrecisionAmount;
                workSheet.Cells[2, "R"] = OverallDifferenceGroup.NinetyFivePercent_Confidence.PrecisionPercent;
                workSheet.Cells[2, "S"] = OverallDifferenceGroup.NinetyFivePercent_Confidence.T_Value;
            }

            ((Excel.Worksheet)excelApp.ActiveWorkbook.Sheets[1]).Select();
            try
            {
                if (Path.GetExtension(ExcelFileOutputPath) == ".xls")
                    excelApp.ActiveWorkbook.SaveAs(ExcelFileOutputPath, Excel.XlFileFormat.xlWorkbookNormal);
                else
                    excelApp.ActiveWorkbook.SaveAs(ExcelFileOutputPath, Excel.XlFileFormat.xlOpenXMLWorkbook);
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                workbook.Close();
                excelApp = null;
            } 
        }
    }

    /*****************************************************************************************************
    *   TValue
    *   - Provides support for cacluating a t-value 
    *
    ******************************************************************************************************/
    public class TValue
    {
        private int NumTerms, nterms, DegreesOfFreedom;
        private double tval, tvallast, lowval, highval;
        private double c0, TEMP, TEMPVAL, front, PI, logold, log1, log2, log3, log4, A, B, cumprob, lowprob, highprob, probval, newprob, diff, eps;
        private double[] C = new double[1000];

        private double Findcumprob()
        {
            double xval = Math.Pow(tval, 2) / (Math.Pow(tval, 2) + DegreesOfFreedom);

            if (DegreesOfFreedom == 2)
            {
                c0 = 1.0;
            }
            else if (DegreesOfFreedom == 3)
            {
                c0 = 4.0 / PI;
            }
            else if (DegreesOfFreedom - 2.0 * (int)(DegreesOfFreedom / 2.0) == 0)
            {
                c0 = 1.0;
                nterms = DegreesOfFreedom / 2 - 1;
                for (int I = 1; I <= nterms; I++)
                {
                    TEMP = 2 * I + 1;
                    c0 = (c0 * TEMP) / (TEMP - 1);
                }
            }
            else
            {
                c0 = 4 / PI;
                nterms = ((DegreesOfFreedom - 1) / 2) - 1;
                for (int I = 1; I <= nterms; I++)
                {
                    TEMP = 2 * I + 2;
                    c0 = (c0 * TEMP) / (TEMP - 1);
                }

            }
            front = Math.Pow(1 - xval, B) * Math.Pow(xval, A);
            TEMPVAL = c0;
            C[0] = c0;
            logold = Math.Log(C[0]);
            if (xval == 0)
            {
                TEMPVAL = 0;
            }
            else
            {
                for (int J = 1; J <= NumTerms; J++)
                {
                    log1 = Math.Log((J - 1 + A + B) / (J + A));
                    log2 = logold;
                    log3 = Math.Log(xval);
                    log4 = log1 + log2 + J * Math.Log(xval);
                    logold = log1 + log2;
                    TEMPVAL = TEMPVAL + Math.Exp(log4);
                }
            }
            return 0.5 * (front * TEMPVAL + 1);
        }

        public double? CalculateT(double confidenceinterval, int Degrees)
        {
            try
            {
                NumTerms = 100;
                lowval = 0;
                highval = 4;
                PI = 4.0 * Math.Atan(1);
                eps = 0.00000000000001;
                DegreesOfFreedom = Degrees;
                B = DegreesOfFreedom / 2.0;
                A = 0.5;
                cumprob = confidenceinterval / 200.0 + .5;

                tval = lowval;
                probval = Findcumprob();
                lowprob = probval;
                tval = highval;
                probval = Findcumprob();
                highprob = probval;
                int Count = 1, MaxCount = 1000;
                while (Count < MaxCount)
                {
                    tvallast = tval;
                    tval = (lowval + highval) / 2;
                    probval = Findcumprob();
                    newprob = probval;
                    if (probval < cumprob)
                    {
                        lowval = tval;
                    }
                    else
                    {
                        highval = tval;
                    }
                    diff = Math.Abs(tval - tvallast) - eps;
                    if (diff <= 0)
                    {
                        break;
                    }
                    Count++;
                }
                if (Count == 1000)
                {
                    //Unable to calculate TVal
                    return null;
                }
                return tval;
            }
            catch(Exception)
            {
                return null;
            }
        }
    }
}
