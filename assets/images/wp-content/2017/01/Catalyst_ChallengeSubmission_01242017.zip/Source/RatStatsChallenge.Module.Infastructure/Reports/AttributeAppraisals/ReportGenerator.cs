﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RatStatsChallenge.Module.Infastructure;
namespace RatStatsChallenge.Module.Infastructure.Reports.AttributeAppraisals
{
    /*****************************************************************************************************
    *   Unrestricted_TXT
    *   - Report data class that is passed to the TT Template generator. It contains all of the data needed
    *   to fill out the fields in the Unrestricted Attribute Appraisals Text Report.
    *
    ******************************************************************************************************/
    public partial class Unrestricted_TXT
    {
        private UnrestrictedAttributeAppraisal.ReportData m_RD;
        public Unrestricted_TXT(UnrestrictedAttributeAppraisal.ReportData RD)
        {
            this.m_RD = RD;
        }
    }
}
