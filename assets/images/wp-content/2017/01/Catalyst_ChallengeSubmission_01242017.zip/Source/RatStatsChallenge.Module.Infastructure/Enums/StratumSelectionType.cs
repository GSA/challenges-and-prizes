﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RatStatsChallenge.Module.Infastructure.Enums
{
    public enum StratumSelectionType
    {
        Unknown = 0,
        Overall,
        Specific
    }
}
