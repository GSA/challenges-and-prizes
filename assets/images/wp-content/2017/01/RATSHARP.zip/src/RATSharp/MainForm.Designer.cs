﻿namespace RATSharp
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.Pages = new System.Windows.Forms.TabControl();
            this.RandomNumbersPage = new System.Windows.Forms.TabPage();
            this.RandomNumbersPages = new System.Windows.Forms.TabControl();
            this.RandomSingleSubPage = new System.Windows.Forms.TabPage();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.R_S_GenerateButton = new System.Windows.Forms.Button();
            this.R_S_NameInput = new System.Windows.Forms.TextBox();
            this.R_S_SeedInput = new System.Windows.Forms.TextBox();
            this.R_S_SamplingFrameHighInput = new System.Windows.Forms.NumericUpDown();
            this.R_S_SequentialOrderQuantityInput = new System.Windows.Forms.NumericUpDown();
            this.R_S_SamplingFrameLowInput = new System.Windows.Forms.NumericUpDown();
            this.R_S_SpareQuantityInput = new System.Windows.Forms.NumericUpDown();
            this.RandomStratifiedSubPage = new System.Windows.Forms.TabPage();
            this.R_SS_StratifiedSaveInformationLabel = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.R_SS_StrataCountOutput = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.R_SS_InputGrid = new System.Windows.Forms.DataGridView();
            this.R_SS_SeedNumberInput = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.R_SS_SequentialQuantityInput = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.R_SS_SpareQuantityInput = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.R_SS_FrameLowInput = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.R_SS_FrameHighInput = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label32 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.R_SS_NameInput = new System.Windows.Forms.TextBox();
            this.RandomSetTwoSubPage = new System.Windows.Forms.TabPage();
            this.RandomSetThreeSubPage = new System.Windows.Forms.TabPage();
            this.RandomSetFourSubPage = new System.Windows.Forms.TabPage();
            this.RandomFramesSingleSubPage = new System.Windows.Forms.TabPage();
            this.RandomFramesSetTwoSubPage = new System.Windows.Forms.TabPage();
            this.RandomRHCSubPage = new System.Windows.Forms.TabPage();
            this.AttributeAppraisalsPage = new System.Windows.Forms.TabPage();
            this.AttributeAppraisalsPages = new System.Windows.Forms.TabControl();
            this.AttributeUnrestrictedSubPage = new System.Windows.Forms.TabPage();
            this.AA_U_ConfidenceLevelPercentageLabel = new System.Windows.Forms.Label();
            this.AA_U_ConfidenceLevelCustomizeButton = new System.Windows.Forms.Button();
            this.AA_U_ConfidenceLevelInput = new System.Windows.Forms.NumericUpDown();
            this.AA_U_DefaultLabel = new System.Windows.Forms.Label();
            this.AA_U_DefaultCustomizeLabel = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.AA_U_IntervalTypeInput = new System.Windows.Forms.ComboBox();
            this.AA_U_GenerateButton = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.AA_U_SampleOfInterestSizeInput = new System.Windows.Forms.NumericUpDown();
            this.AA_U_SampleSizeInput = new System.Windows.Forms.NumericUpDown();
            this.AA_U_UniverseSizeInput = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.AA_U_NameInput = new System.Windows.Forms.TextBox();
            this.AttributeStratifiedSubPage = new System.Windows.Forms.TabPage();
            this.AttributeTwoUnrestrictedSubPage = new System.Windows.Forms.TabPage();
            this.AttributeThreeUnrestrictedSubPage = new System.Windows.Forms.TabPage();
            this.AttributeRHCTwoSubPage = new System.Windows.Forms.TabPage();
            this.AttributeRHCThreeSubPage = new System.Windows.Forms.TabPage();
            this.AttributeStratifiedClusterSubPage = new System.Windows.Forms.TabPage();
            this.AttributeStratifiedMultistageSubPage = new System.Windows.Forms.TabPage();
            this.VariableAppraisalsPage = new System.Windows.Forms.TabPage();
            this.VariableAppraisalsPages = new System.Windows.Forms.TabControl();
            this.VariableUnrestrictedSubPage = new System.Windows.Forms.TabPage();
            this.VA_U_PreviewLabel = new System.Windows.Forms.Label();
            this.VA_U_GenerateButton = new System.Windows.Forms.Button();
            this.VA_U_SourceOption2Input = new System.Windows.Forms.ComboBox();
            this.VA_U_SourceOption1Input = new System.Windows.Forms.ComboBox();
            this.VA_U_SourceInput = new System.Windows.Forms.ComboBox();
            this.VA_U_DataFileFormatInput = new System.Windows.Forms.ListBox();
            this.VA_U_SourcePanel = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.VA_U_SourceInputLabel = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.VA_U_SourceOption2Label = new System.Windows.Forms.Label();
            this.VA_U_SourceOption1Label = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.VA_U_SampleSizeInput = new System.Windows.Forms.NumericUpDown();
            this.VA_U_UniverseSizeInput = new System.Windows.Forms.NumericUpDown();
            this.label18 = new System.Windows.Forms.Label();
            this.VA_U_FileInput = new System.Windows.Forms.TextBox();
            this.VA_U_NameInput = new System.Windows.Forms.TextBox();
            this.VariableStratifiedSubPage = new System.Windows.Forms.TabPage();
            this.VA_S_UniverseSourceOption2Input = new System.Windows.Forms.ComboBox();
            this.VA_S_UniverseSourceOption1Input = new System.Windows.Forms.ComboBox();
            this.VA_S_SourceOption2Input = new System.Windows.Forms.ComboBox();
            this.VA_S_SourceOption1Input = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.VA_S_StrataSizeInput = new System.Windows.Forms.NumericUpDown();
            this.VA_S_UniverseSourceOption2Label = new System.Windows.Forms.Label();
            this.VA_S_UniverseSourceOption1Label = new System.Windows.Forms.Label();
            this.VA_S_SourceOption2Label = new System.Windows.Forms.Label();
            this.VA_S_UniverseSourceInput = new System.Windows.Forms.ComboBox();
            this.VA_S_DataFileFormatInput = new System.Windows.Forms.ListBox();
            this.VA_S_UniverseSourcePanel = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.VA_S_UniverseSourceInputLabel = new System.Windows.Forms.Label();
            this.VA_S_UniverseFileLabel = new System.Windows.Forms.Label();
            this.VA_S_UniverseFileInput = new System.Windows.Forms.TextBox();
            this.VA_S_GenerateButton = new System.Windows.Forms.Button();
            this.VA_S_SourceInput = new System.Windows.Forms.ComboBox();
            this.VA_S_SourcePanel = new System.Windows.Forms.Panel();
            this.VA_S_SourceInputLabel = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.VA_S_SourceOption1Label = new System.Windows.Forms.Label();
            this.VA_S_PreviewLabel = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.VA_S_FileInput = new System.Windows.Forms.TextBox();
            this.VA_S_NameInput = new System.Windows.Forms.TextBox();
            this.VariableTwoUnrestrictedSubPage = new System.Windows.Forms.TabPage();
            this.VariableThreeUnrestrictedSubPage = new System.Windows.Forms.TabPage();
            this.VariableRHCTwoSubPage = new System.Windows.Forms.TabPage();
            this.VariableRHCThreeSubPage = new System.Windows.Forms.TabPage();
            this.VariableStratifiedClusterSubPage = new System.Windows.Forms.TabPage();
            this.VariableStratifiedMultistageSubPage = new System.Windows.Forms.TabPage();
            this.VariablePoststratificationSubPage = new System.Windows.Forms.TabPage();
            this.VariableUnknownUniverseSubPage = new System.Windows.Forms.TabPage();
            this.SampleSizeDeterminationPage = new System.Windows.Forms.TabPage();
            this.SampleSizeDeterminationPages = new System.Windows.Forms.TabControl();
            this.SampleVariableSubPage = new System.Windows.Forms.TabPage();
            this.SampleVariablePages = new System.Windows.Forms.TabControl();
            this.SampleVariableUnrestrictedProbeSubPage = new System.Windows.Forms.TabPage();
            this.SampleVariableUnrestrictedEERSubPage = new System.Windows.Forms.TabPage();
            this.SampleVariableStratifiedSubPage = new System.Windows.Forms.TabPage();
            this.SampleAttributeSubPage = new System.Windows.Forms.TabPage();
            this.HelpPage = new System.Windows.Forms.TabPage();
            this.HelpPages = new System.Windows.Forms.TabControl();
            this.HelpTopicsSubpage = new System.Windows.Forms.TabPage();
            this.AboutSubPage = new System.Windows.Forms.TabPage();
            this.AboutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.label20 = new System.Windows.Forms.Label();
            this.AboutLabel = new System.Windows.Forms.Label();
            this.MainStatusStrip = new System.Windows.Forms.StatusStrip();
            this.MainProgressBar = new System.Windows.Forms.ToolStripProgressBar();
            this.MainStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.Modes = new System.Windows.Forms.TabControl();
            this.MainMode = new System.Windows.Forms.TabPage();
            this.PreviewMode = new System.Windows.Forms.TabPage();
            this.PreviewTablePanel = new System.Windows.Forms.TableLayoutPanel();
            this.PreviewControlPanel = new System.Windows.Forms.Panel();
            this.SaveModeInput = new System.Windows.Forms.ListBox();
            this.PrintPreviewButton = new System.Windows.Forms.Button();
            this.SaveFlatButton = new System.Windows.Forms.Button();
            this.SaveAccessButton = new System.Windows.Forms.Button();
            this.SaveExcelButton = new System.Windows.Forms.Button();
            this.SaveTextButton = new System.Windows.Forms.Button();
            this.SaveHTMLButton = new System.Windows.Forms.Button();
            this.PreviewBrowserContainerPanel = new System.Windows.Forms.Panel();
            this.PreviewBrowser = new System.Windows.Forms.WebBrowser();
            this.KeyboardNavigationButton = new System.Windows.Forms.Button();
            this.KeyboardNavigationMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.Pages.SuspendLayout();
            this.RandomNumbersPage.SuspendLayout();
            this.RandomNumbersPages.SuspendLayout();
            this.RandomSingleSubPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.R_S_SamplingFrameHighInput)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.R_S_SequentialOrderQuantityInput)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.R_S_SamplingFrameLowInput)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.R_S_SpareQuantityInput)).BeginInit();
            this.RandomStratifiedSubPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.R_SS_InputGrid)).BeginInit();
            this.AttributeAppraisalsPage.SuspendLayout();
            this.AttributeAppraisalsPages.SuspendLayout();
            this.AttributeUnrestrictedSubPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AA_U_ConfidenceLevelInput)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AA_U_SampleOfInterestSizeInput)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AA_U_SampleSizeInput)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AA_U_UniverseSizeInput)).BeginInit();
            this.VariableAppraisalsPage.SuspendLayout();
            this.VariableAppraisalsPages.SuspendLayout();
            this.VariableUnrestrictedSubPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.VA_U_SampleSizeInput)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.VA_U_UniverseSizeInput)).BeginInit();
            this.VariableStratifiedSubPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.VA_S_StrataSizeInput)).BeginInit();
            this.SampleSizeDeterminationPage.SuspendLayout();
            this.SampleSizeDeterminationPages.SuspendLayout();
            this.SampleVariableSubPage.SuspendLayout();
            this.SampleVariablePages.SuspendLayout();
            this.HelpPage.SuspendLayout();
            this.HelpPages.SuspendLayout();
            this.AboutSubPage.SuspendLayout();
            this.AboutPanel.SuspendLayout();
            this.MainStatusStrip.SuspendLayout();
            this.Modes.SuspendLayout();
            this.MainMode.SuspendLayout();
            this.PreviewMode.SuspendLayout();
            this.PreviewTablePanel.SuspendLayout();
            this.PreviewControlPanel.SuspendLayout();
            this.PreviewBrowserContainerPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // Pages
            // 
            this.Pages.Controls.Add(this.RandomNumbersPage);
            this.Pages.Controls.Add(this.AttributeAppraisalsPage);
            this.Pages.Controls.Add(this.VariableAppraisalsPage);
            this.Pages.Controls.Add(this.SampleSizeDeterminationPage);
            this.Pages.Controls.Add(this.HelpPage);
            this.Pages.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Pages.Location = new System.Drawing.Point(3, 3);
            this.Pages.Multiline = true;
            this.Pages.Name = "Pages";
            this.Pages.SelectedIndex = 0;
            this.Pages.Size = new System.Drawing.Size(1330, 605);
            this.Pages.TabIndex = 0;
            // 
            // RandomNumbersPage
            // 
            this.RandomNumbersPage.Controls.Add(this.RandomNumbersPages);
            this.RandomNumbersPage.Location = new System.Drawing.Point(4, 29);
            this.RandomNumbersPage.Name = "RandomNumbersPage";
            this.RandomNumbersPage.Padding = new System.Windows.Forms.Padding(3);
            this.RandomNumbersPage.Size = new System.Drawing.Size(1322, 572);
            this.RandomNumbersPage.TabIndex = 0;
            this.RandomNumbersPage.Text = "Random Numbers";
            this.RandomNumbersPage.UseVisualStyleBackColor = true;
            // 
            // RandomNumbersPages
            // 
            this.RandomNumbersPages.Controls.Add(this.RandomSingleSubPage);
            this.RandomNumbersPages.Controls.Add(this.RandomStratifiedSubPage);
            this.RandomNumbersPages.Controls.Add(this.RandomSetTwoSubPage);
            this.RandomNumbersPages.Controls.Add(this.RandomSetThreeSubPage);
            this.RandomNumbersPages.Controls.Add(this.RandomSetFourSubPage);
            this.RandomNumbersPages.Controls.Add(this.RandomFramesSingleSubPage);
            this.RandomNumbersPages.Controls.Add(this.RandomFramesSetTwoSubPage);
            this.RandomNumbersPages.Controls.Add(this.RandomRHCSubPage);
            this.RandomNumbersPages.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RandomNumbersPages.Location = new System.Drawing.Point(3, 3);
            this.RandomNumbersPages.Multiline = true;
            this.RandomNumbersPages.Name = "RandomNumbersPages";
            this.RandomNumbersPages.SelectedIndex = 0;
            this.RandomNumbersPages.Size = new System.Drawing.Size(1316, 566);
            this.RandomNumbersPages.TabIndex = 3;
            // 
            // RandomSingleSubPage
            // 
            this.RandomSingleSubPage.Controls.Add(this.label5);
            this.RandomSingleSubPage.Controls.Add(this.label8);
            this.RandomSingleSubPage.Controls.Add(this.label7);
            this.RandomSingleSubPage.Controls.Add(this.label4);
            this.RandomSingleSubPage.Controls.Add(this.label6);
            this.RandomSingleSubPage.Controls.Add(this.label3);
            this.RandomSingleSubPage.Controls.Add(this.label2);
            this.RandomSingleSubPage.Controls.Add(this.label1);
            this.RandomSingleSubPage.Controls.Add(this.R_S_GenerateButton);
            this.RandomSingleSubPage.Controls.Add(this.R_S_NameInput);
            this.RandomSingleSubPage.Controls.Add(this.R_S_SeedInput);
            this.RandomSingleSubPage.Controls.Add(this.R_S_SamplingFrameHighInput);
            this.RandomSingleSubPage.Controls.Add(this.R_S_SequentialOrderQuantityInput);
            this.RandomSingleSubPage.Controls.Add(this.R_S_SamplingFrameLowInput);
            this.RandomSingleSubPage.Controls.Add(this.R_S_SpareQuantityInput);
            this.RandomSingleSubPage.Location = new System.Drawing.Point(4, 54);
            this.RandomSingleSubPage.Name = "RandomSingleSubPage";
            this.RandomSingleSubPage.Padding = new System.Windows.Forms.Padding(3);
            this.RandomSingleSubPage.Size = new System.Drawing.Size(1308, 508);
            this.RandomSingleSubPage.TabIndex = 0;
            this.RandomSingleSubPage.Text = "Single Stage Random Numbers";
            this.RandomSingleSubPage.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(544, 95);
            this.label5.Margin = new System.Windows.Forms.Padding(8);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(185, 20);
            this.label5.TabIndex = 3;
            this.label5.Text = "Spares in Random Order";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(544, 173);
            this.label8.Margin = new System.Windows.Forms.Padding(8);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(102, 20);
            this.label8.TabIndex = 3;
            this.label8.Text = "High Number";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(384, 173);
            this.label7.Margin = new System.Windows.Forms.Padding(8);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 20);
            this.label7.TabIndex = 3;
            this.label7.Text = "Low Number";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(384, 95);
            this.label4.Margin = new System.Windows.Forms.Padding(8);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(129, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Sequential Order";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(11, 211);
            this.label6.Margin = new System.Windows.Forms.Padding(8);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(152, 20);
            this.label6.TabIndex = 3;
            this.label6.Text = "The sampling frame:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 133);
            this.label3.Margin = new System.Windows.Forms.Padding(8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(356, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Enter the quantity of numbers to be generated in:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 56);
            this.label2.Margin = new System.Windows.Forms.Padding(8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(187, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Name of the audit/review:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 14);
            this.label1.Margin = new System.Windows.Forms.Padding(8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(385, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Seed number (leave blank to generate random seed):";
            // 
            // R_S_GenerateButton
            // 
            this.R_S_GenerateButton.Location = new System.Drawing.Point(572, 405);
            this.R_S_GenerateButton.Margin = new System.Windows.Forms.Padding(8);
            this.R_S_GenerateButton.Name = "R_S_GenerateButton";
            this.R_S_GenerateButton.Size = new System.Drawing.Size(120, 55);
            this.R_S_GenerateButton.TabIndex = 6;
            this.R_S_GenerateButton.Text = "GENERATE";
            this.R_S_GenerateButton.UseVisualStyleBackColor = true;
            this.R_S_GenerateButton.Click += new System.EventHandler(this.R_S_GenerateButton_Click);
            // 
            // R_S_NameInput
            // 
            this.R_S_NameInput.Location = new System.Drawing.Point(214, 53);
            this.R_S_NameInput.Margin = new System.Windows.Forms.Padding(8);
            this.R_S_NameInput.MaxLength = 40;
            this.R_S_NameInput.Name = "R_S_NameInput";
            this.R_S_NameInput.Size = new System.Drawing.Size(318, 26);
            this.R_S_NameInput.TabIndex = 1;
            // 
            // R_S_SeedInput
            // 
            this.R_S_SeedInput.Location = new System.Drawing.Point(412, 11);
            this.R_S_SeedInput.Margin = new System.Windows.Forms.Padding(8);
            this.R_S_SeedInput.Name = "R_S_SeedInput";
            this.R_S_SeedInput.Size = new System.Drawing.Size(120, 26);
            this.R_S_SeedInput.TabIndex = 0;
            this.R_S_SeedInput.Validating += new System.ComponentModel.CancelEventHandler(this.R_S_SeedInput_Validating);
            // 
            // R_S_SamplingFrameHighInput
            // 
            this.R_S_SamplingFrameHighInput.Location = new System.Drawing.Point(548, 209);
            this.R_S_SamplingFrameHighInput.Margin = new System.Windows.Forms.Padding(8);
            this.R_S_SamplingFrameHighInput.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.R_S_SamplingFrameHighInput.Name = "R_S_SamplingFrameHighInput";
            this.R_S_SamplingFrameHighInput.Size = new System.Drawing.Size(144, 26);
            this.R_S_SamplingFrameHighInput.TabIndex = 5;
            this.R_S_SamplingFrameHighInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.R_S_SamplingFrameHighInput.ThousandsSeparator = true;
            this.R_S_SamplingFrameHighInput.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // R_S_SequentialOrderQuantityInput
            // 
            this.R_S_SequentialOrderQuantityInput.Location = new System.Drawing.Point(388, 131);
            this.R_S_SequentialOrderQuantityInput.Margin = new System.Windows.Forms.Padding(8);
            this.R_S_SequentialOrderQuantityInput.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.R_S_SequentialOrderQuantityInput.Name = "R_S_SequentialOrderQuantityInput";
            this.R_S_SequentialOrderQuantityInput.Size = new System.Drawing.Size(144, 26);
            this.R_S_SequentialOrderQuantityInput.TabIndex = 2;
            this.R_S_SequentialOrderQuantityInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.R_S_SequentialOrderQuantityInput.ThousandsSeparator = true;
            this.R_S_SequentialOrderQuantityInput.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // R_S_SamplingFrameLowInput
            // 
            this.R_S_SamplingFrameLowInput.Location = new System.Drawing.Point(388, 209);
            this.R_S_SamplingFrameLowInput.Margin = new System.Windows.Forms.Padding(8);
            this.R_S_SamplingFrameLowInput.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.R_S_SamplingFrameLowInput.Name = "R_S_SamplingFrameLowInput";
            this.R_S_SamplingFrameLowInput.Size = new System.Drawing.Size(144, 26);
            this.R_S_SamplingFrameLowInput.TabIndex = 4;
            this.R_S_SamplingFrameLowInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.R_S_SamplingFrameLowInput.ThousandsSeparator = true;
            this.R_S_SamplingFrameLowInput.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // R_S_SpareQuantityInput
            // 
            this.R_S_SpareQuantityInput.Location = new System.Drawing.Point(548, 131);
            this.R_S_SpareQuantityInput.Margin = new System.Windows.Forms.Padding(8);
            this.R_S_SpareQuantityInput.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.R_S_SpareQuantityInput.Name = "R_S_SpareQuantityInput";
            this.R_S_SpareQuantityInput.Size = new System.Drawing.Size(144, 26);
            this.R_S_SpareQuantityInput.TabIndex = 3;
            this.R_S_SpareQuantityInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.R_S_SpareQuantityInput.ThousandsSeparator = true;
            this.R_S_SpareQuantityInput.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // RandomStratifiedSubPage
            // 
            this.RandomStratifiedSubPage.Controls.Add(this.R_SS_StratifiedSaveInformationLabel);
            this.RandomStratifiedSubPage.Controls.Add(this.label25);
            this.RandomStratifiedSubPage.Controls.Add(this.R_SS_StrataCountOutput);
            this.RandomStratifiedSubPage.Controls.Add(this.label24);
            this.RandomStratifiedSubPage.Controls.Add(this.R_SS_InputGrid);
            this.RandomStratifiedSubPage.Controls.Add(this.label32);
            this.RandomStratifiedSubPage.Controls.Add(this.button1);
            this.RandomStratifiedSubPage.Controls.Add(this.R_SS_NameInput);
            this.RandomStratifiedSubPage.Location = new System.Drawing.Point(4, 54);
            this.RandomStratifiedSubPage.Name = "RandomStratifiedSubPage";
            this.RandomStratifiedSubPage.Padding = new System.Windows.Forms.Padding(3);
            this.RandomStratifiedSubPage.Size = new System.Drawing.Size(1308, 508);
            this.RandomStratifiedSubPage.TabIndex = 7;
            this.RandomStratifiedSubPage.Text = "Stratified Single Stage Random Numbers";
            this.RandomStratifiedSubPage.UseVisualStyleBackColor = true;
            // 
            // R_SS_StratifiedSaveInformationLabel
            // 
            this.R_SS_StratifiedSaveInformationLabel.AutoSize = true;
            this.R_SS_StratifiedSaveInformationLabel.Location = new System.Drawing.Point(11, 476);
            this.R_SS_StratifiedSaveInformationLabel.Margin = new System.Windows.Forms.Padding(8);
            this.R_SS_StratifiedSaveInformationLabel.Name = "R_SS_StratifiedSaveInformationLabel";
            this.R_SS_StratifiedSaveInformationLabel.Size = new System.Drawing.Size(829, 20);
            this.R_SS_StratifiedSaveInformationLabel.TabIndex = 26;
            this.R_SS_StratifiedSaveInformationLabel.Text = "More than 1 stratum entered. Your save files will be automatically appended with " +
    "stratum index (e.g. \"*_Stratum1.txt\")";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(11, 394);
            this.label25.Margin = new System.Windows.Forms.Padding(8);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(131, 20);
            this.label25.TabIndex = 25;
            this.label25.Text = "Number of Strata";
            // 
            // R_SS_StrataCountOutput
            // 
            this.R_SS_StrataCountOutput.Location = new System.Drawing.Point(158, 391);
            this.R_SS_StrataCountOutput.Margin = new System.Windows.Forms.Padding(8);
            this.R_SS_StrataCountOutput.MaxLength = 40;
            this.R_SS_StrataCountOutput.Name = "R_SS_StrataCountOutput";
            this.R_SS_StrataCountOutput.ReadOnly = true;
            this.R_SS_StrataCountOutput.Size = new System.Drawing.Size(125, 26);
            this.R_SS_StrataCountOutput.TabIndex = 24;
            this.R_SS_StrataCountOutput.TabStop = false;
            this.R_SS_StrataCountOutput.Text = "0";
            this.R_SS_StrataCountOutput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.R_SS_StrataCountOutput.TextChanged += new System.EventHandler(this.R_SS_StrataCountOutput_TextChanged);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(11, 95);
            this.label24.Margin = new System.Windows.Forms.Padding(8);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(652, 20);
            this.label24.TabIndex = 23;
            this.label24.Text = "Enter details for Strata (leave Seed Number blank to automatically generate Seed " +
    "Number):";
            // 
            // R_SS_InputGrid
            // 
            this.R_SS_InputGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.R_SS_InputGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.R_SS_SeedNumberInput,
            this.R_SS_SequentialQuantityInput,
            this.R_SS_SpareQuantityInput,
            this.R_SS_FrameLowInput,
            this.R_SS_FrameHighInput});
            this.R_SS_InputGrid.Location = new System.Drawing.Point(15, 131);
            this.R_SS_InputGrid.Margin = new System.Windows.Forms.Padding(8);
            this.R_SS_InputGrid.Name = "R_SS_InputGrid";
            this.R_SS_InputGrid.RowTemplate.Height = 28;
            this.R_SS_InputGrid.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.R_SS_InputGrid.Size = new System.Drawing.Size(677, 244);
            this.R_SS_InputGrid.TabIndex = 1;
            this.R_SS_InputGrid.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.R_SS_InputGrid_CellValidating);
            this.R_SS_InputGrid.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.R_SS_InputGrid_DataError);
            this.R_SS_InputGrid.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.R_SS_InputGrid_EditingControlShowing);
            this.R_SS_InputGrid.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.R_SS_InputGrid_RowsRemoved);
            // 
            // R_SS_SeedNumberInput
            // 
            this.R_SS_SeedNumberInput.HeaderText = "Seed Number";
            this.R_SS_SeedNumberInput.Name = "R_SS_SeedNumberInput";
            // 
            // R_SS_SequentialQuantityInput
            // 
            this.R_SS_SequentialQuantityInput.HeaderText = "Sequential Quantity";
            this.R_SS_SequentialQuantityInput.Name = "R_SS_SequentialQuantityInput";
            this.R_SS_SequentialQuantityInput.Width = 139;
            // 
            // R_SS_SpareQuantityInput
            // 
            this.R_SS_SpareQuantityInput.HeaderText = "Spare Quantity";
            this.R_SS_SpareQuantityInput.Name = "R_SS_SpareQuantityInput";
            this.R_SS_SpareQuantityInput.Width = 109;
            // 
            // R_SS_FrameLowInput
            // 
            this.R_SS_FrameLowInput.HeaderText = "Frame Low";
            this.R_SS_FrameLowInput.Name = "R_SS_FrameLowInput";
            this.R_SS_FrameLowInput.Width = 85;
            // 
            // R_SS_FrameHighInput
            // 
            this.R_SS_FrameHighInput.HeaderText = "Frame High";
            this.R_SS_FrameHighInput.Name = "R_SS_FrameHighInput";
            this.R_SS_FrameHighInput.Width = 88;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(11, 56);
            this.label32.Margin = new System.Windows.Forms.Padding(8);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(187, 20);
            this.label32.TabIndex = 16;
            this.label32.Text = "Name of the audit/review:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(572, 405);
            this.button1.Margin = new System.Windows.Forms.Padding(8);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(120, 55);
            this.button1.TabIndex = 2;
            this.button1.Text = "GENERATE";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.R_SS_GenerateButton_Click);
            // 
            // R_SS_NameInput
            // 
            this.R_SS_NameInput.Location = new System.Drawing.Point(214, 53);
            this.R_SS_NameInput.Margin = new System.Windows.Forms.Padding(8);
            this.R_SS_NameInput.MaxLength = 40;
            this.R_SS_NameInput.Name = "R_SS_NameInput";
            this.R_SS_NameInput.Size = new System.Drawing.Size(318, 26);
            this.R_SS_NameInput.TabIndex = 0;
            // 
            // RandomSetTwoSubPage
            // 
            this.RandomSetTwoSubPage.Location = new System.Drawing.Point(4, 54);
            this.RandomSetTwoSubPage.Name = "RandomSetTwoSubPage";
            this.RandomSetTwoSubPage.Padding = new System.Windows.Forms.Padding(3);
            this.RandomSetTwoSubPage.Size = new System.Drawing.Size(1308, 508);
            this.RandomSetTwoSubPage.TabIndex = 1;
            this.RandomSetTwoSubPage.Text = "Sets of Two Numbers";
            this.RandomSetTwoSubPage.UseVisualStyleBackColor = true;
            // 
            // RandomSetThreeSubPage
            // 
            this.RandomSetThreeSubPage.Location = new System.Drawing.Point(4, 54);
            this.RandomSetThreeSubPage.Name = "RandomSetThreeSubPage";
            this.RandomSetThreeSubPage.Padding = new System.Windows.Forms.Padding(3);
            this.RandomSetThreeSubPage.Size = new System.Drawing.Size(1308, 508);
            this.RandomSetThreeSubPage.TabIndex = 2;
            this.RandomSetThreeSubPage.Text = "Sets of Three Numbers";
            this.RandomSetThreeSubPage.UseVisualStyleBackColor = true;
            // 
            // RandomSetFourSubPage
            // 
            this.RandomSetFourSubPage.Location = new System.Drawing.Point(4, 54);
            this.RandomSetFourSubPage.Name = "RandomSetFourSubPage";
            this.RandomSetFourSubPage.Size = new System.Drawing.Size(1308, 508);
            this.RandomSetFourSubPage.TabIndex = 3;
            this.RandomSetFourSubPage.Text = "Sets of Four Numbers";
            this.RandomSetFourSubPage.UseVisualStyleBackColor = true;
            // 
            // RandomFramesSingleSubPage
            // 
            this.RandomFramesSingleSubPage.Location = new System.Drawing.Point(4, 54);
            this.RandomFramesSingleSubPage.Name = "RandomFramesSingleSubPage";
            this.RandomFramesSingleSubPage.Size = new System.Drawing.Size(1308, 508);
            this.RandomFramesSingleSubPage.TabIndex = 4;
            this.RandomFramesSingleSubPage.Text = "Frames - Single Stage";
            this.RandomFramesSingleSubPage.UseVisualStyleBackColor = true;
            // 
            // RandomFramesSetTwoSubPage
            // 
            this.RandomFramesSetTwoSubPage.Location = new System.Drawing.Point(4, 54);
            this.RandomFramesSetTwoSubPage.Name = "RandomFramesSetTwoSubPage";
            this.RandomFramesSetTwoSubPage.Size = new System.Drawing.Size(1308, 508);
            this.RandomFramesSetTwoSubPage.TabIndex = 5;
            this.RandomFramesSetTwoSubPage.Text = "Frames - Sets of Two Numbers";
            this.RandomFramesSetTwoSubPage.UseVisualStyleBackColor = true;
            // 
            // RandomRHCSubPage
            // 
            this.RandomRHCSubPage.Location = new System.Drawing.Point(4, 54);
            this.RandomRHCSubPage.Name = "RandomRHCSubPage";
            this.RandomRHCSubPage.Size = new System.Drawing.Size(1308, 508);
            this.RandomRHCSubPage.TabIndex = 6;
            this.RandomRHCSubPage.Text = "RHC Sample Selection";
            this.RandomRHCSubPage.UseVisualStyleBackColor = true;
            // 
            // AttributeAppraisalsPage
            // 
            this.AttributeAppraisalsPage.Controls.Add(this.AttributeAppraisalsPages);
            this.AttributeAppraisalsPage.Location = new System.Drawing.Point(4, 29);
            this.AttributeAppraisalsPage.Name = "AttributeAppraisalsPage";
            this.AttributeAppraisalsPage.Padding = new System.Windows.Forms.Padding(3);
            this.AttributeAppraisalsPage.Size = new System.Drawing.Size(1322, 572);
            this.AttributeAppraisalsPage.TabIndex = 1;
            this.AttributeAppraisalsPage.Text = "Attribute Appraisals";
            this.AttributeAppraisalsPage.UseVisualStyleBackColor = true;
            // 
            // AttributeAppraisalsPages
            // 
            this.AttributeAppraisalsPages.Controls.Add(this.AttributeUnrestrictedSubPage);
            this.AttributeAppraisalsPages.Controls.Add(this.AttributeStratifiedSubPage);
            this.AttributeAppraisalsPages.Controls.Add(this.AttributeTwoUnrestrictedSubPage);
            this.AttributeAppraisalsPages.Controls.Add(this.AttributeThreeUnrestrictedSubPage);
            this.AttributeAppraisalsPages.Controls.Add(this.AttributeRHCTwoSubPage);
            this.AttributeAppraisalsPages.Controls.Add(this.AttributeRHCThreeSubPage);
            this.AttributeAppraisalsPages.Controls.Add(this.AttributeStratifiedClusterSubPage);
            this.AttributeAppraisalsPages.Controls.Add(this.AttributeStratifiedMultistageSubPage);
            this.AttributeAppraisalsPages.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AttributeAppraisalsPages.Location = new System.Drawing.Point(3, 3);
            this.AttributeAppraisalsPages.Name = "AttributeAppraisalsPages";
            this.AttributeAppraisalsPages.SelectedIndex = 0;
            this.AttributeAppraisalsPages.Size = new System.Drawing.Size(1316, 566);
            this.AttributeAppraisalsPages.TabIndex = 0;
            // 
            // AttributeUnrestrictedSubPage
            // 
            this.AttributeUnrestrictedSubPage.Controls.Add(this.AA_U_ConfidenceLevelPercentageLabel);
            this.AttributeUnrestrictedSubPage.Controls.Add(this.AA_U_ConfidenceLevelCustomizeButton);
            this.AttributeUnrestrictedSubPage.Controls.Add(this.AA_U_ConfidenceLevelInput);
            this.AttributeUnrestrictedSubPage.Controls.Add(this.AA_U_DefaultLabel);
            this.AttributeUnrestrictedSubPage.Controls.Add(this.AA_U_DefaultCustomizeLabel);
            this.AttributeUnrestrictedSubPage.Controls.Add(this.label15);
            this.AttributeUnrestrictedSubPage.Controls.Add(this.label13);
            this.AttributeUnrestrictedSubPage.Controls.Add(this.AA_U_IntervalTypeInput);
            this.AttributeUnrestrictedSubPage.Controls.Add(this.AA_U_GenerateButton);
            this.AttributeUnrestrictedSubPage.Controls.Add(this.label12);
            this.AttributeUnrestrictedSubPage.Controls.Add(this.label11);
            this.AttributeUnrestrictedSubPage.Controls.Add(this.label10);
            this.AttributeUnrestrictedSubPage.Controls.Add(this.AA_U_SampleOfInterestSizeInput);
            this.AttributeUnrestrictedSubPage.Controls.Add(this.AA_U_SampleSizeInput);
            this.AttributeUnrestrictedSubPage.Controls.Add(this.AA_U_UniverseSizeInput);
            this.AttributeUnrestrictedSubPage.Controls.Add(this.label9);
            this.AttributeUnrestrictedSubPage.Controls.Add(this.AA_U_NameInput);
            this.AttributeUnrestrictedSubPage.Location = new System.Drawing.Point(4, 29);
            this.AttributeUnrestrictedSubPage.Name = "AttributeUnrestrictedSubPage";
            this.AttributeUnrestrictedSubPage.Padding = new System.Windows.Forms.Padding(3);
            this.AttributeUnrestrictedSubPage.Size = new System.Drawing.Size(1308, 533);
            this.AttributeUnrestrictedSubPage.TabIndex = 0;
            this.AttributeUnrestrictedSubPage.Text = "Unrestricted";
            this.AttributeUnrestrictedSubPage.UseVisualStyleBackColor = true;
            // 
            // AA_U_ConfidenceLevelPercentageLabel
            // 
            this.AA_U_ConfidenceLevelPercentageLabel.AutoSize = true;
            this.AA_U_ConfidenceLevelPercentageLabel.Location = new System.Drawing.Point(345, 226);
            this.AA_U_ConfidenceLevelPercentageLabel.Margin = new System.Windows.Forms.Padding(3, 8, 8, 8);
            this.AA_U_ConfidenceLevelPercentageLabel.Name = "AA_U_ConfidenceLevelPercentageLabel";
            this.AA_U_ConfidenceLevelPercentageLabel.Size = new System.Drawing.Size(23, 20);
            this.AA_U_ConfidenceLevelPercentageLabel.TabIndex = 14;
            this.AA_U_ConfidenceLevelPercentageLabel.Text = "%";
            // 
            // AA_U_ConfidenceLevelCustomizeButton
            // 
            this.AA_U_ConfidenceLevelCustomizeButton.Location = new System.Drawing.Point(214, 260);
            this.AA_U_ConfidenceLevelCustomizeButton.Name = "AA_U_ConfidenceLevelCustomizeButton";
            this.AA_U_ConfidenceLevelCustomizeButton.Size = new System.Drawing.Size(125, 34);
            this.AA_U_ConfidenceLevelCustomizeButton.TabIndex = 6;
            this.AA_U_ConfidenceLevelCustomizeButton.Text = "Customize...";
            this.AA_U_ConfidenceLevelCustomizeButton.UseVisualStyleBackColor = true;
            this.AA_U_ConfidenceLevelCustomizeButton.Click += new System.EventHandler(this.AA_U_ConfidenceLevelCustomizeButton_Click);
            // 
            // AA_U_ConfidenceLevelInput
            // 
            this.AA_U_ConfidenceLevelInput.Location = new System.Drawing.Point(214, 223);
            this.AA_U_ConfidenceLevelInput.Margin = new System.Windows.Forms.Padding(8, 8, 3, 8);
            this.AA_U_ConfidenceLevelInput.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.AA_U_ConfidenceLevelInput.Name = "AA_U_ConfidenceLevelInput";
            this.AA_U_ConfidenceLevelInput.Size = new System.Drawing.Size(125, 26);
            this.AA_U_ConfidenceLevelInput.TabIndex = 5;
            this.AA_U_ConfidenceLevelInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.AA_U_ConfidenceLevelInput.ThousandsSeparator = true;
            this.AA_U_ConfidenceLevelInput.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            this.AA_U_ConfidenceLevelInput.Value = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.AA_U_ConfidenceLevelInput.VisibleChanged += new System.EventHandler(this.AA_U_ConfidenceLevelInput_VisibleChanged);
            this.AA_U_ConfidenceLevelInput.Validating += new System.ComponentModel.CancelEventHandler(this.AA_U_ConfidenceLevelInput_Validating);
            // 
            // AA_U_DefaultLabel
            // 
            this.AA_U_DefaultLabel.AutoSize = true;
            this.AA_U_DefaultLabel.Location = new System.Drawing.Point(210, 226);
            this.AA_U_DefaultLabel.Margin = new System.Windows.Forms.Padding(8);
            this.AA_U_DefaultLabel.Name = "AA_U_DefaultLabel";
            this.AA_U_DefaultLabel.Size = new System.Drawing.Size(191, 20);
            this.AA_U_DefaultLabel.TabIndex = 11;
            this.AA_U_DefaultLabel.Text = "Default: {80%, 90%, 95%}";
            // 
            // AA_U_DefaultCustomizeLabel
            // 
            this.AA_U_DefaultCustomizeLabel.AutoSize = true;
            this.AA_U_DefaultCustomizeLabel.Location = new System.Drawing.Point(350, 267);
            this.AA_U_DefaultCustomizeLabel.Margin = new System.Windows.Forms.Padding(8);
            this.AA_U_DefaultCustomizeLabel.Name = "AA_U_DefaultCustomizeLabel";
            this.AA_U_DefaultCustomizeLabel.Size = new System.Drawing.Size(191, 20);
            this.AA_U_DefaultCustomizeLabel.TabIndex = 11;
            this.AA_U_DefaultCustomizeLabel.Text = "Default: {80%, 90%, 95%}";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(11, 225);
            this.label15.Margin = new System.Windows.Forms.Padding(8);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(131, 20);
            this.label15.TabIndex = 11;
            this.label15.Text = "Confidence Level";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(11, 182);
            this.label13.Margin = new System.Windows.Forms.Padding(8);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(95, 20);
            this.label13.TabIndex = 10;
            this.label13.Text = "Interval type";
            // 
            // AA_U_IntervalTypeInput
            // 
            this.AA_U_IntervalTypeInput.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AA_U_IntervalTypeInput.FormattingEnabled = true;
            this.AA_U_IntervalTypeInput.Items.AddRange(new object[] {
            "One-sided interval",
            "Two-sided interval"});
            this.AA_U_IntervalTypeInput.Location = new System.Drawing.Point(214, 179);
            this.AA_U_IntervalTypeInput.Margin = new System.Windows.Forms.Padding(8);
            this.AA_U_IntervalTypeInput.Name = "AA_U_IntervalTypeInput";
            this.AA_U_IntervalTypeInput.Size = new System.Drawing.Size(176, 28);
            this.AA_U_IntervalTypeInput.TabIndex = 4;
            // 
            // AA_U_GenerateButton
            // 
            this.AA_U_GenerateButton.Location = new System.Drawing.Point(436, 405);
            this.AA_U_GenerateButton.Margin = new System.Windows.Forms.Padding(8);
            this.AA_U_GenerateButton.Name = "AA_U_GenerateButton";
            this.AA_U_GenerateButton.Size = new System.Drawing.Size(120, 55);
            this.AA_U_GenerateButton.TabIndex = 7;
            this.AA_U_GenerateButton.Text = "GENERATE";
            this.AA_U_GenerateButton.UseVisualStyleBackColor = true;
            this.AA_U_GenerateButton.Click += new System.EventHandler(this.AA_U_GenerateButton_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(11, 139);
            this.label12.Margin = new System.Windows.Forms.Padding(8);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(385, 20);
            this.label12.TabIndex = 7;
            this.label12.Text = "Number of sample items with characteristic of interest";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(11, 97);
            this.label11.Margin = new System.Windows.Forms.Padding(8);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(98, 20);
            this.label11.TabIndex = 7;
            this.label11.Text = "Sample Size";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(11, 55);
            this.label10.Margin = new System.Windows.Forms.Padding(8);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(106, 20);
            this.label10.TabIndex = 7;
            this.label10.Text = "Universe Size";
            // 
            // AA_U_SampleOfInterestSizeInput
            // 
            this.AA_U_SampleOfInterestSizeInput.Location = new System.Drawing.Point(412, 137);
            this.AA_U_SampleOfInterestSizeInput.Margin = new System.Windows.Forms.Padding(8);
            this.AA_U_SampleOfInterestSizeInput.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.AA_U_SampleOfInterestSizeInput.Name = "AA_U_SampleOfInterestSizeInput";
            this.AA_U_SampleOfInterestSizeInput.Size = new System.Drawing.Size(144, 26);
            this.AA_U_SampleOfInterestSizeInput.TabIndex = 3;
            this.AA_U_SampleOfInterestSizeInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.AA_U_SampleOfInterestSizeInput.ThousandsSeparator = true;
            this.AA_U_SampleOfInterestSizeInput.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            this.AA_U_SampleOfInterestSizeInput.Validating += new System.ComponentModel.CancelEventHandler(this.AA_U_SampleOfInterestSizeInput_Validating);
            // 
            // AA_U_SampleSizeInput
            // 
            this.AA_U_SampleSizeInput.Location = new System.Drawing.Point(214, 95);
            this.AA_U_SampleSizeInput.Margin = new System.Windows.Forms.Padding(8);
            this.AA_U_SampleSizeInput.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.AA_U_SampleSizeInput.Name = "AA_U_SampleSizeInput";
            this.AA_U_SampleSizeInput.Size = new System.Drawing.Size(144, 26);
            this.AA_U_SampleSizeInput.TabIndex = 2;
            this.AA_U_SampleSizeInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.AA_U_SampleSizeInput.ThousandsSeparator = true;
            this.AA_U_SampleSizeInput.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // AA_U_UniverseSizeInput
            // 
            this.AA_U_UniverseSizeInput.Location = new System.Drawing.Point(214, 53);
            this.AA_U_UniverseSizeInput.Margin = new System.Windows.Forms.Padding(8);
            this.AA_U_UniverseSizeInput.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.AA_U_UniverseSizeInput.Name = "AA_U_UniverseSizeInput";
            this.AA_U_UniverseSizeInput.Size = new System.Drawing.Size(144, 26);
            this.AA_U_UniverseSizeInput.TabIndex = 1;
            this.AA_U_UniverseSizeInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.AA_U_UniverseSizeInput.ThousandsSeparator = true;
            this.AA_U_UniverseSizeInput.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(11, 14);
            this.label9.Margin = new System.Windows.Forms.Padding(8);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(187, 20);
            this.label9.TabIndex = 5;
            this.label9.Text = "Name of the audit/review:";
            // 
            // AA_U_NameInput
            // 
            this.AA_U_NameInput.Location = new System.Drawing.Point(214, 11);
            this.AA_U_NameInput.Margin = new System.Windows.Forms.Padding(8);
            this.AA_U_NameInput.MaxLength = 40;
            this.AA_U_NameInput.Name = "AA_U_NameInput";
            this.AA_U_NameInput.Size = new System.Drawing.Size(318, 26);
            this.AA_U_NameInput.TabIndex = 0;
            // 
            // AttributeStratifiedSubPage
            // 
            this.AttributeStratifiedSubPage.Location = new System.Drawing.Point(4, 29);
            this.AttributeStratifiedSubPage.Name = "AttributeStratifiedSubPage";
            this.AttributeStratifiedSubPage.Padding = new System.Windows.Forms.Padding(3);
            this.AttributeStratifiedSubPage.Size = new System.Drawing.Size(1308, 533);
            this.AttributeStratifiedSubPage.TabIndex = 1;
            this.AttributeStratifiedSubPage.Text = "Stratified";
            this.AttributeStratifiedSubPage.UseVisualStyleBackColor = true;
            // 
            // AttributeTwoUnrestrictedSubPage
            // 
            this.AttributeTwoUnrestrictedSubPage.Location = new System.Drawing.Point(4, 29);
            this.AttributeTwoUnrestrictedSubPage.Name = "AttributeTwoUnrestrictedSubPage";
            this.AttributeTwoUnrestrictedSubPage.Size = new System.Drawing.Size(1308, 533);
            this.AttributeTwoUnrestrictedSubPage.TabIndex = 2;
            this.AttributeTwoUnrestrictedSubPage.Text = "Two-Stage Unrestricted";
            this.AttributeTwoUnrestrictedSubPage.UseVisualStyleBackColor = true;
            // 
            // AttributeThreeUnrestrictedSubPage
            // 
            this.AttributeThreeUnrestrictedSubPage.Location = new System.Drawing.Point(4, 29);
            this.AttributeThreeUnrestrictedSubPage.Name = "AttributeThreeUnrestrictedSubPage";
            this.AttributeThreeUnrestrictedSubPage.Size = new System.Drawing.Size(1308, 533);
            this.AttributeThreeUnrestrictedSubPage.TabIndex = 3;
            this.AttributeThreeUnrestrictedSubPage.Text = "Three-Stage Unrestricted";
            this.AttributeThreeUnrestrictedSubPage.UseVisualStyleBackColor = true;
            // 
            // AttributeRHCTwoSubPage
            // 
            this.AttributeRHCTwoSubPage.Location = new System.Drawing.Point(4, 29);
            this.AttributeRHCTwoSubPage.Name = "AttributeRHCTwoSubPage";
            this.AttributeRHCTwoSubPage.Size = new System.Drawing.Size(1308, 533);
            this.AttributeRHCTwoSubPage.TabIndex = 4;
            this.AttributeRHCTwoSubPage.Text = "RHC Two-Stage";
            this.AttributeRHCTwoSubPage.UseVisualStyleBackColor = true;
            // 
            // AttributeRHCThreeSubPage
            // 
            this.AttributeRHCThreeSubPage.Location = new System.Drawing.Point(4, 29);
            this.AttributeRHCThreeSubPage.Name = "AttributeRHCThreeSubPage";
            this.AttributeRHCThreeSubPage.Size = new System.Drawing.Size(1308, 533);
            this.AttributeRHCThreeSubPage.TabIndex = 5;
            this.AttributeRHCThreeSubPage.Text = "RHC Three-Stage";
            this.AttributeRHCThreeSubPage.UseVisualStyleBackColor = true;
            // 
            // AttributeStratifiedClusterSubPage
            // 
            this.AttributeStratifiedClusterSubPage.Location = new System.Drawing.Point(4, 29);
            this.AttributeStratifiedClusterSubPage.Name = "AttributeStratifiedClusterSubPage";
            this.AttributeStratifiedClusterSubPage.Size = new System.Drawing.Size(1308, 533);
            this.AttributeStratifiedClusterSubPage.TabIndex = 6;
            this.AttributeStratifiedClusterSubPage.Text = "Stratified Cluster";
            this.AttributeStratifiedClusterSubPage.UseVisualStyleBackColor = true;
            // 
            // AttributeStratifiedMultistageSubPage
            // 
            this.AttributeStratifiedMultistageSubPage.Location = new System.Drawing.Point(4, 29);
            this.AttributeStratifiedMultistageSubPage.Name = "AttributeStratifiedMultistageSubPage";
            this.AttributeStratifiedMultistageSubPage.Size = new System.Drawing.Size(1308, 533);
            this.AttributeStratifiedMultistageSubPage.TabIndex = 7;
            this.AttributeStratifiedMultistageSubPage.Text = "Stratified Multistage";
            this.AttributeStratifiedMultistageSubPage.UseVisualStyleBackColor = true;
            // 
            // VariableAppraisalsPage
            // 
            this.VariableAppraisalsPage.Controls.Add(this.VariableAppraisalsPages);
            this.VariableAppraisalsPage.Location = new System.Drawing.Point(4, 29);
            this.VariableAppraisalsPage.Name = "VariableAppraisalsPage";
            this.VariableAppraisalsPage.Size = new System.Drawing.Size(1322, 572);
            this.VariableAppraisalsPage.TabIndex = 2;
            this.VariableAppraisalsPage.Text = "Variable Appraisals";
            this.VariableAppraisalsPage.UseVisualStyleBackColor = true;
            // 
            // VariableAppraisalsPages
            // 
            this.VariableAppraisalsPages.Controls.Add(this.VariableUnrestrictedSubPage);
            this.VariableAppraisalsPages.Controls.Add(this.VariableStratifiedSubPage);
            this.VariableAppraisalsPages.Controls.Add(this.VariableTwoUnrestrictedSubPage);
            this.VariableAppraisalsPages.Controls.Add(this.VariableThreeUnrestrictedSubPage);
            this.VariableAppraisalsPages.Controls.Add(this.VariableRHCTwoSubPage);
            this.VariableAppraisalsPages.Controls.Add(this.VariableRHCThreeSubPage);
            this.VariableAppraisalsPages.Controls.Add(this.VariableStratifiedClusterSubPage);
            this.VariableAppraisalsPages.Controls.Add(this.VariableStratifiedMultistageSubPage);
            this.VariableAppraisalsPages.Controls.Add(this.VariablePoststratificationSubPage);
            this.VariableAppraisalsPages.Controls.Add(this.VariableUnknownUniverseSubPage);
            this.VariableAppraisalsPages.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VariableAppraisalsPages.Location = new System.Drawing.Point(0, 0);
            this.VariableAppraisalsPages.Multiline = true;
            this.VariableAppraisalsPages.Name = "VariableAppraisalsPages";
            this.VariableAppraisalsPages.SelectedIndex = 0;
            this.VariableAppraisalsPages.Size = new System.Drawing.Size(1322, 572);
            this.VariableAppraisalsPages.TabIndex = 1;
            // 
            // VariableUnrestrictedSubPage
            // 
            this.VariableUnrestrictedSubPage.Controls.Add(this.VA_U_PreviewLabel);
            this.VariableUnrestrictedSubPage.Controls.Add(this.VA_U_GenerateButton);
            this.VariableUnrestrictedSubPage.Controls.Add(this.VA_U_SourceOption2Input);
            this.VariableUnrestrictedSubPage.Controls.Add(this.VA_U_SourceOption1Input);
            this.VariableUnrestrictedSubPage.Controls.Add(this.VA_U_SourceInput);
            this.VariableUnrestrictedSubPage.Controls.Add(this.VA_U_DataFileFormatInput);
            this.VariableUnrestrictedSubPage.Controls.Add(this.VA_U_SourcePanel);
            this.VariableUnrestrictedSubPage.Controls.Add(this.label16);
            this.VariableUnrestrictedSubPage.Controls.Add(this.VA_U_SourceInputLabel);
            this.VariableUnrestrictedSubPage.Controls.Add(this.label14);
            this.VariableUnrestrictedSubPage.Controls.Add(this.VA_U_SourceOption2Label);
            this.VariableUnrestrictedSubPage.Controls.Add(this.VA_U_SourceOption1Label);
            this.VariableUnrestrictedSubPage.Controls.Add(this.label19);
            this.VariableUnrestrictedSubPage.Controls.Add(this.label17);
            this.VariableUnrestrictedSubPage.Controls.Add(this.VA_U_SampleSizeInput);
            this.VariableUnrestrictedSubPage.Controls.Add(this.VA_U_UniverseSizeInput);
            this.VariableUnrestrictedSubPage.Controls.Add(this.label18);
            this.VariableUnrestrictedSubPage.Controls.Add(this.VA_U_FileInput);
            this.VariableUnrestrictedSubPage.Controls.Add(this.VA_U_NameInput);
            this.VariableUnrestrictedSubPage.Location = new System.Drawing.Point(4, 54);
            this.VariableUnrestrictedSubPage.Name = "VariableUnrestrictedSubPage";
            this.VariableUnrestrictedSubPage.Padding = new System.Windows.Forms.Padding(3);
            this.VariableUnrestrictedSubPage.Size = new System.Drawing.Size(1314, 514);
            this.VariableUnrestrictedSubPage.TabIndex = 0;
            this.VariableUnrestrictedSubPage.Text = "Unrestricted";
            this.VariableUnrestrictedSubPage.UseVisualStyleBackColor = true;
            // 
            // VA_U_PreviewLabel
            // 
            this.VA_U_PreviewLabel.AutoSize = true;
            this.VA_U_PreviewLabel.Location = new System.Drawing.Point(544, 55);
            this.VA_U_PreviewLabel.Margin = new System.Windows.Forms.Padding(8);
            this.VA_U_PreviewLabel.Name = "VA_U_PreviewLabel";
            this.VA_U_PreviewLabel.Size = new System.Drawing.Size(310, 20);
            this.VA_U_PreviewLabel.TabIndex = 17;
            this.VA_U_PreviewLabel.Text = "Preview of the first three rows and columns";
            // 
            // VA_U_GenerateButton
            // 
            this.VA_U_GenerateButton.Location = new System.Drawing.Point(746, 405);
            this.VA_U_GenerateButton.Margin = new System.Windows.Forms.Padding(8);
            this.VA_U_GenerateButton.Name = "VA_U_GenerateButton";
            this.VA_U_GenerateButton.Size = new System.Drawing.Size(120, 55);
            this.VA_U_GenerateButton.TabIndex = 8;
            this.VA_U_GenerateButton.Text = "GENERATE";
            this.VA_U_GenerateButton.UseVisualStyleBackColor = true;
            this.VA_U_GenerateButton.Click += new System.EventHandler(this.VA_U_GenerateButton_Click);
            // 
            // VA_U_SourceOption2Input
            // 
            this.VA_U_SourceOption2Input.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.VA_U_SourceOption2Input.FormattingEnabled = true;
            this.VA_U_SourceOption2Input.Location = new System.Drawing.Point(354, 407);
            this.VA_U_SourceOption2Input.Margin = new System.Windows.Forms.Padding(8);
            this.VA_U_SourceOption2Input.Name = "VA_U_SourceOption2Input";
            this.VA_U_SourceOption2Input.Size = new System.Drawing.Size(318, 28);
            this.VA_U_SourceOption2Input.TabIndex = 7;
            // 
            // VA_U_SourceOption1Input
            // 
            this.VA_U_SourceOption1Input.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.VA_U_SourceOption1Input.FormattingEnabled = true;
            this.VA_U_SourceOption1Input.Location = new System.Drawing.Point(354, 363);
            this.VA_U_SourceOption1Input.Margin = new System.Windows.Forms.Padding(8);
            this.VA_U_SourceOption1Input.Name = "VA_U_SourceOption1Input";
            this.VA_U_SourceOption1Input.Size = new System.Drawing.Size(318, 28);
            this.VA_U_SourceOption1Input.TabIndex = 6;
            // 
            // VA_U_SourceInput
            // 
            this.VA_U_SourceInput.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.VA_U_SourceInput.FormattingEnabled = true;
            this.VA_U_SourceInput.Location = new System.Drawing.Point(214, 137);
            this.VA_U_SourceInput.Margin = new System.Windows.Forms.Padding(8);
            this.VA_U_SourceInput.Name = "VA_U_SourceInput";
            this.VA_U_SourceInput.Size = new System.Drawing.Size(318, 28);
            this.VA_U_SourceInput.TabIndex = 3;
            this.VA_U_SourceInput.SelectionChangeCommitted += new System.EventHandler(this.VA_U_SourceInput_SelectionChangeCommitted);
            // 
            // VA_U_DataFileFormatInput
            // 
            this.VA_U_DataFileFormatInput.FormattingEnabled = true;
            this.VA_U_DataFileFormatInput.ItemHeight = 20;
            this.VA_U_DataFileFormatInput.Items.AddRange(new object[] {
            "Examined Values",
            "Audited Values",
            "Difference Values",
            "Examined and Audited Values",
            "Examined and Difference Values",
            "Audited and Difference Values"});
            this.VA_U_DataFileFormatInput.Location = new System.Drawing.Point(214, 181);
            this.VA_U_DataFileFormatInput.Margin = new System.Windows.Forms.Padding(8);
            this.VA_U_DataFileFormatInput.Name = "VA_U_DataFileFormatInput";
            this.VA_U_DataFileFormatInput.Size = new System.Drawing.Size(318, 124);
            this.VA_U_DataFileFormatInput.TabIndex = 4;
            this.VA_U_DataFileFormatInput.SelectedIndexChanged += new System.EventHandler(this.VA_U_DataFileFormatInput_SelectedIndexChanged);
            // 
            // VA_U_SourcePanel
            // 
            this.VA_U_SourcePanel.Location = new System.Drawing.Point(548, 95);
            this.VA_U_SourcePanel.Margin = new System.Windows.Forms.Padding(8);
            this.VA_U_SourcePanel.Name = "VA_U_SourcePanel";
            this.VA_U_SourcePanel.Size = new System.Drawing.Size(318, 210);
            this.VA_U_SourcePanel.TabIndex = 8;
            this.VA_U_SourcePanel.ControlAdded += new System.Windows.Forms.ControlEventHandler(this.VA_U_SourcePanel_ControlAdded);
            this.VA_U_SourcePanel.ControlRemoved += new System.Windows.Forms.ControlEventHandler(this.VA_U_SourcePanel_ControlRemoved);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(11, 184);
            this.label16.Margin = new System.Windows.Forms.Padding(8);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(128, 20);
            this.label16.TabIndex = 7;
            this.label16.Text = "Data File Format";
            // 
            // VA_U_SourceInputLabel
            // 
            this.VA_U_SourceInputLabel.AutoSize = true;
            this.VA_U_SourceInputLabel.Location = new System.Drawing.Point(11, 140);
            this.VA_U_SourceInputLabel.Margin = new System.Windows.Forms.Padding(8);
            this.VA_U_SourceInputLabel.Name = "VA_U_SourceInputLabel";
            this.VA_U_SourceInputLabel.Size = new System.Drawing.Size(106, 20);
            this.VA_U_SourceInputLabel.TabIndex = 7;
            this.VA_U_SourceInputLabel.Text = "Source Name";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(11, 98);
            this.label14.Margin = new System.Windows.Forms.Padding(8);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(75, 20);
            this.label14.TabIndex = 7;
            this.label14.Text = "Input File";
            // 
            // VA_U_SourceOption2Label
            // 
            this.VA_U_SourceOption2Label.AutoSize = true;
            this.VA_U_SourceOption2Label.Location = new System.Drawing.Point(11, 410);
            this.VA_U_SourceOption2Label.Margin = new System.Windows.Forms.Padding(8);
            this.VA_U_SourceOption2Label.Name = "VA_U_SourceOption2Label";
            this.VA_U_SourceOption2Label.Size = new System.Drawing.Size(124, 20);
            this.VA_U_SourceOption2Label.TabIndex = 7;
            this.VA_U_SourceOption2Label.Text = "Source Option 2";
            // 
            // VA_U_SourceOption1Label
            // 
            this.VA_U_SourceOption1Label.AutoSize = true;
            this.VA_U_SourceOption1Label.Location = new System.Drawing.Point(11, 366);
            this.VA_U_SourceOption1Label.Margin = new System.Windows.Forms.Padding(8);
            this.VA_U_SourceOption1Label.Name = "VA_U_SourceOption1Label";
            this.VA_U_SourceOption1Label.Size = new System.Drawing.Size(124, 20);
            this.VA_U_SourceOption1Label.TabIndex = 7;
            this.VA_U_SourceOption1Label.Text = "Source Option 1";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(11, 323);
            this.label19.Margin = new System.Windows.Forms.Padding(8);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(98, 20);
            this.label19.TabIndex = 7;
            this.label19.Text = "Sample Size";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(11, 55);
            this.label17.Margin = new System.Windows.Forms.Padding(8);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(106, 20);
            this.label17.TabIndex = 7;
            this.label17.Text = "Universe Size";
            // 
            // VA_U_SampleSizeInput
            // 
            this.VA_U_SampleSizeInput.Location = new System.Drawing.Point(214, 321);
            this.VA_U_SampleSizeInput.Margin = new System.Windows.Forms.Padding(8);
            this.VA_U_SampleSizeInput.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.VA_U_SampleSizeInput.Name = "VA_U_SampleSizeInput";
            this.VA_U_SampleSizeInput.Size = new System.Drawing.Size(144, 26);
            this.VA_U_SampleSizeInput.TabIndex = 5;
            this.VA_U_SampleSizeInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.VA_U_SampleSizeInput.ThousandsSeparator = true;
            this.VA_U_SampleSizeInput.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // VA_U_UniverseSizeInput
            // 
            this.VA_U_UniverseSizeInput.Location = new System.Drawing.Point(214, 53);
            this.VA_U_UniverseSizeInput.Margin = new System.Windows.Forms.Padding(8);
            this.VA_U_UniverseSizeInput.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.VA_U_UniverseSizeInput.Name = "VA_U_UniverseSizeInput";
            this.VA_U_UniverseSizeInput.Size = new System.Drawing.Size(144, 26);
            this.VA_U_UniverseSizeInput.TabIndex = 1;
            this.VA_U_UniverseSizeInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.VA_U_UniverseSizeInput.ThousandsSeparator = true;
            this.VA_U_UniverseSizeInput.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(11, 14);
            this.label18.Margin = new System.Windows.Forms.Padding(8);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(187, 20);
            this.label18.TabIndex = 5;
            this.label18.Text = "Name of the audit/review:";
            // 
            // VA_U_FileInput
            // 
            this.VA_U_FileInput.Location = new System.Drawing.Point(214, 95);
            this.VA_U_FileInput.Margin = new System.Windows.Forms.Padding(8);
            this.VA_U_FileInput.Name = "VA_U_FileInput";
            this.VA_U_FileInput.ReadOnly = true;
            this.VA_U_FileInput.Size = new System.Drawing.Size(318, 26);
            this.VA_U_FileInput.TabIndex = 2;
            this.VA_U_FileInput.Click += new System.EventHandler(this.VA_U_FileInput_Click);
            this.VA_U_FileInput.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.VA_U_FileInput_KeyPress);
            // 
            // VA_U_NameInput
            // 
            this.VA_U_NameInput.Location = new System.Drawing.Point(214, 11);
            this.VA_U_NameInput.Margin = new System.Windows.Forms.Padding(8);
            this.VA_U_NameInput.MaxLength = 40;
            this.VA_U_NameInput.Name = "VA_U_NameInput";
            this.VA_U_NameInput.Size = new System.Drawing.Size(318, 26);
            this.VA_U_NameInput.TabIndex = 0;
            // 
            // VariableStratifiedSubPage
            // 
            this.VariableStratifiedSubPage.Controls.Add(this.VA_S_UniverseSourceOption2Input);
            this.VariableStratifiedSubPage.Controls.Add(this.VA_S_UniverseSourceOption1Input);
            this.VariableStratifiedSubPage.Controls.Add(this.VA_S_SourceOption2Input);
            this.VariableStratifiedSubPage.Controls.Add(this.VA_S_SourceOption1Input);
            this.VariableStratifiedSubPage.Controls.Add(this.label30);
            this.VariableStratifiedSubPage.Controls.Add(this.VA_S_StrataSizeInput);
            this.VariableStratifiedSubPage.Controls.Add(this.VA_S_UniverseSourceOption2Label);
            this.VariableStratifiedSubPage.Controls.Add(this.VA_S_UniverseSourceOption1Label);
            this.VariableStratifiedSubPage.Controls.Add(this.VA_S_SourceOption2Label);
            this.VariableStratifiedSubPage.Controls.Add(this.VA_S_UniverseSourceInput);
            this.VariableStratifiedSubPage.Controls.Add(this.VA_S_DataFileFormatInput);
            this.VariableStratifiedSubPage.Controls.Add(this.VA_S_UniverseSourcePanel);
            this.VariableStratifiedSubPage.Controls.Add(this.label22);
            this.VariableStratifiedSubPage.Controls.Add(this.VA_S_UniverseSourceInputLabel);
            this.VariableStratifiedSubPage.Controls.Add(this.VA_S_UniverseFileLabel);
            this.VariableStratifiedSubPage.Controls.Add(this.VA_S_UniverseFileInput);
            this.VariableStratifiedSubPage.Controls.Add(this.VA_S_GenerateButton);
            this.VariableStratifiedSubPage.Controls.Add(this.VA_S_SourceInput);
            this.VariableStratifiedSubPage.Controls.Add(this.VA_S_SourcePanel);
            this.VariableStratifiedSubPage.Controls.Add(this.VA_S_SourceInputLabel);
            this.VariableStratifiedSubPage.Controls.Add(this.label21);
            this.VariableStratifiedSubPage.Controls.Add(this.VA_S_SourceOption1Label);
            this.VariableStratifiedSubPage.Controls.Add(this.VA_S_PreviewLabel);
            this.VariableStratifiedSubPage.Controls.Add(this.label26);
            this.VariableStratifiedSubPage.Controls.Add(this.VA_S_FileInput);
            this.VariableStratifiedSubPage.Controls.Add(this.VA_S_NameInput);
            this.VariableStratifiedSubPage.Location = new System.Drawing.Point(4, 54);
            this.VariableStratifiedSubPage.Name = "VariableStratifiedSubPage";
            this.VariableStratifiedSubPage.Padding = new System.Windows.Forms.Padding(3);
            this.VariableStratifiedSubPage.Size = new System.Drawing.Size(1314, 514);
            this.VariableStratifiedSubPage.TabIndex = 1;
            this.VariableStratifiedSubPage.Text = "Stratified";
            this.VariableStratifiedSubPage.UseVisualStyleBackColor = true;
            // 
            // VA_S_UniverseSourceOption2Input
            // 
            this.VA_S_UniverseSourceOption2Input.FormattingEnabled = true;
            this.VA_S_UniverseSourceOption2Input.Location = new System.Drawing.Point(882, 405);
            this.VA_S_UniverseSourceOption2Input.Margin = new System.Windows.Forms.Padding(8);
            this.VA_S_UniverseSourceOption2Input.Name = "VA_S_UniverseSourceOption2Input";
            this.VA_S_UniverseSourceOption2Input.Size = new System.Drawing.Size(176, 28);
            this.VA_S_UniverseSourceOption2Input.TabIndex = 10;
            this.VA_S_UniverseSourceOption2Input.Validating += new System.ComponentModel.CancelEventHandler(this.VA_S_OptionInput_Validating);
            // 
            // VA_S_UniverseSourceOption1Input
            // 
            this.VA_S_UniverseSourceOption1Input.FormattingEnabled = true;
            this.VA_S_UniverseSourceOption1Input.Location = new System.Drawing.Point(882, 321);
            this.VA_S_UniverseSourceOption1Input.Margin = new System.Windows.Forms.Padding(8);
            this.VA_S_UniverseSourceOption1Input.Name = "VA_S_UniverseSourceOption1Input";
            this.VA_S_UniverseSourceOption1Input.Size = new System.Drawing.Size(176, 28);
            this.VA_S_UniverseSourceOption1Input.TabIndex = 9;
            this.VA_S_UniverseSourceOption1Input.Validating += new System.ComponentModel.CancelEventHandler(this.VA_S_OptionInput_Validating);
            // 
            // VA_S_SourceOption2Input
            // 
            this.VA_S_SourceOption2Input.FormattingEnabled = true;
            this.VA_S_SourceOption2Input.Location = new System.Drawing.Point(882, 173);
            this.VA_S_SourceOption2Input.Margin = new System.Windows.Forms.Padding(8);
            this.VA_S_SourceOption2Input.Name = "VA_S_SourceOption2Input";
            this.VA_S_SourceOption2Input.Size = new System.Drawing.Size(176, 28);
            this.VA_S_SourceOption2Input.TabIndex = 8;
            this.VA_S_SourceOption2Input.Validating += new System.ComponentModel.CancelEventHandler(this.VA_S_OptionInput_Validating);
            // 
            // VA_S_SourceOption1Input
            // 
            this.VA_S_SourceOption1Input.FormattingEnabled = true;
            this.VA_S_SourceOption1Input.Location = new System.Drawing.Point(882, 95);
            this.VA_S_SourceOption1Input.Margin = new System.Windows.Forms.Padding(8);
            this.VA_S_SourceOption1Input.Name = "VA_S_SourceOption1Input";
            this.VA_S_SourceOption1Input.Size = new System.Drawing.Size(176, 28);
            this.VA_S_SourceOption1Input.TabIndex = 7;
            this.VA_S_SourceOption1Input.Validating += new System.ComponentModel.CancelEventHandler(this.VA_S_OptionInput_Validating);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(11, 367);
            this.label30.Margin = new System.Windows.Forms.Padding(8);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(131, 20);
            this.label30.TabIndex = 47;
            this.label30.Text = "Number of Strata";
            // 
            // VA_S_StrataSizeInput
            // 
            this.VA_S_StrataSizeInput.Location = new System.Drawing.Point(214, 365);
            this.VA_S_StrataSizeInput.Margin = new System.Windows.Forms.Padding(8);
            this.VA_S_StrataSizeInput.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.VA_S_StrataSizeInput.Name = "VA_S_StrataSizeInput";
            this.VA_S_StrataSizeInput.Size = new System.Drawing.Size(144, 26);
            this.VA_S_StrataSizeInput.TabIndex = 6;
            this.VA_S_StrataSizeInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.VA_S_StrataSizeInput.ThousandsSeparator = true;
            this.VA_S_StrataSizeInput.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // VA_S_UniverseSourceOption2Label
            // 
            this.VA_S_UniverseSourceOption2Label.AutoSize = true;
            this.VA_S_UniverseSourceOption2Label.Location = new System.Drawing.Point(878, 374);
            this.VA_S_UniverseSourceOption2Label.Margin = new System.Windows.Forms.Padding(8, 8, 8, 3);
            this.VA_S_UniverseSourceOption2Label.Name = "VA_S_UniverseSourceOption2Label";
            this.VA_S_UniverseSourceOption2Label.Size = new System.Drawing.Size(190, 20);
            this.VA_S_UniverseSourceOption2Label.TabIndex = 44;
            this.VA_S_UniverseSourceOption2Label.Text = "Universe Source Option 2";
            // 
            // VA_S_UniverseSourceOption1Label
            // 
            this.VA_S_UniverseSourceOption1Label.AutoSize = true;
            this.VA_S_UniverseSourceOption1Label.Location = new System.Drawing.Point(878, 290);
            this.VA_S_UniverseSourceOption1Label.Margin = new System.Windows.Forms.Padding(8, 8, 8, 3);
            this.VA_S_UniverseSourceOption1Label.Name = "VA_S_UniverseSourceOption1Label";
            this.VA_S_UniverseSourceOption1Label.Size = new System.Drawing.Size(190, 20);
            this.VA_S_UniverseSourceOption1Label.TabIndex = 43;
            this.VA_S_UniverseSourceOption1Label.Text = "Universe Source Option 1";
            // 
            // VA_S_SourceOption2Label
            // 
            this.VA_S_SourceOption2Label.AutoSize = true;
            this.VA_S_SourceOption2Label.Location = new System.Drawing.Point(878, 142);
            this.VA_S_SourceOption2Label.Margin = new System.Windows.Forms.Padding(8, 8, 8, 3);
            this.VA_S_SourceOption2Label.Name = "VA_S_SourceOption2Label";
            this.VA_S_SourceOption2Label.Size = new System.Drawing.Size(124, 20);
            this.VA_S_SourceOption2Label.TabIndex = 39;
            this.VA_S_SourceOption2Label.Text = "Source Option 2";
            // 
            // VA_S_UniverseSourceInput
            // 
            this.VA_S_UniverseSourceInput.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.VA_S_UniverseSourceInput.FormattingEnabled = true;
            this.VA_S_UniverseSourceInput.Location = new System.Drawing.Point(214, 321);
            this.VA_S_UniverseSourceInput.Margin = new System.Windows.Forms.Padding(8);
            this.VA_S_UniverseSourceInput.Name = "VA_S_UniverseSourceInput";
            this.VA_S_UniverseSourceInput.Size = new System.Drawing.Size(318, 28);
            this.VA_S_UniverseSourceInput.TabIndex = 5;
            this.VA_S_UniverseSourceInput.SelectionChangeCommitted += new System.EventHandler(this.VA_S_UniverseSourceInput_SelectionChangeCommitted);
            // 
            // VA_S_DataFileFormatInput
            // 
            this.VA_S_DataFileFormatInput.FormattingEnabled = true;
            this.VA_S_DataFileFormatInput.ItemHeight = 20;
            this.VA_S_DataFileFormatInput.Items.AddRange(new object[] {
            "Examined Values",
            "Audited Values",
            "Difference Values",
            "Examined and Audited Values",
            "Examined and Difference Values",
            "Audited and Difference Values"});
            this.VA_S_DataFileFormatInput.Location = new System.Drawing.Point(214, 139);
            this.VA_S_DataFileFormatInput.Margin = new System.Windows.Forms.Padding(8);
            this.VA_S_DataFileFormatInput.Name = "VA_S_DataFileFormatInput";
            this.VA_S_DataFileFormatInput.Size = new System.Drawing.Size(318, 124);
            this.VA_S_DataFileFormatInput.TabIndex = 3;
            this.VA_S_DataFileFormatInput.SelectedIndexChanged += new System.EventHandler(this.VA_S_DataFileFormatInput_SelectedIndexChanged);
            // 
            // VA_S_UniverseSourcePanel
            // 
            this.VA_S_UniverseSourcePanel.Location = new System.Drawing.Point(548, 279);
            this.VA_S_UniverseSourcePanel.Margin = new System.Windows.Forms.Padding(8);
            this.VA_S_UniverseSourcePanel.Name = "VA_S_UniverseSourcePanel";
            this.VA_S_UniverseSourcePanel.Size = new System.Drawing.Size(318, 210);
            this.VA_S_UniverseSourcePanel.TabIndex = 36;
            this.VA_S_UniverseSourcePanel.ControlAdded += new System.Windows.Forms.ControlEventHandler(this.VA_S_Panel_ControlAdded);
            this.VA_S_UniverseSourcePanel.ControlRemoved += new System.Windows.Forms.ControlEventHandler(this.VA_S_Panel_ControlRemoved);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(11, 142);
            this.label22.Margin = new System.Windows.Forms.Padding(8);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(128, 20);
            this.label22.TabIndex = 34;
            this.label22.Text = "Data File Format";
            // 
            // VA_S_UniverseSourceInputLabel
            // 
            this.VA_S_UniverseSourceInputLabel.AutoSize = true;
            this.VA_S_UniverseSourceInputLabel.Location = new System.Drawing.Point(11, 324);
            this.VA_S_UniverseSourceInputLabel.Margin = new System.Windows.Forms.Padding(8);
            this.VA_S_UniverseSourceInputLabel.Name = "VA_S_UniverseSourceInputLabel";
            this.VA_S_UniverseSourceInputLabel.Size = new System.Drawing.Size(106, 20);
            this.VA_S_UniverseSourceInputLabel.TabIndex = 35;
            this.VA_S_UniverseSourceInputLabel.Text = "Source Name";
            // 
            // VA_S_UniverseFileLabel
            // 
            this.VA_S_UniverseFileLabel.AutoSize = true;
            this.VA_S_UniverseFileLabel.Location = new System.Drawing.Point(11, 282);
            this.VA_S_UniverseFileLabel.Margin = new System.Windows.Forms.Padding(8);
            this.VA_S_UniverseFileLabel.Name = "VA_S_UniverseFileLabel";
            this.VA_S_UniverseFileLabel.Size = new System.Drawing.Size(141, 20);
            this.VA_S_UniverseFileLabel.TabIndex = 33;
            this.VA_S_UniverseFileLabel.Text = "Universe Input File";
            // 
            // VA_S_UniverseFileInput
            // 
            this.VA_S_UniverseFileInput.Location = new System.Drawing.Point(214, 279);
            this.VA_S_UniverseFileInput.Margin = new System.Windows.Forms.Padding(8);
            this.VA_S_UniverseFileInput.Name = "VA_S_UniverseFileInput";
            this.VA_S_UniverseFileInput.ReadOnly = true;
            this.VA_S_UniverseFileInput.Size = new System.Drawing.Size(318, 26);
            this.VA_S_UniverseFileInput.TabIndex = 4;
            this.VA_S_UniverseFileInput.Click += new System.EventHandler(this.VA_S_UniverseFileInput_Click);
            this.VA_S_UniverseFileInput.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.VA_S_UniverseFileInput_KeyPress);
            // 
            // VA_S_GenerateButton
            // 
            this.VA_S_GenerateButton.Location = new System.Drawing.Point(1179, 405);
            this.VA_S_GenerateButton.Margin = new System.Windows.Forms.Padding(8);
            this.VA_S_GenerateButton.Name = "VA_S_GenerateButton";
            this.VA_S_GenerateButton.Size = new System.Drawing.Size(120, 55);
            this.VA_S_GenerateButton.TabIndex = 11;
            this.VA_S_GenerateButton.Text = "GENERATE";
            this.VA_S_GenerateButton.UseVisualStyleBackColor = true;
            this.VA_S_GenerateButton.Click += new System.EventHandler(this.VA_S_GenerateButton_Click);
            // 
            // VA_S_SourceInput
            // 
            this.VA_S_SourceInput.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.VA_S_SourceInput.FormattingEnabled = true;
            this.VA_S_SourceInput.Location = new System.Drawing.Point(214, 95);
            this.VA_S_SourceInput.Margin = new System.Windows.Forms.Padding(8);
            this.VA_S_SourceInput.Name = "VA_S_SourceInput";
            this.VA_S_SourceInput.Size = new System.Drawing.Size(318, 28);
            this.VA_S_SourceInput.TabIndex = 2;
            this.VA_S_SourceInput.SelectionChangeCommitted += new System.EventHandler(this.VA_S_SourceInput_SelectionChangeCommitted);
            // 
            // VA_S_SourcePanel
            // 
            this.VA_S_SourcePanel.Location = new System.Drawing.Point(548, 53);
            this.VA_S_SourcePanel.Margin = new System.Windows.Forms.Padding(8);
            this.VA_S_SourcePanel.Name = "VA_S_SourcePanel";
            this.VA_S_SourcePanel.Size = new System.Drawing.Size(318, 210);
            this.VA_S_SourcePanel.TabIndex = 26;
            this.VA_S_SourcePanel.ControlAdded += new System.Windows.Forms.ControlEventHandler(this.VA_S_Panel_ControlAdded);
            this.VA_S_SourcePanel.ControlRemoved += new System.Windows.Forms.ControlEventHandler(this.VA_S_Panel_ControlRemoved);
            // 
            // VA_S_SourceInputLabel
            // 
            this.VA_S_SourceInputLabel.AutoSize = true;
            this.VA_S_SourceInputLabel.Location = new System.Drawing.Point(11, 98);
            this.VA_S_SourceInputLabel.Margin = new System.Windows.Forms.Padding(8);
            this.VA_S_SourceInputLabel.Name = "VA_S_SourceInputLabel";
            this.VA_S_SourceInputLabel.Size = new System.Drawing.Size(106, 20);
            this.VA_S_SourceInputLabel.TabIndex = 25;
            this.VA_S_SourceInputLabel.Text = "Source Name";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(11, 56);
            this.label21.Margin = new System.Windows.Forms.Padding(8);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(75, 20);
            this.label21.TabIndex = 23;
            this.label21.Text = "Input File";
            // 
            // VA_S_SourceOption1Label
            // 
            this.VA_S_SourceOption1Label.AutoSize = true;
            this.VA_S_SourceOption1Label.Location = new System.Drawing.Point(878, 61);
            this.VA_S_SourceOption1Label.Margin = new System.Windows.Forms.Padding(8, 8, 8, 3);
            this.VA_S_SourceOption1Label.Name = "VA_S_SourceOption1Label";
            this.VA_S_SourceOption1Label.Size = new System.Drawing.Size(124, 20);
            this.VA_S_SourceOption1Label.TabIndex = 16;
            this.VA_S_SourceOption1Label.Text = "Source Option 1";
            // 
            // VA_S_PreviewLabel
            // 
            this.VA_S_PreviewLabel.AutoSize = true;
            this.VA_S_PreviewLabel.Location = new System.Drawing.Point(548, 14);
            this.VA_S_PreviewLabel.Margin = new System.Windows.Forms.Padding(8);
            this.VA_S_PreviewLabel.Name = "VA_S_PreviewLabel";
            this.VA_S_PreviewLabel.Size = new System.Drawing.Size(310, 20);
            this.VA_S_PreviewLabel.TabIndex = 16;
            this.VA_S_PreviewLabel.Text = "Preview of the first three rows and columns";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(11, 14);
            this.label26.Margin = new System.Windows.Forms.Padding(8);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(187, 20);
            this.label26.TabIndex = 16;
            this.label26.Text = "Name of the audit/review:";
            // 
            // VA_S_FileInput
            // 
            this.VA_S_FileInput.Location = new System.Drawing.Point(214, 53);
            this.VA_S_FileInput.Margin = new System.Windows.Forms.Padding(8);
            this.VA_S_FileInput.Name = "VA_S_FileInput";
            this.VA_S_FileInput.ReadOnly = true;
            this.VA_S_FileInput.Size = new System.Drawing.Size(318, 26);
            this.VA_S_FileInput.TabIndex = 1;
            this.VA_S_FileInput.Click += new System.EventHandler(this.VA_S_FileInput_Click);
            this.VA_S_FileInput.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.VA_S_FileInput_KeyPress);
            // 
            // VA_S_NameInput
            // 
            this.VA_S_NameInput.Location = new System.Drawing.Point(214, 11);
            this.VA_S_NameInput.Margin = new System.Windows.Forms.Padding(8);
            this.VA_S_NameInput.MaxLength = 40;
            this.VA_S_NameInput.Name = "VA_S_NameInput";
            this.VA_S_NameInput.Size = new System.Drawing.Size(318, 26);
            this.VA_S_NameInput.TabIndex = 0;
            // 
            // VariableTwoUnrestrictedSubPage
            // 
            this.VariableTwoUnrestrictedSubPage.Location = new System.Drawing.Point(4, 54);
            this.VariableTwoUnrestrictedSubPage.Name = "VariableTwoUnrestrictedSubPage";
            this.VariableTwoUnrestrictedSubPage.Size = new System.Drawing.Size(1314, 514);
            this.VariableTwoUnrestrictedSubPage.TabIndex = 2;
            this.VariableTwoUnrestrictedSubPage.Text = "Two-Stage Unrestricted";
            this.VariableTwoUnrestrictedSubPage.UseVisualStyleBackColor = true;
            // 
            // VariableThreeUnrestrictedSubPage
            // 
            this.VariableThreeUnrestrictedSubPage.Location = new System.Drawing.Point(4, 54);
            this.VariableThreeUnrestrictedSubPage.Name = "VariableThreeUnrestrictedSubPage";
            this.VariableThreeUnrestrictedSubPage.Size = new System.Drawing.Size(1314, 514);
            this.VariableThreeUnrestrictedSubPage.TabIndex = 3;
            this.VariableThreeUnrestrictedSubPage.Text = "Three-Stage Unrestricted";
            this.VariableThreeUnrestrictedSubPage.UseVisualStyleBackColor = true;
            // 
            // VariableRHCTwoSubPage
            // 
            this.VariableRHCTwoSubPage.Location = new System.Drawing.Point(4, 54);
            this.VariableRHCTwoSubPage.Name = "VariableRHCTwoSubPage";
            this.VariableRHCTwoSubPage.Size = new System.Drawing.Size(1314, 514);
            this.VariableRHCTwoSubPage.TabIndex = 4;
            this.VariableRHCTwoSubPage.Text = "RHC Two-Stage";
            this.VariableRHCTwoSubPage.UseVisualStyleBackColor = true;
            // 
            // VariableRHCThreeSubPage
            // 
            this.VariableRHCThreeSubPage.Location = new System.Drawing.Point(4, 54);
            this.VariableRHCThreeSubPage.Name = "VariableRHCThreeSubPage";
            this.VariableRHCThreeSubPage.Size = new System.Drawing.Size(1314, 514);
            this.VariableRHCThreeSubPage.TabIndex = 5;
            this.VariableRHCThreeSubPage.Text = "RHC Three-Stage";
            this.VariableRHCThreeSubPage.UseVisualStyleBackColor = true;
            // 
            // VariableStratifiedClusterSubPage
            // 
            this.VariableStratifiedClusterSubPage.Location = new System.Drawing.Point(4, 54);
            this.VariableStratifiedClusterSubPage.Name = "VariableStratifiedClusterSubPage";
            this.VariableStratifiedClusterSubPage.Size = new System.Drawing.Size(1314, 514);
            this.VariableStratifiedClusterSubPage.TabIndex = 6;
            this.VariableStratifiedClusterSubPage.Text = "Stratified Cluster";
            this.VariableStratifiedClusterSubPage.UseVisualStyleBackColor = true;
            // 
            // VariableStratifiedMultistageSubPage
            // 
            this.VariableStratifiedMultistageSubPage.Location = new System.Drawing.Point(4, 54);
            this.VariableStratifiedMultistageSubPage.Name = "VariableStratifiedMultistageSubPage";
            this.VariableStratifiedMultistageSubPage.Size = new System.Drawing.Size(1314, 514);
            this.VariableStratifiedMultistageSubPage.TabIndex = 7;
            this.VariableStratifiedMultistageSubPage.Text = "Stratified Multistage";
            this.VariableStratifiedMultistageSubPage.UseVisualStyleBackColor = true;
            // 
            // VariablePoststratificationSubPage
            // 
            this.VariablePoststratificationSubPage.Location = new System.Drawing.Point(4, 54);
            this.VariablePoststratificationSubPage.Name = "VariablePoststratificationSubPage";
            this.VariablePoststratificationSubPage.Size = new System.Drawing.Size(1314, 514);
            this.VariablePoststratificationSubPage.TabIndex = 8;
            this.VariablePoststratificationSubPage.Text = "Poststratification";
            this.VariablePoststratificationSubPage.UseVisualStyleBackColor = true;
            // 
            // VariableUnknownUniverseSubPage
            // 
            this.VariableUnknownUniverseSubPage.Location = new System.Drawing.Point(4, 54);
            this.VariableUnknownUniverseSubPage.Name = "VariableUnknownUniverseSubPage";
            this.VariableUnknownUniverseSubPage.Size = new System.Drawing.Size(1314, 514);
            this.VariableUnknownUniverseSubPage.TabIndex = 9;
            this.VariableUnknownUniverseSubPage.Text = "Unknown Universe Size";
            this.VariableUnknownUniverseSubPage.UseVisualStyleBackColor = true;
            // 
            // SampleSizeDeterminationPage
            // 
            this.SampleSizeDeterminationPage.Controls.Add(this.SampleSizeDeterminationPages);
            this.SampleSizeDeterminationPage.Location = new System.Drawing.Point(4, 29);
            this.SampleSizeDeterminationPage.Name = "SampleSizeDeterminationPage";
            this.SampleSizeDeterminationPage.Size = new System.Drawing.Size(1322, 572);
            this.SampleSizeDeterminationPage.TabIndex = 3;
            this.SampleSizeDeterminationPage.Text = "Sample Size Determination";
            this.SampleSizeDeterminationPage.UseVisualStyleBackColor = true;
            // 
            // SampleSizeDeterminationPages
            // 
            this.SampleSizeDeterminationPages.Controls.Add(this.SampleVariableSubPage);
            this.SampleSizeDeterminationPages.Controls.Add(this.SampleAttributeSubPage);
            this.SampleSizeDeterminationPages.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SampleSizeDeterminationPages.Location = new System.Drawing.Point(0, 0);
            this.SampleSizeDeterminationPages.Name = "SampleSizeDeterminationPages";
            this.SampleSizeDeterminationPages.SelectedIndex = 0;
            this.SampleSizeDeterminationPages.Size = new System.Drawing.Size(1322, 572);
            this.SampleSizeDeterminationPages.TabIndex = 0;
            // 
            // SampleVariableSubPage
            // 
            this.SampleVariableSubPage.Controls.Add(this.SampleVariablePages);
            this.SampleVariableSubPage.Location = new System.Drawing.Point(4, 29);
            this.SampleVariableSubPage.Name = "SampleVariableSubPage";
            this.SampleVariableSubPage.Padding = new System.Windows.Forms.Padding(3);
            this.SampleVariableSubPage.Size = new System.Drawing.Size(1314, 539);
            this.SampleVariableSubPage.TabIndex = 0;
            this.SampleVariableSubPage.Text = "Variable Sample Size Determination";
            this.SampleVariableSubPage.UseVisualStyleBackColor = true;
            // 
            // SampleVariablePages
            // 
            this.SampleVariablePages.Controls.Add(this.SampleVariableUnrestrictedProbeSubPage);
            this.SampleVariablePages.Controls.Add(this.SampleVariableUnrestrictedEERSubPage);
            this.SampleVariablePages.Controls.Add(this.SampleVariableStratifiedSubPage);
            this.SampleVariablePages.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SampleVariablePages.Location = new System.Drawing.Point(3, 3);
            this.SampleVariablePages.Name = "SampleVariablePages";
            this.SampleVariablePages.SelectedIndex = 0;
            this.SampleVariablePages.Size = new System.Drawing.Size(1308, 533);
            this.SampleVariablePages.TabIndex = 0;
            // 
            // SampleVariableUnrestrictedProbeSubPage
            // 
            this.SampleVariableUnrestrictedProbeSubPage.Location = new System.Drawing.Point(4, 29);
            this.SampleVariableUnrestrictedProbeSubPage.Name = "SampleVariableUnrestrictedProbeSubPage";
            this.SampleVariableUnrestrictedProbeSubPage.Padding = new System.Windows.Forms.Padding(3);
            this.SampleVariableUnrestrictedProbeSubPage.Size = new System.Drawing.Size(1300, 500);
            this.SampleVariableUnrestrictedProbeSubPage.TabIndex = 0;
            this.SampleVariableUnrestrictedProbeSubPage.Text = "Unrestricted - Using a Probe Sample";
            this.SampleVariableUnrestrictedProbeSubPage.UseVisualStyleBackColor = true;
            // 
            // SampleVariableUnrestrictedEERSubPage
            // 
            this.SampleVariableUnrestrictedEERSubPage.Location = new System.Drawing.Point(4, 29);
            this.SampleVariableUnrestrictedEERSubPage.Name = "SampleVariableUnrestrictedEERSubPage";
            this.SampleVariableUnrestrictedEERSubPage.Padding = new System.Windows.Forms.Padding(3);
            this.SampleVariableUnrestrictedEERSubPage.Size = new System.Drawing.Size(1300, 500);
            this.SampleVariableUnrestrictedEERSubPage.TabIndex = 1;
            this.SampleVariableUnrestrictedEERSubPage.Text = "Unrestricted - Using Estimated Error Rate";
            this.SampleVariableUnrestrictedEERSubPage.UseVisualStyleBackColor = true;
            // 
            // SampleVariableStratifiedSubPage
            // 
            this.SampleVariableStratifiedSubPage.Location = new System.Drawing.Point(4, 29);
            this.SampleVariableStratifiedSubPage.Name = "SampleVariableStratifiedSubPage";
            this.SampleVariableStratifiedSubPage.Size = new System.Drawing.Size(1300, 500);
            this.SampleVariableStratifiedSubPage.TabIndex = 2;
            this.SampleVariableStratifiedSubPage.Text = "Stratified";
            this.SampleVariableStratifiedSubPage.UseVisualStyleBackColor = true;
            // 
            // SampleAttributeSubPage
            // 
            this.SampleAttributeSubPage.Location = new System.Drawing.Point(4, 29);
            this.SampleAttributeSubPage.Name = "SampleAttributeSubPage";
            this.SampleAttributeSubPage.Padding = new System.Windows.Forms.Padding(3);
            this.SampleAttributeSubPage.Size = new System.Drawing.Size(1314, 539);
            this.SampleAttributeSubPage.TabIndex = 1;
            this.SampleAttributeSubPage.Text = "Attribute Sample Size Determination";
            this.SampleAttributeSubPage.UseVisualStyleBackColor = true;
            // 
            // HelpPage
            // 
            this.HelpPage.Controls.Add(this.HelpPages);
            this.HelpPage.Location = new System.Drawing.Point(4, 29);
            this.HelpPage.Name = "HelpPage";
            this.HelpPage.Size = new System.Drawing.Size(1322, 572);
            this.HelpPage.TabIndex = 4;
            this.HelpPage.Text = "Help";
            this.HelpPage.UseVisualStyleBackColor = true;
            // 
            // HelpPages
            // 
            this.HelpPages.Controls.Add(this.HelpTopicsSubpage);
            this.HelpPages.Controls.Add(this.AboutSubPage);
            this.HelpPages.Dock = System.Windows.Forms.DockStyle.Fill;
            this.HelpPages.Location = new System.Drawing.Point(0, 0);
            this.HelpPages.Name = "HelpPages";
            this.HelpPages.SelectedIndex = 0;
            this.HelpPages.Size = new System.Drawing.Size(1322, 572);
            this.HelpPages.TabIndex = 0;
            // 
            // HelpTopicsSubpage
            // 
            this.HelpTopicsSubpage.Location = new System.Drawing.Point(4, 29);
            this.HelpTopicsSubpage.Name = "HelpTopicsSubpage";
            this.HelpTopicsSubpage.Padding = new System.Windows.Forms.Padding(3);
            this.HelpTopicsSubpage.Size = new System.Drawing.Size(1314, 539);
            this.HelpTopicsSubpage.TabIndex = 0;
            this.HelpTopicsSubpage.Text = "Help Topics";
            this.HelpTopicsSubpage.UseVisualStyleBackColor = true;
            // 
            // AboutSubPage
            // 
            this.AboutSubPage.Controls.Add(this.AboutPanel);
            this.AboutSubPage.Location = new System.Drawing.Point(4, 29);
            this.AboutSubPage.Name = "AboutSubPage";
            this.AboutSubPage.Padding = new System.Windows.Forms.Padding(3);
            this.AboutSubPage.Size = new System.Drawing.Size(1314, 539);
            this.AboutSubPage.TabIndex = 1;
            this.AboutSubPage.Text = "About RATSharp";
            this.AboutSubPage.UseVisualStyleBackColor = true;
            // 
            // AboutPanel
            // 
            this.AboutPanel.ColumnCount = 1;
            this.AboutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.AboutPanel.Controls.Add(this.label20, 0, 0);
            this.AboutPanel.Controls.Add(this.AboutLabel, 0, 1);
            this.AboutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AboutPanel.Location = new System.Drawing.Point(3, 3);
            this.AboutPanel.Name = "AboutPanel";
            this.AboutPanel.RowCount = 2;
            this.AboutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 180F));
            this.AboutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.AboutPanel.Size = new System.Drawing.Size(1308, 533);
            this.AboutPanel.TabIndex = 1;
            // 
            // label20
            // 
            this.label20.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(518, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(271, 163);
            this.label20.TabIndex = 0;
            this.label20.Text = "🐀#";
            // 
            // AboutLabel
            // 
            this.AboutLabel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.AboutLabel.AutoSize = true;
            this.AboutLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AboutLabel.Location = new System.Drawing.Point(464, 180);
            this.AboutLabel.Name = "AboutLabel";
            this.AboutLabel.Size = new System.Drawing.Size(379, 200);
            this.AboutLabel.TabIndex = 0;
            this.AboutLabel.Text = resources.GetString("AboutLabel.Text");
            this.AboutLabel.UseMnemonic = false;
            // 
            // MainStatusStrip
            // 
            this.MainStatusStrip.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.MainStatusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MainProgressBar,
            this.MainStatus});
            this.MainStatusStrip.Location = new System.Drawing.Point(0, 644);
            this.MainStatusStrip.Name = "MainStatusStrip";
            this.MainStatusStrip.Size = new System.Drawing.Size(1344, 28);
            this.MainStatusStrip.TabIndex = 1;
            // 
            // MainProgressBar
            // 
            this.MainProgressBar.MarqueeAnimationSpeed = 50;
            this.MainProgressBar.Name = "MainProgressBar";
            this.MainProgressBar.Size = new System.Drawing.Size(300, 22);
            // 
            // MainStatus
            // 
            this.MainStatus.Name = "MainStatus";
            this.MainStatus.Size = new System.Drawing.Size(0, 23);
            this.MainStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Modes
            // 
            this.Modes.Controls.Add(this.MainMode);
            this.Modes.Controls.Add(this.PreviewMode);
            this.Modes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Modes.Location = new System.Drawing.Point(0, 0);
            this.Modes.Name = "Modes";
            this.Modes.SelectedIndex = 0;
            this.Modes.Size = new System.Drawing.Size(1344, 644);
            this.Modes.TabIndex = 0;
            // 
            // MainMode
            // 
            this.MainMode.Controls.Add(this.Pages);
            this.MainMode.Location = new System.Drawing.Point(4, 29);
            this.MainMode.Name = "MainMode";
            this.MainMode.Padding = new System.Windows.Forms.Padding(3);
            this.MainMode.Size = new System.Drawing.Size(1336, 611);
            this.MainMode.TabIndex = 0;
            this.MainMode.Text = "Main Menu";
            this.MainMode.UseVisualStyleBackColor = true;
            // 
            // PreviewMode
            // 
            this.PreviewMode.Controls.Add(this.PreviewTablePanel);
            this.PreviewMode.Location = new System.Drawing.Point(4, 29);
            this.PreviewMode.Name = "PreviewMode";
            this.PreviewMode.Padding = new System.Windows.Forms.Padding(3);
            this.PreviewMode.Size = new System.Drawing.Size(1336, 611);
            this.PreviewMode.TabIndex = 1;
            this.PreviewMode.Text = "Preview";
            this.PreviewMode.UseVisualStyleBackColor = true;
            // 
            // PreviewTablePanel
            // 
            this.PreviewTablePanel.ColumnCount = 1;
            this.PreviewTablePanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.PreviewTablePanel.Controls.Add(this.PreviewControlPanel, 0, 0);
            this.PreviewTablePanel.Controls.Add(this.PreviewBrowserContainerPanel, 0, 1);
            this.PreviewTablePanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PreviewTablePanel.Location = new System.Drawing.Point(3, 3);
            this.PreviewTablePanel.Name = "PreviewTablePanel";
            this.PreviewTablePanel.RowCount = 2;
            this.PreviewTablePanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 57F));
            this.PreviewTablePanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.PreviewTablePanel.Size = new System.Drawing.Size(1330, 605);
            this.PreviewTablePanel.TabIndex = 0;
            // 
            // PreviewControlPanel
            // 
            this.PreviewControlPanel.BackColor = System.Drawing.SystemColors.Control;
            this.PreviewControlPanel.Controls.Add(this.SaveModeInput);
            this.PreviewControlPanel.Controls.Add(this.PrintPreviewButton);
            this.PreviewControlPanel.Controls.Add(this.SaveFlatButton);
            this.PreviewControlPanel.Controls.Add(this.SaveAccessButton);
            this.PreviewControlPanel.Controls.Add(this.SaveExcelButton);
            this.PreviewControlPanel.Controls.Add(this.SaveTextButton);
            this.PreviewControlPanel.Controls.Add(this.SaveHTMLButton);
            this.PreviewControlPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PreviewControlPanel.Location = new System.Drawing.Point(3, 3);
            this.PreviewControlPanel.Name = "PreviewControlPanel";
            this.PreviewControlPanel.Size = new System.Drawing.Size(1324, 51);
            this.PreviewControlPanel.TabIndex = 1;
            // 
            // SaveModeInput
            // 
            this.SaveModeInput.Dock = System.Windows.Forms.DockStyle.Right;
            this.SaveModeInput.FormattingEnabled = true;
            this.SaveModeInput.ItemHeight = 20;
            this.SaveModeInput.Items.AddRange(new object[] {
            "Save only",
            "Save and open"});
            this.SaveModeInput.Location = new System.Drawing.Point(1204, 0);
            this.SaveModeInput.Name = "SaveModeInput";
            this.SaveModeInput.Size = new System.Drawing.Size(120, 51);
            this.SaveModeInput.TabIndex = 8;
            // 
            // PrintPreviewButton
            // 
            this.PrintPreviewButton.Location = new System.Drawing.Point(1113, 3);
            this.PrintPreviewButton.Name = "PrintPreviewButton";
            this.PrintPreviewButton.Size = new System.Drawing.Size(85, 45);
            this.PrintPreviewButton.TabIndex = 7;
            this.PrintPreviewButton.Text = "Print";
            this.PrintPreviewButton.UseVisualStyleBackColor = true;
            this.PrintPreviewButton.Click += new System.EventHandler(this.PrintPreviewButton_Click);
            // 
            // SaveFlatButton
            // 
            this.SaveFlatButton.Location = new System.Drawing.Point(891, 3);
            this.SaveFlatButton.Name = "SaveFlatButton";
            this.SaveFlatButton.Size = new System.Drawing.Size(216, 45);
            this.SaveFlatButton.TabIndex = 6;
            this.SaveFlatButton.Text = "Save as Flat File";
            this.SaveFlatButton.UseVisualStyleBackColor = true;
            this.SaveFlatButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // SaveAccessButton
            // 
            this.SaveAccessButton.Location = new System.Drawing.Point(669, 3);
            this.SaveAccessButton.Name = "SaveAccessButton";
            this.SaveAccessButton.Size = new System.Drawing.Size(216, 45);
            this.SaveAccessButton.TabIndex = 5;
            this.SaveAccessButton.Text = "Save as Access (*.accdb)";
            this.SaveAccessButton.UseVisualStyleBackColor = true;
            this.SaveAccessButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // SaveExcelButton
            // 
            this.SaveExcelButton.Location = new System.Drawing.Point(447, 3);
            this.SaveExcelButton.Name = "SaveExcelButton";
            this.SaveExcelButton.Size = new System.Drawing.Size(216, 45);
            this.SaveExcelButton.TabIndex = 4;
            this.SaveExcelButton.Text = "Save as Excel (*.xlsx)";
            this.SaveExcelButton.UseVisualStyleBackColor = true;
            this.SaveExcelButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // SaveTextButton
            // 
            this.SaveTextButton.Location = new System.Drawing.Point(225, 3);
            this.SaveTextButton.Name = "SaveTextButton";
            this.SaveTextButton.Size = new System.Drawing.Size(216, 45);
            this.SaveTextButton.TabIndex = 3;
            this.SaveTextButton.Text = "Save as Text (*.txt)";
            this.SaveTextButton.UseVisualStyleBackColor = true;
            this.SaveTextButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // SaveHTMLButton
            // 
            this.SaveHTMLButton.Location = new System.Drawing.Point(3, 3);
            this.SaveHTMLButton.Name = "SaveHTMLButton";
            this.SaveHTMLButton.Size = new System.Drawing.Size(216, 45);
            this.SaveHTMLButton.TabIndex = 2;
            this.SaveHTMLButton.Text = "Save as HTML (*.html)";
            this.SaveHTMLButton.UseVisualStyleBackColor = true;
            this.SaveHTMLButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // PreviewBrowserContainerPanel
            // 
            this.PreviewBrowserContainerPanel.Controls.Add(this.PreviewBrowser);
            this.PreviewBrowserContainerPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PreviewBrowserContainerPanel.Location = new System.Drawing.Point(3, 60);
            this.PreviewBrowserContainerPanel.Name = "PreviewBrowserContainerPanel";
            this.PreviewBrowserContainerPanel.Size = new System.Drawing.Size(1324, 542);
            this.PreviewBrowserContainerPanel.TabIndex = 2;
            // 
            // PreviewBrowser
            // 
            this.PreviewBrowser.AllowWebBrowserDrop = false;
            this.PreviewBrowser.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PreviewBrowser.Location = new System.Drawing.Point(0, 0);
            this.PreviewBrowser.MinimumSize = new System.Drawing.Size(20, 20);
            this.PreviewBrowser.Name = "PreviewBrowser";
            this.PreviewBrowser.ScriptErrorsSuppressed = true;
            this.PreviewBrowser.Size = new System.Drawing.Size(1324, 542);
            this.PreviewBrowser.TabIndex = 1;
            this.PreviewBrowser.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.PreviewBrowser_DocumentCompleted);
            this.PreviewBrowser.GotFocus += new System.EventHandler(this.PreviewBrowser_GotFocus);
            this.PreviewBrowser.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.PreviewBrowser_PreviewKeyDown);
            // 
            // KeyboardNavigationButton
            // 
            this.KeyboardNavigationButton.ContextMenuStrip = this.KeyboardNavigationMenu;
            this.KeyboardNavigationButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.KeyboardNavigationButton.Location = new System.Drawing.Point(1262, 0);
            this.KeyboardNavigationButton.Name = "KeyboardNavigationButton";
            this.KeyboardNavigationButton.Size = new System.Drawing.Size(75, 23);
            this.KeyboardNavigationButton.TabIndex = 1;
            this.KeyboardNavigationButton.Text = "KBD";
            this.KeyboardNavigationButton.UseVisualStyleBackColor = true;
            this.KeyboardNavigationButton.Click += new System.EventHandler(this.KeyboardNavigationButton_Click);
            // 
            // KeyboardNavigationMenu
            // 
            this.KeyboardNavigationMenu.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.KeyboardNavigationMenu.Name = "KeyboardNavigationMenu";
            this.KeyboardNavigationMenu.Size = new System.Drawing.Size(74, 4);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.KeyboardNavigationButton;
            this.ClientSize = new System.Drawing.Size(1344, 672);
            this.Controls.Add(this.Modes);
            this.Controls.Add(this.MainStatusStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(1366, 728);
            this.Name = "MainForm";
            this.Text = "RAT#";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.Pages.ResumeLayout(false);
            this.RandomNumbersPage.ResumeLayout(false);
            this.RandomNumbersPages.ResumeLayout(false);
            this.RandomSingleSubPage.ResumeLayout(false);
            this.RandomSingleSubPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.R_S_SamplingFrameHighInput)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.R_S_SequentialOrderQuantityInput)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.R_S_SamplingFrameLowInput)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.R_S_SpareQuantityInput)).EndInit();
            this.RandomStratifiedSubPage.ResumeLayout(false);
            this.RandomStratifiedSubPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.R_SS_InputGrid)).EndInit();
            this.AttributeAppraisalsPage.ResumeLayout(false);
            this.AttributeAppraisalsPages.ResumeLayout(false);
            this.AttributeUnrestrictedSubPage.ResumeLayout(false);
            this.AttributeUnrestrictedSubPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AA_U_ConfidenceLevelInput)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AA_U_SampleOfInterestSizeInput)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AA_U_SampleSizeInput)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AA_U_UniverseSizeInput)).EndInit();
            this.VariableAppraisalsPage.ResumeLayout(false);
            this.VariableAppraisalsPages.ResumeLayout(false);
            this.VariableUnrestrictedSubPage.ResumeLayout(false);
            this.VariableUnrestrictedSubPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.VA_U_SampleSizeInput)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.VA_U_UniverseSizeInput)).EndInit();
            this.VariableStratifiedSubPage.ResumeLayout(false);
            this.VariableStratifiedSubPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.VA_S_StrataSizeInput)).EndInit();
            this.SampleSizeDeterminationPage.ResumeLayout(false);
            this.SampleSizeDeterminationPages.ResumeLayout(false);
            this.SampleVariableSubPage.ResumeLayout(false);
            this.SampleVariablePages.ResumeLayout(false);
            this.HelpPage.ResumeLayout(false);
            this.HelpPages.ResumeLayout(false);
            this.AboutSubPage.ResumeLayout(false);
            this.AboutPanel.ResumeLayout(false);
            this.AboutPanel.PerformLayout();
            this.MainStatusStrip.ResumeLayout(false);
            this.MainStatusStrip.PerformLayout();
            this.Modes.ResumeLayout(false);
            this.MainMode.ResumeLayout(false);
            this.PreviewMode.ResumeLayout(false);
            this.PreviewTablePanel.ResumeLayout(false);
            this.PreviewControlPanel.ResumeLayout(false);
            this.PreviewBrowserContainerPanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl Pages;
        private System.Windows.Forms.TabPage RandomNumbersPage;
        private System.Windows.Forms.TextBox R_S_SeedInput;
        private System.Windows.Forms.TabPage AttributeAppraisalsPage;
        private System.Windows.Forms.Button R_S_GenerateButton;
        private System.Windows.Forms.NumericUpDown R_S_SamplingFrameHighInput;
        private System.Windows.Forms.NumericUpDown R_S_SamplingFrameLowInput;
        private System.Windows.Forms.NumericUpDown R_S_SpareQuantityInput;
        private System.Windows.Forms.NumericUpDown R_S_SequentialOrderQuantityInput;
        private System.Windows.Forms.TabControl RandomNumbersPages;
        private System.Windows.Forms.TabPage RandomSingleSubPage;
        private System.Windows.Forms.TabPage RandomSetTwoSubPage;
        private System.Windows.Forms.TabPage RandomSetThreeSubPage;
        private System.Windows.Forms.TabPage RandomSetFourSubPage;
        private System.Windows.Forms.TabPage RandomFramesSingleSubPage;
        private System.Windows.Forms.TabPage RandomFramesSetTwoSubPage;
        private System.Windows.Forms.TabPage RandomRHCSubPage;
        private System.Windows.Forms.TabPage VariableAppraisalsPage;
        private System.Windows.Forms.TabPage SampleSizeDeterminationPage;
        private System.Windows.Forms.TabPage HelpPage;
        private System.Windows.Forms.TabControl HelpPages;
        private System.Windows.Forms.TabPage HelpTopicsSubpage;
        private System.Windows.Forms.TabPage AboutSubPage;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox R_S_NameInput;
        private System.Windows.Forms.TabControl AttributeAppraisalsPages;
        private System.Windows.Forms.TabPage AttributeUnrestrictedSubPage;
        private System.Windows.Forms.Button AA_U_GenerateButton;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown AA_U_SampleOfInterestSizeInput;
        private System.Windows.Forms.NumericUpDown AA_U_SampleSizeInput;
        private System.Windows.Forms.NumericUpDown AA_U_UniverseSizeInput;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox AA_U_NameInput;
        private System.Windows.Forms.TabPage AttributeStratifiedSubPage;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox AA_U_IntervalTypeInput;
        private System.Windows.Forms.StatusStrip MainStatusStrip;
        private System.Windows.Forms.TabControl Modes;
        private System.Windows.Forms.TabPage MainMode;
        private System.Windows.Forms.TabPage AttributeTwoUnrestrictedSubPage;
        private System.Windows.Forms.TabPage AttributeThreeUnrestrictedSubPage;
        private System.Windows.Forms.TabPage AttributeRHCTwoSubPage;
        private System.Windows.Forms.TabPage AttributeRHCThreeSubPage;
        private System.Windows.Forms.TabPage AttributeStratifiedClusterSubPage;
        private System.Windows.Forms.TabPage AttributeStratifiedMultistageSubPage;
        private System.Windows.Forms.TabControl VariableAppraisalsPages;
        private System.Windows.Forms.TabPage VariableUnrestrictedSubPage;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.NumericUpDown VA_U_UniverseSizeInput;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox VA_U_NameInput;
        private System.Windows.Forms.TabPage VariableStratifiedSubPage;
        private System.Windows.Forms.TabPage VariableTwoUnrestrictedSubPage;
        private System.Windows.Forms.TabPage VariableThreeUnrestrictedSubPage;
        private System.Windows.Forms.TabPage VariableRHCTwoSubPage;
        private System.Windows.Forms.TabPage VariableRHCThreeSubPage;
        private System.Windows.Forms.TabPage VariableStratifiedClusterSubPage;
        private System.Windows.Forms.TabPage VariableStratifiedMultistageSubPage;
        private System.Windows.Forms.TextBox VA_U_FileInput;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ListBox VA_U_DataFileFormatInput;
        private System.Windows.Forms.Panel VA_U_SourcePanel;
        private System.Windows.Forms.ComboBox VA_U_SourceInput;
        private System.Windows.Forms.ComboBox VA_U_SourceOption2Input;
        private System.Windows.Forms.ComboBox VA_U_SourceOption1Input;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label VA_U_SourceInputLabel;
        private System.Windows.Forms.Label VA_U_SourceOption2Label;
        private System.Windows.Forms.Label VA_U_SourceOption1Label;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.NumericUpDown VA_U_SampleSizeInput;
        private System.Windows.Forms.Button VA_U_GenerateButton;
        private System.Windows.Forms.ComboBox VA_S_UniverseSourceInput;
        private System.Windows.Forms.ListBox VA_S_DataFileFormatInput;
        private System.Windows.Forms.Panel VA_S_UniverseSourcePanel;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label VA_S_UniverseSourceInputLabel;
        private System.Windows.Forms.Label VA_S_UniverseFileLabel;
        private System.Windows.Forms.TextBox VA_S_UniverseFileInput;
        private System.Windows.Forms.Button VA_S_GenerateButton;
        private System.Windows.Forms.ComboBox VA_S_SourceInput;
        private System.Windows.Forms.Panel VA_S_SourcePanel;
        private System.Windows.Forms.Label VA_S_SourceInputLabel;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox VA_S_FileInput;
        private System.Windows.Forms.TextBox VA_S_NameInput;
        private System.Windows.Forms.TabPage VariablePoststratificationSubPage;
        private System.Windows.Forms.TabPage VariableUnknownUniverseSubPage;
        private System.Windows.Forms.Label VA_U_PreviewLabel;
        private System.Windows.Forms.Label VA_S_UniverseSourceOption2Label;
        private System.Windows.Forms.Label VA_S_UniverseSourceOption1Label;
        private System.Windows.Forms.Label VA_S_SourceOption2Label;
        private System.Windows.Forms.Label VA_S_SourceOption1Label;
        private System.Windows.Forms.Label VA_S_PreviewLabel;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.NumericUpDown VA_S_StrataSizeInput;
        private System.Windows.Forms.ComboBox VA_S_SourceOption1Input;
        private System.Windows.Forms.ComboBox VA_S_UniverseSourceOption2Input;
        private System.Windows.Forms.ComboBox VA_S_UniverseSourceOption1Input;
        private System.Windows.Forms.ComboBox VA_S_SourceOption2Input;
        private System.Windows.Forms.TabPage PreviewMode;
        private System.Windows.Forms.TableLayoutPanel PreviewTablePanel;
        private System.Windows.Forms.WebBrowser PreviewBrowser;
        private System.Windows.Forms.Panel PreviewControlPanel;
        private System.Windows.Forms.ListBox SaveModeInput;
        private System.Windows.Forms.Button SaveHTMLButton;
        private System.Windows.Forms.ToolStripStatusLabel MainStatus;
        private System.Windows.Forms.ToolStripProgressBar MainProgressBar;
        private System.Windows.Forms.Button SaveTextButton;
        private System.Windows.Forms.Button SaveFlatButton;
        private System.Windows.Forms.Button SaveAccessButton;
        private System.Windows.Forms.Button SaveExcelButton;
        private System.Windows.Forms.Panel PreviewBrowserContainerPanel;
        private System.Windows.Forms.TableLayoutPanel AboutPanel;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label AboutLabel;
        private System.Windows.Forms.Button KeyboardNavigationButton;
        private System.Windows.Forms.ContextMenuStrip KeyboardNavigationMenu;
        private System.Windows.Forms.Button AA_U_ConfidenceLevelCustomizeButton;
        private System.Windows.Forms.NumericUpDown AA_U_ConfidenceLevelInput;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label AA_U_ConfidenceLevelPercentageLabel;
        private System.Windows.Forms.Label AA_U_DefaultCustomizeLabel;
        private System.Windows.Forms.Label AA_U_DefaultLabel;
        private System.Windows.Forms.TabPage RandomStratifiedSubPage;
        private System.Windows.Forms.DataGridView R_SS_InputGrid;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox R_SS_NameInput;
        private System.Windows.Forms.DataGridViewTextBoxColumn R_SS_SeedNumberInput;
        private System.Windows.Forms.DataGridViewTextBoxColumn R_SS_SequentialQuantityInput;
        private System.Windows.Forms.DataGridViewTextBoxColumn R_SS_SpareQuantityInput;
        private System.Windows.Forms.DataGridViewTextBoxColumn R_SS_FrameLowInput;
        private System.Windows.Forms.DataGridViewTextBoxColumn R_SS_FrameHighInput;
        private System.Windows.Forms.Label R_SS_StratifiedSaveInformationLabel;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox R_SS_StrataCountOutput;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button PrintPreviewButton;
        private System.Windows.Forms.TabControl SampleSizeDeterminationPages;
        private System.Windows.Forms.TabPage SampleVariableSubPage;
        private System.Windows.Forms.TabControl SampleVariablePages;
        private System.Windows.Forms.TabPage SampleVariableUnrestrictedProbeSubPage;
        private System.Windows.Forms.TabPage SampleVariableUnrestrictedEERSubPage;
        private System.Windows.Forms.TabPage SampleVariableStratifiedSubPage;
        private System.Windows.Forms.TabPage SampleAttributeSubPage;
    }
}

