﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

using System;
using System.Data;
using System.Linq;

namespace RATSharp.Renderers
{
    /// <summary>
    ///  <see cref="IRATResult"/> Microsoft Access database renderer.
    /// </summary>
    public static class AccessDatabase
    {
        /// <summary>
        ///  Renders a <see cref="DataSet"/> according to the underlying type of <paramref name="result"/>.
        /// </summary>
        /// <param name="result">Audit/review result that implements <see cref="IRATResult"/> interface.</param>
        internal static DataSet Render(IRATResult result)
        {
            if (result is RandomNumbersSingleResult)
            {
                return Render(result as RandomNumbersSingleResult);
            }

            return null;
        }

        /// <summary>
        ///  Renders a <see cref="RandomNumbersSingleResult"/> object to a <see cref="DataSet"/>.
        /// </summary>
        /// <param name="result">Single Stage Random Numbers Generation result.</param>
        static DataSet Render(RandomNumbersSingleResult result)
        {
            DataSet dataset = new DataSet(typeof(RandomNumbersSingleResult).ToString());

            DataTable reportTable = new DataTable("Report");
            DataTable valuesTable = new DataTable("Values");
            DataTable sparesTable = new DataTable("Spares");

            reportTable.Columns.Add("Seed-Number", typeof(double));
            reportTable.Columns.Add("Date", typeof(DateTime));
            reportTable.Columns.Add("Time", typeof(DateTime));

            valuesTable.Columns.Add("Order", typeof(int));
            valuesTable.Columns.Add("Value", typeof(int));

            sparesTable.Columns.Add("Order", typeof(int));
            sparesTable.Columns.Add("Value", typeof(int));

            reportTable.Rows.Add(result.SeedNumber, result.DateTime, result.DateTime);

            foreach (var number in result.Numbers.Take(result.SequentialSampleSize))
            {
                valuesTable.Rows.Add(number.Key, number.Value);
            }

            foreach (var number in result.Numbers.Skip(result.SequentialSampleSize))
            {
                sparesTable.Rows.Add(number.Key, number.Value);
            }

            dataset.Tables.Add(reportTable);
            dataset.Tables.Add(valuesTable);
            dataset.Tables.Add(sparesTable);

            return dataset;
        }
    }
}
