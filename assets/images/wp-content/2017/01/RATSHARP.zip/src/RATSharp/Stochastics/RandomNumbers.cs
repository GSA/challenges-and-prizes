﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace RATSharp.Stochastics
{
    /// <summary>
    ///  Random number generation facilities mimicking Visual Basic/Microsoft Excel random number generation logic.
    /// </summary>
    class RandomNumbers
    {
        /// <summary>
        ///  Static counter for unique seed generation.
        /// </summary>
        static int Counter = 0;

        /// <summary>
        ///  Lock facility to ensure unique seed generation.
        /// </summary>
        static object SeedGenerationLock = new object();

        /// <summary>
        ///  Gets a random seed between 0 and 100,000 with at most 2 decimal places.
        /// </summary>
        public static double GetSeed()
        {
            lock (SeedGenerationLock)
            {
                var random = new Random(unchecked((new Random(Counter++)).Next() + (int)DateTime.UtcNow.ToBinary()));
                return Math.Round(100_000 * random.NextDouble(), 2);
            }
        }

        /// <summary>
        ///  Gets seeds required for Wichmann-Hill random number generation.
        /// </summary>
        /// <param name="userSeed">User-provided or randomly generated seed for Wichmann-Hill seed generation.</param>
        /// <param name="seedA">Contains the first seed for Wichmann-Hill random number generation.</param>
        /// <param name="seedB">Contains the second seed for Wichmann-Hill random number generation.</param>
        /// <param name="seedC">Contains the third seed for Wichmann-Hill random number generation.</param>
        static void GetWichmannHillSeeds(
            double userSeed,
            out Int64 seedA,
            out Int64 seedB,
            out Int64 seedC)
        {
            const UInt64 _2toPower24 = 0b1_00000000_00000000_00000000ul;
            UInt64 trackingSeedA = 0ul;
            UInt64 trackingSeedB = 0ul;
            UInt64 trackingSeedC = 0ul;

            // Step 1
            Int32 step1 = 3758214;

            // Step 2:  Store the seed provided by the user as a double

            // Step 3
            var step3 = BitConverter.GetBytes(userSeed)                             // Step 3:  The bit string from step 2 is truncated to include only the first 32 bits.
                .Skip(4)
                .Take(4)                                                            //              include only first 4*8 bits
                .GetUInt16s();                                                      //              convert to unsigned 16-bit values

            // Step 4
            UInt16 step4 = Convert.ToUInt16(step3.First() ^ step3.Last());          // Step 4:  The first 16 bits and the last 16 bits of the bit string in Step 3 are then XOR’d together

            // Step 5
            UInt32 step5 = 0;
            step5 |= Convert.ToUInt32(BitConverter.GetBytes(step1).First());     // xxxxxxxx_xxxxxxxx_xxxxxxxx_XXXXXXXX
            step5 |= Convert.ToUInt32(step4) << 8;                              // xxxxxxxx_XXXXXXXX_XXXXXXXX_xxxxxxxx

            // Step 6
            UInt64 step6 = Convert.ToUInt64(step5);

            for (;;)
            {
                // Step 7
                UInt64 step7 = step6 * 1140671485ul + 12820163ul;

                // Step 8
                trackingSeedA = step7 % _2toPower24;

                // Step 9
                UInt64 step9 = (trackingSeedA * 30269ul) / _2toPower24 + 1ul;
                if (step9 < 30269ul)
                {
                    seedA = Convert.ToInt64(step9);
                    break;
                }
                else
                {
                    step6 = trackingSeedA;
                }
            }

            for (;;)
            {
                // Step 10
                UInt64 step10 = trackingSeedA * 1140671485ul + 12820163ul;

                // Step 11
                trackingSeedB = step10 % _2toPower24;

                // Step 12
                UInt64 step12 = (trackingSeedB * 30307ul) / _2toPower24 + 1ul;
                if (step12 < 30307ul)
                {
                    seedB = Convert.ToInt64(step12);
                    break;
                }
                else
                {
                    trackingSeedA = trackingSeedB;
                }
            }

            for (;;)
            {
                // Step 13
                UInt64 step13 = trackingSeedB * 1140671485ul + 12820163ul;

                // Step 14
                trackingSeedC = step13 % _2toPower24;

                // Step 15
                UInt64 step15 = (trackingSeedC * 30323ul) / _2toPower24 + 1ul;
                if (step15 < 30323ul)
                {
                    seedC = Convert.ToInt64(step15);
                    break;
                }
                else
                {
                    trackingSeedB = trackingSeedC;
                }
            }
        }

        /// <summary>
        ///  Generates deduplicated numbers from Wichmann-Hill random number generation.
        /// </summary>
        /// <param name="userSeed">Desired number of Wichmann-Hill random numbers to be generated.</param>
        /// <param name="userSeed">User-provided or randomly generated seed for Wichmann-Hill seed generation.</param>
        /// <param name="universe">The target universe/frame size of generated random number.</param>
        /// <param name="lowNumber">Lower bound of the target universe/frame size.</param>
        /// <param name="reportProgress">Method to be called with percentage completion as argument when random number generation is progressing.</param>
        public static UnorderedSet<UInt64> GetWichmannHillSet(
            int count,
            double userSeed,
            int universe,
            int lowNumber,
            Action<int> reportProgress)
        {
            UnorderedSet<UInt64> wichmannHillSet = new UnorderedSet<UInt64>();

            var progress = 0;

            GetWichmannHillSeeds(userSeed, out Int64 seedA, out Int64 seedB, out Int64 seedC);

            while (wichmannHillSet.Count < count)
            {
                var term1 = (seedA / 177L);
                var term2 = seedA - (177L * term1);
                seedA = 171L * term2 - 2L * term1;

                if (seedA <= 0)
                {
                    seedA = seedA + 30269L;
                }

                term1 = (seedB / 176L);
                term2 = seedB - (176L * term1);
                seedB = 172L * term2 - 35L * term1;

                if (seedB <= 0)
                {
                    seedB = seedB + 30307L;
                }

                term1 = (seedC / 178L);
                term2 = seedC - (178L * term1);
                seedC = 170L * term2 - 63L * term1;

                if (seedC <= 0)
                {
                    seedC = seedC + 30323L;
                }

                var term4 = seedA / 30269.0 + seedB / 30307.0 + seedC / 30323.0;

                wichmannHillSet.Add(Convert.ToUInt64(Math.Floor((term4 - Math.Floor(term4)) * universe) + lowNumber));

                if (100 * wichmannHillSet.Count / count > progress)
                {
                    progress = 100 * wichmannHillSet.Count / count;
                    reportProgress(progress);
                }
            }

            return wichmannHillSet;
        }
    }

    /// <summary>
    ///  Represents a strongly typed set of unique objects that can be accessed by index in insertion order. Provides deduplication facility through hashtable.
    /// </summary>
    /// <typeparam name="T">The type of elements in the set.</typeparam>
    class UnorderedSet<T> : IEnumerable<T>
    {
        /// <summary>
        ///  Backing list of <see cref="UnorderedSet{T}"/>
        /// </summary>
        List<T> List = new List<T>();

        /// <summary>
        ///  Backing set of <see cref="UnorderedSet{T}"/>
        /// </summary>
        HashSet<T> HashSet = new HashSet<T>();

        /// <summary>
        ///  Gets the number of elements contained in the <see cref="UnorderedSet{T}"/>
        /// </summary>
        public int Count => List.Count;

        /// <summary>
        ///  Adds the specified element to a set.
        /// </summary>
        /// <param name="item">The element to add to the set.</param>
        public void Add(T item)
        {
            if (false == HashSet.Contains(item))
            {
                HashSet.Add(item);
                List.Add(item);
            }
        }

        /// <summary>
        ///  Remove the specified element from a set.
        /// </summary>
        /// <param name="item">The element to remove from the set.</param>
        public bool Remove(T item)
        {
            return
                List.Remove(item) &&
                HashSet.Remove(item);
        }

        /// <summary>
        ///  Implements <see cref="IEnumerable"/> through <see cref="List"/>.
        /// </summary>
        public IEnumerator<T> GetEnumerator()
        {
            return List.AsReadOnly().GetEnumerator();
        }

        /// <summary>
        ///  Implements <see cref="IEnumerable"/> through <see cref="List"/>.
        /// </summary>
        IEnumerator IEnumerable.GetEnumerator()
        {
            return List.AsReadOnly().GetEnumerator();
        }
    }
}

namespace RATSharp
{
    /// <summary>
    ///  Contains extension methods used throughout the program.
    /// </summary>
    public static partial class Extensions
    {
        /// <summary>
        ///  Bitwise-converts this <see cref="byte"/> collection to <see cref="UInt16"/> collection.
        /// </summary>
        public static IEnumerable<UInt16> GetUInt16s(this IEnumerable<byte> byteEnumerable)
        {
            var index = 0u;
            UInt16 _16bit = 0;

            foreach (var byteContent in byteEnumerable)
            {
                _16bit |= Convert.ToUInt16(Convert.ToUInt16(byteContent) << 8);

                if (1 == index % 2)
                {
                    yield return _16bit;
                }

                _16bit >>= 8;

                ++index;
            }

            if (1 == index % 2)
            {
                throw new InvalidCastException("Odd-sized byte enumerable cannot be casted to 16-bit enumerable.");
            }
        }
    }
}
