﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

using RATSharp.Stochastics;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace RATSharp
{
    /// <summary>
    ///  Primary form for the program.
    /// </summary>
    public partial class MainForm : Form
    {
        /// <summary>
        ///  UI setup phase for Single Stage Random Numbers, called by <see cref="MainForm_Load"/>.
        /// </summary>
        private void R_S_Load()
        {
            // do nothing
        }

        /// <summary>
        ///  User input validation procedure for Single Stage Random Numbers.
        /// </summary>
        private bool R_S_Validate()
        {
            if ((int)R_S_SamplingFrameHighInput.Value < (int)R_S_SamplingFrameLowInput.Value)
            {
                DefaultMessageBox.Error($"Frame size must be positive. Please enter High Number greater than the Low Number.");
                R_S_SequentialOrderQuantityInput.Focus();
                return false;
            }

            if ((int)R_S_SequentialOrderQuantityInput.Value < 1)
            {
                DefaultMessageBox.Error($"Request at least 1 sequential random number.");
                R_S_SequentialOrderQuantityInput.Focus();
                return false;
            }

            if ((int)R_S_SamplingFrameHighInput.Value - (int)R_S_SamplingFrameLowInput.Value + 1 < (int)R_S_SequentialOrderQuantityInput.Value + (int)R_S_SpareQuantityInput.Value)
            {
                DefaultMessageBox.Error($"Total requested random numbers ({(int)R_S_SequentialOrderQuantityInput.Value + (int)R_S_SpareQuantityInput.Value}) cannot be more than the frame size ({(int)R_S_SamplingFrameHighInput.Value - (int)R_S_SamplingFrameLowInput.Value + 1}). " +
                           "Please request less random numbers or widen the frame size.");
                R_S_SequentialOrderQuantityInput.Focus();
                return false;
            }

            return true;
        }

        #region Event handlers

        /// <summary>
        ///  Handles <see cref="Button.Click"/> event fired by <see cref="R_S_GenerateButton"/>.
        /// </summary>
        private void R_S_GenerateButton_Click(object sender, EventArgs e)
        {
            if (!R_S_Validate())
            {
                return;
            }

            MainStatus.Text = "Computation started";
            MainProgressBar.Style = ProgressBarStyle.Marquee;

            var userSeed = double.TryParse(R_S_SeedInput.Text, out double seed) ? seed : RandomNumbers.GetSeed();
            var sequentialOrderQuantity = (int)R_S_SequentialOrderQuantityInput.Value;
            var spareQuantity = (int)R_S_SpareQuantityInput.Value;
            var highNumber = (int)R_S_SamplingFrameHighInput.Value;
            var lowNumber = (int)R_S_SamplingFrameLowInput.Value;

            var result = new RandomNumbersSingleResult()
            {
                Name = R_S_NameInput.Text,
                SeedNumber = userSeed,
                SequentialSampleSize = sequentialOrderQuantity,
                SpareSampleSize = spareQuantity,
                UniverseSize = highNumber - lowNumber + 1,
                Sum = 0
            };

            var worker = new BackgroundWorker()
            {
                WorkerReportsProgress = true
            };

            worker.DoWork += (object lambdaSender, DoWorkEventArgs lambdaArgs) =>
            {
                var lambdaResult = lambdaArgs.Argument as RandomNumbersSingleResult;
                Action<int> reportProgress = (int percentProgress) =>
                {
                    (lambdaSender as BackgroundWorker).ReportProgress(percentProgress);
                };

                var set = RandomNumbers.GetWichmannHillSet(sequentialOrderQuantity + spareQuantity, userSeed, highNumber - lowNumber + 1, lowNumber, reportProgress);

                UInt64 order = 1;
                lambdaResult.Numbers = set
                    .Take(sequentialOrderQuantity)
                    .AsParallel()
                    .Select(value => new KeyValuePair<ulong, ulong>(order++, value.AccumulateTo(ref result.Sum)))
                    .OrderBy(row => row.Value)
                    .AsSequential()
                    .Concat(set
                        .Skip(sequentialOrderQuantity)
                        .Select(value => new KeyValuePair<ulong, ulong>(order++, value.AccumulateTo(ref result.Sum)))
                    ).ToList();

                lambdaArgs.Result = lambdaResult;
            };

            worker.RunWorkerCompleted += (object lambdaSender, RunWorkerCompletedEventArgs lambdaArgs) =>
            {
                MainStatus.Text = $"Rendering result...";
                SetActiveResult(lambdaArgs.Result as RandomNumbersSingleResult);
                MainStatus.Text = $"Completed.";
                MainProgressBar.Value = 0;
                RandomSingleSubPage.Controls.SetEnabled(true);
            };

            worker.ProgressChanged += (object lambdaSender, ProgressChangedEventArgs lambdaArgs) =>
            {
                MainStatus.Text = $"Computed {lambdaArgs.ProgressPercentage}%";
                MainProgressBar.Style = ProgressBarStyle.Blocks;
                MainProgressBar.Value = lambdaArgs.ProgressPercentage;
            };

            RandomSingleSubPage.Controls.SetEnabled(false);

            worker.RunWorkerAsync(result);
        }

        /// <summary>
        ///  Handles <see cref="TextBox.Validating"/> event fired by <see cref="R_S_SeedInput"/>.
        /// </summary>
        private void R_S_SeedInput_Validating(object sender, CancelEventArgs e)
        {
            var inputTextBox = sender as TextBox;

            if (0 == inputTextBox.Text.Length)
            {   // allow empty field
                return;
            }

            if (false == double.TryParse(inputTextBox.Text, out double seed))
            {   // if the input text is not a decimal, clear input
                inputTextBox.Text = "";
                e.Cancel = true;
            }
        }

        #endregion
    }

    /// <summary>
    ///  Contains extension methods used throughout the program.
    /// </summary>
    public static partial class Extensions
    {
        /// <summary>
        ///  Fluent interface to support accumulation when used inside a LINQ query.
        /// </summary>
        /// <param name="accumulation">Variable to accumulate to.</param>
        public static UInt64 AccumulateTo(
            this UInt64 value,
            ref UInt64 accumulation)
        {
            accumulation += value;
            return value;
        }
    }
}