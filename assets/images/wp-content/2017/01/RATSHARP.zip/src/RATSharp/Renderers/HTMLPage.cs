﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;

namespace RATSharp.Renderers
{
    /// <summary>
    ///  <see cref="IRATResult"/> HTML renderer.
    /// </summary>
    public static class HTMLPage
    {   /// This class is implemented using heredoc to preserve visual integrity of rendering result.
        /// For more information about heredoc, see https://en.wikipedia.org/w/index.php?title=Here_document&oldid=756198374

        /// <summary>
        ///  Gets the style tag for this HTML document containing CSS declarations required to visually 
        ///  format the page.
        /// </summary>
        static string Style => @"
    <style>
body { font-size: 75% }
h1 { text-align: center }
h2 { text-align: center }
table:not(.table-conf):not(.table-stratum-summary):not(.table-universe) { border-collapse: collapse }
table:not(#table-strata) td.n { background-color: #ddd; border: 1px solid #888 }
table.fit-to-contents, td { width: 1% }
table#table-heading { width: 100% }
table#table-result > tbody > tr { border: 1px solid #000 }
table#table-result > tbody > tr > td:nth-child(1),
table#table-result > tbody > tr > td:nth-child(3) { vertical-align: top }
tr.total-row { border-top: 1px solid #000 }
td, th { 
    padding-left: 5px;
    padding-right: 5px;
}
th[colspan] { border-bottom: 1px solid #000 }
td.h, td.e, p.h { text-align: center }
td.n, td.r { text-align: right }
tr:last-child > td.hide-if-last { display: none }
span[nowrap] { white-space: nowrap }
.b { font-weight: bolder }
.highlight { background-color: #fec }
.warn { color: #f00 }
    </style>";

        /// <summary>
        ///  Renders HTML output according to the underlying type of <paramref name="result"/>.
        /// </summary>
        /// <param name="result">Analysis result to render.</param>
        internal static string Render(IRATResult result)
        {
            if (result is VariableAppraisalStratifiedResult)
            {
                return RenderPage(result, content: Render(result as VariableAppraisalStratifiedResult))
                    .Replace("#TYPE", "STRATIFIED VARIABLE APPRAISAL");
            }
            else if (result is VariableAppraisalUnrestrictedResult)
            {
                return RenderPage(result, content: Render(result as VariableAppraisalUnrestrictedResult))
                    .Replace("#TYPE", "UNRESTRICTED VARIABLE APPRAISAL");
            }
            else if (result is AttributeAppraisalUnrestrictedResult)
            {
                return RenderPage(result, content: Render(result as AttributeAppraisalUnrestrictedResult))
                    .Replace("#TYPE", "SINGLE STAGE ATTRIBUTE APPRAISAL");
            }
            else if (result is RandomNumbersStratifiedResult)
            {
                return RenderPage(result, content: Render(result as RandomNumbersStratifiedResult))
                    .Replace("#TYPE", "RANDOM NUMBER GENERATOR");
            }
            else if (result is RandomNumbersSingleResult)
            {
                return RenderPage(result, content: Render(result as RandomNumbersSingleResult))
                    .Replace("#TYPE", "RANDOM NUMBER GENERATOR");
            }

            return "";
        }

        /// <summary>
        ///  Renders a <see cref="VariableAppraisalConfidence"/> object to HTML.
        /// </summary>
        /// <param name="confidence">Confidence interval details from Variable Appraisal result.</param>
        /// <param name="p">Confidence level of this interval.</param>
        /// <param name="index">Index of this confidence interval within the group.</param>
        /// <param name="count">Number of confidence intervals to be rendered in total.</param>
        static string Render(
            VariableAppraisalConfidence confidence,
            double p,
            int index,
            int count)
        {
            return $@"
            <tr>
    <td class=""e"">{p:p0}</td>
    {"<td></td>".Repeat(count - index - 1)}
    <td class=""n"">{confidence.LowerLimit:#,#}</td>
    {"<td></td>".Repeat(index)}
    <td class=""n"">{confidence.Precision:#,#}</td>
    <td class=""n"">({confidence.PrecisionRatio:p2})</td>
    {"<td></td>".Repeat(index)}
    <td class=""n"">{confidence.UpperLimit:#,#}</td>
    {"<td></td>".Repeat(count - index - 1)}
    <td class=""n"">{confidence.Statistic:#.000000000000}</td>
            </tr>";
        }

        /// <summary>
        ///  Renders a collection of <see cref="VariableAppraisalConfidence"/> objects to HTML.
        /// </summary>
        /// <param name="confidenceLimits">
        ///  A collection of <see cref="VariableAppraisalConfidence"/> objects as sorted dictionary with
        ///  confidence levels as keys.
        /// </param>
        static string Render(SortedDictionary<double, VariableAppraisalConfidence> confidenceLimits)
        {
            return $@"
    <p class=""h b"">CONFIDENCE LIMITS</p>
    <table align=""center"" class=""table-conf"">
        <thead>
            <tr>
    <th>CONFIDENCE LEVEL</th>
    <th colspan=""{confidenceLimits.Count}"">LOWER LIMIT</th>
    <th>PRECISION</th>
    <th>(PERCENT)</th>
    <th colspan=""{confidenceLimits.Count}"">UPPER LIMIT</th>
    <th>{(confidenceLimits.IsZ() ? "Z" : "T")}-VALUE USED</th>
            </tr>
        </thead>
        <tbody>
{
    confidenceLimits.Select((confidence, i) => Render(confidence.Value, confidence.Key, i, confidenceLimits.Count)).Concat()
}
        </tbody>
    </table>";
        }

        /// <summary>
        ///  Renders a <see cref="VariableAppraisalResult"/> object to HTML.
        /// </summary>
        /// <param name="result">Variable Appraisal result.</param>
        /// <param name="index">
        ///  Stratum index of this result. A negative value indicates that this result is not a member of
        ///  any stratum.
        /// </param>
        /// <param name="universe">Universe size of the appraisal.</param>
        static string Render(
            VariableAppraisalResult result,
            int index,
            int universe)
        {
            return $@"
            <tr>
    <td class=""c"">
        {
            (result.ConfidenceLimits.IsZ() ? "OVERALL" :
            index < 0 ? "" : $"Stratum&nbsp;{index + 1}")
        }
    </td>
    <td>
    <table align=""center"" class=""table-stratum-summary"">
        <thead>
            <tr>
{
    (result.ConfidenceLimits.IsZ() ? "" : @"
    <th>MEAN</th>
    <th>STANDARD DEVIATION</th>
    <th>SKEWNESS</th>
    <th>KURTOSIS</th>
    <th>STANDARD ERROR (MEAN)</th>
")
}
    <th>STANDARD ERROR (TOTAL)</th>
    <th>POINT ESTIMATE</th>
            </tr>
        </thead>
        <tbody>
            <tr>
{
    (result.ConfidenceLimits.IsZ() ? "" : $@"
    <td class=""n"">{result.Mean:#,#.00}</td>
    <td class=""n"">{result.StandardDeviation:#,#.00}</td>
    <td class=""n"">{result.Skewness:#,#.00}</td>
    <td class=""n"">{result.Kurtosis:#,#.00}</td>
    <td class=""n"">{result.StandardErrorMean:#,#.00}</td>
")
}
    <td class=""n"">{result.StandardErrorTotal:#,#}</td>
    <td class=""n"">{result.PointEstimate:#,#}</td>
            </tr>
        </tbody>
    </table>
{
    (result.Summary[0].SampleSize <= 1 ? @"<p class=""b h warn"">SAMPLE SIZE TOO SMALL TO COMPUTE CONFIDENCE INTERVAL</p>" : Render(result.ConfidenceLimits))
}
    </td>
    <td>
        <table align=""center"" class=""table-universe"">
            <thead>
                <tr>
        <th>UNIVERSE SIZE</th>
        <th><br/><br/><br/></th>
                </tr>
            </thead>
            <tbody>
                <tr>
        <td class=""n"">{universe:#,0}</td>
                </tr>
            </tbody>
        </table>
    </td>
            </tr>
";
        }

        /// <summary>
        ///  Renders a <see cref="AttributeAppraisalConfidence"/> object to HTML.
        /// </summary>
        /// <param name="confidence">Confidence interval details from Attribute Appraisal result.</param>
        /// <param name="p">Confidence level of this interval.</param>
        /// <param name="index">Index of this confidence interval within the group.</param>
        /// <param name="count">Number of confidence intervals to be rendered in total.</param>
        static string Render(
            AttributeAppraisalConfidence confidence,
            double p,
            int index,
            int count)
        {
            return $@"
            <tr>
    <td class=""e"">{p:p0}</td>
{(
    // if has confidence limit, print limit
    confidence.LowerLimit.HasValue ? $@"
    {"<td></td>".Repeat(2 * (count - index - 1))}
    <td class=""n"">{confidence.LowerLimit:#,0}</td>
    <td class=""n""><span nowrap>{confidence.LowerLimitRatio:p3}</span></td>
    {"<td></td>".Repeat(2 * index)}".RegexReplace(@" (?=\%)", string.Empty) :

    // else if doesn't have confidence limit, print notice
    index == 0 ? $@"
    <td rowspan=""{count}"" colspan=""{2 * count}"" class=""highlight"">
       <span nowrap>SINCE NO ITEMS HAVING THE CHARACTERISTIC(S) OF INTEREST</span>
       <span nowrap>WERE FOUND IN THE SAMPLE, THE PROGRAM HAS CALCULATED</span>
       <span nowrap>ONLY THE MAXIMUM NUMBER OF ITEMS HAVING THE</span>
       <span nowrap>CHARACTERISTIC(S) OF INTEREST IN THE UNIVERSE.</span>
    </td>" :

    // else don't print anything
    string.Empty
)}
{(
    // if has confidence limit, print limit
    confidence.UpperLimit.HasValue ? $@"
    {"<td></td>".Repeat(2 * index)}
    <td class=""n"">{confidence.UpperLimit:#,0}</td>
    <td class=""n""><span nowrap>{confidence.UpperLimitRatio:p3}</span></td>
    {"<td></td>".Repeat(2 * (count - index - 1))}" :

    // else if doesn't have confidence limit, print notice
    index == 0 ? $@"
    <td rowspan=""{count}"" colspan=""{2 * count}"" class=""highlight"">
        <span nowrap>SINCE ALL SAMPLE ITEMS CONTAINED THE CHARACTERISTIC(S)</span>
        <span nowrap>OF INTEREST, THE PROGRAM HAS CALCULATED ONLY</span>
        <span nowrap>THE MINIMUM NUMBER OF ITEMS IN THE UNIVERSE</span>
        <span nowrap>HAVING THE CHARACTERISTIC(S) OF INTEREST.</span>
    </td>" :

    // else don't print anything
    string.Empty
)}
            </tr>";
        }

        /// <summary>
        ///  Renders a collection of <see cref="AttributeAppraisalConfidence"/> objects to HTML.
        /// </summary>
        /// <param name="confidenceLimits">
        ///  A collection of <see cref="AttributeAppraisalConfidence"/> objects as sorted dictionary with
        ///  confidence levels as keys.
        /// </param>
        static string Render(SortedDictionary<double, AttributeAppraisalConfidence> confidenceLimits)
        {
            return $@"
    <p class=""h b"">CONFIDENCE LIMITS</p>
    <table align=""center"" class=""table-conf"">
        <thead>
            <tr>
    <th>CONFIDENCE LEVEL</th>
    <th colspan=""{2 * confidenceLimits.Count}"">LOWER LIMIT</th>
    <th colspan=""{2 * confidenceLimits.Count}"">UPPER LIMIT</th>
            </tr>
        </thead>
        <tbody>
{
    confidenceLimits.Select((confidence, i) => Render(confidence.Value, confidence.Key, i, confidenceLimits.Count)).Concat()
}
        </tbody>
    </table>";
        }

        /// <summary>
        ///  Renders a collection of random numbers to HTML.
        /// </summary>
        /// <param name="numbers">A collection of random numbers key-value pair with its order as keys.</param>
        /// <param name="sequentialSize">
        ///  Count of first elements within <paramref name="numbers"/> that are sorted in sequential order.
        /// </param>
        static string Render(
            IEnumerable<KeyValuePair<UInt64, UInt64>> numbers,
            int sequentialSize)
        {
            return $@"
    <p class=""h b"">RANDOM NUMBERS</p>
    <table align=""center"" class=""table-random-numbers fit-to-contents"">
        <thead>
            <tr>
    <th>SELECTION ORDER</th>
    <th>VALUE</th>
            </tr>
        </thead>
        <tbody>
            <tr>
    <td colspan=""2"" class=""highlight"">(SEQUENTIAL&nbsp;ORDER)</td>
            </tr>
{
    numbers.Take(sequentialSize).Select(number => $@"
            <tr>
    <td class=""n"">{number.Key}</td>
    <td class=""n"">{number.Value}</td>
            </tr>
").Concat()
}
            <tr>
    <td colspan=""2"" class=""highlight hide-if-last"">SPARES&nbsp;(RANDOM&nbsp;ORDER)</td>
            </tr>
{
    numbers.Skip(sequentialSize).Select(number => $@"
            <tr>
    <td class=""n"">{number.Key}</td>
    <td class=""n"">{number.Value}</td>
            </tr>
").Concat()
}
        </tbody>
    </table>";
        }

        /// <summary>
        ///  Renders a <see cref="VariableAppraisalStratifiedResult"/> object to HTML.
        /// </summary>
        /// <param name="result">Stratified Variable Appraisal result.</param>
        static string Render(VariableAppraisalStratifiedResult result)
        {
            return $@"
    <table class=""fit-to-contents"" align=""center"" id=""table-strata"">
        <thead>
            <tr>
    <th>STRATUM&nbsp;NUMBER</th>
    <th>SAMPLE&nbsp;SIZE</th>
{
    result.Overall.Types.Select(type => $@"
    <th>TOTAL&nbsp;OF {type.ToString().ToUpperInvariant()}&nbsp;VALUES</th>").Concat()
}
    <th>NONZERO&nbsp;ITEMS</th>
            </tr>
        </thead>
        <tbody>
{
    result.Strata.Select(stratum => $@"
            <tr>
    <td class=""n"">{stratum.Key + 1:d}</td>
    <td class=""n"">{stratum.Value.Summary.SampleSize:d}</td>
{
    stratum.Value.Types.Select(type => $@"
    <td class=""n"">{stratum.Value[type].Sum:#,0.00}</td>").Concat()
}
    <td class=""n"">{stratum.Value.Summary.NonzeroSize:d}</td>
            </tr>
").Concat()
}
            <tr class=""total-row"">
    <th>TOTALS</th>
    <td class=""n"">{result.Overall.Summary.SampleSize}</td>
{
    result.Overall.Types.Select(type => $@"
    <td class=""n"">{result.Overall[type].Sum:#,#}</td>").Concat()
}
    <td class=""n"">{result.Overall.Summary.NonzeroSize}</td>
            </tr>
        </tbody>
    </table>
    <br/>
    <table align=""center"" class=""fit-to-contents"" id=""table-result"">
        <tbody>
{
    // for each appraisal variable type
    result.Overall.Types.Select(type => $@"
            <tr style=""border: 0px""><td colspan=3></td></tr>
            <tr>
    <td colspan=3 class=""h b highlight""><br/>{type.ToString().ToUpperInvariant()}<br/><br/></td>
            </tr>
{
    // for each stratum
    result.Strata.Select(stratum => Render(stratum.Value[type], stratum.Key, stratum.Value.Summary.UniverseSize)).Concat() +
    // overall
    Render(result.Overall[type], -1, result.Overall.Summary.UniverseSize)
}").Concat()
}
        </tbody>
    </table>
";
        }

        /// <summary>
        ///  Renders a <see cref="VariableAppraisalUnrestrictedResult"/> object to HTML.
        /// </summary>
        /// <param name="result">Unrestricted Variable Appraisal result.</param>
        static string Render(VariableAppraisalUnrestrictedResult result)
        {
            return $@"
    <table class=""fit-to-contents"" align=""center"" id=""table-strata"">
        <thead>
            <tr>
    <th>SAMPLE&nbsp;SIZE</th>
{
    result.Types.Select(type => $@"
    <th>TOTAL&nbsp;OF {type.ToString().ToUpperInvariant()}&nbsp;VALUES</th>").Concat()
}
    <th>NONZERO&nbsp;ITEMS</th>
            </tr>
        </thead>
        <tbody>
            <tr>
    <td class=""n"">{result.Summary.SampleSize:d}</td>
{
    result.Types.Select(type => $@"
    <td class=""n"">{result[type].Sum:#,0.00}</td>").Concat()
}
    <td class=""n"">{result.Summary.NonzeroSize:d}</td>
            </tr>
        </tbody>
    </table>
    <br/>
    <table align=""center"" class=""fit-to-contents"" id=""table-result"">
        <tbody>
{
    // for each appraisal variable type
    result.Types.Select(type => $@"
            <tr style=""border: 0px""><td colspan=3></td></tr>
            <tr>
    <td colspan=3 class=""h b highlight""><br/>{type.ToString().ToUpperInvariant()}<br/><br/></td>
            </tr>
{
    // overall
    Render(result[type], -1, result.Summary.UniverseSize)
}").Concat()
}
        </tbody>
    </table>
";
        }

        /// <summary>
        ///  Renders an <see cref="AttributeAppraisalUnrestrictedResult"/> object to HTML.
        /// </summary>
        /// <param name="result">Unrestricted Attribute Appraisal result.</param>
        static string Render(AttributeAppraisalUnrestrictedResult result)
        {
            return $@"
    <table align=""center"" class=""table-stratum-summary"">
        <thead>
            <tr>
    <th rowspan=""2"">UNIVERSE SIZE</th>
    <th rowspan=""2"">SAMPLE SIZE</th>
    <th colspan=""3"">CHARACTERISTICS OF INTEREST</th>
    <th colspan=""2"">STANDARD ERROR</th>
            </tr>
            <tr>
    <th>QUANTITY IDENTIFIED IN SAMPLE</th>
    <th>PROJECTED QUANTITY IN&nbsp;UNIVERSE</th>
    <th>PERCENT</th>
    <th>PROJECTED QUANTITY</th>
    <th>PERCENT</th>
            </tr>
        </thead>
        <tbody>
            <tr>
    <td class=""n"">{result.UniverseSize:#,0}</td>
    <td class=""n"">{result.SampleSize:#,0}</td>
    <td class=""n"">{result.SampleOfInterestSize:#,0}</td>
    <td class=""n"">{result.PopulationOfInterestSize:#,0}</td>
    <td class=""n"">{result.PopulationOfInterestRatio:p3}</td>
    <td class=""n"">{result.StandardErrorTotal:#,0}</td>
    <td class=""n"">{result.StandardErrorMean:p3}</td>
            </tr>
        </tbody>
    </table>
{
    Render(result.ConfidenceLimits)
}";
        }

        /// <summary>
        ///  Renders a <see cref="RandomNumbersStratifiedResult"/> object to HTML.
        /// </summary>
        /// <param name="result">Single Stage Stratified Random Numbers Generation result.</param>
        static string Render(RandomNumbersStratifiedResult result)
        {
            return result.Strata.Select((stratum, i) => $@"
    <h2>Stratum {i + 1}</h2>
    <table align=""center"" class=""table-random-summary fit-to-contents"">
        <thead>
            <tr>
    <th>SEED NUMBER</th>
    <th>UNIVERSE SIZE</th>
    <th>TOTAL RANDOM NUMBERS GENERATED</th>
    <th>SUMMATION OF RANDOM NUMBERS</th>
            </tr>
        </thead>
        <tbody>
            <tr>
    <td class=""n"">{stratum.SeedNumber}</td>
    <td class=""n"">{stratum.UniverseSize:#,0}</td>
    <td class=""n"">{stratum.SampleSize:#,0}</td>
    <td class=""n"">{stratum.Sum:#,0}</td>
            </tr>
        </tbody>
    </table>
{
    Render(stratum.Numbers, stratum.SequentialSampleSize)
}").Concat();
        }

        /// <summary>
        ///  Renders a <see cref="RandomNumbersSingleResult"/> object to HTML.
        /// </summary>
        /// <param name="result">Single Stage Random Numbers Generation result.</param>
        static string Render(RandomNumbersSingleResult result)
        {
            return $@"
    <table align=""center"" class=""table-random-summary fit-to-contents"">
        <thead>
            <tr>
    <th>SEED NUMBER</th>
    <th>UNIVERSE SIZE</th>
    <th>TOTAL RANDOM NUMBERS GENERATED</th>
    <th>SUMMATION OF RANDOM NUMBERS</th>
            </tr>
        </thead>
        <tbody>
            <tr>
    <td class=""n"">{result.SeedNumber:#,0}</td>
    <td class=""n"">{result.UniverseSize:#,0}</td>
    <td class=""n"">{result.SampleSize:#,0}</td>
    <td class=""n"">{result.Sum:#,0}</td>
            </tr>
        </tbody>
    </table>
{
    Render(result.Numbers, result.SequentialSampleSize)
}";
        }

        /// <summary>
        ///  Renders a placeholder HTML page representation of analysis result, and subsequently renders content onto it.
        /// </summary>
        /// <param name="result">Analysis result.</param>
        /// <param name="content">Content of the page.</param>
        static string RenderPage(
            IRATResult result,
            string content)
        {
            return $@"<!doctype html>
<html>
<head>
    <meta http-equiv=""X-UA-Compatible"" content=""IE=edge"" />
    <title>{HttpUtility.HtmlEncode(result.Name)}</title>
{Style}
</head>
<body>
    <h1>RAT# Statistical Software</h1>
    <table align=""center"" id=""table-heading"">
        <tbody>
            <tr>
    <td>Date: {result.DateTime.ToString("d", CultureInfo.CreateSpecificCulture("en-us"))}</td>
    <td class=""h"">
        DEPARTMENT OF HEALTH &amp; HUMAN SERVICES <br/>
        OIG - OFFICE OF AUDIT SERVICES <br/>
        #TYPE <br/>
        AUDIT/REVIEW: {HttpUtility.HtmlEncode(result.Name)} <br/>
{
    (null == result.File ? "" : $@"
        <br/>
        DATA FILE USED: {HttpUtility.HtmlEncode(result.File)} <br/>")
}
    </td>
    <td class=""r"">Time: {result.DateTime.ToString("HH:mm")}</td>
            </tr>
        </tbody>
    </table>
    <br/>
{content}
</body>
</html>
";
        }
    }
}
