﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RATSharp
{
    /// <summary>
    ///  Contains extension methods used throughout the program.
    /// </summary>
    public static partial class Extensions
    {
        /// <summary>
        ///  Centers this string within fixed width bounds by padding with whitespaces.
        /// </summary>
        /// <param name="width">Width of the bounds in numbers of characters.</param>
        /// <param name="padRight">Boolean value indicating whether to add trailing whitespace pads.</param>
        public static string CenterFixedWidth(
            this string input,
            int width,
            bool padRight = false)
        {
            int leftPad = (width - input.Length) / 2;
            int rightPad = padRight ? width - input.Length - leftPad : 0;
            return $"{" ".Repeat(leftPad)}{input}{" ".Repeat(rightPad)}";
        }

        /// <summary>
        ///  Centers each string in a collection of strings within fixed width bounds by padding with whitespaces.
        /// </summary>
        /// <param name="width">Width of the bounds in numbers of characters.</param>
        /// <param name="padRight">Boolean value indicating whether to add trailing whitespace pads.</param>
        public static IEnumerable<string> CenterFixedWidth(
            this IEnumerable<string> input,
            int width,
            bool padRight = false)
        {
            return input.Select(line => line.CenterFixedWidth(width, padRight));
        }

        /// <summary>
        ///  Repeats this string <paramref name="count"/> times.
        /// </summary>
        /// <param name="count">Count of repetition.</param>
        public static string Repeat(
            this string input,
            int count)
        {
            if (!string.IsNullOrEmpty(input) && count > 0)
            {
                StringBuilder builder = new StringBuilder(input.Length * count);

                for (int i = 0; i < count; i++) builder.Append(input);

                return builder.ToString();
            }

            return string.Empty;
        }

        /// <summary>
        ///  Wraps this string into multiple lines with each line not exceeding fixed width bounds.
        /// </summary>
        /// <param name="width">Width of the bounds in numbers of characters.</param>
        public static IEnumerable<string> WrapFixedWidth(
            this string input,
            int width)
        {
            int length = 0;
            return input
                .Split(new[] { " " }, StringSplitOptions.RemoveEmptyEntries)
                .GroupBy(word => Math.Floor((length += word.Length) / (decimal)width))
                .Select(line => line.Concat(" "));
        }
    }
}
