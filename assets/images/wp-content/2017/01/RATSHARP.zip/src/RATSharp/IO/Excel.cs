﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

using RATSharp.Renderers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;

namespace RATSharp.IO
{
    /// <summary>
    ///  Microsoft Excel Table abstraction.
    ///  Specializes <see cref="IOTable"/> with specific Excel decorators.
    /// </summary>
    public partial class ExcelIOTable : IOTable
    {
        /// <summary>
        ///  OLEDB connection string for data transfer.
        /// </summary>
        public string ConnectionString;

        /// <summary>
        ///  Backing field for <see cref="Sources"/> property
        /// </summary>
        public List<string> Worksheets;

        /// <summary>
        ///  Gets tables in the connected Excel workbook.
        /// </summary>
        public override IEnumerable<string> Sources
        {
            get { return Worksheets.AsReadOnly(); }
            set { Worksheets = value.ToList(); }
        }
    }

    /// <summary>
    ///  Microsoft Excel Table abstraction for Variable Appraisal input.
    ///  Specializes <see cref="ExcelIOTable"/> with facilities relevant to Variable Appraisal.
    /// </summary>
    public partial class ExcelVariableInput : ExcelIOTable, IVariableInput
    {
        /// <summary>
        ///  Gets a principal submatrix of the table suitable for previewing its content.
        /// </summary>
        public object[][] Preview { get; private set; }

        /// <summary>
        ///  Loads a specific spreadsheet to memory.
        /// </summary>
        /// <param name="source">The Excel workbook spreadsheet to be loaded.</param>
        public int Load(string source)
        {
            source += "$";
            if (Regex.IsMatch(source, @"\s"))
            {
                source = $"'{source}'";
            }

            var connectionStringBuilder = new OleDbConnectionStringBuilder(ConnectionString);
            connectionStringBuilder["Extended Properties"] = (new[] { (string)connectionStringBuilder["Extended Properties"], "HDR=No" }).Concat("; ");

            // Get the data table
            var adapter = new OleDbDataAdapter($"SELECT * FROM [{source}]", connectionStringBuilder.ConnectionString);
            var dataset = new DataSet();

            adapter.Fill(dataset, "source");

            DataTable = dataset.Tables["source"];
            Loaded = true;

            connectionStringBuilder["Extended Properties"] = (new[] { (string)connectionStringBuilder["Extended Properties"], "IMEX=1", "TypeGuessRows=0", "ImportMixedTypes=Text" }).Concat("; ");
            adapter = new OleDbDataAdapter($"SELECT TOP 3 * FROM [{source}]", connectionStringBuilder.ConnectionString);

            adapter.Fill(dataset, "preview");
            Preview = dataset.Tables["preview"].Rows
                     .Cast<DataRow>()
                     .Take(3)
                     .Select(row => row.ItemArray
                         .Take(3)
                         .ToArray())
                     .ToArray();

            return DataTable.Rows.Count;
        }
    }

    /// <summary>
    ///  Contains Excel workbook-specific I/O facilities.
    /// </summary>
    class Excel
    {
        /// <summary>
        ///  Performs loading of an Excel workbook to <paramref name="input"/> as specified by its <see cref="IOTable.FileName"/>.
        /// </summary>
        /// <param name="input">The Variable Appraisal input to perform loading on.</param>
        public static void Open(ref IVariableInput input)
        {
            var excelVariableInput = input as ExcelVariableInput;
            var fileName = excelVariableInput.FileName;
            var legacy = fileName.EndsWith(".xls");

            var connectionStringBuilder = new OleDbConnectionStringBuilder()
            {
                DataSource = fileName
            };

            if (legacy)
            {
                connectionStringBuilder.Provider = "Microsoft.Jet.OLEDB.4.0";
                connectionStringBuilder.Add("Extended Properties", "Excel 8.0");
            }
            else
            {
                connectionStringBuilder.Provider = "Microsoft.ACE.OLEDB.12.0";
                connectionStringBuilder.Add("Extended Properties", "Excel 12.0 xml");
            }

            connectionStringBuilder.Add("Data Source", fileName);

            excelVariableInput.ConnectionString = connectionStringBuilder.ConnectionString;

            // Create connection object
            var dbConnection = new OleDbConnection(excelVariableInput.ConnectionString);

            // Open connection with the database.
            dbConnection.Open();
            excelVariableInput.AsTable().Sources = dbConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null).Rows.Cast<DataRow>()
                .Select(row => row.Field<string>("TABLE_NAME")).Where(table => table.EndsWith("$") || (table.StartsWith("'") && table.EndsWith("$'")))
                .Select(name => name.Replace("$", ""))
                .Select(name => (name.StartsWith("'") && name.EndsWith("'")) ? name.RegexReplace(@"(^'|'$)", "") : name);

            input = excelVariableInput as IVariableInput;
        }

        /// <summary>
        ///  Writes an Excel workbook off a template to save <paramref name="result"/>.
        /// </summary>
        /// <param name="fileName">The full path to file to target Excel workbook.</param>
        /// <param name="result">The analysis result to save.</param>
        public static void WriteFromTemplate(
            string fileName,
            IRATResult result)
        {
            if (result is RandomNumbersStratifiedResult)
            {
                foreach (var stratum in (result as RandomNumbersStratifiedResult).Strata.ExpandResult(fileName, "Stratum"))
                {
                    WriteFromTemplate(stratum.Key, stratum.Value);
                }
            }

            var input = ExcelWorkbook.Render(result);

            if (string.IsNullOrWhiteSpace(input))
            {   // not supported
                return;
            }

            var assembly = Assembly.GetExecutingAssembly();
            var tempDirectory = Directory.CreateDirectory(Path.Combine(Path.GetTempPath(), AppDomain.CurrentDomain.FriendlyName, Path.GetRandomFileName()));

            var inputByFile = input.Split(Separator.File);

            var sharedString = inputByFile.ElementAtOrDefault(0);
            var sheet1 = inputByFile.ElementAtOrDefault(1);
            var sheet2 = inputByFile.ElementAtOrDefault(2);

            using (var stream = assembly.GetManifestResourceStream($"RATSharp.Resources.{result.GetType().Name}.xlsx"))
            using (var archive = new ZipArchive(stream))
            {
                archive.ExtractToDirectory(tempDirectory.FullName);
            }

            using (var stream = new FileStream(Path.Combine(tempDirectory.FullName, "xl", "sharedStrings.xml"), FileMode.Open, FileAccess.ReadWrite, FileShare.Read))
            using (var reader = new StreamReader(stream))
            using (var writer = new StreamWriter(stream))
            {
                var content = reader.ReadToEnd()
                    .Replace(@"#TITLE", sharedString);
                stream.Seek(0, SeekOrigin.Begin);
                writer.Write(content);
                stream.SetLength(stream.Position);
            }

            using (var stream = new FileStream(Path.Combine(tempDirectory.FullName, "xl", "worksheets", "sheet1.xml"), FileMode.Open, FileAccess.ReadWrite, FileShare.Read))
            using (var reader = new StreamReader(stream))
            using (var writer = new StreamWriter(stream))
            {
                var sheet1ByGroup = sheet1.Split(Separator.Group);
                var dimension = sheet1ByGroup.ElementAtOrDefault(0);
                var date = sheet1ByGroup.ElementAtOrDefault(1);
                var time = sheet1ByGroup.ElementAtOrDefault(2);
                var seedNumber = sheet1ByGroup.ElementAtOrDefault(3);
                var universeSize = sheet1ByGroup.ElementAtOrDefault(4);
                var records = sheet1ByGroup.ElementAtOrDefault(5).Split(Separator.Record);

                var content = reader.ReadToEnd()
                    .RegexReplace(@"<dimension ref=.*?/>", dimension)
                    .Replace(@"<c r=""B6"" s=""8""><v>0</v></c>", date)     // TODO replace with more intent-driven regex
                    .Replace(@"<c r=""D6"" s=""9""><v>0</v></c>", time)
                    .Replace(@"<c r=""C9"" s=""3""/>", seedNumber)
                    .Replace(@"<c r=""D9"" s=""10""/>", universeSize);

                if (records?.Any() ?? false)
                {
                    content = content
                        .Replace(@"<c r=""A9"" s=""4""/><c r=""B9"" s=""1""/>", records.First());
                }

                if (records?.Length > 1)
                {
                    content = content
                        .RegexReplace(@"(?=</sheetData>)", records.Skip(1).Concat());
                }

                stream.Seek(0, SeekOrigin.Begin);
                writer.Write(content);
                stream.SetLength(stream.Position);
            }

            using (var stream = new FileStream(Path.Combine(tempDirectory.FullName, "xl", "worksheets", "sheet2.xml"), FileMode.Open, FileAccess.ReadWrite, FileShare.Read))
            using (var reader = new StreamReader(stream))
            using (var writer = new StreamWriter(stream))
            {
                var sheet2ByGroup = sheet2.Split(Separator.Group);
                var dimension = sheet2ByGroup.ElementAtOrDefault(0);
                var records = sheet2ByGroup.ElementAtOrDefault(1)?.Split(Separator.Record);

                var content = reader.ReadToEnd()
                    .RegexReplace(@"<dimension ref=.*?/>", dimension)
                    .RegexReplace(@"(?=</sheetData>)", records?.Concat());

                stream.Seek(0, SeekOrigin.Begin);
                writer.Write(content);
                stream.SetLength(stream.Position);
            }

            if (File.Exists(fileName))
            {
                File.Delete(fileName);
            }

            ZipFile.CreateFromDirectory(tempDirectory.FullName, fileName);

            tempDirectory.Delete(recursive: true);
        }

        /// <summary>
        ///  Checks if an A1-style notation cell reference is valid.
        /// </summary>
        /// <param name="reference">An A1-style notation cell reference.</param>
        public static bool IsValidReference(string reference)
        {
            return TryParseReference(reference, out int row, out int column);
        }

        /// <summary>
        ///  Tries to convert the specified A1-style notation cell reference to its row and column offset equivalent.
        ///  The offset is relative to the topleft-most cell.
        ///  A return value indicates whether the conversion succeeded or failed.
        /// </summary>
        /// <param name="reference">An A1-style notation cell reference.</param>
        /// <param name="row">Contains the row offset represented by <paramref name="reference"/>.</param>
        /// <param name="column">Contains the column offset represented by <paramref name="reference"/>.</param>
        public static bool TryParseReference(
            string reference,
            out int row,
            out int column)
        {
            row = -1;
            column = -1;

            var match = Regex.Match(reference, @"(?<C>^[A-Za-z]{1,3})(?<R>\d{1,7}$)");

            if (null == match)
            {
                return false;
            }

            row = int.Parse(match.Groups["R"].Value) - 1;
            column = (new[] { 0, 26, (int)Math.Pow(26, 2) }).Take(match.Groups["C"].Value.Length).Sum() +
                match.Groups["C"].Value.ToUpperInvariant().Select(c => (int)(c - 'A')).Aggregate((m, l) => (26 * m + l));

            row = (row < Math.Pow(2, 20)) ? row : -1;
            column = (column < Math.Pow(2, 14)) ? column : -1;

            return (Math.Min(row, column) >= 0);
        }
    }
}
