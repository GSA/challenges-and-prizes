﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

using System;
using System.Linq;
using System.Web;

namespace RATSharp.Renderers
{
    /// <summary>
    ///  <see cref="IRATResult"/> Microsoft Excel workbook renderer.
    /// </summary>
    public static class ExcelWorkbook
    {   /// This class is implemented using heredoc to preserve visual integrity of rendering result.
        /// For more information about heredoc, see https://en.wikipedia.org/w/index.php?title=Here_document&oldid=756198374

        /// <summary>
        ///  Renders an Office Open XML spreadsheet string according to the underlying type of <paramref name="result"/>.
        /// </summary>
        /// <param name="result">Analysis result to render.</param>
        internal static string Render(IRATResult result)
        {
            if (result is RandomNumbersSingleResult)
            {
                return Render(result as RandomNumbersSingleResult);
            }

            return "";
        }

        /// <summary>
        ///  Renders a <see cref="RandomNumbersSingleResult"/> object to Office Open XML spreadsheet string.
        /// </summary>
        /// <param name="result">Single Stage Random Numbers Generation result.</param>
        static string Render(RandomNumbersSingleResult result)
        {
            return $@"{
                    HttpUtility.HtmlEncode(result.Name)
                }{
                IO.Separator.File
                }{      // dimension
                        $@"<dimension ref=""A1:D{Math.Min(9, 8 + result.SequentialSampleSize)}"" />"
                }{
                    IO.Separator.Group
                }{      // date
                        $@"<c r=""B6"" s=""8""><v>{result.DateTime.ToOADate()}</v></c>"
                }{
                    IO.Separator.Group
                }{      // time
                        $@"<c r=""D6"" s=""9""><v>{result.DateTime.ToOADate()}</v></c>"
                }{
                    IO.Separator.Group
                }{      // seed number
                        $@"<c r=""C9"" s=""3""><v>{result.SeedNumber:0.00}</v></c>"
                }{
                    IO.Separator.Group
                }{      // universe size
                        $@"<c r=""D9"" s=""10""><v>{result.UniverseSize:0}</v></c>"
                }{
                    IO.Separator.Group
                }{      // sequential order values
                        result.Numbers.Take(1).Select(number => $@"<c r=""A9"" s=""4""><v>{number.Key}</v></c><c r=""B9"" s=""1""><v>{number.Value}</v></c>").Concat(
                        result.Numbers.Skip(1).Take(Math.Max(0, result.SequentialSampleSize - 1)).Select((number, i) =>
                            $@"<row r=""{10 + i}"" spans=""1:2"" x14ac:dyDescent=""0.35"">" +
                                $@"<c r=""A{10 + i}"" s=""4""><v>{number.Key}</v></c>" +
                                $@"<c r=""B{10 + i}"" s=""1""><v>{number.Value}</v></c>" +
                            $@"</row>")).Concat(IO.Separator.Record)
                }{
                IO.Separator.File
                }{      // dimension
                        $@"<dimension ref=""A1:B{1 + result.SpareSampleSize}"" />"
                }{
                    IO.Separator.Group
                }{     // random order values
                        result.Numbers.Skip(result.SequentialSampleSize).Select((number, i) =>
                            $@"<row r=""{2 + i}"" spans=""1:2"" x14ac:dyDescent=""0.35"">" +
                                $@"<c r=""A{2 + i}"" s=""4""><v>{number.Key}</v></c>" +
                                $@"<c r=""B{2 + i}"" s=""1""><v>{number.Value}</v></c>" +
                            $@"</row>").Concat()
                }";
        }

        /// <summary>
        ///  Renders a placeholder spreadsheet representation of analysis result, and subsequently renders content onto it.
        /// </summary>
        /// <param name="result">Analysis result.</param>
        /// <param name="content">Content of the page.</param>
        [Obsolete("Not implemented", true)]
        static string RenderPage(
            IRATResult result,
            string content)
        {
            return @"";
        }
    }
}
