﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

using RATSharp.Stochastics;
using System;
using System.Collections.Generic;

namespace RATSharp
{
    /// <summary>
    ///  Contains confidence limits from Unrestricted Attribute Appraisal.
    /// </summary>
    public class AttributeAppraisalConfidence
    {
        #region Fields

        public UInt64? LowerLimit = null;
        public UInt64? UpperLimit = null;
        public double? LowerLimitRatio = null;
        public double? UpperLimitRatio = null;

        #endregion

        /// <summary>
        ///  Sets the confidence limits, both nominal and rational.
        /// </summary>
        public void SetLimit(
            CDFType type,
            UInt64 value,
            UInt64 universe)
        {
            switch (type)
            {
                case CDFType.LessOrEqualTo:
                    LowerLimit = value;
                    LowerLimitRatio = value / (double)universe;
                    break;
                case CDFType.GreaterOrEqualTo:
                    UpperLimit = value;
                    UpperLimitRatio = value / (double)universe;
                    break;
                default:    throw new InvalidOperationException("Error computing CDF: AttributeAppraisalConfidence.SetLimit()");
            }
        }
    }

    /// <summary>
    ///  Contains result for Unrestricted Attribute Appraisal.
    /// </summary>
    public class AttributeAppraisalUnrestrictedResult : IRATResult
    {
        #region Fields

        public UInt64 UniverseSize;
        public UInt64 SampleSize;
        public UInt64 PopulationOfInterestSize;
        public UInt64 SampleOfInterestSize;
        public double PopulationOfInterestRatio;
        public double StandardErrorTotal;
        public double StandardErrorMean;
        public SortedDictionary<double, AttributeAppraisalConfidence> ConfidenceLimits = new SortedDictionary<double, AttributeAppraisalConfidence>();

        #endregion

        #region IRATResult implementation

        public DateTime DateTime { get; set; } = DateTime.Now;
        public string File { get; set; }
        public string Name { get; set; }

        #endregion
    }
}
