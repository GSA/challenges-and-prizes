﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace RATSharp
{
    /// <summary>
    ///  Exposes standard properties of an analysis result
    /// </summary>
    internal interface IRATResult
    {
        string Name { get; set; }
        string File { get; set; }
        DateTime DateTime { get; set; }
    }

    /// <summary>
    ///  Contains extension methods used throughout the program.
    /// </summary>
    public static partial class Extensions
    {
        /// <summary>
        ///  Set the <see cref="Control.Enabled"/> property of each <see cref="Control"/> in this
        ///  <see cref="Control.ControlCollection"/> to a value.
        /// </summary>
        /// <param name="value">The value to set <see cref="Control.Enabled"/> to.</param>
        /// <returns>
        ///  Collection of controls whose <see cref="Control.Enabled"/> are changed as a result
        ///  of calling this function.
        /// </returns>
        public static IEnumerable<Control> SetEnabled(
            this Control.ControlCollection controls,
            bool value)
        {
            return controls.Cast<Control>().SetEnabled(value);
        }

        /// <summary>
        ///  Set the <see cref="Control.Enabled"/> property of each <see cref="Control"/> in this
        ///  <see cref="Control"/> collection to a value.
        /// </summary>
        /// <param name="value">The value to set <see cref="Control.Enabled"/> to.</param>
        /// <returns>
        ///  Collection of controls whose <see cref="Control.Enabled"/> are changed as a result
        ///  of calling this function.
        /// </returns>
        public static IEnumerable<Control> SetEnabled(
            this IEnumerable<Control> controls,
            bool value)
        {
            var modifiedControls = new List<Control>();

            foreach (Control control in controls)
            {
                if (control.Enabled == value) continue;
                control.Enabled = value;
                modifiedControls.Add(control);
            }

            return modifiedControls;
        }
    }
}
