﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace RATSharp.IO
{
    /// <summary>
    ///  Space-delimited tet file Table abstraction.
    ///  Specializes <see cref="IOTable"/> with specific space-delimited text file decorators.
    /// </summary>
    public partial class TextIOTable : IOTable
    {
        /// <summary>
        ///  Gets at most the one table in the text file.
        /// </summary>
        public override IEnumerable<string> Sources { get; set; }
    }

    /// <summary>
    ///  Space-delimited text file abstraction for Variable Appraisal input.
    ///  Specializes <see cref="TextIOTable"/> with facilities relevant to Variable Appraisal.
    /// </summary>
    public partial class TextVariableInput : TextIOTable, IVariableInput
    {
        /// <summary>
        ///  Gets the number of columns in the loaded table.
        /// </summary>
        public int Columns { get; set; }

        /// <summary>
        ///  Gets a principal submatrix of the table suitable for previewing its content.
        /// </summary>
        public object[][] Preview { get; private set; }

        /// <summary>
        ///  Loads a specific table to memory.
        /// </summary>
        /// <param name="source">The space-delimited text table to be loaded.</param>
        public int Load(string source)
        {
            var dataTable = new DataTable("source");

            using (var reader = File.OpenText(FileName))
            {
                Preview = reader.ReadLines()
                    .Take(3)
                    .Select(row => Regex.Matches(row, Text.FieldPattern)
                        .Cast<Match>()
                        .Take(3)
                        .Select(match => match.Value.Trim())
                        .ToArray())
                    .ToArray();

                reader.BaseStream.Seek(0, SeekOrigin.Begin);
                reader.DiscardBufferedData();

                var data = reader.ReadLines()
                            .Select(row => Regex.Matches(row, Text.FieldPattern)
                                .Cast<Match>()
                                .Select(match => match.Value.Trim())
                                .ToList())
                            .ToList();

                var columns = data.AsParallel().Max(row => row.Count);

                for (var i = 0; i < columns; ++i)
                {
                    dataTable.Columns.Add(new DataColumn(null, typeof(object)));
                }

                foreach (var row in data)
                {
                    var dataRow = dataTable.NewRow();
                    var column = 0;
                    foreach (var field in row)
                    {
                        if (Regex.IsMatch(field, Text.NumberPattern))
                        {
                            dataRow.SetField<object>(column++, double.Parse(field.RegexReplace(@"\s+", ""), NumberStyles.Any));
                        }
                        else
                        {
                            dataRow.SetField<object>(column++, field);
                        }
                    }
                    dataTable.Rows.Add(dataRow);
                }
            }

            DataTable = dataTable;
            Loaded = true;

            return dataTable.Rows.Count;
        }
    }

    /// <summary>
    ///  Contains space-delimited text file-specific I/O facilities.
    /// </summary>
    class Text
    {
        public const string NumberPattern = @"(?:(^|\s))(\((?:\s*)\$?\s*(\d(\,?\d{3})*\.?\d*|\.\s*\d+)\s*\)|[-+]*\s*\$?\s*(\d(\,?\d{3})*\.?\d*|\.\s*\d+))(?=(\s|$))";
        public const string FieldPattern =  @"(?:(^|\s))(\((?:\s*)\$?\s*(\d(\,?\d{3})*\.?\d*|\.\s*\d+)\s*\)|[-+]*\s*\$?\s*(\d(\,?\d{3})*\.?\d*|\.\s*\d+)|\W+)(?=(\s|$))";

        /// <summary>
        ///  Performs loading of a space-delimited text file to <paramref name="input"/> as specified by its <see cref="IOTable.FileName"/>.
        /// </summary>
        /// <param name="input">The Variable Appraisal input to perform loading on.</param>
        public static void Open(ref IVariableInput input)
        {
            var textVariableInput = input as TextVariableInput;

            textVariableInput.Sources = new List<string> { Path.GetFileNameWithoutExtension(textVariableInput.FileName) };

            using (var reader = File.OpenText(textVariableInput.FileName))
            {
                textVariableInput.Columns = Regex.Matches(reader.ReadLine(), FieldPattern).Count;
            }

            input = textVariableInput as IVariableInput;
        }

        /// <summary>
        ///  Writes a string to a file.
        /// </summary>
        /// <param name="fileName">The full path to target file.</param>
        /// <param name="content">The string to be written to target file.</param>
        public static void Write(
            string fileName,
            string content)
        {
            using (var file = File.Create(fileName))
            using (var writer = new StreamWriter(file))
            {   // use output as file path if null
                writer.Write(content);
            }
        }

        /// <summary>
        ///  Writes a text file to save <paramref name="result"/>.
        /// </summary>
        /// <param name="fileName">The full path to file to target file.</param>
        /// <param name="result">The analysis result to save.</param>
        /// <param name="renderingFunction">Function to render <paramref name="result"/> as string.</param>
        public static void Write(
            string fileName,
            IRATResult result,
            Func<IRATResult, string> renderingFunction)
        {
            if (result is RandomNumbersStratifiedResult)
            {
                foreach (var stratum in (result as RandomNumbersStratifiedResult).Strata.ExpandResult(fileName, "Stratum"))
                {
                    var stratumResult = stratum.Value;
                    stratumResult.File = stratum.Key;
                    Write(stratum.Key, stratum.Value, renderingFunction);
                }
            }
            else if (result is RandomNumbersSingleResult)
            {
                Write(fileName, renderingFunction(result));
            }
        }
    }
}

namespace RATSharp
{
    /// <summary>
    ///  Contains extension methods used throughout the program.
    /// </summary>
    public static partial class Extensions
    {
        /// <summary>
        ///  Reads content of this stream as a collection of text lines.
        /// </summary>
        public static IEnumerable<string> ReadLines(this StreamReader reader)
        {
            string line; while ((line = reader.ReadLine()) != null) yield return line;
        }
    }
}