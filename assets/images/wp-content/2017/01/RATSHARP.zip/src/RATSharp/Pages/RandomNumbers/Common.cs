﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace RATSharp
{
    /// <summary>
    ///  <see cref="KeyPressEventHandler"/> definitions suitable for filtering common input groups.
    /// </summary>
    internal static class KeyPressFilter
    {
        /// <summary>
        ///  <see cref="KeyPressEventHandler"/> definition suitable for allowing only integer input.
        /// </summary>
        internal static readonly KeyPressEventHandler RestrictToInteger = new KeyPressEventHandler((object sender, KeyPressEventArgs e) =>
        {
            var control = sender as DataGridViewTextBoxEditingControl;
            e.Handled = !char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar);
        });

        /// <summary>
        ///  <see cref="KeyPressEventHandler"/> definition suitable for allowing only decimal input.
        /// </summary>
        internal static readonly KeyPressEventHandler RestrictToDecimal = new KeyPressEventHandler((object sender, KeyPressEventArgs e) =>
        {
            var control = sender as DataGridViewTextBoxEditingControl;
            e.Handled = !char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && !('.' == e.KeyChar && !control.Text.Contains("."));
        });
    }

    /// <summary>
    ///  <see cref="DataGridViewCellStyle"/> definitions suitable for common types.
    /// </summary>
    internal static class CellStyle
    {
        /// <summary>
        ///  <see cref="DataGridViewCellStyle"/> definitions suitable for numeric display with thousands separator.
        /// </summary>
        internal static readonly DataGridViewCellStyle Numeric = new DataGridViewCellStyle()
        {
            Format = "#,0",
            NullValue = null
        };

        /// <summary>
        ///  <see cref="DataGridViewCellStyle"/> definitions suitable for decimal display with at most two decimal places.
        /// </summary>
        internal static readonly DataGridViewCellStyle Decimal = new DataGridViewCellStyle()
        {
            Format = "0.##",
            NullValue = null
        };
    }

    struct RandomNumbersTask
    {
        public double SeedNumber;
        public int SequentialOrderQuantity;
        public int SpareQuantity;
        public int HighNumber;
        public int LowNumber;
    }

    /// <summary>
    ///  Contains result for Single Stage Random Numbers.
    /// </summary>
    public class RandomNumbersSingleResult : IRATResult
    {
        #region Fields

        public double SeedNumber;
        public int UniverseSize;
        public int SequentialSampleSize;
        public int SpareSampleSize;
        public UInt64 Sum;
        public IEnumerable<KeyValuePair<UInt64, UInt64>> Numbers = new List<KeyValuePair<UInt64, UInt64>>();

        #endregion

        #region Properties

        public int SampleSize => SequentialSampleSize + SpareSampleSize;

        #endregion

        #region IRATResult implementation

        public DateTime DateTime { get; set; } = DateTime.Now;
        public string File { get; set; }
        public string Name { get; set; }

        #endregion
    }

    /// <summary>
    ///  Contains result for Stratified Single Stage Random Numbers.
    /// </summary>
    public class RandomNumbersStratifiedResult : IRATResult
    {
        #region Fields

        public RandomNumbersSingleResult[] Strata;

        #endregion

        #region IRATResult implementation

        public DateTime DateTime { get; set; } = DateTime.Now;
        public string File { get; set; }
        public string Name { get; set; }

        #endregion
    }
}
