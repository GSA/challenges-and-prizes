﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

using RATSharp.Renderers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Reflection;

namespace RATSharp.IO
{
    /// <summary>
    ///  Microsoft Access Table abstraction.
    ///  Specializes <see cref="IOTable"/> with specific Access decorators.
    /// </summary>
    public partial class AccessIOTable : IOTable
    {
        /// <summary>
        ///  OLEDB connection string for data transfer.
        /// </summary>
        public string ConnectionString;

        /// <summary>
        ///  Backing field for <see cref="Sources"/> property
        /// </summary>
        List<string> Tables;

        /// <summary>
        ///  Gets tables in the connected Access database.
        /// </summary>
        public override IEnumerable<string> Sources
        {
            get { return Tables.AsReadOnly(); }
            set { Tables = value.ToList(); }
        }
    }

    /// <summary>
    ///  Microsoft Access Table abstraction for Variable Appraisal input.
    ///  Specializes <see cref="AccessIOTable"/> with facilities relevant to Variable Appraisal.
    /// </summary>
    public partial class AccessVariableInput : AccessIOTable, IVariableInput
    {
        /// <summary>
        ///  Gets a collection of strings containing fields of the loaded table. An empty collection is returned if no tables are loaded.
        /// </summary>
        public IEnumerable<string> Fields => DataTable?.Columns.Cast<DataColumn>().Select(c => c.ColumnName) ?? new List<string>().AsReadOnly();

        /// <summary>
        ///  Gets a principal submatrix of the table suitable for previewing its content.
        /// </summary>
        public object[][] Preview { get; private set; }

        /// <summary>
        ///  Loads a specific table to memory.
        /// </summary>
        /// <param name="source">The Access database table to be loaded.</param>
        public int Load(string source)
        {
            // Get the data table
            var adapter = new OleDbDataAdapter($"SELECT * FROM [{source}]", ConnectionString);
            var dataset = new DataSet();

            adapter.Fill(dataset, "source");

            DataTable = dataset.Tables["source"];
            Loaded = true;
            
            adapter = new OleDbDataAdapter($"SELECT TOP 3 * FROM [{source}]", ConnectionString);

            adapter.Fill(dataset, "preview");
            Preview = dataset.Tables["preview"].Rows
                     .Cast<DataRow>()
                     .Take(3)
                     .Select(row => row.ItemArray
                         .Take(3)
                         .ToArray())
                     .ToArray();

            return DataTable.Rows.Count;
        }
    }

    /// <summary>
    ///  Contains Access database-specific I/O facilities.
    /// </summary>
    internal static class Access
    {
        /// <summary>
        ///  Performs loading of an Access database to <paramref name="input"/> as specified by its <see cref="IOTable.FileName"/>.
        /// </summary>
        /// <param name="input">The Variable Appraisal input to perform loading on.</param>
        internal static void Open(ref IVariableInput input)
        {
            var accessVariableInput = input as AccessVariableInput;
            var fileName = accessVariableInput.FileName;
            var legacy = fileName.EndsWith(".mdb");

            var connectionStringBuilder = new OleDbConnectionStringBuilder()
            {
                DataSource = fileName
            };

            if (legacy)
            {
                connectionStringBuilder.Provider = "Microsoft.Jet.OLEDB.4.0";
            }
            else
            {
                connectionStringBuilder.Provider = "Microsoft.ACE.OLEDB.12.0";
            }

            connectionStringBuilder.Add("Data Source", fileName);

            accessVariableInput.ConnectionString = connectionStringBuilder.ConnectionString;

            // Create connection object
            var dbConnection = new OleDbConnection(accessVariableInput.ConnectionString);

            // Open connection with the database.
            dbConnection.Open();
            accessVariableInput.AsTable().Sources = dbConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null).Rows.Cast<DataRow>()
                .Where(row => "TABLE" == row.Field<string>("TABLE_TYPE"))
                .Select(row => row.Field<string>("TABLE_NAME"));

            input = accessVariableInput as IVariableInput;
        }

        /// <summary>
        ///  Performs updating of an Access database to <paramref name="fileName"/> by inserting records in <paramref name="dataset"/>.
        /// </summary>
        /// <param name="fileName">The full path to file to perform updating on.</param>
        /// <param name="dataset">The dataset containing records to insert.</param>
        internal static void Update(
            string fileName,
            DataSet dataset)
        {
            var legacy = fileName.EndsWith(".mdb");

            var connectionStringBuilder = new OleDbConnectionStringBuilder()
            {
                DataSource = fileName
            };

            if (legacy)
            {
                connectionStringBuilder.Provider = "Microsoft.Jet.OLEDB.4.0";
            }
            else
            {
                connectionStringBuilder.Provider = "Microsoft.ACE.OLEDB.12.0";
            }

            // Get the data table
            foreach (DataTable table in dataset.Tables)
            {
                var adapter = new OleDbDataAdapter($"SELECT * FROM [{table.TableName}]", connectionStringBuilder.ConnectionString);
                var targetDataset = new DataSet();

                adapter.Fill(targetDataset, table.TableName);

                var dbc = new OleDbConnection(connectionStringBuilder.ConnectionString);
                dbc.Open();
                // define
                if (typeof(RandomNumbersSingleResult).ToString() == dataset.DataSetName)
                {
                    if ("Report" == table.TableName)
                    {
                        adapter.InsertCommand = new OleDbCommand($"INSERT INTO [{table.TableName}] ([Seed-Number], [Date], [Time]) VALUES (@SeedNumber, @Date, @Time)", dbc);
                        adapter.InsertCommand.Parameters.Add(new OleDbParameter() { ParameterName = "@SeedNumber", OleDbType = OleDbType.Double, Value = DBNull.Value, SourceColumn = "Seed-Number" });
                        adapter.InsertCommand.Parameters.Add(new OleDbParameter() { ParameterName = "@Date", OleDbType = OleDbType.Date, Value = DBNull.Value, SourceColumn = "Date" });
                        adapter.InsertCommand.Parameters.Add(new OleDbParameter() { ParameterName = "@Time", OleDbType = OleDbType.Date, Value = DBNull.Value, SourceColumn = "Time" });

                        targetDataset.Tables[table.TableName].Rows.Add(table.Rows[0].ItemArray[0], table.Rows[0].ItemArray[1], table.Rows[0].ItemArray[2]);
                    }
                    else
                    {
                        adapter.InsertCommand = new OleDbCommand($"INSERT INTO [{table.TableName}] ([Order], [Value]) VALUES (@Order, @Value)", dbc);
                        adapter.InsertCommand.Parameters.Add(new OleDbParameter() { ParameterName = "@Order", OleDbType = OleDbType.Integer, Value = DBNull.Value, SourceColumn = "Order" });
                        adapter.InsertCommand.Parameters.Add(new OleDbParameter() { ParameterName = "@Value", OleDbType = OleDbType.Integer, Value = DBNull.Value, SourceColumn = "Value" });

                        foreach (DataRow row in table.Rows)
                        {
                            targetDataset.Tables[table.TableName].Rows.Add(row.ItemArray[0], row.ItemArray[1]);
                        }
                    }
                }

                adapter.Update(dataset, table.TableName);

                dbc.Close();
            }
        }

        /// <summary>
        ///  Writes an Access database off a template to save <paramref name="result"/>.
        /// </summary>
        /// <param name="fileName">The full path to file to target Access database.</param>
        /// <param name="result">The analysis result to save.</param>
        internal static void WriteFromTemplate(
            string fileName,
            IRATResult result)
        {
            // check result type
            if (result is RandomNumbersStratifiedResult)
            {
                foreach (var stratum in (result as RandomNumbersStratifiedResult).Strata.ExpandResult(fileName, "Stratum"))
                {
                    WriteFromTemplate(stratum.Key, stratum.Value);
                }
            }
            else if (result is RandomNumbersSingleResult)
            { }
            else return;

            var assembly = Assembly.GetExecutingAssembly();
            var tempDirectory = Directory.CreateDirectory(Path.Combine(Path.GetTempPath(), AppDomain.CurrentDomain.FriendlyName, Path.GetRandomFileName()));
            string tempFile = Path.Combine(tempDirectory.FullName, Path.GetRandomFileName());

            using (var stream = assembly.GetManifestResourceStream($"RATSharp.Resources.{result.GetType().Name}.accdb"))
            using (var reader = new BinaryReader(stream))
            using (var writeStream = File.Create(tempFile))
            using (var writer =  new BinaryWriter(writeStream))
            {
                for (int? length = null; length > 0 || null == length;)
                {
                    writer.Write(reader.ReadBytes(1024 * 1024).Length(out length));
                }
            }

            Update(tempFile, AccessDatabase.Render(result));

            if (File.Exists(fileName))
            {
                File.Delete(fileName);
            }

            File.Copy(tempFile, fileName);
            File.Delete(tempFile);
            tempDirectory.Delete(recursive: true);
        }
    }
}

namespace RATSharp
{
    /// <summary>
    ///  Contains extension methods used throughout the program.
    /// </summary>
    public static partial class Extensions
    {
        /// <summary>
        ///  Fluent interface to output length of this array.
        /// </summary>
        /// <param name="length">Contains the length of array.</param>
        public static T[] Length<T>(
            this T[] array,
            out int? length)
        {
            length = array.Count();
            return array;
        }
    }
}
