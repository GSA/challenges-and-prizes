﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

using RATSharp.IO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace RATSharp
{
    /// <summary>
    ///  Specifies type of value within Variable Appraisal.
    /// </summary>
    internal enum AppraisalVariableType
    {
        Examined,
        Audited,
        Difference
    }

    /// <summary>
    ///  Variable Appraisal facilities.
    /// </summary>
    public static class VariableAppraisal
    {
        /// <summary>
        ///  Converts information of variable type from listed human-readable option UI to its
        ///  corresponding <see cref="AppraisalVariableType"/> tokens.
        /// </summary>
        internal static AppraisalVariableType[] GetDataFormatFromInputIndex(int selectedIndex)
        {
            switch (selectedIndex)
            {
                case 0:
                    // Examined Values
                    return new[] { AppraisalVariableType.Examined };
                case 1:
                    // Audited Values
                    return new[] { AppraisalVariableType.Audited };
                case 2:
                    // Difference Values
                    return new[] { AppraisalVariableType.Difference };
                case 3:
                    // Examined and Audited Values
                    return new[] { AppraisalVariableType.Examined, AppraisalVariableType.Audited };
                case 4:
                    // Examined and Difference Values
                    return new[] { AppraisalVariableType.Examined, AppraisalVariableType.Difference };
                case 5:
                    // Audited and Difference Values
                    return new[] { AppraisalVariableType.Audited, AppraisalVariableType.Difference };
                default:
                    throw new InvalidOperationException();
            }
        }

        /// <summary>
        ///  Loads a file containing input to Variable Appraisal to an <see cref="IVariableInput"/> object.
        /// </summary>
        /// <param name="fileName">The file containing input for Variable Appraisal.</param>
        /// <param name="input">Contains the input to Variable Appraisal as loaded from the file.</param>
        public static void Load(
            string fileName,
            out IVariableInput input)
        {
            input = IOTable.FromFile(fileName);

            if (input is TextVariableInput)
            {
                Text.Open(ref input);
            }
            else if (input is ExcelVariableInput)
            {
                Excel.Open(ref input);
            }
            else if (input is AccessVariableInput)
            {
                Access.Open(ref input);
            }
        }

        /// <summary>
        ///  Loads a preview for input to Variable Appraisal to a <see cref="DataGridView"/> and emplace it
        ///  within a UI <see cref="Panel"/>.
        /// </summary>
        /// <param name="input">Input to Variable Appraisal to load a preview from.</param>
        /// <param name="panel">UI <see cref="Panel"/> to emplace the produced preview within.</param>
        public static void Preview(
            IVariableInput input,
            ref Panel panel)
        {
            var previewGrid = new DataGridView()
            {
                ColumnCount = 3,
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToOrderColumns = false,
                ClipboardCopyMode = DataGridViewClipboardCopyMode.Disable,
                EditMode = DataGridViewEditMode.EditProgrammatically,
                RowHeadersWidth = 50,
                ShowEditingIcon = false
            };

            foreach (var row in input.Preview)
            {
                previewGrid.Rows.Add(row);
            }

            foreach (DataGridViewRow row in previewGrid.Rows)
            {
                row.HeaderCell.Value = $"{row.Index + 1}";
                row.Resizable = DataGridViewTriState.False;
                row.ReadOnly = true;
            }

            foreach (DataGridViewColumn column in previewGrid.Columns)
            {
                column.HeaderCell.Value =
                    input is AccessVariableInput ? (input as AccessVariableInput).Fields.ElementAtOrDefault(column.Index) :
                    input is ExcelVariableInput ?  $"{(char)(column.Index + 'A')}" :
                    input is TextVariableInput ?   $"{column.Index + 1}" :
                    "";

                column.Width = (panel.Width - 20) / 4;
                column.ReadOnly = true;
                column.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }

            panel.Controls.Clear();
            panel.Controls.Add(previewGrid);
        }
    }

    /// <summary>
    ///  Contains summary from Variable Appraisal.
    /// </summary>
    public class VariableAppraisalSummary
    {
        #region Fields

        internal int SampleSize;
        internal int UniverseSize;
        internal int NonzeroSize;

        #endregion
    }

    /// <summary>
    ///  Contains confidence limits from Variable Appraisal.
    /// </summary>
    public class VariableAppraisalConfidence
    {
        /// <summary>
        ///  Specifies underlying distribution type of Variable Appraisal confidence limits.
        /// </summary>
        enum ConfidenceType
        {
            Unknown,
            Z,
            T
        }

        #region Fields

        private ConfidenceType Type = ConfidenceType.Unknown;

        internal double LowerLimit;
        internal double UpperLimit;
        internal double Precision;
        internal double PrecisionRatio;

        #endregion

        #region Properties

        internal decimal Statistic { get; private set; }
        internal decimal T
        {
            get { return Statistic; }
            set { Type = ConfidenceType.T; Statistic = value; }
        }

        internal decimal Z
        {
            get { return Statistic; }
            set { Type = ConfidenceType.Z; Statistic = value; }
        }

        internal bool IsT => ConfidenceType.T == Type;
        internal bool IsZ => ConfidenceType.Z == Type;

        #endregion
    }

    /// <summary>
    ///  Contains result for Variable Appraisal.
    /// </summary>
    public class VariableAppraisalResult
    {
        #region Fields

        internal VariableAppraisalSummary[] Summary;
        internal double Sum;
        internal double Mean;
        internal double StandardDeviation;
        internal double Skewness;
        internal double Kurtosis;
        internal double StandardErrorMean;
        internal double StandardErrorTotal;
        internal double PointEstimate;

        internal SortedDictionary<double, VariableAppraisalConfidence> ConfidenceLimits = new SortedDictionary<double, VariableAppraisalConfidence>();

        #endregion
    }

    /// <summary>
    ///  Contains result for a single stratum within a Stratified Variable Appraisal.
    /// </summary>
    public class VariableAppraisalStratumResult
    {
        #region Fields

        SortedDictionary<AppraisalVariableType, VariableAppraisalResult> Results = new SortedDictionary<AppraisalVariableType, VariableAppraisalResult>();

        #endregion

        #region Properties

        internal AppraisalVariableType[] Types => Results.Keys.ToArray();
        internal VariableAppraisalSummary Summary => Results.FirstOrDefault().Value.Summary[0];

        #endregion

        /// <summary>
        ///  Exposes indexing of the multiple <see cref="VariableAppraisalResult"/>s contained, based on their
        ///  <see cref="AppraisalVariableType"/>.
        /// </summary>
        /// <param name="type"></param>
        internal VariableAppraisalResult this[AppraisalVariableType type]
        {
            get { return Results[type]; }
            set { Results[type] = value; }
        }
    }

    /// <summary>
    ///  Contains result for Unrestricted Variable Appraisal.
    /// </summary>
    public class VariableAppraisalUnrestrictedResult : VariableAppraisalStratumResult, IRATResult
    {
        #region IRATResult implementation

        public DateTime DateTime { get; set; } = DateTime.Now;
        public string File { get; set; }
        public string Name { get; set; }

        #endregion
    }

    /// <summary>
    ///  Contains result for Stratified Variable Appraisal.
    /// </summary>
    public class VariableAppraisalStratifiedResult : IRATResult
    {
        #region Fields

        public SortedDictionary<int, VariableAppraisalStratumResult> Strata = new SortedDictionary<int, VariableAppraisalStratumResult>();
        public VariableAppraisalStratumResult Overall = new VariableAppraisalStratumResult();

        #endregion

        #region IRATResult implementation

        public DateTime DateTime { get; set; } = DateTime.Now;
        public string File { get; set; }
        public string Name { get; set; }

        #endregion
    }

    /// <summary>
    ///  Contains extension methods used throughout the program.
    /// </summary>
    public static partial class Extensions
    {
        /// <summary>
        ///  Gets whether this collection of <see cref="VariableAppraisalConfidence"/> is of confidence limits
        ///  constructed upon Student's t-distribution.
        /// </summary>
        /// <typeparam name="T">This collection's key type.</typeparam>
        public static bool IsT<T>(this IDictionary<T, VariableAppraisalConfidence> dict)
        {
            return dict.Values.FirstOrDefault()?.IsT ?? false;
        }

        /// <summary>
        ///  Gets whether this collection of <see cref="VariableAppraisalConfidence"/> is of confidence limits
        ///  constructed upon standard normal distribution.
        /// </summary>
        /// <typeparam name="T">This collection's key type.</typeparam>
        public static bool IsZ<T>(this IDictionary<T, VariableAppraisalConfidence> dict)
        {
            return dict.Values.FirstOrDefault()?.IsZ ?? false;
        }
    }
}
