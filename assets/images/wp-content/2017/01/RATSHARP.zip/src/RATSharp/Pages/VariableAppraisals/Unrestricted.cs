﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

using RATSharp.IO;
using RATSharp.Stochastics;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace RATSharp
{
    public partial class MainForm : Form
    {
        private OpenFileDialog VA_U_FileDialog = new OpenFileDialog();
        private AppraisalVariableType[] VA_U_DataFileFormat = new AppraisalVariableType[] { };
        private IVariableInput VA_U_Input;
        private int VA_U_DropdownDefaultHeight;
        private ComboBox[] VA_U_OptionInputs;
        private Label[] VA_U_OptionLabels;

        /// <summary>
        ///  UI setup phase for Unrestricted Variable Appraisal, called by <see cref="MainForm_Load"/>.
        /// </summary>
        private void VA_U_Load()
        {
            VA_U_FileDialog.Filter += "Text files (*.txt)|*.txt";
            VA_U_FileDialog.Filter += "|Microsoft Access files (*.accdb)|*.accdb";
            VA_U_FileDialog.Filter += "|Microsoft Excel files (*.xls, *.xslx)|*.xls;*.xlsx";
            VA_U_FileDialog.Filter += "|Supported files (*.txt, *.accdb, *.xls, *.xslx)|*.txt;*.accdb;*.xls;*.xlsx";
            VA_U_FileDialog.Filter += "|All files (*.*)|*.*";
            VA_U_FileDialog.FilterIndex = 4;

            VA_U_DropdownDefaultHeight = VA_U_SourceOption1Input.Height;
            VA_U_OptionInputs = new[]
            {
                VA_U_SourceOption1Input,
                VA_U_SourceOption2Input
            };

            VA_U_OptionLabels = new[]
            {
                VA_U_SourceOption1Label,
                VA_U_SourceOption2Label
            };

            foreach (var control in VA_U_OptionInputs.Cast<Control>().Concat(VA_U_OptionLabels.Cast<Control>()))
            {
                control.Visible = false;
            }

            VA_U_PreviewLabel.Visible = false;
        }

        /// <summary>
        ///  User input validation procedure for Unrestricted Variable Appraisal.
        /// </summary>
        private bool VA_U_Validate()
        {
            if (VA_U_UniverseSizeInput.Value <= 0 ||
                VA_U_UniverseSizeInput.Value % 1 != 0)
            {
                DefaultMessageBox.Error($"{VA_U_UniverseSizeInput.Value} is not a valid Universe Size.");
                VA_U_UniverseSizeInput.Focus();
                return false;
            }

            if (!File.Exists(VA_U_FileInput.Text))
            {
                DefaultMessageBox.Error($"Please make sure the Input File '{VA_U_FileInput.Text}' points to a valid and accessible file.");
                VA_U_FileInput.Focus();
                return false;
            }

            if (!VA_U_Input.Loaded)
            {
                DefaultMessageBox.Error($"Please select a valid Table/Worksheet name.");
                VA_U_SourceInput.Focus();
                return false;
            }

            if (VA_U_DataFileFormatInput.SelectedIndex < 0)
            {
                DefaultMessageBox.Error($"Please select a Data File Format for your input.");
                VA_U_DataFileFormatInput.Focus();
                return false;
            }

            if (VA_U_SampleSizeInput.Value <= 0 ||
                VA_U_SampleSizeInput.Value % 1 != 0)
            {
                DefaultMessageBox.Error($"{VA_U_SampleSizeInput.Value} is not a valid Sample Size.");
                VA_U_SampleSizeInput.Focus();
                return false;
            }

            if (VA_U_UniverseSizeInput.Value < VA_U_SampleSizeInput.Value)
            {
                DefaultMessageBox.Error($"Universe Size ({VA_U_UniverseSizeInput.Value}) cannot be smaller than Sample Size ({VA_U_SampleSizeInput.Value}).");
                VA_U_UniverseSizeInput.Focus();
                return false;
            }

            return true;
        /// <summary>
        ///  User input validation procedure for Stratified Variable Appraisal.
        /// </summary>
        }

        #region Event handlers

        /// <summary>
        ///  Handles <see cref="ListBox.SelectedIndexChanged"/> event fired by <see cref="VA_U_DataFileFormatInput"/>.
        /// </summary>
        private void VA_U_DataFileFormatInput_SelectedIndexChanged(object sender, EventArgs e)
        {
            VA_U_DataFileFormat = VariableAppraisal.GetDataFormatFromInputIndex(VA_U_DataFileFormatInput.SelectedIndex);

            if (VA_U_Input != null)
            {
                VA_U_UpdateOptionPrompt();
            }
        }

        /// <summary>
        ///  Handles <see cref="TextBox.Click"/> event fired by <see cref="VA_U_FileInput"/>.
        /// </summary>
        private void VA_U_FileInput_Click(object sender, EventArgs e)
        {
            if (0 == VA_U_FileInput.Text.Length)
            {
                VA_U_SelectInputFile();
            }
        }

        /// <summary>
        ///  Handles <see cref="TextBox.KeyPress"/> event fired by <see cref="VA_U_FileInput"/>.
        /// </summary>
        private void VA_U_FileInput_KeyPress(object sender, KeyPressEventArgs e)
        {
            VA_U_SelectInputFile();
        }

        /// <summary>
        ///  Handles <see cref="Button.Click"/> event fired by <see cref="VA_U_GenerateButton"/>.
        /// </summary>
        private void VA_U_GenerateButton_Click(object sender, EventArgs e)
        {
            VariableAppraisalUnrestrictedResult result = null;

            if (!VA_U_Validate())
            {
                return;
            }

            try
            {
                switch (VA_U_Input?.AsTable().Type)
                {
                    case IOFileType.Text:
                        result = VA_U_GenerateFromText();
                        break;
                    case IOFileType.Excel:
                        result = VA_U_GenerateFromExcel();
                        break;
                    case IOFileType.Access:
                        result = VA_U_GenerateFromAccess();
                        break;
                }

                SetActiveResult(result);
            }
            catch (OperationCanceledException exception)
            {
                Controls.Find(exception.Source, true).FirstOrDefault()?.Focus();
            }
            catch (InvalidOperationException exception)
            {
                DefaultMessageBox.Error(exception.Message);
            }
            catch (Exception exception)
            {
                Clipboard.SetText(exception.StackTrace);
                DefaultMessageBox.Error($"Unexpected {exception.GetType()}: {exception.Message}");
            }
        }

        /// <summary>
        ///  Handles <see cref="ComboBox.SelectionChangeCommitted"/> event fired by <see cref="VA_U_SourceInput"/>.
        /// </summary>
        private void VA_U_SourceInput_SelectionChangeCommitted(object sender, EventArgs e)
        {
            VA_U_SampleSizeInput.Value = VA_U_Input.Load(VA_U_SourceInput.SelectedItem as string);
            VariableAppraisal.Preview(VA_U_Input, ref VA_U_SourcePanel);
            VA_U_UpdateOptionPrompt(sourceChanged: true);
        }

        /// <summary>
        ///  Handles <see cref="Panel.ControlAdded"/> event fired by <see cref="VA_U_SourcePanel"/>.
        /// </summary>
        private void VA_U_SourcePanel_ControlAdded(object sender, ControlEventArgs e)
        {
            VA_U_PreviewLabel.Visible = true;
        }

        /// <summary>
        ///  Handles <see cref="Panel.ControlRemoved"/> event fired by <see cref="VA_U_SourcePanel"/>.
        /// </summary>
        private void VA_U_SourcePanel_ControlRemoved(object sender, ControlEventArgs e)
        {
            VA_U_PreviewLabel.Visible = false;
        }

        #endregion

        #region Feature implementation

        /// <summary>
        ///  Generates Unrestricted Variable Appraisal from Microsoft Access database input.
        /// </summary>
        private VariableAppraisalUnrestrictedResult VA_U_GenerateFromAccess()
        {
            if (VA_U_SourceOption1Input.SelectedIndex < 0)
            {
                DefaultMessageBox.Error($"Please enter field name for {VA_U_DataFileFormat[0].ToString().ToLowerInvariant()} values.");
                throw new OperationCanceledException() { Source = VA_U_SourceOption1Input.Name };
            }

            if (VA_S_DataFileFormat.Length == 2)
            {
                if (VA_U_SourceOption2Input.SelectedIndex < 0)
                {
                    DefaultMessageBox.Error($"Please enter field name for {VA_U_DataFileFormat[1].ToString().ToLowerInvariant()} values.");
                    throw new OperationCanceledException() { Source = VA_U_SourceOption2Input.Name };
                }
            }

            var rawData = VA_U_Input.AsTable().DataTable.Copy();

            foreach (var column in rawData.Columns.Cast<DataColumn>().Where(column => !VA_U_OptionInputs.Any(input => input.Text == column.ColumnName)).ToList())
            {
                rawData.Columns.Remove(column);
            }

            for (var type = 0; type < VA_U_DataFileFormat.Length; ++type)
            {
                rawData.Columns[VA_U_OptionInputs[type].SelectedItem as string].ColumnName = VA_U_DataFileFormat[type].ToString();
            }

            return VA_U_GenerateFromDataTable(rawData);
        }

        /// <summary>
        ///  Generates Unrestricted Variable Appraisal from Microsoft Excel workbook input.
        /// </summary>
        private VariableAppraisalUnrestrictedResult VA_U_GenerateFromExcel()
        {
            var dataRowOffset = new[] { 0, 0 };
            var dataColumnOffset = new[] { 0, 0 };

            var rawData = VA_U_Input.AsTable().DataTable.Copy();

            if (!Excel.TryParseReference(VA_U_SourceOption1Input.Text, out dataRowOffset[0], out dataColumnOffset[0]))
            {
                DefaultMessageBox.Error($"Please enter valid cell reference for first {VA_U_DataFileFormat[0].ToString().ToLowerInvariant()} value.");
                throw new OperationCanceledException() { Source = VA_U_SourceOption1Input.Name };
            }

            var firstColumn = rawData.Columns[dataColumnOffset[0]];
            var sampleSize = (int)VA_U_SampleSizeInput.Value;

            if (VA_U_DataFileFormat.Length == 2)
            {
                if (!Excel.TryParseReference(VA_U_SourceOption2Input.Text, out dataRowOffset[1], out dataColumnOffset[1]))
                {
                    DefaultMessageBox.Error($"Please enter valid cell reference for first {VA_U_DataFileFormat[1].ToString().ToLowerInvariant()} value.");
                    throw new OperationCanceledException() { Source = VA_U_SourceOption2Input.Name };
                }

                rawData.Columns[dataColumnOffset[1]].SetOrdinal(0);
                if (dataRowOffset[1] > 0)
                {
                    for (var i = 0; i < sampleSize; ++i)
                    {
                        rawData.Rows[i].ItemArray[0] = rawData.Rows[i + dataRowOffset[1]].ItemArray[0];
                    }
                }
            }

            firstColumn.SetOrdinal(0);
            if (dataRowOffset[0] > 0)
            {
                for (var i = 0; i < sampleSize; ++i)
                {
                    rawData.Rows[i].ItemArray[0] = rawData.Rows[i + dataRowOffset[0]].ItemArray[0];
                }
            }

            foreach (var column in rawData.Columns.Cast<DataColumn>().Skip(VA_U_DataFileFormat.Length).ToList())
            {
                rawData.Columns.Remove(column);
            }

            while (rawData.Rows.Count > sampleSize)
            {
                rawData.Rows.RemoveAt(sampleSize);
            }

            if (VA_U_DataFileFormat.Length > rawData.Columns.Count)
            {
                DefaultMessageBox.Error($"Data File Format is incompatible with this Input File and Column A configuration, expecting {VA_U_DataFileFormat.Length} data columns in Input.");
                throw new OperationCanceledException() { Source = VA_U_DataFileFormatInput.Name };
            }

            for (var type = 0; type < VA_U_DataFileFormat.Length; ++type)
            {
                rawData.Columns[type].ColumnName = VA_U_DataFileFormat[type].ToString();
            }

            return VA_U_GenerateFromDataTable(rawData);
        }

        /// <summary>
        ///  Generates Unrestricted Variable Appraisal from text file input.
        /// </summary>
        private VariableAppraisalUnrestrictedResult VA_U_GenerateFromText()
        {
            var rawData = VA_U_Input.AsTable().DataTable.Copy();

            rawData.Columns.RemoveAt(0);

            for (var type = 0; type < VA_U_DataFileFormat.Length; ++type)
            {
                rawData.Columns[type].ColumnName = VA_U_DataFileFormat[type].ToString();
            }

            return VA_U_GenerateFromDataTable(rawData);
        }

        /// <summary>
        ///  Generates Unrestricted Variable Appraisal from DataTable from text, Excel, or Access input.
        /// </summary>
        private VariableAppraisalUnrestrictedResult VA_U_GenerateFromDataTable(DataTable rawData)
        {
            var summary = new VariableAppraisalSummary();
            var result = new VariableAppraisalUnrestrictedResult()
            {
                Name = VA_U_NameInput.Text,
                File = $"{VA_U_FileInput.Text}[{VA_U_SourceInput.Text}]"
            };

            summary.SampleSize = (int)VA_U_SampleSizeInput.Value;
            summary.UniverseSize = (int)VA_U_UniverseSizeInput.Value;

            if (summary.SampleSize > 10_000)
            {
                DefaultMessageBox.Warning("Using sample size larger than 10,000 is not supported in previous RAT-STATS versions. " +
                            "This program uses interpolation for sample size larger than 10,000 and will be accurate to 9 significant figures for most use cases, regardless of the number of figures shown on the report. " +
                            "Please consult with a Statistics Specialist for this sample size.");
            }

            // parse
            var data = rawData.Columns.Cast<DataColumn>().ToDictionary(
                column => (AppraisalVariableType)Enum.Parse(typeof(AppraisalVariableType), column.ColumnName),
                column => new List<double>());

            var rowCount = 0;
            foreach (DataRow row in rawData.Rows)
            {
                foreach (var type in data.Keys)
                {   // TODO can be multithreaded
                    data[type].Add(Convert.ToDouble(row.Field<object>(type.ToString())));
                }

                if (++rowCount >= summary.SampleSize)
                {
                    break;
                }
            }

            if (rowCount < summary.SampleSize &&
                DialogResult.OK != MessageBox.Show($"Only found {rowCount} items which is less than the specified sample size of {summary.SampleSize}." +
                    "\r\n\r\n" + $"Would you like to continue with {rowCount} items instead?", "RATSharp Recoverable Error Encountered", MessageBoxButtons.OKCancel))
            {
                throw new OperationCanceledException() { Source = VA_U_SampleSizeInput.Name };
            }

            if (rawData.Columns.Count == 2)
            {   // derive the third value
                switch (VA_U_DataFileFormatInput.SelectedIndex)
                {
                    case 3:
                        // Examined and Audited Values
                        data[AppraisalVariableType.Difference] =
                        data[AppraisalVariableType.Examined].AsParallel()
                            .Zip(data[AppraisalVariableType.Audited].AsParallel(),
                                (examined, audited) => examined - audited).ToList();
                        break;
                    case 4:
                        // Examined and Difference Values
                        data[AppraisalVariableType.Audited] =
                        data[AppraisalVariableType.Examined].AsParallel()
                            .Zip(data[AppraisalVariableType.Difference].AsParallel(),
                                (examined, difference) => examined - difference).ToList();
                        break;
                    case 5:
                        // Audited and Difference Values
                        data[AppraisalVariableType.Examined] =
                        data[AppraisalVariableType.Audited].AsParallel()
                            .Zip(data[AppraisalVariableType.Difference].AsParallel(),
                                (audited, difference) => audited + difference).ToList();
                        break;
                    default:    throw new InvalidOperationException("Error computing the third set of values.");
                }
            }

            foreach (var column in data)
            {   // TODO parallelizable
                result[column.Key] = new VariableAppraisalResult() { Summary = new[] { summary } };
                result[column.Key].Sum = column.Value.AsParallel().Sum();
                var mean = result[column.Key].Sum / summary.SampleSize;
                result[column.Key].Mean = mean;

                if (data.Count == 1 || AppraisalVariableType.Difference == column.Key)
                {
                    summary.NonzeroSize = column.Value.AsParallel().Count(row => row != 0);
                }

                result[column.Key].PointEstimate = summary.UniverseSize * mean;  // RAT-STATS does not produce this value if sample size == 0 or 1

                if (summary.SampleSize <= 1)
                {   // continuing would only produce NaN's
                    continue;
                }

                var CentralMoment2Term = column.Value.AsParallel().Sum(row => Math.Pow(row - mean, 2));
                var CentralMoment3Term = column.Value.AsParallel().Sum(row => Math.Pow(row - mean, 3));
                var CentralMoment4Term = column.Value.AsParallel().Sum(row => Math.Pow(row - mean, 4));

                var standardDeviation = Math.Sqrt(CentralMoment2Term / (summary.SampleSize - 1));
                result[column.Key].StandardDeviation = standardDeviation;
                result[column.Key].Skewness = CentralMoment3Term / summary.SampleSize / Math.Pow(CentralMoment2Term / summary.SampleSize, 1.5);
                result[column.Key].Kurtosis = summary.SampleSize * CentralMoment4Term / CentralMoment2Term / CentralMoment2Term;
                result[column.Key].StandardErrorMean = standardDeviation * Math.Sqrt((summary.UniverseSize - summary.SampleSize) / (double)summary.UniverseSize / summary.SampleSize);
                result[column.Key].StandardErrorTotal = summary.UniverseSize * result[column.Key].StandardErrorMean;

                foreach (var p in ConfidenceInterval.DefaultLevels)
                {
                    var confidence = new VariableAppraisalConfidence()
                    {
                        T = TDistribution.InverseCDF[p][summary.SampleSize - 1]
                    };
                    confidence.Precision = (double)confidence.T * result[column.Key].StandardErrorTotal;
                    confidence.UpperLimit = result[column.Key].PointEstimate + confidence.Precision;
                    confidence.LowerLimit = result[column.Key].PointEstimate - confidence.Precision;
                    confidence.PrecisionRatio = Math.Max(0, confidence.Precision / result[column.Key].PointEstimate);   // specification: zero if negative

                    result[column.Key].ConfidenceLimits[p] = confidence;
                }
            }

            return result;
        }

        /// <summary>
        ///  Handles input file prompt and lays out UI suitable for the selected input file type.
        /// </summary>
        private void VA_U_SelectInputFile()
        {
            if (DialogResult.OK != VA_U_FileDialog.ShowDialog())
            {
                return;
            }

            try
            {
                VariableAppraisal.Load(VA_U_FileDialog.FileName, out VA_U_Input);

                var inputTable = VA_U_Input.AsTable();

                VA_U_FileInput.Text = inputTable.FileName;
                VA_U_SourceInput.Items.Clear();
                VA_U_SourceInput.Items.AddRange(inputTable.Sources.ToArray());
                VA_U_SourcePanel.Controls.Clear();

                // auto select first sheet
                if (1 == inputTable.Sources.Count())
                {
                    VA_U_SourceInput.SelectedIndex = 0;
                    VA_U_SampleSizeInput.Value = VA_U_Input.Load(VA_U_SourceInput.SelectedItem as string);
                    VariableAppraisal.Preview(VA_U_Input, ref VA_U_SourcePanel);
                }

                for (var i = 0; i < VA_U_OptionLabels.Length; ++i)
                {
                    VA_U_OptionLabels[i].Visible = IOFileType.Text != inputTable.Type;
                    VA_U_OptionInputs[i].Visible = IOFileType.Text != inputTable.Type;
                    VA_U_OptionInputs[i].Items.Clear();
                }

                foreach (var dropdown in VA_U_OptionInputs)
                {
                    if (!(VA_U_Input is AccessVariableInput))
                    {
                        dropdown.Items.Clear();
                    }
                    dropdown.DropDownStyle = (VA_U_Input is AccessVariableInput) ? ComboBoxStyle.DropDownList : ComboBoxStyle.Simple;
                    dropdown.Height = VA_U_DropdownDefaultHeight;   // ComboBox height bug workaround
                }

                switch (inputTable?.Type)
                {
                    case IOFileType.Text:
                        VA_U_SourceInputLabel.Text = "Source name";
                        break;
                    case IOFileType.Excel:
                        VA_U_SourceInputLabel.Text = "Worksheet name";
                        /*
                        VA_U_SourceOption1Label.Text = "What is in Row 1?";
                        VA_U_SourceOption1Input.Items.Add("Labels (don't include row in analysis)");
                        VA_U_SourceOption1Input.Items.Add("Sample data (include row in analysis)");
                        VA_U_SourceOption2Label.Text = "What is in Column A?";
                        VA_U_SourceOption2Input.Items.Add("Line numbers e.g. 1, 2, 3, ... (don't include column in analysis)");
                        VA_U_SourceOption2Input.Items.Add("Sample data (include column in analysis)");
                        */

                        VA_U_DataFileFormat?.Zip(VA_U_OptionLabels.Take(2), (type, label) =>
                        {
                            label.Text = $"Enter cell location for first {type.ToString().ToLowerInvariant()} value (e.g. A1)";
                            return true;
                        }).ToArray();
                        VA_U_UpdateOptionPrompt(sourceChanged: true);
                        break;
                    case IOFileType.Access:
                        VA_U_SourceInputLabel.Text = "Table name";
                        VA_U_UpdateOptionPrompt(sourceChanged: true);
                        break;
                    default:
                        break;
                }
            }
            catch (InvalidOperationException exception) when (exception.TargetSite.Name.Equals("GetDataSource"))
            {
                DefaultMessageBox.Error($"Cannot open {VA_U_FileDialog.FileName} using OLEDB connection. " +
                                        $"Please install {(Environment.Is64BitProcess ? 64 : 32)}-bit Microsoft Access Database Engine 2010 Redistributable to open Microsoft Office files.");
            }
        }

        /// <summary>
        ///  Lays out UI suitable for user response to options.
        /// </summary>
        private void VA_U_UpdateOptionPrompt(bool sourceChanged = false)
        {
            if (VA_U_Input is AccessVariableInput)
            {
                var accessInput = VA_U_Input as AccessVariableInput;

                for (var i = 0; i < VA_U_OptionLabels.Length; ++i)
                {
                    VA_U_OptionLabels[i].Text = VA_U_DataFileFormat.Length <= i ? "" : $"Field name for {VA_U_DataFileFormat[i].ToString().ToLowerInvariant()} values";
                    VA_U_OptionLabels[i].Visible = VA_U_DataFileFormat.Length > i;
                    VA_U_OptionInputs[i].Visible = VA_U_DataFileFormat.Length > i;

                    if (sourceChanged)
                    {
                        VA_U_OptionInputs[i].Items.Clear();
                        foreach (var column in accessInput.Fields)
                        {
                            VA_U_OptionInputs[i].Items.Add(column);
                        }
                    }
                }
            }
            else if (VA_U_Input is ExcelVariableInput)
            {
                var excelInput = VA_U_Input as ExcelVariableInput;

                for (var i = 0; i < VA_U_OptionLabels.Length; ++i)
                {
                    VA_U_OptionLabels[i].Text = VA_U_DataFileFormat.Length <= i ? "" : $"Cell location for first {VA_U_DataFileFormat[i].ToString().ToLowerInvariant()} value (e.g. A1)";
                    VA_U_OptionLabels[i].Visible = VA_U_DataFileFormat.Length > i;
                    VA_U_OptionInputs[i].Visible = VA_U_DataFileFormat.Length > i;

                    if (sourceChanged)
                    {
                        VA_U_OptionInputs[i].Items.Clear();
                    }
                }
            }
        }

        #endregion
    }
}