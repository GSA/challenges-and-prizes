﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace RATSharp.Renderers
{
    /// <summary>
    ///  <see cref="IRATResult"/> plain text renderer.
    /// </summary>
    public static class PlainText
    {   /// This class is implemented using heredoc to preserve visual integrity of rendering result.
        /// For more information about heredoc, see https://en.wikipedia.org/w/index.php?title=Here_document&oldid=756198374

        /// <summary>
        ///  Defines default fixed width of generated representation, in number of characters.
        /// </summary>
        const int TextFileWidth = 80;

        /// <summary>
        ///  Defines number of characters occupied by date and time display, including critical margins.
        /// </summary>
        const int DateTimeMargin = 16 + 16;

        /// <summary>
        ///  Renders text output according to the underlying type of <paramref name="result"/>.
        /// </summary>
        /// <param name="result">Analysis result to render.</param>
        internal static string Render(IRATResult result)
        {
            if (result is VariableAppraisalStratifiedResult)
            {
                return RenderPage(result, content: Render(result as VariableAppraisalStratifiedResult))
                    .Replace("#TYPE", "STRATIFIED VARIABLE APPRAISAL".CenterFixedWidth(TextFileWidth - DateTimeMargin, true));
            }
            else if (result is VariableAppraisalUnrestrictedResult)
            {
                return RenderPage(result, content: Render(result as VariableAppraisalUnrestrictedResult))
                    .Replace("#TYPE", "UNRESTRICTED VARIABLE APPRAISAL".CenterFixedWidth(TextFileWidth - DateTimeMargin, true));
            }
            else if (result is AttributeAppraisalUnrestrictedResult)
            {
                return RenderPage(result, content: Render(result as AttributeAppraisalUnrestrictedResult))
                    .Replace("#TYPE", "SINGLE STAGE ATTRIBUTE APPRAISAL".CenterFixedWidth(TextFileWidth - DateTimeMargin, true));
            }
            else if (result is RandomNumbersSingleResult)
            {
                return RenderPage(result, content: Render(result as RandomNumbersSingleResult))
                    .Replace("#TYPE", "RANDOM NUMBER GENERATOR".CenterFixedWidth(TextFileWidth - DateTimeMargin, true));
            }

            return "";
        }

        /// <summary>
        ///  Renders a <see cref="VariableAppraisalConfidence"/> object to text file.
        /// </summary>
        /// <param name="confidence">Confidence interval details from Variable Appraisal result.</param>
        /// <param name="p">Confidence level of this interval.</param>
        /// <param name="index">Index of this confidence interval within the group.</param>
        /// <param name="count">Number of confidence intervals to be rendered in total.</param>
        static string Render(
            VariableAppraisalConfidence confidence,
            double p,
            int index,
            int count)
        {
            return $@"
{                 $"{p:#,0%}".PadLeft(42)} CONFIDENCE LEVEL
           LOWER LIMIT       {$"{confidence.LowerLimit:#,0}".PadLeft(30)}
           UPPER LIMIT       {$"{confidence.UpperLimit:#,0}".PadLeft(30)}
           PRECISION AMOUNT  {$"{confidence.Precision:#,0}".PadLeft(30)}
           PRECISION PERCENT {$"{confidence.PrecisionRatio:#.00%}".PadLeft(31)}
           {
           (confidence.IsZ ? "Z" : "T")
           }-VALUE USED      {$"{confidence.Statistic:#.000000000000}".PadLeft(30)}
";
        }

        /// <summary>
        ///  Renders a collection of <see cref="VariableAppraisalConfidence"/> objects to text file.
        /// </summary>
        /// <param name="confidenceLimits">
        ///  A collection of <see cref="VariableAppraisalConfidence"/> objects as sorted dictionary with
        ///  confidence levels as keys.
        /// </param>
        static string Render(SortedDictionary<double, VariableAppraisalConfidence> confidenceLimits)
        {
            return $@"
                                        CONFIDENCE LIMITS{
                confidenceLimits.Select((confidence, i) => Render(confidence.Value, confidence.Key, i, confidenceLimits.Count)).Concat()}";
        }

        /// <summary>
        ///  Renders a <see cref="VariableAppraisalResult"/> object to text file.
        /// </summary>
        /// <param name="result">Variable Appraisal result.</param>
        /// <param name="index">
        ///  Stratum index of this result. A negative value indicates that this result is not a member of
        ///  any stratum.
        /// </param>
        /// <param name="universe">Universe size of the appraisal.</param>
        static string Render(
            VariableAppraisalResult result,
            int index,
            int universe)
        {
            return $@"{(
    result.ConfidenceLimits.IsZ() ?
        $@"
OVERALL    POINT ESTIMATE / UNIVERSE {$"{result.PointEstimate:#,0}".PadLeft(19)
                                                       } {$"{universe:#,0}".PadLeft(18)}
           STANDARD ERROR            {$"{result.StandardErrorTotal:#,0}".PadLeft(19)}" :
        $@"
{(
    index < 0 ?
    string.Empty.PadLeft(10) :
    $"Stratum {index + 1}".PadRight(10)
        )} MEAN / UNIVERSE           {$"{result.Mean:#,#.00}".PadLeft(19)
                                                       } {$"{universe:#,0}".PadLeft(18)}
           STANDARD DEVIATION        {$"{result.StandardDeviation:#,#.00}".PadLeft(19)}
           SKEWNESS                  {$"{result.Skewness:#,#.00}".PadLeft(19)}
           KURTOSIS                  {$"{result.Kurtosis:#,#.00}".PadLeft(19)}
           STANDARD ERROR (MEAN)     {$"{result.StandardErrorMean:#,#.00}".PadLeft(19)}
           STANDARD ERROR (TOTAL)    {$"{result.StandardErrorTotal:#,0}".PadLeft(19)}
           POINT ESTIMATE            {$"{result.PointEstimate:#,0}".PadLeft(19)}"
)}
{
    Render(result.ConfidenceLimits)
}";
        }

        /// <summary>
        ///  Renders a <see cref="AttributeAppraisalConfidence"/> object to text file.
        /// </summary>
        /// <param name="confidence">Confidence interval details from Attribute Appraisal result.</param>
        /// <param name="p">Confidence level of this interval.</param>
        /// <param name="index">Index of this confidence interval within the group.</param>
        /// <param name="count">Number of confidence intervals to be rendered in total.</param>
        static string Render(
            AttributeAppraisalConfidence confidence,
            double p,
            int index,
            int count)
        {
            return $@"
{                   $"{p:0%}".PadLeft(42)} CONFIDENCE LEVEL{(
    // if no lower limit, print nothing
    null == confidence.LowerLimit ? "" : $@"
         LOWER LIMIT - QUANTITY {$"{confidence.LowerLimit:#,0}".PadLeft(27)}
                       PERCENT  {$"{confidence.LowerLimitRatio:.000%}".PadLeft(28)}"
)}{(
    // if no upper limit, print nothing
    null == confidence.UpperLimit ? "" : $@"
         UPPER LIMIT - QUANTITY {$"{confidence.UpperLimit:#,0}".PadLeft(27)}
                       PERCENT  {$"{confidence.UpperLimitRatio:.000%}".PadLeft(28)}"
)}
";
        }

        /// <summary>
        ///  Renders a collection of <see cref="AttributeAppraisalConfidence"/> objects to text file.
        /// </summary>
        /// <param name="confidenceLimits">
        ///  A collection of <see cref="AttributeAppraisalConfidence"/> objects as sorted dictionary with
        ///  confidence levels as keys.
        /// </param>
        static string Render(SortedDictionary<double, AttributeAppraisalConfidence> confidenceLimits)
        {
            return $@"
                                        CONFIDENCE LIMITS
{
    confidenceLimits.Select((confidence, i) => Render(confidence.Value, confidence.Key, i, confidenceLimits.Count)).Concat()
}{(
    // print notice if required
    // if no lower limit
    !confidenceLimits.Any(confidence => confidence.Value.LowerLimit.HasValue) ?
    @"
   SINCE NO ITEMS HAVING THE CHARACTERISTIC(S) OF INTEREST WERE FOUND IN THE
   SAMPLE, THE PROGRAM HAS CALCULATED ONLY THE MAXIMUM NUMBER OF ITEMS
   HAVING THE CHARACTERISTIC(S) OF INTEREST IN THE UNIVERSE." :
    // else if no upper limit
    !confidenceLimits.Any(confidence => confidence.Value.UpperLimit.HasValue) ?
    @"
   SINCE ALL SAMPLE ITEMS CONTAINED THE CHARACTERISTIC(S) OF INTEREST, THE
   PROGRAM HAS CALCULATED ONLY THE MINIMUM NUMBER OF ITEMS IN THE UNIVERSE
   HAVING THE CHARACTERISTIC(S) OF INTEREST." :
   // else print nothing
   ""
)}";
        }

        /// <summary>
        ///  Renders a <see cref="VariableAppraisalStratifiedResult"/> object to text file.
        /// </summary>
        /// <param name="result">Stratified Variable Appraisal result.</param>
        static string Render(VariableAppraisalStratifiedResult result)
        {
            return $@"
{
    (new[] { "DATA FILE USED:", result.File }).Concat(" ").CenterFixedWidth(TextFileWidth)
}

{(
    1 == result.Overall.Types.Count() ?
        // one variable type
        $@"
         STRATUM     SAMPLE
          NUMBER      SIZE       VALUE OF SAMPLE   NONZERO ITEMS
{
    result.Strata.Select(stratum => $@"{
$"{1 + stratum.Key:#,0}".PadLeft(14)
}   {
                 $"{stratum.Value.Summary.SampleSize:#,0}".PadLeft(9)
}  {
                            $"{stratum.Value[stratum.Value.Types.FirstOrDefault()].Sum:#,0.00}".PadLeft(20)
} {
                                                 $"{stratum.Value.Summary.NonzeroSize:#,0}".PadLeft(15)
}
").Concat()
}
        TOTALS   {
    // total
    $@"{
                 $"{result.Overall.Summary.SampleSize:#,0}".PadLeft(9)
}  {
                            $"{result.Overall[result.Overall.Types.FirstOrDefault()].Sum:#,0.00}".PadLeft(20)
} {
                                                 $"{result.Overall.Summary.NonzeroSize:#,0}".PadLeft(15)
}"
}
" :
        // complete variable types
        $@"
 STR SAMPLE         EXAMINED    NONZERO        TOTAL OF          TOTAL OF
 NBR  SIZE            VALUE      DIFFS        DIFF VALUES        AUD VALUES
{
    result.Strata.Select(stratum => $@"{
$"{1 + stratum.Key:#,0}".PadLeft(3)
}  {
     $"{stratum.Value.Summary.SampleSize:#,0}".PadLeft(6)
} {
            $"{stratum.Value[AppraisalVariableType.Examined].Sum:#,0.00}".PadLeft(16)
} {
                             $"{stratum.Value.Summary.NonzeroSize:#,0}".PadLeft(10)
}  {
                                         $"{stratum.Value[AppraisalVariableType.Difference].Sum:#,0.00}".PadLeft(16)
}  {
                                                           $"{stratum.Value[AppraisalVariableType.Audited].Sum:#,0.00}".PadLeft(16)
}
").Concat()
}
{   // total
    $@"{
$"{result.Overall.Summary.SampleSize:#,0}".PadLeft(11)
} {
            $"{result.Overall[AppraisalVariableType.Examined].Sum:#,0.00}".PadLeft(16)
} {
                             $"{result.Overall.Summary.NonzeroSize:#,0}".PadLeft(10)
}  {
                                         $"{result.Overall[AppraisalVariableType.Difference].Sum:#,0.00}".PadLeft(16)
}  {
                                                           $"{result.Overall[AppraisalVariableType.Audited].Sum:#,0.00}".PadLeft(16)
}"
}
")}{
    result.Overall.Types.Select(type => $@"

{
           // ----------------- A P P R A I S A L   T Y P E ------------------
           type.GetPlainTextSeparator()
}{
    // for each stratum
    result.Strata.Select(stratum => Render(stratum.Value[type], stratum.Key, stratum.Value.Summary.UniverseSize)).Concat() +
    // overall
    Render(result.Overall[type], -1, result.Overall.Summary.UniverseSize)
}")
    // merge all types
    .Concat()
}
";
        }

        /// <summary>
        ///  Renders a <see cref="VariableAppraisalUnrestrictedResult"/> object to text file.
        /// </summary>
        /// <param name="result">Unrestricted Variable Appraisal result.</param>
        static string Render(VariableAppraisalUnrestrictedResult result)
        {
            return $@"
{
    (new[] { "DATA FILE USED:", result.File }).Concat(" ").CenterFixedWidth(TextFileWidth)
}

{(
    1 == result.Types.Count() ?
    // one variable type
        $@"
               SAMPLE SIZE       VALUE OF SAMPLE   NONZERO ITEMS
{
$"{result.Summary.SampleSize:#,0}".PadLeft(26)
}  {
                           $"{result[result.Types.FirstOrDefault()].Sum:#,0.00}".PadLeft(20)
} {
                                                 $"{result.Summary.NonzeroSize:#,0}".PadLeft(15)
}" :
    // complete variable types
        $@"
     SAMPLE         EXAMINED    NONZERO        TOTAL OF          TOTAL OF
      SIZE            VALUE      DIFFS        DIFF VALUES        AUD VALUES
{
$"{result.Summary.SampleSize:#,0}".PadLeft(11)
} {
            $"{result[AppraisalVariableType.Examined].Sum:#,0.00}".PadLeft(16)
} {
                             $"{result.Summary.NonzeroSize:#,0}".PadLeft(10)
}  {
                                         $"{result[AppraisalVariableType.Difference].Sum:#,0.00}".PadLeft(16)
}  {
                                                           $"{result[AppraisalVariableType.Audited].Sum:#,0.00}".PadLeft(16)
}
")}
{
    result.Types.Select(type => $@"
{
        // ----------------- A P P R A I S A L   T Y P E ------------------
           type.GetPlainTextSeparator()
}{
    Render(result[type], -1, result.Summary.UniverseSize)
}").Concat()
}
";
        }

        /// <summary>
        ///  Renders an <see cref="AttributeAppraisalUnrestrictedResult"/> object to text file.
        /// </summary>
        /// <param name="result">Unrestricted Attribute Appraisal result.</param>
        static string Render(AttributeAppraisalUnrestrictedResult result)
        {
            return $@"{
    (new[] { "OUTPUT FILE:", result.File }).Concat(" ").CenterFixedWidth(TextFileWidth)
}


         UNIVERSE SIZE                                                  {result.UniverseSize:#,0}
         SAMPLE SIZE                                                    {result.SampleSize:#,0}
         CHARACTERISTIC(S) OF INTEREST
           QUANTITY IDENTIFIED IN SAMPLE                                {result.SampleOfInterestSize:#,0}
           PROJECTED QUANTITY IN UNIVERSE                               {result.PopulationOfInterestSize:#,0}
           PERCENT                                                      {result.PopulationOfInterestRatio:#.000%}
         STANDARD ERROR
           PROJECTED QUANTITY                                           {result.StandardErrorTotal:#,0}
           PERCENT                                                      {result.StandardErrorMean:#.000%}
{
    Render(result.ConfidenceLimits)
}";
        }

        /// <summary>
        ///  Renders a <see cref="RandomNumbersSingleResult"/> object to text file.
        /// </summary>
        /// <param name="result">Single Stage Random Numbers Generation result.</param>
        static string Render(RandomNumbersSingleResult result)
        {
            return $@"{

$"SEED NUMBER: {result.SeedNumber}".PadRight(50)} FRAME SIZE: {$"{result.UniverseSize:#,0}".PadLeft(15)}


     FILE OF RANDOM NUMBERS: {result.File}

     TOTAL RANDOM NUMBERS GENERATED: {result.SampleSize:#,0}

THE NUMBERS ARE IN THE FOLLOWING FORMAT IN YOUR FILE:
   POSITIONS 1 THROUGH  6 - ORDER OF SELECTION
   POSITIONS 7 THROUGH 17 - RANDOM NUMBER
EACH COLUMN OF NUMBERS IS RIGHT JUSTIFIED.


Selection
  Order     Value
{
    result.Numbers
        .Select(number => $"{number.Key}".PadLeft(6) + $"{number.Value}".PadLeft(11))
        .Concat("\r\n")
}

SUMMATION OF RANDOM NUMBERS = {result.Sum:#,0}";
        }

        /// <summary>
        ///  Renders a placeholder text file representation of analysis result, and subsequently renders content onto it.
        /// </summary>
        /// <param name="result">Analysis result.</param>
        /// <param name="content">Content of the page.</param>
        static string RenderPage(
            IRATResult result,
            string content)
        {
            return $@"{"RAT#".CenterFixedWidth(TextFileWidth)}
                             Statistical Software
Date: {result.DateTime.ToString("d", CultureInfo.CreateSpecificCulture("en-us")).PadRight(10)
                                                        }#TYPE     Time: {result.DateTime.ToString("HH:mm")
                                                                        }
 {(new[] { "AUDIT/REVIEW:", result.Name }).Concat(" ").CenterFixedWidth(TextFileWidth)}
{content}
";
        }
    }
}

namespace RATSharp
{
    /// <summary>
    ///  Contains extension methods used throughout the program.
    /// </summary>
    public static partial class Extensions
    {
        /// <summary>
        ///  Gets a visually separating string for this Appraisal variable type.
        /// </summary>
        internal static string GetPlainTextSeparator(this AppraisalVariableType type)
        {
            switch (type)
            {
                case AppraisalVariableType.Examined: return "           ----------------------- E X A M I N E D ------------------------";
                case AppraisalVariableType.Audited: return "           ----------------------- A U D I T E D --------------------------";
                case AppraisalVariableType.Difference: return "           --------------------- D I F F E R E N C E ----------------------";
            }
            return string.Empty;
        }
    }
}
