﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

using System;
using System.Collections.Generic;

namespace RATSharp.IO
{
    /// <summary>
    ///  Defines ASV-compliant separator characters as defined by ASCII standard.
    /// </summary>
    public static class Separator
    {
        /// <summary>
        ///  File separator (␜) ASCII character code 28.
        /// </summary>
        public const char File = (char)28;

        /// <summary>
        ///  Group separator (␝) ASCII character code 29.
        /// </summary>
        public const char Group = (char)29;

        /// <summary>
        ///  Record separator (␞) ASCII character code 30.
        /// </summary>
        public const char Record = (char)30;

        /// <summary>
        ///  Unit separator (␟) ASCII character code 31.
        /// </summary>
        public const char Unit = (char)31;
    }
}

namespace RATSharp
{
    /// <summary>
    ///  Contains extension methods used throughout the program.
    /// </summary>
    public static partial class Extensions
    {
        /// <summary>
        ///  Expands this <see cref="IRATResult"/> array into key-value pairs with suitable serial filename and optional prefix.
        /// </summary>
        /// <param name="baseFileName">The base file name which is a full path to file to the target.</param>
        /// <param name="suffixPrefix">Prefix for the suffixed serial numbers.</param>
        internal static IEnumerable<KeyValuePair<string, IRATResult>> ExpandResult(
            this IRATResult[] resultArray,
            string baseFileName,
            string suffixPrefix = "")
        {
            if (1 == resultArray.Length)
            {
                yield return new KeyValuePair<string, IRATResult>(baseFileName, resultArray[0]);
            }
            else
            {
                var leftPad = 1 + (int)Math.Floor(Math.Log10(resultArray.Length));
                for (var i = 0; i < resultArray.Length; ++i)
                {
                    yield return new KeyValuePair<string, IRATResult>(baseFileName.RegexReplace(@"^([^\.]*)(\.[^\.]+|)$", $"$1_{suffixPrefix}{$"{i + 1}".PadLeft(leftPad, '0')}$2"), resultArray[i]);
                }
            }
        }
    }
}
