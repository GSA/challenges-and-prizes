﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

using RATSharp.Stochastics;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;

namespace RATSharp
{
    /// <summary>
    ///  Primary form for the program.
    /// </summary>
    public partial class MainForm
    {
        /// <summary>
        ///  Collection of R_SS_InputGrid columns.
        /// </summary>
        private DataGridViewTextBoxColumn[] R_SS_GridInputColumns;

        /// <summary>
        ///  UI setup phase for Stratified Single Stage Random Numbers, called by <see cref="MainForm_Load"/>.
        /// </summary>
        private void R_SS_Load()
        {
            R_SS_GridInputColumns = new[]
            {
                R_SS_SeedNumberInput,
                R_SS_SequentialQuantityInput,
                R_SS_SpareQuantityInput,
                R_SS_FrameLowInput,
                R_SS_FrameHighInput
            };

            foreach (var column in R_SS_GridInputColumns)
            {
                column.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                column.DefaultCellStyle = CellStyle.Numeric;
                column.MaxInputLength = 10;
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
                column.ValueType = typeof(int);
            }

            R_SS_SeedNumberInput.DefaultCellStyle = CellStyle.Decimal;
            R_SS_SeedNumberInput.MaxInputLength = 20;
            R_SS_SeedNumberInput.ValueType = typeof(double?);

            R_SS_StratifiedSaveInformationLabel.Visible = false;
        }

        /// <summary>
        ///  User input validation procedure for Stratified Single Stage Random Numbers.
        /// </summary>
        private bool R_SS_Validate()
        {
            for (var i = 0; i < R_SS_InputGrid.Rows.Count; ++i)
            {
                if (R_SS_InputGrid.Rows[i].IsNewRow)
                {
                    continue;
                }

                if (R_SS_InputGrid.Rows[i].Cells.Cast<DataGridViewTextBoxCell>().Skip(1).Any(cell => null == cell.Value))
                {
                    R_SS_InputGrid.Rows.RemoveAt(i--);
                    continue;
                }

                if ((int)R_SS_InputGrid.Rows[i].Cells[R_SS_FrameHighInput.Index].Value < (int)R_SS_InputGrid.Rows[i].Cells[R_SS_FrameLowInput.Index].Value)
                {
                    DefaultMessageBox.Error($"Stratum {i + 1}: Frame size must be positive. Please enter High Number greater than the Low Number.");
                    R_SS_InputGrid.Focus();
                    return false;
                }

                if ((int)R_SS_InputGrid.Rows[i].Cells[R_SS_SequentialQuantityInput.Index].Value < 1)
                {
                    DefaultMessageBox.Error($"Stratum {i + 1}: Request at least 1 sequential random number.");
                    R_SS_InputGrid.Focus();
                    return false;
                }

                if ((int)R_SS_InputGrid.Rows[i].Cells[R_SS_FrameHighInput.Index].Value - (int)R_SS_InputGrid.Rows[i].Cells[R_SS_FrameLowInput.Index].Value + 1 < (int)R_SS_InputGrid.Rows[i].Cells[R_SS_SequentialQuantityInput.Index].Value + (int)R_SS_InputGrid.Rows[i].Cells[R_SS_SpareQuantityInput.Index].Value)
                {
                    DefaultMessageBox.Error($"Stratum {i + 1}: Total requested random numbers ({(int)R_SS_InputGrid.Rows[i].Cells[R_SS_SequentialQuantityInput.Index].Value + (int)R_SS_InputGrid.Rows[i].Cells[R_SS_SpareQuantityInput.Index].Value}) cannot be more than the frame size ({(int)R_SS_InputGrid.Rows[i].Cells[R_SS_FrameHighInput.Index].Value - (int)R_SS_InputGrid.Rows[i].Cells[R_SS_FrameLowInput.Index].Value + 1}). " +
                               "Please request less random numbers or widen the frame size.");
                    R_SS_InputGrid.Focus();
                    return false;
                }
            }

            return true;
        }

        #region Event handlers

        /// <summary>
        ///  Handles <see cref="Button.Click"/> event fired by <see cref="R_SS_GenerateButton"/>.
        /// </summary>
        private void R_SS_GenerateButton_Click(object sender, EventArgs e)
        {
            if (!R_SS_Validate())
            {
                return;
            }

            MainStatus.Text = "Computation started";
            MainProgressBar.Style = ProgressBarStyle.Marquee;

            var tasks = R_SS_InputGrid.Rows.Cast<DataGridViewRow>().Where(row => !row.IsNewRow).Select(row => new RandomNumbersTask()
            {
                SeedNumber = (double)(row.Cells[R_SS_SeedNumberInput.Index].Value ?? RandomNumbers.GetSeed()),
                SequentialOrderQuantity = (int)row.Cells[R_SS_SequentialQuantityInput.Index].Value,
                SpareQuantity = (int)row.Cells[R_SS_SpareQuantityInput.Index].Value,
                HighNumber = (int)row.Cells[R_SS_FrameHighInput.Index].Value,
                LowNumber = (int)row.Cells[R_SS_FrameLowInput.Index].Value
            });

            var worker = new BackgroundWorker()
            {
                WorkerReportsProgress = true
            };

            worker.DoWork += (object lambdaSender, DoWorkEventArgs lambdaArgs) =>
            {
                var lambdaTasks = lambdaArgs.Argument as IEnumerable<RandomNumbersTask>;
                Action<int> reportProgress = (int percentProgress) =>
                {
                    (lambdaSender as BackgroundWorker).ReportProgress(percentProgress);
                };

                var lambdaResult = lambdaTasks.AsParallel().Select((task, i) =>
                {
                    var taskResult = new RandomNumbersSingleResult()
                    {
                        Name = $"{R_SS_NameInput.Text} (Stratum {i + 1})",
                        SeedNumber = task.SeedNumber,
                        SequentialSampleSize = task.SequentialOrderQuantity,
                        SpareSampleSize = task.SpareQuantity,
                        UniverseSize = task.HighNumber - task.LowNumber + 1,
                        Sum = 0
                    };

                    var set = RandomNumbers.GetWichmannHillSet(task.SequentialOrderQuantity + task.SpareQuantity, task.SeedNumber, task.HighNumber - task.LowNumber + 1, task.LowNumber, reportProgress);

                    UInt64 order = 1;
                    taskResult.Numbers = set
                        .Take(task.SequentialOrderQuantity)
                        .AsParallel()
                        .Select(value => new KeyValuePair<ulong, ulong>(order++, value.AccumulateTo(ref taskResult.Sum)))
                        .OrderBy(row => row.Value)
                        .AsSequential()
                        .Concat(set
                            .Skip(task.SequentialOrderQuantity)
                            .Select(value => new KeyValuePair<ulong, ulong>(order++, value.AccumulateTo(ref taskResult.Sum)))
                        ).ToList();

                    return taskResult;
                }).ToArray();

                lambdaArgs.Result = new RandomNumbersStratifiedResult()
                {
                    Name = R_SS_NameInput.Text,
                    Strata = lambdaResult
                };
            };

            worker.RunWorkerCompleted += (object lambdaSender, RunWorkerCompletedEventArgs lambdaArgs) =>
            {
                MainStatus.Text = $"Rendering result...";
                SetActiveResult(lambdaArgs.Result as RandomNumbersStratifiedResult);
                MainStatus.Text = $"Completed.";
                MainProgressBar.Value = 0;
                RandomStratifiedSubPage.Controls.SetEnabled(true);
            };

            worker.ProgressChanged += (object lambdaSender, ProgressChangedEventArgs lambdaArgs) =>
            {
                MainStatus.Text = $"Computed {lambdaArgs.ProgressPercentage}%";
                MainProgressBar.Style = ProgressBarStyle.Blocks;
                MainProgressBar.Value = lambdaArgs.ProgressPercentage;
            };

            RandomStratifiedSubPage.Controls.SetEnabled(false);

            worker.RunWorkerAsync(tasks);
        }

        /// <summary>
        ///  Handles <see cref="DataGridView.CellValidating"/> event fired by <see cref="R_SS_InputGrid"/>.
        /// </summary>
        private void R_SS_InputGrid_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            R_SS_StrataCountOutput.Text = (R_SS_InputGrid.Rows.Cast<DataGridViewRow>().Where(row => !row.IsNewRow && string.IsNullOrEmpty(row.ErrorText)).Count()).ToString();
            R_SS_InputGrid.Rows[e.RowIndex].ErrorText = "";
            R_SS_InputGrid.AllowUserToAddRows = true;

            if (R_SS_InputGrid.Rows[e.RowIndex].IsNewRow) { return; }
            if (R_SS_InputGrid.Rows[e.RowIndex].Cells.OfType<DataGridViewCell>().Any(cell => !cell.IsInEditMode && cell.ColumnIndex != R_SS_SeedNumberInput.Index && null == cell.Value))
            {
                R_SS_InputGrid.AllowUserToAddRows = false;
                R_SS_InputGrid.Rows[e.RowIndex].ErrorText = "Stratum specification cannot be empty.";
            }
        }

        /// <summary>
        ///  Handles <see cref="DataGridView.DataError"/> event fired by <see cref="R_SS_InputGrid"/>.
        /// </summary>
        private void R_SS_InputGrid_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            if (e.ColumnIndex == R_SS_SeedNumberInput.Index)
            {
                BlinkStatus("The value must be a positive decimal.");
            }
            else
            {
                BlinkStatus("The value must be a non-negative integer less than 2,147,483,647.");
            }
        }

        /// <summary>
        ///  Handles <see cref="DataGridView.EditingControlShowing"/> event fired by <see cref="R_SS_InputGrid"/>.
        /// </summary>
        private void R_SS_InputGrid_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            e.Control.KeyPress -= KeyPressFilter.RestrictToInteger;
            e.Control.KeyPress -= KeyPressFilter.RestrictToDecimal;
            e.Control.KeyPress += (R_SS_SeedNumberInput == R_SS_InputGrid.CurrentCell.OwningColumn) ? KeyPressFilter.RestrictToDecimal : KeyPressFilter.RestrictToInteger;
        }

        /// <summary>
        ///  Handles <see cref="DataGridView.RowsRemoved"/> event fired by <see cref="R_SS_InputGrid"/>.
        /// </summary>
        private void R_SS_InputGrid_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            if (0 == R_SS_InputGrid.Rows.Count)
            {
                R_SS_InputGrid.AllowUserToAddRows = true;
            }
        }

        /// <summary>
        ///  Handles <see cref="TextBox.TextChanged"/> event fired by <see cref="R_SS_StrataCountOutput"/>.
        /// </summary>
        private void R_SS_StrataCountOutput_TextChanged(object sender, EventArgs e)
        {
            R_SS_StratifiedSaveInformationLabel.Visible = (int.TryParse(R_SS_StrataCountOutput.Text, out int value) && value > 1);
        }

        #endregion
    }
}
