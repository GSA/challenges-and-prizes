﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

using System;
using System.Collections.Generic;
using System.Data;

namespace RATSharp.IO
{
    /// <summary>
    ///  Specifies constants defining which file type an I/O facility represents.
    /// </summary>
    public enum IOFileType
    {
        /// <summary>
        ///  The I/O facility represents a text file.
        /// </summary>
        Text,

        /// <summary>
        ///  The I/O facility represents a Microsoft Excel workbook.
        /// </summary>
        Excel,

        /// <summary>
        ///  The I/O facility represents a Microsoft Access database.
        /// </summary>
        Access
    }

    /// <summary>
    ///  Represents a container of Table-style data for I/O purposes. This class is abstract.
    /// </summary>
    public abstract class IOTable
    {
        #region Properties

        /// <summary>
        ///  When overridden in a derived class, gets or sets the table names contained by this object.
        /// </summary>
        public abstract IEnumerable<string> Sources { get; set; }

        /// <summary>
        ///  When overridden in a derived class, gets the represented file type.
        /// </summary>
        public abstract IOFileType Type { get; }

        /// <summary>
        ///  Gets the Table currently loaded to memory.
        /// </summary>
        public DataTable DataTable { get; set; }

        /// <summary>
        ///  Gets the file name the data loads from.
        /// </summary>
        public string FileName { get; private set; }

        #endregion

        /// <summary>
        ///  A factory method to create Variable Appraisal input object from an input file.
        /// </summary>
        /// <param name="fileName">Variable Appraisal input file.</param>
        public static IVariableInput FromFile(string fileName)
        {
            if (fileName.EndsWith(".txt", StringComparison.InvariantCultureIgnoreCase))
            {
                return new TextVariableInput() { FileName = fileName } as IVariableInput;
            }
            else if (fileName.EndsWith(".xls", StringComparison.InvariantCultureIgnoreCase) ||
                     fileName.EndsWith(".xlsx", StringComparison.InvariantCultureIgnoreCase))
            {
                return new ExcelVariableInput() { FileName = fileName } as IVariableInput;
            }
            else if (fileName.EndsWith(".accdb", StringComparison.InvariantCultureIgnoreCase))
            {
                return new AccessVariableInput() { FileName = fileName } as IVariableInput;
            }

            return null;
        }
    }

    public partial class TextIOTable
    {
        /// <summary>
        ///  Gets the represented file type.
        /// </summary>
        public override IOFileType Type { get; } = IOFileType.Text;
    }

    public partial class ExcelIOTable
    {
        /// <summary>
        ///  Gets the represented file type.
        /// </summary>
        public override IOFileType Type { get; } = IOFileType.Excel;
    }

    public partial class AccessIOTable
    {
        /// <summary>
        ///  Gets the represented file type.
        /// </summary>
        public override IOFileType Type { get; } = IOFileType.Access;
    }
}
