﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

using RATSharp.Stochastics;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RATSharp
{
    /// <summary>
    ///  Primary form for the program.
    /// </summary>
    public partial class MainForm : Form
    {
        /// <summary>
        ///  UI setup phase for Unrestricted Attribute Appraisal, called by <see cref="MainForm_Load"/>.
        /// </summary>
        private void AA_U_Load()
        {
            AA_U_ConfidenceLevelInput.Visible = false;
            AA_U_ConfidenceLevelPercentageLabel.Visible = false;
            AA_U_DefaultCustomizeLabel.Visible = false;
        }

        /// <summary>
        ///  User input validation procedure for Unrestricted Attribute Appraisal.
        /// </summary>
        private bool AA_U_Validate()
        {
            if (AA_U_UniverseSizeInput.Value <= 0 ||
                AA_U_UniverseSizeInput.Value % 1 != 0)
            {
                DefaultMessageBox.Error($"{VA_U_UniverseSizeInput.Value} is not a valid Universe Size.");
                VA_U_UniverseSizeInput.Focus();
                return false;
            }

            if (AA_U_SampleSizeInput.Value <= 0 ||
                AA_U_SampleSizeInput.Value % 1 != 0)
            {
                DefaultMessageBox.Error($"{AA_U_SampleSizeInput.Value} is not a valid Sample Size.");
                AA_U_SampleSizeInput.Focus();
                return false;
            }

            if (AA_U_SampleOfInterestSizeInput.Value < 0 ||
                AA_U_SampleOfInterestSizeInput.Value % 1 != 0)
            {
                DefaultMessageBox.Error($"{AA_U_SampleOfInterestSizeInput.Value} is not a valid number of samples with characteristics of interest.");
                AA_U_SampleOfInterestSizeInput.Focus();
                return false;
            }

            if (AA_U_SampleOfInterestSizeInput.Value > AA_U_SampleSizeInput.Value)
            {
                DefaultMessageBox.Error($"Number of samples with characteristics of interest cannot be larger than Sample Size.");
                AA_U_SampleOfInterestSizeInput.Focus();
                return false;
            }

            if (AA_U_SampleOfInterestSizeInput.Value < 0 ||
                AA_U_SampleOfInterestSizeInput.Value % 1 != 0)
            {
                DefaultMessageBox.Error($"{AA_U_SampleOfInterestSizeInput.Value} is not a valid number of samples with characteristics of interest.");
                AA_U_SampleOfInterestSizeInput.Focus();
                return false;
            }

            if (-1 == AA_U_IntervalTypeInput.SelectedIndex)
            {
                DefaultMessageBox.Error($"Please choose from one of the interval types.");
                AA_U_IntervalTypeInput.Focus();
                return false;
            }

            return true;
        }

        #region Event handlers

        /// <summary>
        ///  Handles <see cref="Button.Click"/> event fired by <see cref="AA_U_ConfidenceLevelCustomizeButton"/>.
        /// </summary>
        private void AA_U_ConfidenceLevelCustomizeButton_Click(object sender, EventArgs e)
        {
            if (AA_U_ConfidenceLevelInput.Visible)
            {
                AA_U_ConfidenceLevelCustomizeButton.Text = "Customize...";
            }
            else
            {
                AA_U_ConfidenceLevelCustomizeButton.Text = "Use Default";
                AA_U_ConfidenceLevelInput.Focus();
            }

            AA_U_ConfidenceLevelInput.Visible = !AA_U_ConfidenceLevelInput.Visible;
        }

        /// <summary>
        ///  Handles <see cref="TextBox.Validating"/> event fired by <see cref="AA_U_ConfidenceLevelInput"/>.
        /// </summary>
        private void AA_U_ConfidenceLevelInput_Validating(object sender, CancelEventArgs e)
        {
            e.Cancel |= AA_U_ConfidenceLevelInput.Value <= 50;
            e.Cancel |= AA_U_ConfidenceLevelInput.Value >= 100;

            if (e.Cancel) BlinkStatus("Value must be greater than 50 and less than 100");
        }

        /// <summary>
        ///  Handles <see cref="TextBox.VisibleChanged"/> event fired by <see cref="AA_U_ConfidenceLevelInput"/>.
        /// </summary>
        private void AA_U_ConfidenceLevelInput_VisibleChanged(object sender, EventArgs e)
        {
            AA_U_DefaultLabel.Visible = !AA_U_ConfidenceLevelInput.Visible;
            AA_U_DefaultCustomizeLabel.Visible = AA_U_ConfidenceLevelInput.Visible;
            AA_U_ConfidenceLevelPercentageLabel.Visible = AA_U_ConfidenceLevelInput.Visible;
        }

        /// <summary>
        ///  Handles <see cref="Button.Click"/> event fired by <see cref="AA_U_GenerateButton"/>.
        /// </summary>
        private void AA_U_GenerateButton_Click(object sender, EventArgs e)
        {
            if (!AA_U_Validate())
            {
                return;
            }

            MainStatus.Text = "Computation started";
            MainProgressBar.Style = ProgressBarStyle.Marquee;

            var universe = (UInt64)AA_U_UniverseSizeInput.Value;
            var sample = (UInt64)AA_U_SampleSizeInput.Value;
            var sampleOfInterest = (UInt64)AA_U_SampleOfInterestSizeInput.Value;
            var intervalType = AA_U_IntervalTypeInput.SelectedItem == AA_U_IntervalTypeInput.Items[0] ? IntervalType.OneSided : IntervalType.TwoSided;
            var oneSidedType = 0 == sampleOfInterest ? CDFType.GreaterOrEqualTo :
                sample == sampleOfInterest ? CDFType.LessOrEqualTo : (CDFType?)null;

            var ratioSample = sample / (double)universe;
            var ratioOfInterest = sampleOfInterest / (double)sample;
            var populationOfInterest = Math.Ceiling(ratioOfInterest * universe);

            var standardErrorTerm = Math.Sqrt(sample * ratioOfInterest * (1 - ratioOfInterest) * (1 - ratioSample));
            var standardError = standardErrorTerm * Math.Sqrt(sample / (double)(sample - 1)) / ratioSample;
            var standardErrorRatio = standardErrorTerm / Math.Sqrt(sample * (double)(sample - 1));
            var confidenceLevels = AA_U_ConfidenceLevelInput.Visible ? new[] { (double)AA_U_ConfidenceLevelInput.Value / 100 } : ConfidenceInterval.DefaultLevels;

            var result = new AttributeAppraisalUnrestrictedResult()
            {
                Name = VA_U_NameInput.Text,
                SampleSize = sample,
                UniverseSize = universe,
                SampleOfInterestSize = sampleOfInterest,
                PopulationOfInterestSize = (UInt64)populationOfInterest,
                PopulationOfInterestRatio = ratioOfInterest,
                StandardErrorMean = standardErrorRatio,
                StandardErrorTotal = standardError,
                ConfidenceLimits = new SortedDictionary<double, AttributeAppraisalConfidence>(confidenceLevels.ToDictionary(p => p, p => new AttributeAppraisalConfidence()))
            };

            var tails = (new CDFType[] { CDFType.LessOrEqualTo, CDFType.GreaterOrEqualTo })
                .Where(tail => oneSidedType?.Complement() != tail);
            var resultsBag = new ConcurrentBag<Tuple<double, CDFType, UInt64>>();

            var worker = new BackgroundWorker()
            {
                WorkerReportsProgress = true
            };

            worker.DoWork += (object lambdaSender, DoWorkEventArgs lambdaArgs) =>
            {
                var tasks = confidenceLevels.Count() * tails.Count();
                var lambdaResult = lambdaArgs.Argument as AttributeAppraisalUnrestrictedResult;

                Parallel.ForEach(confidenceLevels, p =>
                {
                    Parallel.ForEach(tails, tail =>
                    {
                        resultsBag.Add(new Tuple<double, CDFType, UInt64>(
                            p,
                            tail,
                            HypergeometricDistribution.PosteriorInterval(universe, sample, sampleOfInterest, p, tail, intervalType)));

                        (lambdaSender as BackgroundWorker).ReportProgress(100 * resultsBag.Count / tasks);
                    });

                    if (oneSidedType != null &&
                        IntervalType.TwoSided == intervalType)
                    {
                        lambdaResult.ConfidenceLimits[p].SetLimit(oneSidedType.Value.Complement(), lambdaResult.PopulationOfInterestSize, lambdaResult.UniverseSize);
                    }
                });

                var results = confidenceLevels.ToDictionary(p => p, p => new SortedDictionary<CDFType, UInt64>());


                while (resultsBag.TryTake(out Tuple<double, CDFType, UInt64> confidenceResult))
                {
                    lambdaResult.ConfidenceLimits[confidenceResult.Item1].SetLimit(confidenceResult.Item2, confidenceResult.Item3, lambdaResult.UniverseSize);
                }

                lambdaArgs.Result = lambdaResult;
            };

            worker.RunWorkerCompleted += (object lambdaSender, RunWorkerCompletedEventArgs lambdaArgs) =>
            {
                SetActiveResult(lambdaArgs.Result as AttributeAppraisalUnrestrictedResult);
                MainStatus.Text = $"Completed.";
                MainProgressBar.Value = 0;
                AttributeUnrestrictedSubPage.Controls.SetEnabled(true);
            };

            worker.ProgressChanged += (object lambdaSender, ProgressChangedEventArgs lambdaArgs) =>
            {
                MainStatus.Text = $"Computed {lambdaArgs.ProgressPercentage}%";
                MainProgressBar.Style = ProgressBarStyle.Blocks;
                MainProgressBar.Value = lambdaArgs.ProgressPercentage;
            };

            AttributeUnrestrictedSubPage.Controls.SetEnabled(false);

            worker.RunWorkerAsync(result);
        }

        /// <summary>
        ///  Handles <see cref="NumericUpDown.Validating"/> event fired by AA_U_SampleOfInterestSizeInput.
        /// </summary>
        private void AA_U_SampleOfInterestSizeInput_Validating(object sender, CancelEventArgs e)
        {
            var SampleOfInterestSizeInput = sender as NumericUpDown;
            var SampleSizeInput = AA_U_SampleSizeInput;

            if (SampleOfInterestSizeInput.Value == 0 || SampleOfInterestSizeInput.Value == SampleSizeInput.Value)
            {
                AA_U_IntervalTypeInput.Enabled = true;
                AA_U_IntervalTypeInput.SelectedItem = null;
            }
            else
            {
                AA_U_IntervalTypeInput.Enabled = false;
                AA_U_IntervalTypeInput.SelectedItem = AA_U_IntervalTypeInput.Items[1];
            }
        }

        #endregion
    }
}