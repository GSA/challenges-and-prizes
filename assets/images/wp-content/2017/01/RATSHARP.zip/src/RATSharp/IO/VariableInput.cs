﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

namespace RATSharp.IO
{
    /// <summary>
    ///  Exposes facilities specific to Variable Appraisal input.
    /// </summary>
    public interface IVariableInput
    {
        /// <summary>
        ///  Gets whether a table has been loaded to memory.
        /// </summary>
        bool Loaded { get; }

        /// <summary>
        ///  Gets a principal submatrix of the table suitable for previewing its content.
        /// </summary>
        object[][] Preview { get; }

        /// <summary>
        ///  Returns the <see cref="IOTable"/> behind this interface.
        /// </summary>
        IOTable AsTable();

        /// <summary>
        ///  Loads a specific table to memory.
        /// </summary>
        /// <param name="source">The name of table to be loaded.</param>
        int Load(string source);
    }

    public partial class AccessVariableInput
    {
        /// <summary>
        ///  Gets whether a table has been loaded to memory.
        /// </summary>
        public bool Loaded { get; private set; } = false;

        /// <summary>
        ///  Returns the <see cref="IOTable"/> behind this interface, with <see cref="AccessIOTable"/> underlying type.
        /// </summary>
        public IOTable AsTable()
        {
            return this as AccessIOTable;
        }
    }

    public partial class ExcelVariableInput
    {
        /// <summary>
        ///  Gets whether a spreadsheet has been loaded to memory.
        /// </summary>
        public bool Loaded { get; private set; } = false;

        /// <summary>
        ///  Returns the <see cref="IOTable"/> behind this interface, with <see cref="ExcelIOTable"/> underlying type.
        /// </summary>
        public IOTable AsTable()
        {
            return this as ExcelIOTable;
        }
    }

    public partial class TextVariableInput
    {
        /// <summary>
        ///  Gets whether a table has been loaded to memory.
        /// </summary>
        public bool Loaded { get; private set; } = false;

        /// <summary>
        ///  Returns the <see cref="IOTable"/> behind this interface, with <see cref="TextIOTable"/> underlying type.
        /// </summary>
        public IOTable AsTable()
        {
            return this as TextIOTable;
        }
    }
}
