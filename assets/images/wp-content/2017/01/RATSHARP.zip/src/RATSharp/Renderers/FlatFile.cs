﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

using System;
using System.Globalization;
using System.Linq;

namespace RATSharp.Renderers
{
    /// <summary>
    ///  <see cref="IRATResult"/> flat file renderer.
    /// </summary>
    public static class FlatFile
    {   /// This class is implemented using heredoc to preserve visual integrity of rendering result.
        /// For more information about heredoc, see https://en.wikipedia.org/w/index.php?title=Here_document&oldid=756198374

        /// <summary>
        ///  Defines default fixed width of generated representation, in number of characters.
        /// </summary>
        const int TextFileWidth = 80;

        /// <summary>
        ///  Defines number of characters occupied by date and time display, including critical margins.
        /// </summary>
        const int DateTimeMargin = 16 + 16;

        /// <summary>
        ///  Renders flat file according to the underlying type of <paramref name="result"/>.
        /// </summary>
        /// <param name="result">Analysis result to render.</param>
        internal static string Render(IRATResult result)
        {
            if (result is RandomNumbersSingleResult)
            {
                return RenderPage(result, content: Render(result as RandomNumbersSingleResult))
                    .Replace("#TYPE", "RANDOM NUMBER GENERATOR".CenterFixedWidth(TextFileWidth - DateTimeMargin, true));
            }

            return "";
        }

        /// <summary>
        ///  Renders a <see cref="RandomNumbersSingleResult"/> object to flat file.
        /// </summary>
        /// <param name="result">Single Stage Random Numbers Generation result.</param>
        static string Render(RandomNumbersSingleResult result)
        {
            return $@"{

$"SEED NUMBER: {result.SeedNumber}".PadRight(50)} FRAME SIZE: {$"{result.UniverseSize:#,0}".PadLeft(15)}


     FILE OF RANDOM NUMBERS: {result.File}

     TOTAL RANDOM NUMBERS GENERATED: {result.SampleSize:#,0}


{
    result.Numbers
        .Select(number => $"{number.Key}".PadLeft(1 + Math.Max(3, (int)Math.Floor(Math.Log10(result.SampleSize))), '0') + $"{number.Value}".PadLeft(10, '0'))
        .Concat("\r\n")
}

SUMMATION OF RANDOM NUMBERS = {result.Sum:#,0}";
        }

        /// <summary>
        ///  Renders a placeholder flat file representation of analysis result, and subsequently renders content onto it.
        /// </summary>
        /// <param name="result">Analysis result.</param>
        /// <param name="content">Content of the page.</param>
        static string RenderPage(
            IRATResult result,
            string content)
        {
            return $@"{"RAT#".CenterFixedWidth(TextFileWidth)}
                             Statistical Software
Date: {result.DateTime.ToString("d", CultureInfo.CreateSpecificCulture("en-us")).PadRight(10)
                                                        }#TYPE     Time: {result.DateTime.ToString("HH:mm")
                                                                        }
 {(new[] { "AUDIT/REVIEW:", result.Name }).Concat(" ").CenterFixedWidth(TextFileWidth)}
{content}
";
        }
    }
}
