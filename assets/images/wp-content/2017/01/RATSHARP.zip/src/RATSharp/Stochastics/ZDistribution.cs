﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

using System;

namespace RATSharp.Stochastics
{
    /// <summary>
    ///  Standard normal, or equivalently Z, or N(0, 1), probability distribution facilities.
    /// </summary>
    public class ZDistribution
    {
        public class InverseCDFLookup
        {
            /// <summary>
            ///  Default constructor for <see cref="InverseCDFLookup"/>.
            /// </summary>
            internal InverseCDFLookup() { }

            /// <summary>
            ///  Indexing interface for two-tailed inverse cumulative distribution function table lookup.
            /// </summary>
            /// <param name="p">Standardized quantile of the desired inverse cumulative distribution value</param>
            public decimal this[double p] => InverseCDFTable[(int)Math.Floor(p * 100)];
        }

        public class InverseCDFOneTailedLookup
        {
            /// <summary>
            ///  Default constructor for <see cref="InverseCDFOneTailedLookup"/>.
            /// </summary>
            internal InverseCDFOneTailedLookup() { }

            /// <summary>
            ///  Indexing interface for one-tailed inverse cumulative distribution function table lookup.
            /// </summary>
            /// <param name="p">Standardized quantile of the desired inverse cumulative distribution value</param>
            public decimal this[double p] => InverseCDFTable[(int)Math.Floor(p * 200 - 100)];
        }

        /// <summary>
        ///  Static indexing interface for two-tailed inverse cumulative distribution function table lookup.
        /// </summary>
        public static InverseCDFLookup InverseCDF => new InverseCDFLookup();

        /// <summary>
        ///  Static indexing interface for one-tailed inverse cumulative distribution function table lookup.
        /// </summary>
        public static InverseCDFOneTailedLookup InverseCDFOneTailed => new InverseCDFOneTailedLookup();

        /// <summary>
        ///  Lookup table for inverse cumulative distribution function of Z-distributed random variable.
        /// </summary>
        static decimal[] InverseCDFTable = new[]{
            // p=0.5, 0.505, ...
            0.000000000000m, 0.012533469508m, 0.025068908259m, 0.037608287661m, 0.050153583465m, 0.062706777943m, 0.075269862100m, 0.087844837896m, 0.100433720511m, 0.113038540645m,
            0.125661346855m, 0.138304207961m, 0.150969215497m, 0.163658486233m, 0.176374164781m, 0.189118426273m, 0.201893479142m, 0.214701568002m, 0.227544976641m, 0.240426031142m,
            0.253347103136m, 0.266310613204m, 0.279319034447m, 0.292374896227m, 0.305480788099m, 0.318639363964m, 0.331853346437m, 0.345125531470m, 0.358458793251m, 0.371856089385m,
            0.385320466408m, 0.398855065642m, 0.412463129441m, 0.426148007841m, 0.439913165673m, 0.453762190170m, 0.467698799115m, 0.481726849585m, 0.495850347347m, 0.510073456969m,
            0.524400512708m, 0.538836030278m, 0.553384719556m, 0.568051498339m, 0.582841507271m, 0.597760126042m, 0.612812991017m, 0.628006014438m, 0.643345405393m, 0.658837692736m,
            0.674489750196m, 0.690308823933m, 0.706302562840m, 0.722479051928m, 0.738846849185m, 0.755415026360m, 0.772193214189m, 0.789191652658m, 0.806421247018m, 0.823893630339m,
            0.841621233573m, 0.859617364242m, 0.877896295051m, 0.896473364002m, 0.915365087843m, 0.934589291073m, 0.954165253146m, 0.974113877059m, 0.994457883210m, 1.015222033217m,
            1.036433389494m, 1.058121617685m, 1.080319340815m, 1.103062556200m, 1.126391129039m, 1.150349380376m, 1.174986792066m, 1.200358858031m, 1.226528120037m, 1.253565438470m,
            1.281551565545m, 1.310579112168m, 1.340755033690m, 1.372203808999m, 1.405071560310m, 1.439531470938m, 1.475791028179m, 1.514101887619m, 1.554773594597m, 1.598193139923m,
            1.644853626951m, 1.695397710272m, 1.750686071252m, 1.811910672953m, 1.880793608151m, 1.959963984540m, 2.053748910632m, 2.170090377585m, 2.326347874041m, 2.575829303549m
        };
    }
}
