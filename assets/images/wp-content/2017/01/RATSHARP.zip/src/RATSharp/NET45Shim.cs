﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace RATSharp
{
    namespace NET45
    {
        class Path
        {
            public static string Combine(params string[] paths)
            {
                if (0 == paths.Length) return null;
                var path = paths[0];
                for (var i = 1; i < paths.Length; ++i)
                {
                    path = System.IO.Path.Combine(path, paths[i]);
                }

                return path;
            }

            public static string Combine(string[] paths, object @object)
            {
                if (0 == paths.Length) return null;
                var path = paths[0];
                for (var i = 1; i < paths.Length; ++i)
                {
                    path = System.IO.Path.Combine(path, paths[i]);
                }

                return path;
            }
        }
    }

    class ConcurrentBag<T>
    {
        List<T> Bag = new List<T>();
        static object BagLock = new object();

        public bool TryTake(out T item)
        {
            lock (BagLock)
            {
                item = Bag.ElementAtOrDefault(0);
                if (0 == Bag.Count)
                {
                    return false;
                }

                Bag.RemoveAt(0);
                return true;
            }
        }

        public void Add(T item)
        {
            lock (BagLock)
            {
                Bag.Add(item);
            }
        }

        public int Count
        {
            get
            {
                lock (BagLock) { return Bag.Count; }
            }
        }
    }

    class ConcurrentDictionary<TKey, TValue> : IDictionary<TKey, TValue>
    {
        Dictionary<TKey, TValue> Dictionary = new Dictionary<TKey, TValue>();
        static object DictionaryLock = new object();

        public TValue this[TKey key] { get => ((IDictionary<TKey, TValue>)Dictionary)[key]; set => ((IDictionary<TKey, TValue>)Dictionary)[key] = value; }

        public int Count => ((IDictionary<TKey, TValue>)Dictionary).Count;

        public bool IsReadOnly => ((IDictionary<TKey, TValue>)Dictionary).IsReadOnly;

        public ICollection<TKey> Keys => ((IDictionary<TKey, TValue>)Dictionary).Keys;

        public ICollection<TValue> Values => ((IDictionary<TKey, TValue>)Dictionary).Values;

        public void Add(KeyValuePair<TKey, TValue> item)
        {
            lock (DictionaryLock)
                ((IDictionary<TKey, TValue>)Dictionary).Add(item);
        }

        public void Add(TKey key, TValue value)
        {
            lock (DictionaryLock)
                ((IDictionary<TKey, TValue>)Dictionary).Add(key, value);
        }

        public void Clear()
        {
            lock (DictionaryLock)
            ((IDictionary<TKey, TValue>)Dictionary).Clear();
        }

        public bool Contains(KeyValuePair<TKey, TValue> item)
        {
            lock (DictionaryLock)
                return ((IDictionary<TKey, TValue>)Dictionary).Contains(item);
        }

        public bool ContainsKey(TKey key)
        {
            lock (DictionaryLock)
                return ((IDictionary<TKey, TValue>)Dictionary).ContainsKey(key);
        }

        public void CopyTo(KeyValuePair<TKey, TValue>[] array, int arrayIndex)
        {
            lock (DictionaryLock)
                ((IDictionary<TKey, TValue>)Dictionary).CopyTo(array, arrayIndex);
        }

        public IEnumerator<KeyValuePair<TKey, TValue>> GetEnumerator()
        {
            lock (DictionaryLock)
                return ((IDictionary<TKey, TValue>)Dictionary).GetEnumerator();
        }

        public bool Remove(KeyValuePair<TKey, TValue> item)
        {
            lock (DictionaryLock)
                return ((IDictionary<TKey, TValue>)Dictionary).Remove(item);
        }

        public bool Remove(TKey key)
        {
            lock (DictionaryLock)
                return ((IDictionary<TKey, TValue>)Dictionary).Remove(key);
        }

        public bool TryGetValue(TKey key, out TValue value)
        {
            lock (DictionaryLock)
                return ((IDictionary<TKey, TValue>)Dictionary).TryGetValue(key, out value);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            lock (DictionaryLock)
                return ((IDictionary<TKey, TValue>)Dictionary).GetEnumerator();
        }
    }

    class Tuple<T1, T2, T3>
    {
        public T1 Item1;
        public T2 Item2;
        public T3 Item3;

        public Tuple(T1 item1, T2 item2, T3 item3)
        {
            Item1 = item1;
            Item2 = item2;
            Item3 = item3;
        }
    }

    class Parallel
    {
        public static void ForEach<T>(IEnumerable<T> items, Action<T> action)
        {
            foreach (var item in items) action(item);
        }
    }

    public enum ZipArchiveMode
    {
        /// <summary>
        ///  Only creating new archive entries is permitted.
        /// </summary>
        Create,
        /// <summary>
        ///  Only reading archive entries is permitted.
        /// </summary>
        Read,
        /// <summary>
        ///  Both read and write operations are permitted for archive entries.
        /// </summary>
        Update
    }

    class ZipArchive : IDisposable
    {
        static Type Type = typeof(System.IO.Packaging.Package).Assembly.GetType("MS.Internal.IO.Zip.ZipArchive");

        private object external;
        private ZipArchive() { }
        public enum CompressionMethodEnum { Stored, Deflated };
        public enum DeflateOptionEnum { Normal, Maximum, Fast, SuperFast };

        private MethodInfo GetExternalInstanceMethod(string name, BindingFlags bindingAttr = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
        {
            return external.GetType().GetMethod(name, bindingAttr);
        }

        public static ZipArchive New(System.IO.Stream stream, ZipArchiveMode mode = ZipArchiveMode.Read)
        {
            switch (mode)
            {
                case ZipArchiveMode.Create: return OpenOnStream(stream, System.IO.FileMode.CreateNew, System.IO.FileAccess.Write, streaming: true);
                case ZipArchiveMode.Read:   return OpenOnStream(stream, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                case ZipArchiveMode.Update: return OpenOnStream(stream, System.IO.FileMode.OpenOrCreate, streaming: true);
                default:                    throw new InvalidOperationException();  // unreachable
            }
        }

        public static ZipArchive OpenOnFile(string path, System.IO.FileMode mode = System.IO.FileMode.Open, System.IO.FileAccess access = System.IO.FileAccess.Read, System.IO.FileShare share = System.IO.FileShare.Read, bool streaming = false)
        {
            var meth = Type.GetMethod("OpenOnFile", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
            return new ZipArchive { external = meth.Invoke(null, new object[] { path, mode, access, share, streaming }) };
        }

        public static ZipArchive OpenOnStream(System.IO.Stream stream, System.IO.FileMode mode = System.IO.FileMode.OpenOrCreate, System.IO.FileAccess access = System.IO.FileAccess.ReadWrite, bool streaming = false)
        {
            var meth = Type.GetMethod("OpenOnStream", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
            return new ZipArchive { external = meth.Invoke(null, new object[] { stream, mode, access, streaming }) };
        }

        public ZipFileInfo AddFile(string path, CompressionMethodEnum compmeth = CompressionMethodEnum.Deflated, DeflateOptionEnum option = DeflateOptionEnum.Normal)
        {
            var meth = Type.GetMethod("AddFile", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            var comp = Type.Assembly.GetType("MS.Internal.IO.Zip.CompressionMethodEnum").GetField(compmeth.ToString()).GetValue(null);
            var opti = Type.Assembly.GetType("MS.Internal.IO.Zip.DeflateOptionEnum").GetField(option.ToString()).GetValue(null);
            return new ZipFileInfo { external = meth.Invoke(external, new object[] { path, comp, opti }) };
        }

        public void DeleteFile(string name)
        {
            GetExternalInstanceMethod("DeleteFile").Invoke(external, new object[] { name });
        }

        public void Dispose()
        {
            ((IDisposable) external).Dispose();
        }

        public ZipFileInfo GetFile(string name)
        {
            return new ZipFileInfo { external = GetExternalInstanceMethod("GetFile").Invoke(external, new object[] { name }) };
        }

        public IEnumerable<ZipFileInfo> Files
        {
            get
            {
                var coll = GetExternalInstanceMethod("GetFiles").Invoke(external, null) as System.Collections.IEnumerable; //ZipFileInfoCollection
                foreach (var p in coll) yield return new ZipFileInfo { external = p };
            }
        }

        public IEnumerable<string> FileNames => Files.Select(p => p.Name).OrderBy(p => p);

        public struct ZipFileInfo
        {
            internal object external;

            private object GetProperty(string name)
            {
                return external.GetType().GetProperty(name, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic).GetValue(external, null);
            }

            public override string ToString()
            {
                return Name;// base.ToString();
            }

            public string Name => (string) GetProperty("Name");
            public DateTime LastModFileDateTime => (DateTime) GetProperty("LastModFileDateTime");
            public bool FolderFlag => (bool) GetProperty("FolderFlag");
            public bool VolumeLabelFlag => (bool) GetProperty("VolumeLabelFlag");
            public object CompressionMethod => GetProperty("CompressionMethod");
            public object DeflateOption => GetProperty("DeflateOption");

            public System.IO.Stream GetStream(System.IO.FileMode mode = System.IO.FileMode.Open, System.IO.FileAccess access = System.IO.FileAccess.Read)
            {
                var meth = external.GetType().GetMethod("GetStream", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                return (System.IO.Stream) meth.Invoke(external, new object[] { mode, access });
            }
        }

        public void ExtractToDirectory(string directoryName)
        {
            foreach (var file in Files.OrderBy(f => f.Name))
            {
                var name = file.Name.Split('\\', '/').Reverse().FirstOrDefault();
                var path = NET45.Path.Combine(file.Name.Split('\\', '/').Reverse().Skip(1).Reverse().ToArray());
                var dir = System.IO.Directory.CreateDirectory(System.IO.Path.Combine(directoryName, path ?? string.Empty));
                if (!name.IsNullOrEmpty())
                {
                    using (var stream = file.GetStream())
                    using (var reader = new System.IO.BinaryReader(stream))
                    using (var targetStream = System.IO.File.Create(System.IO.Path.Combine(dir.FullName, name)))
                    using (var writer = new System.IO.BinaryWriter(targetStream))
                    {
                        for (int? length = null; length > 0 || null == length;)
                        {
                            writer.Write(reader.ReadBytes(1024 * 1024).Length(out length));
                        }
                    }
                }
            }
        }
    }

    public static class ZipFile
    {
        public static void CreateFromDirectory(string sourceDirectoryName, string destinationArchiveFileName)
        {
            using (var archive = ZipArchive.OpenOnFile(destinationArchiveFileName, System.IO.FileMode.CreateNew, System.IO.FileAccess.Write, System.IO.FileShare.None, true))
            {
                foreach (var file in System.IO.Directory.GetFiles(sourceDirectoryName, "*", System.IO.SearchOption.AllDirectories))
                {
                    var path = file.Replace(sourceDirectoryName, "").RegexReplace($@"^\\?", "").Replace('\\', '/');
                    var archiveFile = archive.AddFile(path);
                    using (var stream = System.IO.File.Open(file, System.IO.FileMode.Open))
                    using (var reader = new System.IO.BinaryReader(stream))
                    using (var targetStream = archiveFile.GetStream(access: System.IO.FileAccess.Write))
                    using (var writer = new System.IO.BinaryWriter(targetStream))
                    {
                        for (int? length = null; length > 0 || null == length;)
                        {
                            writer.Write(reader.ReadBytes(1024 * 1024).Length(out length));
                        }
                    }
                }
            }
        }
    }

    public static partial class Extensions
    {
        public static IEnumerable<TZip> Zip<T1, T2, TZip>(this IEnumerable<T1> items1, IEnumerable<T2> items2, Func<T1, T2, TZip> func)
        {
            for (var i = 0; i < Math.Min(items1.Count(), items2.Count()); ++i)
            {
                yield return func(items1.ElementAt(i), items2.ElementAt(i));
            }
        }

        public static IEnumerable<T> AsParallel<T>(this IEnumerable<T> items)
        {
            return items;
        }

        public static IEnumerable<T> AsSequential<T>(this IEnumerable<T> items)
        {
            return items;
        }

        public static bool IsNullOrEmpty(this string input)
        {
            return null == input || 0 == input.Length;
        }
    }
}
