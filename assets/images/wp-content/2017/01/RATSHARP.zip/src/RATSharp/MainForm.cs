﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

namespace RATSharp
{
    /// <summary>
    ///  Stores states required by status bar blinking action.
    /// </summary>
    struct BlinkArgs
    {
        public Color[] Colors;
        public int Count;
        public Color Color => Colors[0];
        public BlinkArgs GetNext() { return new BlinkArgs() { Colors = Colors.Reverse().ToArray(), Count = Count - 1 }; }
    };

    /// <summary>
    ///  Primary form for the program.
    /// </summary>
    public partial class MainForm : Form
    {
        /// <summary>
        ///  Currently active result of the session.
        /// </summary>
        private IRATResult ActiveResult;

        internal MainForm()
        {
            InitializeComponent();
        }

        #region Event Handlers

        /// <summary>
        ///  Handles <see cref="Form.Load"/> event fired by <see cref="MainForm"/>.
        /// </summary>
        private void MainForm_Load(object sender, EventArgs e)
        {
            // start on about subpage
            Pages.SelectedTab = HelpPage;
            HelpPages.SelectedTab = AboutSubPage;

            // subpage load
            PreviewMode_Load();
            R_S_Load();
            R_SS_Load();
            AA_U_Load();
            VA_U_Load();
            VA_S_Load();

            // defaults to save only
            SaveModeInput.SelectedIndex = 0;

            KeyboardNavigationMenu.Items.AddRange(Menufy(Modes).ToArray());

            /*
            // TEST
            R_S_SeedInput.Text = "48863.78";
            R_S_SequentialOrderQuantityInput.Value = 10;
            R_S_SpareQuantityInput.Value = 4;
            R_S_SamplingFrameHighInput.Value = 1000;
            R_S_SamplingFrameLowInput.Value = 1;

            // TEST
            AA_U_UniverseSizeInput.Value = 10000;
            AA_U_SampleSizeInput.Value = 400;
            AA_U_SampleOfInterestSizeInput.Value = 82;
            */

            AboutLabel.Text += $@"

.NET Framework Version {Environment.Version.ToString()}";
        }

        /// <summary>
        ///  Handles <see cref="Button.Click"/> event fired by <see cref="KeyboardNavigationButton"/>.
        /// </summary>
        private void KeyboardNavigationButton_Click(object sender, EventArgs e)
        {
            KeyboardNavigationMenu.Show(Left + Width, Top);
            KeyboardNavigationMenu.Items[0].Select();
        }

        #endregion

        #region Feature implementation

        /// <summary>
        ///  Recursively converts tab pages to keyboard navigation menu.
        /// </summary>
        IEnumerable<ToolStripItem> Menufy(
            TabControl tab,
            Dictionary<TabControl, TabPage> parents = null)
        {
            parents = parents ?? new Dictionary<TabControl, TabPage>();
            foreach (TabPage page in tab?.Controls.OfType<TabPage>() ?? new TabPage[] { })
            {
                var pageParents = new Dictionary<TabControl, TabPage>(parents)
                {
                    [tab] = page
                };

                var menuItem = new ToolStripMenuItem(page.Text, null, (object s, EventArgs args) => 
                {
                    foreach (var parent in pageParents)
                    {
                        parent.Key.SelectedTab = parent.Value;
                    }
                });

                menuItem.DropDownItems.AddRange(Menufy(page.Controls.OfType<TabControl>().SingleOrDefault(), pageParents).ToArray());
                yield return menuItem as ToolStripItem;
            }
        }

        /// <summary>
        ///  Sets active result of the session, enables the supported save buttons accordingly, and triggers
        ///  rendering of the result to preview element.
        /// </summary>
        /// <param name="result"></param>
        private void SetActiveResult(IRATResult result)
        {
            ActiveResult = result;

            PreviewControlPanel.Controls.SetEnabled(false);
            SaveHTMLButton.Enabled = true;
            PrintPreviewButton.Enabled = true;
            SaveModeInput.Enabled = true;

            if (result is VariableAppraisalStratifiedResult)
            {
                SaveTextButton.Enabled = true;
            }
            else if (result is VariableAppraisalUnrestrictedResult)
            {
                SaveTextButton.Enabled = true;
            }
            else if (result is AttributeAppraisalUnrestrictedResult)
            {
                SaveTextButton.Enabled = true;
            }
            else if (result is RandomNumbersSingleResult ||
                     result is RandomNumbersStratifiedResult)
            {   // all output supported
                PreviewControlPanel.Controls.SetEnabled(true);
            }

            PreviewBrowser_Render(result);
        }

        /// <summary>
        ///  Triggers blinking of status bar to catch user attention.
        /// </summary>
        /// <param name="message"></param>
        private void BlinkStatus(string message = "")
        {
            MainStatus.Text = message;

            var worker = new BackgroundWorker();
            worker.DoWork += (object sender, DoWorkEventArgs e) =>
            {
                Thread.Sleep(millisecondsTimeout: 100);
                e.Result = e.Argument ?? new BlinkArgs() { Colors = new[] { Color.MistyRose, SystemColors.Control }, Count = 11 };
            };
            worker.RunWorkerCompleted += (object sender, RunWorkerCompletedEventArgs e) =>
            {
                MainStatusStrip.BackColor = ((BlinkArgs)e.Result).Color;
                if (((BlinkArgs)e.Result).Count > 0) worker.RunWorkerAsync(((BlinkArgs)e.Result).GetNext()); else MainStatus.Text = "";
            };
 
            worker.RunWorkerAsync();
        }

        #endregion
    }

    /// <summary>
    ///  Default message box facility for the program.
    /// </summary>
    internal static class DefaultMessageBox
    {
        /// <summary>
        ///  Shows standardized error message box for the program.
        /// </summary>
        public static bool Error(
            string message,
            string caption = "RATSharp Error")
        {
            MessageBox.Show(message, caption, MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }

        /// <summary>
        ///  Shows standardized warning message box for the program.
        /// </summary>
        public static bool Warning(
            string message,
            string caption = "RATSharp Warning")
        {
            MessageBox.Show(message, caption, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }
    }

    /// <summary>
    ///  Contains extension methods used throughout the program.
    /// </summary>
    public static partial class Extensions
    {
        /// <summary>
        ///  Performs regular expression substring replacement to this string.
        /// </summary>
        /// <param name="pattern">Desired regular expression pattern to match tokens that will be replaced.</param>
        /// <param name="replacement">String that will replace the desired tokens.</param>
        public static string RegexReplace(
            this string input,
            string pattern,
            string replacement)
        {
            return Regex.Replace(input, pattern, replacement);
        }

        /// <summary>
        ///  Concatenate this collection of strings with an optional joining string.
        /// </summary>
        /// <param name="joiner">Optional joining string to put between concatenated strings.</param>
        public static string Concat(
            this IEnumerable<string> strings,
            string joiner = "")
        {
            return strings.Any() ? strings.Aggregate((l, r) => $"{l}{joiner}{r}") : string.Empty;
        }

        /// <summary>
        ///  Concatenate this collection of strings with a joining character.
        /// </summary>
        /// <param name="strings"></param>
        /// <param name="joiner">The joining character to put between concatenated strings.</param>
        public static string Concat(
            this IEnumerable<string> strings,
            char joiner)
        {
            return strings.Any() ? strings.Aggregate((l, r) => $"{l}{joiner}{r}") : string.Empty;
        }
    }
}
