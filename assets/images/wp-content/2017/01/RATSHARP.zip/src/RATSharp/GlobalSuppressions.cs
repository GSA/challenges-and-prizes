﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

// This file is used by Code Analysis to maintain SuppressMessage 
// attributes that are applied to this project.
// Project-level suppressions either have no target or are given 
// a specific target and scoped to a namespace, type, member, etc.

[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Style", "IDE0027:Simplify collection initialization", Justification = "Simplified initialization does not support member field access as rvalue", Scope = "member", Target = "~M:RATSharp.IO.ExcelVariableInput.Load(System.String)~System.Int32")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Style", "IDE0027:Simplify collection initialization", Justification = "Simplified initialization does not support member field access as rvalue", Scope = "member", Target = "~M:RATSharp.IO.ExcelIOTable.Update")]