﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

namespace RATSharp.Stochastics
{
    /// <summary>
    ///  Contains facilities for confidence interval computation.
    /// </summary>
    public static class ConfidenceInterval
    {
        /// <summary>
        ///  Defines default confidence levels to use in the absence of user input.
        /// </summary>
        public static readonly double[] DefaultLevels = { 0.8, 0.9, 0.95 };
    }
}
