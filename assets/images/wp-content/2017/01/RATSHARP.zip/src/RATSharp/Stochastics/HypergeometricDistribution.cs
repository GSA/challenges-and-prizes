﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

using RATSharp.Stochastics;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;

namespace RATSharp.Stochastics
{
    /// <summary>
    ///  Specifies constants defining which cumulation type a cumulative distribution function is.
    /// </summary>
    public enum CDFType
    {
        LessOrEqualTo = -1,
        GreaterOrEqualTo = 1
    }

    /// <summary>
    ///  Specifies constants defining which type a confidence interval is, based on the number of bounded sides.
    /// </summary>
    public enum IntervalType
    {
        OneSided = 0,
        TwoSided = 1
    }

    /// <summary>
    ///  Hypergeometric probability distribution facilities.
    /// </summary>
    internal class HypergeometricDistribution
    {
        /// <summary>
        ///  Distribution parameter N (population size) for memoization table.
        /// </summary>
        static UInt64 N = UInt64.MaxValue;

        /// <summary>
        ///  Distribution parameter K (population of interest size) for memoization table.
        /// </summary>
        static UInt64 K = UInt64.MaxValue;

        /// <summary>
        ///  Memoization table for dynamic programming version of Hypergeometric probability mass function computation.
        /// </summary>
        static ConcurrentDictionary<UInt64, double> partialPMFMemo;

        /// <summary>
        ///  Memoization table initialization facility for dynamic programming version of Hypergeometric probability mass function computation.
        /// </summary>
        /// <param name="N">Distribution parameter N (population size).</param>
        /// <param name="K">Distribution parameter K (population of interest size).</param>
        static void InitializeMemoTable(
            UInt64 N,
            UInt64 K)
        {
            if (HypergeometricDistribution.N != N ||
                HypergeometricDistribution.K != K)
            {
                partialPMFMemo = new ConcurrentDictionary<ulong, double>();
                HypergeometricDistribution.N = N;
                HypergeometricDistribution.K = K;
            }
        }

        /// <summary>
        ///  Hypergeometric probability mass function computation.
        /// </summary>
        /// <param name="N">Distribution parameter N (population size).</param>
        /// <param name="K">Distribution parameter K (population of interest size).</param>
        /// <param name="n">Distribution parameter n (sample size).</param>
        /// <param name="k">Distribution independent variable k (sample size of interest).</param>
        public static double PMF(
            UInt64 N,
            UInt64 K,
            UInt64 n,
            UInt64 k)
        {
            // use symmetry to avoid over-/under-flow
            if (n > K)
            {
                return PMF(N, n, K, k);
            }

            SafeDouble p = 1.0;
            UInt64 i = 1ul;

            for (; i <= n; ++i)
            {
                if (i <= k)
                {
                    p *= (K + 1 - i) / (double)i;
                }

                if (i <= n - k)
                {
                    p *= (N - K + 1 - i) / (double)i;
                }

                if (i <= n)
                {
                    p /= (N + 1 - i) / (double)i;
                }
            }

            return p;
        }

        /// <summary>
        ///  Dynamic programming version of Hypergeometric probability mass function computation.
        /// </summary>
        /// <param name="N">Distribution parameter N (population size).</param>
        /// <param name="K">Distribution parameter K (population of interest size).</param>
        /// <param name="n">Distribution parameter n (sample size).</param>
        /// <param name="k">Distribution independent variable k (sample size of interest).</param>
        [Obsolete("Dynamic programming as currently written reduces effectiveness of mathematical symmetry of Hypergeometric PMF, and is therefore much less efficient.")]
        public static double PMF_DP(
            UInt64 N,
            UInt64 K,
            UInt64 n,
            UInt64 k)
        {
            InitializeMemoTable(N, K);
            double p = 1.0;
            UInt64 i = 0ul;

            if (partialPMFMemo.Any() && k > 0)
            {
                i = Math.Min(Math.Min(k, n - k), (UInt64)partialPMFMemo.Count);
                p = partialPMFMemo[i];
            }

            for (++i; i <= n; ++i)
            {
                if ((UInt64)partialPMFMemo.Count < i - 1 &&
                    i - 1 <= Math.Min(k, n - k))
                {
                    partialPMFMemo[i - 1] = p;
                }

                if (i <= k)
                {
                    p *= (K + 1 - i) / (double)i;
                }

                if (i <= n - k)
                {
                    p *= (N - K + 1 - i) / (double)i;
                }

                if (i <= n)
                {
                    p /= (N + 1 - i) / (double)i;
                }
            }

            return p;
        }

        /// <summary>
        ///  Hypergeometric cumulative distribution function computation.
        /// </summary>
        /// <param name="N">Distribution parameter N (population size).</param>
        /// <param name="K">Distribution parameter K (population of interest size).</param>
        /// <param name="n">Distribution parameter n (sample size).</param>
        /// <param name="k">Distribution independent variable k (sample size of interest).</param>
        /// <param name="cdfType">Cumulation type of cumulative distribution function.</param>
        public static double CDF(
            UInt64 N,
            UInt64 K,
            UInt64 n,
            UInt64 k,
            CDFType cdfType)
        {
            var kMin = n + K > N ? n + K - N : 0ul;
            var kMax = Math.Min(n, K);

            if (k < kMin)
            {
                return 0;
            }

            if (k > kMax)
            {
                return 1;
            }

            var rangeLower = k - kMin;
            var rangeUpper = kMax - k;
            double cp = 0.0;

            if (rangeLower > rangeUpper && CDFType.LessOrEqualTo == cdfType)
            {
                return 1 - CDF(N, K, n, k + 1, CDFType.GreaterOrEqualTo);
            }
            else if (rangeLower < rangeUpper && CDFType.GreaterOrEqualTo == cdfType)
            {
                return 1 - CDF(N, K, n, k - 1, CDFType.LessOrEqualTo);
            }

            switch (cdfType)
            {
                case CDFType.LessOrEqualTo:
                    for (var i = k; i >= kMin && i != UInt64.MaxValue; --i)
                    {
                        cp += PMF(N, K, n, i);
                    }
                    break;
                case CDFType.GreaterOrEqualTo:
                    for (var i = kMax; i >= k; --i)
                    {
                        cp += PMF(N, K, n, i);
                    }
                    break;
            }

            return cp;
        }

        /// <summary>
        ///  Returns the Z-score of a standardized quantile.
        /// </summary>
        /// <param name="p">Standardized quantile of interest (between 0 and 1).</param>
        /// <param name="cdfType">Cumulation type of cumulative distribution function.</param>
        static double ZScore(
            double p,
            CDFType cdfType)
        {
            double z = (double)ZDistribution.InverseCDFOneTailed[p];

            if (CDFType.LessOrEqualTo == cdfType)
            {
                z = -z;
            }

            return z;
        }

        /// <summary>
        ///  Returns posterior quantile of hypergeometrically distributed variable using Agresti-Coull method.
        /// </summary>
        /// <param name="N">Distribution parameter N (population size).</param>
        /// <param name="K">Distribution parameter K (population of interest size).</param>
        /// <param name="k">Distribution independent variable k (sample size of interest).</param>
        /// <param name="p">Standardized quantile of interest.</param>
        /// <param name="cdfType">Cumulation type of cumulative distribution function.</param>
        public static UInt64 ApproximatePosteriorQuantile(
            UInt64 N,
            UInt64 K,
            UInt64 k,
            double p,
            CDFType cdfType)
        {
            return ApproximatePosteriorQuantile(N, K, k, ZScore(p, cdfType));
        }

        /// <summary>
        ///  Returns posterior quantile of hypergeometrically distributed variable using Agresti-Coull method.
        /// </summary>
        /// <param name="N">Distribution parameter N (population size).</param>
        /// <param name="K">Distribution parameter K (population of interest size).</param>
        /// <param name="k">Distribution independent variable k (sample size of interest).</param>
        /// <param name="z">Z-score of standardized quantile of interest.</param>
        public static UInt64 ApproximatePosteriorQuantile(
            UInt64 N,
            UInt64 K,
            UInt64 k,
            double z)
        {
            // Wald
            // double ratio = k / (double)K;
            // return (UInt64)(N * (ratio + z * Math.Sqrt((ratio * (1 - ratio)) / K)));

            // Agresti-Coull
            double zsq = Math.Pow(z, 2);
            double trial = K + zsq;
            double ratio = (k + zsq / 2) / trial;
            return (UInt64)(N * (ratio + z * Math.Sqrt((ratio * (1 - ratio)) / trial)));
        }

        /// <summary>
        ///  Returns posterior confidence interval for a hypergeometrically distributed variable.
        /// </summary>
        /// <param name="N">Distribution parameter N (population size).</param>
        /// <param name="K">Distribution parameter K (population of interest size).</param>
        /// <param name="k">Distribution independent variable k (sample size of interest).</param>
        /// <param name="p">Standardized quantile of interest.</param>
        /// <param name="cdfType">Cumulation type of cumulative distribution function.</param>
        /// <param name="intervalType">Type of confidence interval to compute.</param>
        public static UInt64 PosteriorInterval(
            UInt64 N,
            UInt64 K,
            UInt64 k,
            double p,
            CDFType cdfType,
            IntervalType intervalType = IntervalType.TwoSided)
        {
            // coarse guess
            var pTail = IntervalType.OneSided == intervalType ? p : 1 - (1 - p) / 2;
            var guessZ = ZScore(pTail, cdfType);
            var guess = ApproximatePosteriorQuantile(N, K, k, guessZ);
            var guessP = CDF(N, K, guess, k, cdfType.Complement());
            var compareCondition = guessP.CompareTo(1 - pTail);
            var increment = ((int)cdfType == compareCondition) ? 0.05 : -0.05;
            var solver = new BinarySolver()
            {
                Goal = 1 - pTail,
                Tolerance = 1
            };

            while (!solver.AddBound(guess, guessP))
            {
                guessZ += increment;
                guess = ApproximatePosteriorQuantile(N, K, k, guessZ);
                guessP = CDF(N, K, guess, k, cdfType.Complement());
                if (double.IsNaN(guessP))
                {
                    throw new ArithmeticException();
                }
            }

            try
            {
                while (!solver.Solved)
                {
                    guess = (UInt64)solver.GetNext();
                    guessP = CDF(N, K, guess, k, cdfType.Complement());
                    solver.AddBound(guess, guessP);
                }

                return (UInt64)solver.Bounds.Values.Max().X;
            }
            catch (ArithmeticException)
            {
                DefaultMessageBox.Warning("Sample size is too large, shown bounds are approximate.");

                return (UInt64)solver.Bounds.Values.Max().X;
            }
        }


        /// <summary>
        ///  Linear search version of posterior confidence interval computation for a hypergeometrically distributed variable.
        /// </summary>
        /// <param name="N">Distribution parameter N (population size).</param>
        /// <param name="K">Distribution parameter K (population of interest size).</param>
        /// <param name="k">Distribution independent variable k (sample size of interest).</param>
        /// <param name="p">Standardized quantile of interest.</param>
        /// <param name="cdfType">Cumulation type of cumulative distribution function.</param>
        /// <param name="intervalType">Type of confidence interval to compute.</param>
        [Obsolete("Linear search is slow and not recommended.", true)]
        public static UInt64 PosteriorInterval_Linear(
            UInt64 N,
            UInt64 K,
            UInt64 k,
            double p,
            CDFType cdfType,
            IntervalType intervalType = IntervalType.TwoSided)
        {
            var pTail = IntervalType.OneSided == intervalType ? p : 1 - (1 - p) / 2;
            var guess = ApproximatePosteriorQuantile(N, K, k, pTail, cdfType);
            var guessP = CDF(N, K, guess, k, cdfType.Complement());

            Func<bool> loopCheck = () => false;
            Action loopIncrement = () => {};

            if (CDFType.LessOrEqualTo == cdfType && guessP < 1 - pTail)
            {   // contract
                loopCheck = () => guessP < 1 - pTail;
                loopIncrement = () => { ++guess; };
            }
            else if (CDFType.LessOrEqualTo == cdfType && guessP > 1 - pTail)
            {   // expand
                loopCheck = () => guessP > 1 - pTail;
                loopIncrement = () => { --guess; };
                // TODO: don't take last value
            }
            else if (CDFType.GreaterOrEqualTo == cdfType && guessP < 1 - pTail)
            {   // contract
                loopCheck = () => guessP < 1 - pTail;
                loopIncrement = () => { --guess; };
            }
            else if (CDFType.GreaterOrEqualTo == cdfType && guessP > 1 - pTail)
            {   // expand
                loopCheck = () => guessP > 1 - pTail;
                loopIncrement = () => { ++guess; };
                // TODO: don't take last value
            }

            for (; loopCheck(); )
            {
                loopIncrement();
                guessP = CDF(N, K, guess, k, cdfType.Complement());
            }

            return guess;
        }
    }

    /// <summary>
    ///  Binary search solver suitable for monotonic functions.
    /// </summary>
    public class BinarySolver
    {
        /// <summary>
        ///  A two-dimensional point in the problem space.
        /// </summary>
        public class Point : IComparable
        {
            /// <summary>
            ///  Independent variable value of the point.
            /// </summary>
            public double X;

            /// <summary>
            ///  Dependent variable value of the point.
            /// </summary>
            public double Y;

            /// <summary>
            ///  Compares only the dependent variable value to another <see cref="Point"/>.
            /// </summary>
            public int CompareTo(object obj)
            {
                return obj is Point ? Y.CompareTo((obj as Point).Y) : Y.CompareTo(obj);
            }
        }

        /// <summary>
        ///  The goal value sought by this binary solver.
        /// </summary>
        public double Goal;

        /// <summary>
        ///  The independent value tolerance of this binary solver to declare a solution.
        /// </summary>
        public double Tolerance;

        public double LastAttemptedX = -1;

        /// <summary>
        ///  Search bounds.
        /// </summary>
        public Dictionary<int, Point> Bounds = new Dictionary<int, Point>();

        /// <summary>
        ///  Gets whether the solver has found a solution that satisfies the set parameters.
        /// </summary>
        public bool Solved => Math.Abs(Bounds.Values.Select(p => p.X).Aggregate((x1, x2) => x1 - x2)) <= Tolerance;

        /// <summary>
        ///  Adds a bound to the solver. Return value indicates whether the solver has found a bound on each side.
        /// </summary>
        /// <param name="X">Independent variable value of the bound</param>
        /// <param name="Y">Dependent variable value of the bound</param>
        public bool AddBound(
            double X,
            double Y)
        {
            if (LastAttemptedX == X)
            {
                throw new ArithmeticException();
            }

            if (!Bounds.TryGetValue(Goal.CompareTo(Y), out Point p) || Math.Abs(Goal - Y) <= Math.Abs(Goal - p.Y))
            {
                Bounds[Goal.CompareTo(Y)] = new Point() { X = X, Y = Y };
            }

            LastAttemptedX = X;

            return 2 == Bounds.Count;
        }

        /// <summary>
        ///  Returns the next independent variable value to test to narrow the search bounds.
        /// </summary>
        public double GetNext()
        {
            double nextDelta = (Goal - Bounds[-1].Y) / (Bounds[1].Y - Bounds[-1].Y) * (Bounds[1].X - Bounds[-1].X);
            return Math.Sign(nextDelta) * Math.Min(Math.Abs(Bounds[1].X - Bounds[-1].X) - Math.Abs(Tolerance), Math.Max(Math.Abs(Tolerance), Math.Abs(nextDelta))) + Bounds[-1].X;
        }
    }

    /// <summary>
    ///  A wrapper for <see cref="double"/> with safeguards against underflows and overflows.
    /// </summary>
    public class SafeDouble
    {
        Queue<double> Overflowing = new Queue<double>();
        Queue<double> Underflowing = new Queue<double>();
        double PartialProduct = 1;

        public SafeDouble(double d)
        {
            PartialProduct = d;
        }

        public static SafeDouble operator *(SafeDouble d, double m)
        {
            if (Math.Abs(m) > 1 && Math.Abs(double.MaxValue / m) < Math.Abs(d.PartialProduct))
            {
                d.Overflowing.Enqueue(d.PartialProduct);
                d.PartialProduct = m;
            }
            else if (Math.Abs(m) < 1 && Math.Abs(double.Epsilon / m) > Math.Abs(d.PartialProduct))
            {
                d.Underflowing.Enqueue(d.PartialProduct);
                d.PartialProduct = m;
            }
            else
            {
                d.PartialProduct *= m;
            }

            return d;
        }

        public static SafeDouble operator /(SafeDouble d, double m)
        {
            return d * (1 / m);
        }

        public static implicit operator SafeDouble(double d)
        {
            return new SafeDouble(d);
        }

        public static implicit operator double(SafeDouble d)
        {
            double product = d.PartialProduct;
            while (d.Overflowing.Any() || d.Underflowing.Any())
            {
                if (d.Underflowing.Any() && Math.Abs(double.Epsilon / d.Underflowing.Peek()) < Math.Abs(product))
                {
                    product *= d.Underflowing.Dequeue();
                }
                else if (d.Overflowing.Any() && Math.Abs(double.MaxValue / d.Overflowing.Peek()) > Math.Abs(product))
                {
                    product *= d.Overflowing.Dequeue();
                }
                else if (d.Underflowing.Any())
                {
                    throw new ArithmeticException("Unhandled underflow.");
                }
                else
                {
                    throw new ArithmeticException("Unhandled overflow.");
                }
            }

            return product;
        }
    }
}

namespace RATSharp
{
    /// <summary>
    ///  Contains extension methods used throughout the program.
    /// </summary>
    public static partial class Extensions
    {
        /// <summary>
        ///  Returns the complement of this cumulative distribution function type.
        /// </summary>
        public static CDFType Complement(this CDFType cdfType)
        {
            return (CDFType)(-(int)cdfType);
        }
    }

}
