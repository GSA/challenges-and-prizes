﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

using RATSharp.IO;
using RATSharp.Renderers;
using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace RATSharp
{
    public partial class MainForm : Form
    {
        private SaveFileDialog SaveOutputDialog = new SaveFileDialog();
        private Rectangle? PreviewWindowBounds;
        private Point PreviewWindowPosition;

        /// <summary>
        ///  UI setup phase for Preview mode, called by <see cref="MainForm_Load"/>.
        /// </summary>
        private void PreviewMode_Load()
        {
            PreviewControlPanel.Controls.SetEnabled(false);
            SaveHTMLButton.Tag = "HTML page (*.html)|*.html";
            SaveTextButton.Tag = "Text file (*.txt)|*.txt";
            SaveExcelButton.Tag = "Microsoft Excel file (*.xlsx)|*.xlsx";
            SaveAccessButton.Tag = "Microsoft Access file (*.accdb)|*.accdb";
            SaveFlatButton.Tag = "Flat file|*";
        }

        #region Event Handlers

        /// <summary>
        ///  Handles <see cref="Button.Click"/> event fired by Save buttons.
        /// </summary>
        private void SaveButton_Click(object sender, EventArgs e)
        {
            var activeButtons = PreviewControlPanel.Controls.SetEnabled(false);

            SaveOutputDialog.FileName = ActiveResult.Name.EmptyCoalesce("RATSharpResult");
            SaveOutputDialog.Filter = (sender as Button).Tag as string;
            SaveOutputDialog.FilterIndex = 0;

            if (DialogResult.OK != SaveOutputDialog.ShowDialog())
            {
                activeButtons.SetEnabled(true);
                return;
            }

            try
            {
                ActiveResult.File = ActiveResult.File ?? SaveOutputDialog.FileName;
                if (SaveHTMLButton == sender)
                {
                    IO.Text.Write(SaveOutputDialog.FileName, PreviewBrowser.DocumentText);
                }
                else if (SaveTextButton == sender)
                {
                    IO.Text.Write(SaveOutputDialog.FileName, ActiveResult, PlainText.Render);
                }
                else if (SaveExcelButton == sender)
                {
                    Excel.WriteFromTemplate(SaveOutputDialog.FileName, ActiveResult);
                }
                else if (SaveAccessButton == sender)
                {
                    Access.WriteFromTemplate(SaveOutputDialog.FileName, ActiveResult);
                }
                else if (SaveFlatButton == sender)
                {
                    if ((ActiveResult as RandomNumbersSingleResult).SampleSize >= 10000)
                    {
                        DefaultMessageBox.Warning(
                            $@"Previous versions of RAT-STATS program outputs flat file in the format of:
{""                           }    [4 digits of order][10 digits of random number value]

{""                           }You have selected large sample size which requires more than 4 digits of order, therefore RATSharp will use as many digits as necessary for this sample size.

{""                           }Press OK to acknowledge this warning.");
                    }

                    IO.Text.Write(SaveOutputDialog.FileName, ActiveResult, FlatFile.Render);
                }

                if (1 == SaveModeInput.SelectedIndex)
                {
                    Process.Start(SaveOutputDialog.FileName);
                }
            }
            catch (IOException exception) when (exception.HResult.Equals(unchecked((int)0x80070020)))
            {
                DefaultMessageBox.Error($"'{SaveOutputDialog.FileName}' is currently being opened by another program. Please close the other program or choose a different name or path.");
            }
            catch (InvalidOperationException exception) when (exception.TargetSite.Name.Equals("GetDataSource"))
            {
                DefaultMessageBox.Error($"Cannot save {SaveOutputDialog.FileName} using OLEDB connection. " +
                                        $"Please install {(Environment.Is64BitProcess ? 64 : 32)}-bit Microsoft Access Database Engine 2010 Redistributable to save to Microsoft Access database files.");
            }

            activeButtons.SetEnabled(true);
        }

        /// <summary>
        ///  Handles <see cref="WebBrowser.GotFocus"/> event fired by <see cref="PreviewBrowser"/>.
        /// </summary>
        private void PreviewBrowser_GotFocus(object sender, EventArgs e)
        {
            (sender as WebBrowser).Document?.Focus();
            if (null == (sender as WebBrowser).Document)
            {
                MainStatus.Text = "Press Esc to return to menu navigation.";
            }
        }

        /// <summary>
        ///  Handles <see cref="WebBrowser.Lost"/> event fired by <see cref="PreviewBrowser"/>.
        /// </summary>
        private void PreviewBrowser_LostFocus(object sender, EventArgs e)
        {

        }

        /// <summary>
        ///  Handles <see cref="WebBrowser.PreviewKeyDown"/> event fired by <see cref="PreviewBrowser"/>.
        /// </summary>
        private void PreviewBrowser_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Escape))
            {
                Modes.Focus();
                MainStatus.Text = string.Empty;
            }
        }

        /// <summary>
        ///  Handles <see cref="WebBrowser.DocumentCompleted"/> event fired by <see cref="PreviewBrowser"/>.
        /// </summary>
        private void PreviewBrowser_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            var browser = sender as WebBrowser;

            PreviewWindowBounds = browser.Document.Body?.ScrollRectangle;
            PreviewWindowPosition = new Point();
            browser.Document.Focusing += (object lambdaSender, HtmlElementEventArgs args) =>
            {
                (browser.Parent as Panel).BorderStyle = BorderStyle.Fixed3D;
                MainStatus.Text = "Browsing preview, use Ctrl+Arrow keys (Up, Down, Left, Right): navigate | Esc: return to menu navigation.";
            };
            browser.Document.LosingFocus += (object lambdaSender, HtmlElementEventArgs args) =>
            {
                (browser.Parent as Panel).BorderStyle = BorderStyle.None;
                MainStatus.Text = string.Empty;
            };
            browser.Focus();
        }

        /// <summary>
        ///  Handles <see cref="Button.Click"/> event fired by <see cref="PrintPreviewButton"/>.
        /// </summary>
        private void PrintPreviewButton_Click(object sender, EventArgs e)
        {
            PreviewBrowser.ShowPrintPreviewDialog();
        }

        #endregion

        #region Feature implementation

        /// <summary>
        ///  Supports scrolling using Arrow keypress.
        /// </summary>
        [Obsolete("Does not support smooth scrolling, use Alt+Arrow keys instead.")]
        private Point PreviewBrowser_GetNewScrollPosition(
            int left,
            int top)
        {
            const int scrollStep = 50;

            PreviewWindowPosition.X += scrollStep * left;
            PreviewWindowPosition.Y += scrollStep * top;

            PreviewWindowPosition.X = PreviewWindowPosition.X.Clamp(0, PreviewWindowBounds?.Width ?? 0);
            PreviewWindowPosition.Y = PreviewWindowPosition.Y.Clamp(0, PreviewWindowBounds?.Height ?? 0);

            return PreviewWindowPosition;
        }

        /// <summary>
        ///  Renders result to preview browser.
        /// </summary>
        internal void PreviewBrowser_Render(IRATResult result)
        {
            var html = HTMLPage.Render(result);

            PreviewBrowser.DocumentText = "0";
            PreviewBrowser.Document.OpenNew(true);
            PreviewBrowser.Document.Write(html);
            PreviewBrowser.Refresh();

            // get parent tab control and navigate to there
            Modes.SelectedTab = PreviewMode;
            PreviewBrowser.Focus();
        }

        #endregion
    }

    /// <summary>
    ///  Contains extension methods used throughout the program.
    /// </summary>
    public static partial class Extensions
    {
        /// <summary>
        ///  Clamps this integer to not more than <paramref name="min"/> and not more than <paramref name="max"/>.
        /// </summary>
        public static int Clamp(
            this int value,
            int min,
            int max)
        {
            if (min > max) return value.Clamp(min: max, max: min);
            return Math.Min(max, Math.Max(min, value));
        }

        /// <summary>
        ///  Coalesce this string with another string if this string is null or empty.
        /// </summary>
        public static string EmptyCoalesce(
            this string value,
            string input)
        {
            return string.IsNullOrEmpty(value) ? input : value;
        }
    }
}
