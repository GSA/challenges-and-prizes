﻿// Copyright (c) 2017 Pradipta Ariyo Bhaskoro Hendri
// Pradipta Ariyo Bhaskoro Hendri permits use of this file by OIG up to and not exceeding Terms and Conditions of
// Statistical Software for Healthcare Oversight Challenge at Challenge.gov from September 2016 to May 2017.
// See the LICENSE file in the project root for more information.

using RATSharp.IO;
using RATSharp.Stochastics;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace RATSharp
{
    public partial class MainForm : Form
    {
        private OpenFileDialog VA_S_FileDialog = new OpenFileDialog();
        private AppraisalVariableType[] VA_S_DataFileFormat = new AppraisalVariableType[] { };
        private IVariableInput VA_S_Input;
        private IVariableInput VA_S_UniverseInput;
        private int VA_S_DropdownDefaultHeight;
        private ComboBox[] VA_S_OptionInputs;
        private Label[] VA_S_OptionLabels;

        /// <summary>
        ///  UI setup phase for Stratified Variable Appraisal, called by <see cref="MainForm_Load"/>.
        /// </summary>
        private void VA_S_Load()
        {
            VA_S_FileDialog.Filter += "Text files (*.txt)|*.txt";
            VA_S_FileDialog.Filter += "|Microsoft Access files (*.accdb)|*.accdb";
            VA_S_FileDialog.Filter += "|Microsoft Excel files (*.xls, *.xslx)|*.xls;*.xlsx";
            VA_S_FileDialog.Filter += "|Supported files (*.txt, *.accdb, *.xls, *.xslx)|*.txt;*.accdb;*.xls;*.xlsx";
            VA_S_FileDialog.Filter += "|All files (*.*)|*.*";
            VA_S_FileDialog.FilterIndex = 4;

            VA_S_DropdownDefaultHeight = VA_S_SourceOption1Input.Height;
            VA_S_OptionInputs = new[]
            {
                VA_S_SourceOption1Input,
                VA_S_SourceOption2Input,
                VA_S_UniverseSourceOption1Input,
                VA_S_UniverseSourceOption2Input
            };

            VA_S_OptionLabels = new[]
            {
                VA_S_SourceOption1Label,
                VA_S_SourceOption2Label,
                VA_S_UniverseSourceOption1Label,
                VA_S_UniverseSourceOption2Label
            };

            VA_S_UniverseFileInput.Visible = false;
            VA_S_UniverseFileLabel.Visible = false;

            foreach (var control in VA_S_OptionInputs.Cast<Control>().Concat(VA_S_OptionLabels.Cast<Control>()))
            {
                control.Visible = false;
            }

            VA_S_PreviewLabel.Visible = false;
        }

        /// <summary>
        ///  User input validation procedure for Stratified Variable Appraisal.
        /// </summary>
        private bool VA_S_Validate()
        {
            if (!File.Exists(VA_S_FileInput.Text))
            {
                DefaultMessageBox.Error($"Please make sure the Input File '{VA_S_FileInput.Text}' points to a valid and accessible file.");
                VA_S_FileInput.Focus();
                return false;
            }

            if (!File.Exists(VA_S_UniverseFileInput.Text))
            {
                DefaultMessageBox.Error($"Please make sure the Universe Input File '{VA_S_UniverseFileInput.Text}' points to a valid and accessible file.");
                VA_S_UniverseFileInput.Focus();
                return false;
            }

            if (!VA_S_Input.Loaded)
            {
                DefaultMessageBox.Error($"Please select a valid Table/Worksheet name.");
                VA_S_SourceInput.Focus();
                return false;
            }

            if (!VA_S_UniverseInput.Loaded)
            {
                DefaultMessageBox.Error($"Please select a valid Universe Table/Worksheet name.");
                VA_S_UniverseSourceInput.Focus();
                return false;
            }

            if (VA_S_DataFileFormatInput.SelectedIndex < 0)
            {
                DefaultMessageBox.Error($"Please select a Data File Format for your input.");
                VA_S_DataFileFormatInput.Focus();
                return false;
            }

            if (VA_S_StrataSizeInput.Value <= 0 ||
                VA_S_StrataSizeInput.Value % 1 != 0)
            {
                DefaultMessageBox.Error($"{VA_S_StrataSizeInput.Value} is not a valid Number of Strata.");
                VA_S_StrataSizeInput.Focus();
                return false;
            }

            for (var i = 0; i < VA_S_OptionInputs.Length; ++i)
            {
                if (VA_S_OptionInputs[i].Visible && 0 == VA_S_OptionInputs[i].Text.Length)
                {
                    DefaultMessageBox.Error($"Please respond to the following: {VA_S_OptionLabels[i].Text}");
                    VA_S_OptionInputs[i].Focus();
                    return false;
                }
            }

            return true;
        }

        #region Event handlers

        /// <summary>
        ///  Handles <see cref="ListBox.SelectedIndexChanged"/> event fired by <see cref="VA_S_DataFileFormatInput"/>.
        /// </summary>
        private void VA_S_DataFileFormatInput_SelectedIndexChanged(object sender, EventArgs e)
        {
            VA_S_DataFileFormat = VariableAppraisal.GetDataFormatFromInputIndex(VA_S_DataFileFormatInput.SelectedIndex);

            if (VA_S_Input != null)
            {
                VA_S_UpdateOptionPrompt();
            }
        }

        /// <summary>
        ///  Handles <see cref="TextBox.Click"/> event fired by <see cref="VA_S_FileInput"/>.
        /// </summary>
        private void VA_S_FileInput_Click(object sender, EventArgs e)
        {
            if (0 == VA_S_FileInput.Text.Length)
            {
                VA_S_SelectInputFile();
            }
        }

        /// <summary>
        ///  Handles <see cref="TextBox.KeyPress"/> event fired by <see cref="VA_S_FileInput"/>.
        /// </summary>
        private void VA_S_FileInput_KeyPress(object sender, KeyPressEventArgs e)
        {
            VA_S_SelectInputFile();
        }

        /// <summary>
        ///  Handles <see cref="Button.Click"/> event fired by <see cref="VA_S_GenerateButton"/>.
        /// </summary>
        private void VA_S_GenerateButton_Click(object sender, EventArgs e)
        {
            VariableAppraisalStratifiedResult result = null;
            if (!VA_S_Validate())
            {
                return;
            }

            try
            {
                switch (VA_S_Input?.AsTable().Type)
                {
                    case IOFileType.Text:
                        result = VA_S_GenerateFromText();
                        break;
                    case IOFileType.Excel:
                        result = VA_S_GenerateFromExcel();
                        break;
                    case IOFileType.Access:
                        result = VA_S_GenerateFromAccess();
                        break;
                    default:
                        throw new InvalidOperationException("Unsupported input type.");
                }

                SetActiveResult(result);
            }
            catch (OperationCanceledException exception)
            {
                Controls.Find(exception.Source, true).FirstOrDefault()?.Focus();
            }
            catch (InvalidOperationException exception)
            {
                DefaultMessageBox.Error(exception.Message);
            }
            catch (Exception exception)
            {
                Clipboard.SetText(exception.StackTrace);
                DefaultMessageBox.Error($"Unexpected {exception.GetType()}: {exception.Message}");
            }
        }

        /// <summary>
        ///  Handles <see cref="ComboBox.Validating"/> event fired by option ComboBoxes.
        /// </summary>
        private void VA_S_OptionInput_Validating(object sender, CancelEventArgs e)
        {
            var input = sender as ComboBox;

            if (0 == input.Text.Length) return;

            switch (VA_S_Input?.AsTable().Type)
            {
                case IOFileType.Text:
                    e.Cancel |= !int.TryParse(input.Text, out int value) || value <= 0;
                    break;
                case IOFileType.Excel:
                    e.Cancel |= !Excel.IsValidReference(input.Text);
                    break;
                case IOFileType.Access:
                    break;
                default:
                    e.Cancel = true;
                    break;
            }
        }

        /// <summary>
        ///  Handles <see cref="Panel.ControlAdded"/> event fired by Panels.
        /// </summary>
        private void VA_S_Panel_ControlAdded(object sender, ControlEventArgs e)
        {
            VA_S_PreviewLabel.Visible = true;
        }

        /// <summary>
        ///  Handles <see cref="Panel.ControlRemoved"/> event fired by Panels.
        /// </summary>
        private void VA_S_Panel_ControlRemoved(object sender, ControlEventArgs e)
        {
            VA_S_PreviewLabel.Visible = VA_S_SourcePanel.Controls.Count + VA_S_UniverseSourcePanel.Controls.Count > 0;
        }

        /// <summary>
        ///  Handles <see cref="ComboBox.SelectionChangeCommitted"/> event fired by <see cref="VA_S_SourceInput"/>.
        /// </summary>
        private void VA_S_SourceInput_SelectionChangeCommitted(object sender, EventArgs e)
        {
            VA_S_Input.Load(VA_S_SourceInput.SelectedItem as string);
            VA_S_UpdateOptionPrompt(sourceChanged: true);
            VariableAppraisal.Preview(VA_S_Input, ref VA_S_SourcePanel);
        }

        /// <summary>
        ///  Handles <see cref="TextBox.Click"/> event fired by <see cref="VA_S_UniverseFileInput"/>.
        /// </summary>
        private void VA_S_UniverseFileInput_Click(object sender, EventArgs e)
        {
            if (0 == VA_S_UniverseFileInput.Text.Length)
            {
                VA_S_SelectUniverseInputFile();
            }
        }

        /// <summary>
        ///  Handles <see cref="TextBox.KeyPress"/> event fired by <see cref="VA_S_UniverseFileInput"/>.
        /// </summary>
        private void VA_S_UniverseFileInput_KeyPress(object sender, KeyPressEventArgs e)
        {
            VA_S_SelectUniverseInputFile();
        }

        /// <summary>
        ///  Handles <see cref="ComboBox.SelectionChangeCommitted"/> event fired by <see cref="VA_S_UniverseSourceInput"/>.
        /// </summary>
        private void VA_S_UniverseSourceInput_SelectionChangeCommitted(object sender, EventArgs e)
        {
            VA_S_UniverseInput.Load(VA_S_UniverseSourceInput.SelectedItem as string);
            VA_S_UpdateOptionPrompt(universeSourceChanged: true);
            VariableAppraisal.Preview(VA_S_UniverseInput, ref VA_S_UniverseSourcePanel);
        }

        #endregion

        #region Feature implementation

        /// <summary>
        ///  Generates Stratified Variable Appraisal from Microsoft Access database input.
        /// </summary>
        private VariableAppraisalStratifiedResult VA_S_GenerateFromAccess()
        {
            var dataRowOffset = new[] { 0, 0 };
            var dataColumnOffset = new[] { 0, 0 };

            if (VA_S_UniverseSourceOption1Input.SelectedIndex < 0)
            {
                DefaultMessageBox.Error($"Please enter field name for universe sizes.");
                throw new OperationCanceledException() { Source = VA_S_UniverseSourceOption1Input.Name };
            }

            if (VA_S_UniverseSourceOption2Input.SelectedIndex < 0)
            {
                DefaultMessageBox.Error($"Please enter field name for sample sizes.");
                throw new OperationCanceledException() { Source = VA_S_UniverseSourceOption2Input.Name };
            }

            if (VA_S_SourceOption1Input.SelectedIndex < 0)
            {
                DefaultMessageBox.Error($"Please enter field name for {VA_S_DataFileFormat[0].ToString().ToLowerInvariant()} values.");
                throw new OperationCanceledException() { Source = VA_S_SourceOption1Input.Name };
            }

            if (VA_S_DataFileFormat.Length == 2)
            {
                if (VA_S_SourceOption2Input.SelectedIndex < 0)
                {
                    DefaultMessageBox.Error($"Please enter field name for {VA_S_DataFileFormat[1].ToString().ToLowerInvariant()} values.");
                    throw new OperationCanceledException() { Source = VA_S_SourceOption2Input.Name };
                }
            }

            var strataSize = (int)VA_S_StrataSizeInput.Value;
            var universeInput = VA_S_UniverseInput.AsTable().DataTable;
            var universeSizes = universeInput.Rows.Cast<DataRow>().Select(row => Convert.ToInt32(row.Field<object>(VA_S_UniverseSourceOption1Input.Text))).ToList();
            var sampleSizes = universeInput.Rows.Cast<DataRow>().Select(row => Convert.ToInt32(row.Field<object>(VA_S_UniverseSourceOption2Input.Text))).ToList();

            // parse sample size and universe
            if (universeSizes.Count() != strataSize ||
                sampleSizes.Count() != strataSize)
            {
                DefaultMessageBox.Error($"Incompatible Universe Input File for {strataSize} strata, please check Number of Strata and Universe Input File.");
                throw new OperationCanceledException() { Source = VA_S_StrataSizeInput.Name };
            }

            var rawData = VA_S_Input.AsTable().DataTable.Copy();

            dataColumnOffset[0] = rawData.Columns.IndexOf(VA_S_SourceOption1Input.Text);
            dataColumnOffset[1] = rawData.Columns.IndexOf(VA_S_SourceOption2Input.Text);

            return VA_S_GenerateFromDataTable(rawData, universeSizes, sampleSizes, dataRowOffset, dataColumnOffset);
        }

        /// <summary>
        ///  Generates Stratified Variable Appraisal from Microsoft Excel workbook input.
        /// </summary>
        private VariableAppraisalStratifiedResult VA_S_GenerateFromExcel()
        {
            var dataRowOffset = new[] { 0, 0 };
            var dataColumnOffset = new[] { 0, 0 };

            if (!Excel.TryParseReference(VA_S_UniverseSourceOption1Input.Text, out int universeRowOffset, out int universeColumnOffset))
            {
                DefaultMessageBox.Error($"Please enter valid cell reference for universe sizes.");
                throw new OperationCanceledException() { Source = VA_S_UniverseSourceOption1Input.Name };
            }

            if (!Excel.TryParseReference(VA_S_UniverseSourceOption2Input.Text, out int sampleRowOffset, out int sampleColumnOffset))
            {
                DefaultMessageBox.Error($"Please enter valid cell reference for sample sizes.");
                throw new OperationCanceledException() { Source = VA_S_UniverseSourceOption2Input.Name };
            }

            if (!Excel.TryParseReference(VA_S_SourceOption1Input.Text, out dataRowOffset[0], out dataColumnOffset[0]))
            {
                DefaultMessageBox.Error($"Please enter valid cell reference for first {VA_S_DataFileFormat[0].ToString().ToLowerInvariant()} value.");
                throw new OperationCanceledException() { Source = VA_S_SourceOption1Input.Name };
            }

            if (VA_S_DataFileFormat.Length == 2)
            {
                if (!Excel.TryParseReference(VA_S_SourceOption2Input.Text, out dataRowOffset[1], out dataColumnOffset[1]))
                {
                    DefaultMessageBox.Error($"Please enter valid cell reference for first {VA_S_DataFileFormat[1].ToString().ToLowerInvariant()} value.");
                    throw new OperationCanceledException() { Source = VA_S_SourceOption2Input.Name };
                }
            }

            var strataSize = (int)VA_S_StrataSizeInput.Value;
            var universeInput = VA_S_UniverseInput.AsTable().DataTable;
            var universeSizes = universeInput.Rows.Cast<DataRow>().Skip(universeRowOffset).Take(strataSize).Select(row => Convert.ToInt32(row.ItemArray[universeColumnOffset])).ToList();
            var sampleSizes = universeInput.Rows.Cast<DataRow>().Skip(sampleRowOffset).Take(strataSize).Select(row => Convert.ToInt32(row.ItemArray[sampleColumnOffset])).ToList();

            // parse sample size and universe
            if (universeSizes.Count() != strataSize ||
                sampleSizes.Count() != strataSize)
            {
                DefaultMessageBox.Error($"Incompatible Universe Input File for {strataSize} strata, please check Number of Strata and Universe Input File.");
                throw new OperationCanceledException() { Source = VA_S_StrataSizeInput.Name };
            }

            var rawData = VA_S_Input.AsTable().DataTable.Copy();

            return VA_S_GenerateFromDataTable(rawData, universeSizes, sampleSizes, dataRowOffset, dataColumnOffset);
        }

        /// <summary>
        ///  Generates Stratified Variable Appraisal from text file input.
        /// </summary>
        private VariableAppraisalStratifiedResult VA_S_GenerateFromText()
        {
            var dataRowOffset = new[] { 0, 0 };
            var dataColumnOffset = new[] { 0, 0 };

            if (VA_S_SourceOption1Input.Text.Length == 0)
            {
                DefaultMessageBox.Error($"Please enter column number for {VA_S_DataFileFormat[0].ToString().ToLowerInvariant()} values.");
                throw new OperationCanceledException() { Source = VA_S_SourceOption1Input.Name };
            }

            dataColumnOffset[0] = int.Parse(VA_S_SourceOption1Input.Text) - 1;

            if (VA_S_DataFileFormat.Length == 2)
            {
                if (VA_S_SourceOption2Input.Text.Length == 0)
                {
                    DefaultMessageBox.Error($"Please enter column number for {VA_S_DataFileFormat[1].ToString().ToLowerInvariant()} values.");
                    throw new OperationCanceledException() { Source = VA_S_SourceOption2Input.Name };
                }

                dataColumnOffset[1] = int.Parse(VA_S_SourceOption2Input.Text) - 1;
            }

            var strataSize = (int)VA_S_StrataSizeInput.Value;
            var universeInput = VA_S_UniverseInput.AsTable().DataTable;
            var universeSizes = universeInput.Rows.Cast<DataRow>().Select(row => Convert.ToInt32(row.Field<object>(1))).ToList();
            var sampleSizes = universeInput.Rows.Cast<DataRow>().Select(row => Convert.ToInt32(row.Field<object>(2))).ToList();

            // parse sample size and universe
            if (universeSizes.Count() != strataSize ||
                sampleSizes.Count() != strataSize)
            {
                DefaultMessageBox.Error($"Incompatible Universe Input File for {strataSize} strata, please check Number of Strata and Universe Input File.");
                throw new OperationCanceledException() { Source = VA_S_StrataSizeInput.Name };
            }

            var rawData = VA_S_Input.AsTable().DataTable.Copy();

            return VA_S_GenerateFromDataTable(rawData, universeSizes, sampleSizes, dataRowOffset, dataColumnOffset);
        }

        /// <summary>
        ///  Generates Stratified Variable Appraisal from DataTable from text, Excel, or Access input.
        /// </summary>
        private VariableAppraisalStratifiedResult VA_S_GenerateFromDataTable(
            DataTable rawData,
            IEnumerable<int> universeSizes,
            IEnumerable<int> sampleSizes,
            int[] dataRowOffset,
            int[] dataColumnOffset)
        {
            if (universeSizes.Zip(sampleSizes, (universe, sample) => universe >= sample).Any(valid => !valid))
            {
                DefaultMessageBox.Error($"Universe size cannot be smaller than sample size. Please check Universe Input File content or cell references.");
                throw new OperationCanceledException() { Source = VA_S_UniverseFileInput.Name };
            }

            var result = new VariableAppraisalStratifiedResult()
            {
                Name = VA_S_NameInput.Text,
                File = $"{VA_S_FileInput.Text}[{VA_S_SourceInput.Text}]"
            };

            var strataSize = universeSizes.Count();
            var totalSampleSize = sampleSizes.Sum();

            if (sampleSizes.Any(sample => sample > 10_000))
            {
                DefaultMessageBox.Warning("Using sample size larger than 10,000 is not supported in previous RAT-STATS versions. " +
                            "This program uses interpolation for sample size larger than 10,000 and will be accurate to 9 significant figures for most use cases, regardless of the number of figures shown on the report. " +
                            "Please consult with a Statistics Specialist for this sample size.");
            }

            // verify sample size against data
            for (var i = 0; i < 2; ++i)
            {
                if (rawData.Rows.Count - dataRowOffset[i] < totalSampleSize)
                {
                    DefaultMessageBox.Error($"Incompatible Input source, Universe Input source, or row offset for {VA_S_DataFileFormat[i].ToString().ToLowerInvariant()} values. " +
                              $"Only {rawData.Rows.Count - dataRowOffset[i]} rows found but Universe Input source specified total sample size of {totalSampleSize}. " +
                               "Please verify your inputs again.");
                    throw new OperationCanceledException() { Source = VA_S_SourceInput.Name };
                }

                if (rawData.Columns.Count <= dataColumnOffset[i])
                {
                    DefaultMessageBox.Error($"Invalid column selected for {VA_S_DataFileFormat[i].ToString().ToLowerInvariant()} values. " +
                              $"Only {rawData.Columns.Count} columns found. " +
                               "Please verify your inputs again.");
                    throw new OperationCanceledException() { Source = VA_S_OptionInputs[i].Name };
                }
            }

            // parse
            var data = new List<Dictionary<AppraisalVariableType, List<double>>>();
            bool? parseAsString = false;

            for (var stratum = 0; stratum < strataSize; ++stratum)
            {   // TODO paralellizable
                var stratumData = new Dictionary<AppraisalVariableType, List<double>>();
                var rowOffset = sampleSizes.Take(stratum).Sum();

                for (var type = 0; type < VA_S_DataFileFormat.Length; ++type)
                {
                    var typeData = new List<double>();
                    var typeRowOffset = dataRowOffset[type] + rowOffset;
                    var typeColumnOffset = dataColumnOffset[type];

                    for (var row = 0; row < sampleSizes.ElementAtOrDefault(stratum); ++row)
                    {
                        if (parseAsString ?? true)
                        {
                            var value = rawData.Rows[typeRowOffset + row].Field<object>(typeColumnOffset);
                            if (value is ValueType)
                            {
                                typeData.Add(Convert.ToDouble(value));
                            }
                            else if (double.TryParse(value as string, NumberStyles.Any, CultureInfo.InvariantCulture, out double numericValue))
                            {
                                typeData.Add(numericValue);
                            }
                            else
                            {
                                var valueAsString = Convert.ToString(rawData.Rows[typeRowOffset + row].Field<object>(typeColumnOffset));

                                valueAsString = valueAsString.RegexReplace(@"[^\d\.\,\-]", "");
                                typeData.Add(double.TryParse(valueAsString, out numericValue) ? numericValue : 0);
                            }

                            parseAsString = parseAsString ?? false;
                        }
                        else
                        {
                            try
                            {
                                typeData.Add(Convert.ToDouble(rawData.Rows[typeRowOffset + row].Field<object>(typeColumnOffset)));
                            }
                            catch (FormatException exception) when (exception.HResult.Equals(unchecked((int)0x80131537)))
                            {
                                var badValue = Convert.ToString(rawData.Rows[typeRowOffset + row].Field<object>(typeColumnOffset));
                                var userOption = MessageBox.Show(
                                    $@"Program failed to import row {typeRowOffset + row + 1} of {VA_S_DataFileFormat[type].ToString().ToLowerInvariant()} values. The cell content is: '{badValue}'. This may be due to:
{""                                   }    - wrong column chosen
{""                                   }    - column/value explicitly formatted to be text/string type
{""                                   }    - corrupted file input, or other causes.

{""                                   }This program can try to read the value again as text after removing all non-digit characters except negative sign (-), decimal separator (.), and thousand separators (,). Unrecoverable text will be substituted with zero.

{""                                   }Your options are:
{""                                   }    Abort: Terminate this operation and correct the problem before retrying.
{""                                   }    Retry: Try to process this value as text only once, and show this warning again the next time.
{""                                   }    Ignore: Process all remaining values as text (may be slower but does not restart the operation). This may affect analysis result.",
                                    "RATSharp Recoverable Error Encountered", MessageBoxButtons.AbortRetryIgnore);
                                switch (userOption)
                                {
                                    case DialogResult.Abort:    throw new OperationCanceledException();
                                    case DialogResult.Retry:    parseAsString = null; break;
                                    case DialogResult.Ignore:   parseAsString = true; break;
                                }
                                --row;
                            }
                        }
                    }

                    stratumData[VA_S_DataFileFormat[type]] = typeData;
                }

                if (VA_S_DataFileFormat.Length == 2)
                {   // derive the third value
                    switch (VA_S_DataFileFormatInput.SelectedIndex)
                    {
                        case 3:
                            // Examined and Audited Values
                            stratumData[AppraisalVariableType.Difference] =
                            stratumData[AppraisalVariableType.Examined].AsParallel()
                                .Zip(stratumData[AppraisalVariableType.Audited].AsParallel(),
                                    (examined, audited) => examined - audited).ToList();
                            break;
                        case 4:
                            // Examined and Difference Values
                            stratumData[AppraisalVariableType.Audited] =
                            stratumData[AppraisalVariableType.Examined].AsParallel()
                                .Zip(stratumData[AppraisalVariableType.Difference].AsParallel(),
                                    (examined, difference) => examined - difference).ToList();
                            break;
                        case 5:
                            // Audited and Difference Values
                            stratumData[AppraisalVariableType.Examined] =
                            stratumData[AppraisalVariableType.Audited].AsParallel()
                                .Zip(stratumData[AppraisalVariableType.Difference].AsParallel(),
                                    (audited, difference) => audited + difference).ToList();
                            break;
                        default:    throw new InvalidOperationException("Error computing the third set of values.");
                    }
                }

                data.Add(stratumData);
            }

            var stratumIndex = 0;
            foreach (var stratum in data)
            {
                var summary = new VariableAppraisalSummary()
                {
                    UniverseSize = universeSizes.ElementAtOrDefault(stratumIndex),
                    SampleSize = sampleSizes.ElementAtOrDefault(stratumIndex)
                };

                var stratumResult = new VariableAppraisalStratumResult();
                foreach (var column in stratum)
                {   // TODO parallelizable
                    stratumResult[column.Key] = new VariableAppraisalResult() { Summary = new[] { summary } };
                    stratumResult[column.Key].Sum = column.Value.AsParallel().Sum();
                    var mean = stratumResult[column.Key].Sum / summary.SampleSize;
                    stratumResult[column.Key].Mean = mean;

                    if (stratum.Count == 1 || AppraisalVariableType.Difference == column.Key)
                    {
                        summary.NonzeroSize = column.Value.AsParallel().Count(row => row != 0);
                    }

                    stratumResult[column.Key].PointEstimate = summary.UniverseSize * mean;  // RAT-STATS does not produce this value if sample size == 0 or 1

                    if (summary.SampleSize <= 1)
                    {   // continuing would only produce NaN's
                        continue;
                    }

                    var CentralMoment2Term = column.Value.AsParallel().Sum(row => Math.Pow(row - mean, 2));
                    var CentralMoment3Term = column.Value.AsParallel().Sum(row => Math.Pow(row - mean, 3));
                    var CentralMoment4Term = column.Value.AsParallel().Sum(row => Math.Pow(row - mean, 4));

                    var standardDeviation = Math.Sqrt(CentralMoment2Term / (summary.SampleSize - 1));
                    stratumResult[column.Key].StandardDeviation = standardDeviation;
                    stratumResult[column.Key].Skewness = CentralMoment3Term / summary.SampleSize / Math.Pow(CentralMoment2Term / summary.SampleSize, 1.5);
                    stratumResult[column.Key].Kurtosis = summary.SampleSize * CentralMoment4Term / CentralMoment2Term / CentralMoment2Term;
                    stratumResult[column.Key].StandardErrorMean = standardDeviation * Math.Sqrt((summary.UniverseSize - summary.SampleSize) / (double)summary.UniverseSize / summary.SampleSize);
                    stratumResult[column.Key].StandardErrorTotal = summary.UniverseSize * stratumResult[column.Key].StandardErrorMean;

                    foreach (var p in ConfidenceInterval.DefaultLevels)
                    {
                        var confidence = new VariableAppraisalConfidence()
                        {
                            T = TDistribution.InverseCDF[p][summary.SampleSize - 1]
                        };
                        confidence.Precision = (double)confidence.T * stratumResult[column.Key].StandardErrorTotal;
                        confidence.UpperLimit = stratumResult[column.Key].PointEstimate + confidence.Precision;
                        confidence.LowerLimit = stratumResult[column.Key].PointEstimate - confidence.Precision;
                        confidence.PrecisionRatio = Math.Max(0, confidence.Precision / stratumResult[column.Key].PointEstimate);   // specification: zero if negative

                        stratumResult[column.Key].ConfidenceLimits[p] = confidence;
                    }
                }

                result.Strata[stratumIndex++] = stratumResult;
            }

            var overallSummary = new VariableAppraisalSummary()
            {
                UniverseSize = universeSizes.Sum(),
                SampleSize = sampleSizes.Sum(),
                NonzeroSize = result.Strata.Values.Select(stratum => stratum[stratum.Types.First()].Summary[0].NonzeroSize).Sum()
            };

            foreach (var type in data.FirstOrDefault()?.Keys)
            {
                var typeResult = new VariableAppraisalResult()
                {
                    Summary = new[] { overallSummary }
                };

                typeResult.Sum = result.Strata.Values.Select(stratum => stratum[type].Sum).Sum();
                typeResult.PointEstimate = result.Strata.Values.Select(stratum => stratum[type].PointEstimate).Sum();
                typeResult.StandardErrorTotal = Math.Sqrt(
                    result.Strata.Values.Select(stratum => 
                        Math.Pow(stratum[type].StandardDeviation, 2) *
                        (stratum[type].Summary[0].UniverseSize - stratum[type].Summary[0].SampleSize) *
                        stratum[type].Summary[0].UniverseSize /
                        stratum[type].Summary[0].SampleSize).Sum()
                    );

                foreach (var p in new[] { 0.8, 0.9, 0.95 })
                {
                    var confidence = new VariableAppraisalConfidence()
                    {
                        Z = ZDistribution.InverseCDF[p]
                    };
                    confidence.Precision = (double)confidence.Z * typeResult.StandardErrorTotal;
                    confidence.UpperLimit = typeResult.PointEstimate + confidence.Precision;
                    confidence.LowerLimit = typeResult.PointEstimate - confidence.Precision;
                    confidence.PrecisionRatio = Math.Max(0, confidence.Precision / typeResult.PointEstimate);   // specification: zero if negative

                    typeResult.ConfidenceLimits[p] = confidence;
                }

                result.Overall[type] = typeResult;
            }

            return result;
        }

        /// <summary>
        ///  Handles input file prompt and lays out UI suitable for the selected input file type.
        /// </summary>
        public void VA_S_SelectInputFile(bool showDialog = true)
        {
            if (showDialog)
            {
                if (DialogResult.OK != VA_S_FileDialog.ShowDialog())
                {
                    return;
                }
            }

            try
            {
                VariableAppraisal.Load(VA_S_FileDialog.FileName, out VA_S_Input);

                var inputTable = VA_S_Input.AsTable();

                VA_S_FileInput.Text = inputTable.FileName;
                VA_S_SourceInput.Items.Clear();
                VA_S_SourceInput.Items.AddRange(inputTable.Sources.ToArray());
                VA_S_SourcePanel.Controls.Clear();

                if (VA_S_Input is TextVariableInput)
                {
                    VA_S_UniverseFileInput.Visible = true;
                    VA_S_UniverseFileLabel.Visible = true;

                    if (!(VA_S_UniverseInput is TextVariableInput))
                    {
                        VA_S_UniverseFileInput.Text = "";

                        VA_S_UniverseSourceInput.Items.Clear();
                        VA_S_UniverseSourcePanel.Controls.Clear();
                    }
                }
                else if (VA_S_Input != null)
                {
                    VA_S_UniverseFileInput.Visible = false;
                    VA_S_UniverseFileLabel.Visible = false;

                    VariableAppraisal.Load(VA_S_FileDialog.FileName, out VA_S_UniverseInput);
                    VA_S_UniverseFileInput.Text = inputTable.FileName;

                    VA_S_UniverseSourceInput.Items.Clear();
                    VA_S_UniverseSourceInput.Items.AddRange(inputTable.Sources.ToArray());
                    VA_S_UniverseSourcePanel.Controls.Clear();
                }

                if (1 == inputTable.Sources.Count())
                {
                    VA_S_SourceInput.SelectedIndex = 0;
                    VA_S_Input.Load(VA_S_SourceInput.SelectedItem as string);
                    VariableAppraisal.Preview(VA_S_Input, ref VA_S_SourcePanel);
                }

                VA_S_UpdateOptionPrompt(sourceChanged: true, universeSourceChanged: !(VA_S_Input is TextVariableInput));
            }
            catch (InvalidOperationException exception) when (exception.TargetSite.Name.Equals("GetDataSource"))
            {
                DefaultMessageBox.Error($"Cannot open {VA_S_FileDialog.FileName} using OLEDB connection. " +
                                        $"Please install {(Environment.Is64BitProcess ? 64 : 32)}-bit Microsoft Access Database Engine 2010 Redistributable to open Microsoft Office files.");
            }
        }

        /// <summary>
        ///  Handles universe input file prompt and lays out UI suitable for the selected universe input file type.
        /// </summary>
        public void VA_S_SelectUniverseInputFile()
        {
            if (DialogResult.OK != VA_S_FileDialog.ShowDialog())
            {
                return;
            }

            try
            {
                VariableAppraisal.Load(VA_S_FileDialog.FileName, out VA_S_UniverseInput);

                if (VA_S_Input is TextVariableInput && !(VA_S_UniverseInput is TextVariableInput))
                {
                    VA_S_SelectInputFile(showDialog: false);
                    return;
                }

                var inputTable = VA_S_UniverseInput.AsTable();

                VA_S_UniverseFileInput.Text = inputTable.FileName;
                VA_S_UniverseSourceInput.Items.Clear();
                VA_S_UniverseSourceInput.Items.AddRange(inputTable.Sources.ToArray());
                VA_S_UniverseSourcePanel.Controls.Clear();

                if (1 == inputTable.Sources.Count())
                {
                    VA_S_UniverseSourceInput.SelectedIndex = 0;
                    VA_S_UniverseInput.Load(VA_S_UniverseSourceInput.SelectedItem as string);
                    VariableAppraisal.Preview(VA_S_UniverseInput, ref VA_S_UniverseSourcePanel);
                }

                VA_S_UpdateOptionPrompt(sourceChanged: false, universeSourceChanged: true);
            }
            catch (InvalidOperationException exception) when (exception.TargetSite.Name.Equals("GetDataSource"))
            {
                DefaultMessageBox.Error($"Cannot open {VA_S_FileDialog.FileName} using OLEDB connection. " +
                                        $"Please install {(Environment.Is64BitProcess ? 64 : 32)}-bit Microsoft Access Database Engine 2010 Redistributable to open Microsoft Office files.");
            }
        }

        /// <summary>
        ///  Lays out UI suitable for user response to options.
        /// </summary>
        public void VA_S_UpdateOptionPrompt(
            bool sourceChanged = false,
            bool universeSourceChanged = false)
        {
            for (var i = 0; i < 2; ++i)
            {
                VA_S_OptionInputs[i].Visible = i < VA_S_DataFileFormat.Length;
                VA_S_OptionLabels[i].Visible = i < VA_S_DataFileFormat.Length;
                VA_S_OptionInputs[2 + i].Visible = !(VA_S_Input is TextVariableInput || VA_S_UniverseInput is TextVariableInput) && VA_S_UniverseInput.Loaded;
                VA_S_OptionLabels[2 + i].Visible = !(VA_S_Input is TextVariableInput || VA_S_UniverseInput is TextVariableInput) && VA_S_UniverseInput.Loaded;
            }

            foreach (var dropdown in VA_S_OptionInputs)
            {
                if (!(VA_S_Input is AccessVariableInput))
                {
                    dropdown.Items.Clear();
                }
                dropdown.DropDownStyle = (VA_S_Input is AccessVariableInput) ? ComboBoxStyle.DropDownList : ComboBoxStyle.Simple;
                dropdown.Height = VA_S_DropdownDefaultHeight;   // ComboBox height bug workaround
            }

            switch (VA_S_Input?.AsTable().Type)
            {
                case IOFileType.Text:
                    VA_S_SourceInputLabel.Text = "Source name";
                    VA_S_UniverseSourceInputLabel.Text = "Source name";
                    VA_S_DataFileFormat?.Zip(VA_S_OptionLabels.Take(2), (type, label) =>
                    {
                        label.Text = $"Which column has {type.ToString().ToLowerInvariant()} values? (e.g. 2)";
                        return true;
                    }).ToArray();
                    break;
                case IOFileType.Excel:
                    VA_S_SourceInputLabel.Text = "Worksheet name";
                    VA_S_UniverseSourceInputLabel.Text = "Worksheet name";
                    VA_S_DataFileFormat?.Zip(VA_S_OptionLabels.Take(2), (type, label) =>
                    {
                        label.Text = $"Enter cell location for first {type.ToString().ToLowerInvariant()} value (e.g. A1)";
                        return true;
                    }).ToArray();
                    VA_S_UniverseSourceOption1Label.Text = "Enter cell location for universe size of first stratum (e.g. A1)";
                    VA_S_UniverseSourceOption2Label.Text = "Enter cell location for sample size of first stratum (e.g. A1)";
                    break;
                case IOFileType.Access:
                    VA_S_SourceInputLabel.Text = "Table name";
                    VA_S_UniverseSourceInputLabel.Text = "Table name";
                    VA_S_UniverseSourceOption1Label.Text = "Field for universe sizes:";
                    VA_S_UniverseSourceOption2Label.Text = "Field for sample sizes:";
                    var accessInput = VA_S_Input as AccessVariableInput;
                    var accessUniverseInput = VA_S_UniverseInput as AccessVariableInput;

                    for (var i = 0; i < 2; ++i)
                    {
                        VA_S_OptionLabels[i].Text = VA_S_DataFileFormat.Length <= i ? "" : $"Field for {VA_S_DataFileFormat[i].ToString().ToLowerInvariant()} values:";
                        VA_S_OptionLabels[i].Visible = VA_S_DataFileFormat.Length > i;
                        VA_S_OptionInputs[i].Visible = VA_S_DataFileFormat.Length > i;

                        if (sourceChanged)
                        {
                            VA_S_OptionInputs[i].Items.Clear();
                            foreach (var column in accessInput.Fields)
                            {
                                VA_S_OptionInputs[i].Items.Add(column);
                            }
                        }

                        if (universeSourceChanged)
                        {
                            VA_S_OptionInputs[2 + i].Items.Clear();
                            foreach (var column in accessUniverseInput.Fields)
                            {
                                VA_S_OptionInputs[2 + i].Items.Add(column);
                            }
                        }
                    }
                    break;
                default:
                    break;
            }
        }

        #endregion
    }
}