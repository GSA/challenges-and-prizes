﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RatStatsChallenge.Module.Infastructure;
namespace RatStatsChallenge.Module.Infastructure.Reports.VariableAppraisals
{
    public partial class Unrestricted_TXT
    {
        private UnrestrictedVariableAppraisal.ReportData m_RD;
        public Unrestricted_TXT(UnrestrictedVariableAppraisal.ReportData RD)
        {
            this.m_RD = RD;
        }
    }

    public partial class Stratified_TXT
    {
        private StratifiedVariableAppraisal m_RD;
        public Stratified_TXT(StratifiedVariableAppraisal RD)
        {
            this.m_RD = RD;
        }
    }
}
