﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RatStatsChallenge.Module.Infastructure;
namespace RatStatsChallenge.Module.Infastructure.Reports.AttributeAppraisals
{
    public partial class Unrestricted_TXT
    {
        private UnrestrictedAttributeAppraisal.ReportData m_RD;
        public Unrestricted_TXT(UnrestrictedAttributeAppraisal.ReportData RD)
        {
            this.m_RD = RD;
        }
    }
}
