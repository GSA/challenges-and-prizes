﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RatStatsChallenge.Module.Infastructure.Reports.RandomNumber
{
    public partial class SingleStage_TXT
    {
        private RandomSample.ReportData m_RD;
        public SingleStage_TXT(RandomSample.ReportData RD)
        {
            this.m_RD = RD;
        }
    }

    public partial class SingleStage_CSV
    {
        private RandomSample.ReportData m_RD;
        public SingleStage_CSV(RandomSample.ReportData RD)
        {
            this.m_RD = RD;
        }
    }
}
