﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using RatStatsChallenge.Module.Infastructure;
using RatStatsChallenge.Module.Interface.ViewModels.RandomNumbers;

namespace RatStatsChallenge.Module.Interface.Views.RandomNumbers
{
    /// <summary>
    /// Interaction logic for SingleStageRandomNumbersView.xaml
    /// </summary>
    public partial class SingleStageView : UserControl
    {
        public SingleStageView(SingleStageViewModel viewModel)
        {
            this.DataContext = viewModel;
            InitializeComponent();
        }

        private void Process_Button_Click(object sender, RoutedEventArgs e)
        {
            //Check For Validation Errors
            if (UserSeedTextBox.IsEnabled && Validation.GetErrors(UserSeedTextBox).Count > 0)
                return;
            if (Validation.GetErrors(SequentialOrderTextBox).Count > 0)
                return;
            if (Validation.GetErrors(SparesTextBox).Count > 0)
                return;
            if (Validation.GetErrors(SampleFrameLowTextBox).Count > 0)
                return;
            if (Validation.GetErrors(SampleFrameHighTextBox).Count > 0)
                return;
            //Reset Visual Error Indicators
            NoSeedRadio.ClearValue(TextBox.BorderBrushProperty);
            NoSeedRadio.BorderThickness = new Thickness(1);
            YesSeedRadio.ClearValue(TextBox.BorderBrushProperty);
            YesSeedRadio.BorderThickness = new Thickness(1);
            UserSeedTextBox.ClearValue(TextBox.BorderBrushProperty);
            UserSeedTextBox.BorderThickness = new Thickness(1);
            SparesTextBox.ClearValue(TextBox.BorderBrushProperty);
            SparesTextBox.BorderThickness = new Thickness(1);
            SequentialOrderTextBox.ClearValue(TextBox.BorderBrushProperty);
            SequentialOrderTextBox.BorderThickness = new Thickness(1);
            SampleFrameHighTextBox.ClearValue(TextBox.BorderBrushProperty);
            SampleFrameHighTextBox.BorderThickness = new Thickness(1);
            SampleFrameLowTextBox.ClearValue(TextBox.BorderBrushProperty);
            SampleFrameLowTextBox.BorderThickness = new Thickness(1);
            TextOutputCheckBox.ClearValue(TextBox.BorderBrushProperty);
            TextOutputCheckBox.BorderThickness = new Thickness(1);
            CSVOutputCheckBox.ClearValue(TextBox.BorderBrushProperty);
            CSVOutputCheckBox.BorderThickness = new Thickness(1);
            ExcelOutputCheckBox.ClearValue(TextBox.BorderBrushProperty);
            ExcelOutputCheckBox.BorderThickness = new Thickness(1);
            //Check for ViewModel Errors
            bool result = ((SingleStageViewModel)this.DataContext).ReadyToProceed();

            if (!result)
            {
                //ViewModel Errors were found so set visual error indicators
                foreach (ReadyToProceedError BR in ((SingleStageViewModel)this.DataContext).Errors)
                {
                    switch (BR.BindingName)
                    {
                        case "UserProvidedSeedEnabled":
                            UserSeedTextBox.BorderBrush = Brushes.Red;
                            UserSeedTextBox.BorderThickness = new Thickness(2);
                            break;
                        case "SparesNumberCount":
                            SparesTextBox.BorderBrush = Brushes.Red;
                            SparesTextBox.BorderThickness = new Thickness(2);
                            break;
                        case "SequentialNumberCount":
                            SequentialOrderTextBox.BorderBrush = Brushes.Red;
                            SequentialOrderTextBox.BorderThickness = new Thickness(2);
                            break;
                        case "NoSeedRadio":
                            NoSeedRadio.BorderBrush = Brushes.Red;
                            NoSeedRadio.BorderThickness = new Thickness(2);
                            break;
                        case "YesSeedRadio":
                            YesSeedRadio.BorderBrush = Brushes.Red;
                            YesSeedRadio.BorderThickness = new Thickness(2);
                            break;
                        case "UserSeedTextBox":
                            UserSeedTextBox.BorderBrush = Brushes.Red;
                            UserSeedTextBox.BorderThickness = new Thickness(2);
                            break;
                        case "SamplingFrameLow":
                            SampleFrameLowTextBox.BorderBrush = Brushes.Red;
                            SampleFrameLowTextBox.BorderThickness = new Thickness(2);
                            break;
                        case "SamplingFrameHigh":
                            SampleFrameHighTextBox.BorderBrush = Brushes.Red;
                            SampleFrameHighTextBox.BorderThickness = new Thickness(2);
                            break;
                        case "TextOutputCheckBox":
                            TextOutputCheckBox.BorderBrush = Brushes.Red;
                            TextOutputCheckBox.BorderThickness = new Thickness(2);
                            break;
                        case "CSVOutputCheckBox":
                            CSVOutputCheckBox.BorderBrush = Brushes.Red;
                            CSVOutputCheckBox.BorderThickness = new Thickness(2);
                            break;
                        case "ExcelOutputCheckBox":
                            ExcelOutputCheckBox.BorderBrush = Brushes.Red;
                            ExcelOutputCheckBox.BorderThickness = new Thickness(2);
                            break;
                    }
                }
            }
            else
                //No Errors Found so calculate seed
                try
                {
                    this.Cursor = Cursors.Wait;
                    ((SingleStageViewModel)this.DataContext).CalculateSeeds();
                    this.Cursor = Cursors.Arrow;
                }
                catch(Exception Ex)
                {
                    this.Cursor = Cursors.Arrow;
                    MessageBox.Show(Ex.Message);
                }

            return;
        }

        private void ClearFields()
        {
            //Clear Validation Errors
            UserSeedTextBox.Text = "0";
            Validation.ClearInvalid(UserSeedTextBox.GetBindingExpression(TextBox.TextProperty));
            SequentialOrderTextBox.Text = "0";
            Validation.ClearInvalid(SequentialOrderTextBox.GetBindingExpression(TextBox.TextProperty));
            SparesTextBox.Text = "0";
            Validation.ClearInvalid(SparesTextBox.GetBindingExpression(TextBox.TextProperty));
            SampleFrameLowTextBox.Text = "0";
            Validation.ClearInvalid(SampleFrameLowTextBox.GetBindingExpression(TextBox.TextProperty));
            SampleFrameHighTextBox.Text = "0";
            Validation.ClearInvalid(SampleFrameHighTextBox.GetBindingExpression(TextBox.TextProperty));
            //Reset Error Indicators
            NoSeedRadio.ClearValue(TextBox.BorderBrushProperty);
            NoSeedRadio.BorderThickness = new Thickness(1);
            YesSeedRadio.ClearValue(TextBox.BorderBrushProperty);
            YesSeedRadio.BorderThickness = new Thickness(1);
            UserSeedTextBox.ClearValue(TextBox.BorderBrushProperty);
            UserSeedTextBox.BorderThickness = new Thickness(1);
            SparesTextBox.ClearValue(TextBox.BorderBrushProperty);
            SparesTextBox.BorderThickness = new Thickness(1);
            SequentialOrderTextBox.ClearValue(TextBox.BorderBrushProperty);
            SequentialOrderTextBox.BorderThickness = new Thickness(1);
            SampleFrameHighTextBox.ClearValue(TextBox.BorderBrushProperty);
            SampleFrameHighTextBox.BorderThickness = new Thickness(1);
            SampleFrameLowTextBox.ClearValue(TextBox.BorderBrushProperty);
            SampleFrameLowTextBox.BorderThickness = new Thickness(1);
            TextOutputCheckBox.ClearValue(TextBox.BorderBrushProperty);
            TextOutputCheckBox.BorderThickness = new Thickness(1);
            CSVOutputCheckBox.ClearValue(TextBox.BorderBrushProperty);
            CSVOutputCheckBox.BorderThickness = new Thickness(1);
            ExcelOutputCheckBox.ClearValue(TextBox.BorderBrushProperty);
            ExcelOutputCheckBox.BorderThickness = new Thickness(1);
            ((SingleStageViewModel)this.DataContext).ResetFields();
        }

        private void Clear_Fields_Button_Click(object sender, RoutedEventArgs e)
        {
            ClearFields();
        }

        private void Cancel_Button_Click(object sender, RoutedEventArgs e)
        {
            ClearFields();
            ((SingleStageViewModel)this.DataContext).GoHome();
        }
    } 
}
