﻿using System.Windows.Input;
using Prism.Mvvm;
using Prism.Commands;
using Prism.Regions;
using RatStatsChallenge.Module.Infastructure.Enums;
using System;
using RatStatsChallenge.Module.Infastructure;
using RatStatsChallenge.Module.Infastructure.Reports;
using System.Collections.Generic;
using Microsoft.Win32;
using System.Linq;
using Microsoft.VisualBasic.FileIO;
using Excel = Microsoft.Office.Interop.Excel;

using RatStatsChallenge.Module.Infastructure.Reports.VariableAppraisals;

namespace RatStatsChallenge.Module.Interface.ViewModels.VariableAppraisals
{
    public class StratifiedViewModel : BindableBase, INavigationAware
    {
        private readonly IRegionManager MyRegionManager;

        private StratifiedVariableAppraisalDataset DS;
        private StratifiedVariableAppraisal SDS;
        public StratifiedViewModel(IRegionManager regionManager)
        {
            this.MyRegionManager = regionManager;
            this.SelectDataFileCommand = new DelegateCommand<object>(this.OnSelectDataFileCommand);
            this.SelectUniverseFileCommand = new DelegateCommand<object>(this.OnSelectUniverseFileCommand);
        }
        public virtual bool IsNavigationTarget(NavigationContext navigationContext)
        {
            return true;
        }

        public virtual void OnNavigatedFrom(NavigationContext navigationContext)
        {

        }

        public virtual void OnNavigatedTo(NavigationContext navigationContext)
        {
            string SourceViewName = "";
            if (navigationContext.Parameters != null && navigationContext.Parameters["SourceViewName"] != null)
            {
                SourceViewName = navigationContext.Parameters["SourceViewName"].ToString();
                if (SourceViewName == "VariableAppraisals.StratifiedReportView")
                    return;
            }
            ResetFields();
        }

        public void ResetFields()
        {
            SelectedUniverseSpreadsheet = "";
            SelectedDataSpreadsheet = "";
            UniverseFileSpreadsheets = new List<string>();
            DataFileSpreadsheets = new List<string>();
            AuditReviewTitle = "";
            NumberOfStrata = 0;
            DataFileSelectedFileType = SupportedFileType.Unknown;
            UniverseFileSelectedFileType = SupportedFileType.Unknown;
            SelectedDataFileFormatType = DataFileFormatType.Unknown;
            SecondDataCellVisible = false;
            DataFirstCellText = "";
            DataSecondCellText = "";
            DataFirstFieldText = "";
            DataSecondFieldText = "";
            DataFileInputPath = "";
            UniverseFileInputPath = "";
            DataFileHasHeaders = false;
            UniverseFileHasHeaders = false;
            DataFirstCell = "";
            DataSecondCell = "";
            SystemAssignedStratumCounter = false;
            StratumCounterColumn = 1;
            UniverseSizeColumn = 2;
            SampleSizeColumn = 3;
            Excel_UniverseSpreadsheet = "";
            StratumCounterCell = "";
            UniverseSizeCell = "";
            SampleSizeCell = "";
            DataFirstColumn = 1;
            DataSecondColumn = 2;
            TextFileOutputPath = "";
            TextFileOutput = false;
            ExcelFileOutputPath = "";
            ExcelFileOutput = false;
            Errors = new List<ReadyToProceedError>();
        }

        public void GoHome()
        {
            ResetFields();
            MyRegionManager.RequestNavigate("PrimaryPageRegion", "HomePageView");
        }

        private int PrevDataFilterIndex = 1;
        public ICommand SelectDataFileCommand { get; private set; }
        private void OnSelectDataFileCommand(object arg)
        {
            OpenFileDialog FileDialog = new OpenFileDialog();
            FileDialog.DefaultExt = "txt";
            FileDialog.AddExtension = true;

            FileDialog.FilterIndex = PrevDataFilterIndex;
            FileDialog.Filter = "Text File (.txt)|*.txt|Dat File (*.dat)|*dat| Comma Delimited (.csv)|*.csv| Excel (.xlsx) |*.xlsx";
            if (FileDialog.ShowDialog() == true)
            {
                PrevDataFilterIndex = FileDialog.FilterIndex;
                DataFileInputPath = FileDialog.FileName;
                switch (System.IO.Path.GetExtension(DataFileInputPath))
                {
                    case ".txt":
                        DataFileSelectedFileType = SupportedFileType.TXT;
                        Data_File_Text_Options_Visible = true;
                        Data_File_Excel_Options_Visible = false;
                        break;
                    case ".dat":
                        DataFileSelectedFileType = SupportedFileType.DAT;
                        Data_File_Text_Options_Visible = true;
                        Data_File_Excel_Options_Visible = false;
                        break;
                    case ".csv":
                        DataFileSelectedFileType = SupportedFileType.CSV;
                        Data_File_Text_Options_Visible = true;
                        Data_File_Excel_Options_Visible = false;
                        break;
                    case ".xlsx":
                        DataFileSelectedFileType = SupportedFileType.XLSX;
                        Data_File_Text_Options_Visible = false;
                        Data_File_Excel_Options_Visible = true;
                        DataFileLoadExcelSheets();
                        break;
                    default:
                        DataFileSelectedFileType = SupportedFileType.Unknown;
                        Data_File_Text_Options_Visible = false;
                        Data_File_Excel_Options_Visible = false;
                        break;
                }
            }
            else
            {
                DataFileInputPath = "";
                DataFileSelectedFileType = SupportedFileType.Unknown;
                return;
            }
        }

        private string _SelectedUniverseSpreadsheet = "";
        public string SelectedUniverseSpreadsheet
        {
            get { return _SelectedUniverseSpreadsheet; }
            set { SetProperty(ref _SelectedUniverseSpreadsheet, value); }
        }

        private string _SelectedDataSpreadsheet = "";
        public string SelectedDataSpreadsheet
        {
            get { return _SelectedDataSpreadsheet; }
            set { SetProperty(ref _SelectedDataSpreadsheet, value); }
        }

        public void DataFileLoadExcelSheets()
        {
            Excel.Workbook workbook = ExcelAppInterface.excelApp.Workbooks.Open(_DataFileInputPath, null, true);
            List<string> SpreadsheetList = new List<string>();
            foreach (Excel.Worksheet displayWorksheet in workbook.Worksheets)
            {
                SpreadsheetList.Add(displayWorksheet.Name);
            }
            DataFileSpreadsheets = SpreadsheetList;
            if (_DataFileSpreadsheets.Count > 0)
                SelectedDataSpreadsheet = _DataFileSpreadsheets[0];
            workbook.Close();
        }

        public void UniverseFileLoadExcelSheets()
        {
            Excel.Workbook workbook = ExcelAppInterface.excelApp.Workbooks.Open(_UniverseFileInputPath, null, true);
            List<string> SpreadsheetList = new List<string>();
            foreach (Excel.Worksheet displayWorksheet in workbook.Worksheets)
            {
                SpreadsheetList.Add(displayWorksheet.Name);
            }
            UniverseFileSpreadsheets = SpreadsheetList;
            if (_UniverseFileSpreadsheets.Count > 0)
                SelectedUniverseSpreadsheet = _UniverseFileSpreadsheets[0];
            workbook.Close();
        }


        private List<string> _UniverseFileSpreadsheets = new List<string>();
        public List<string> UniverseFileSpreadsheets
        {
            get { return _UniverseFileSpreadsheets; }
            set { SetProperty(ref _UniverseFileSpreadsheets, value); }
        }

        private List<string> _DataFileSpreadsheets = new List<string>();
        public List<string> DataFileSpreadsheets
        {
            get { return _DataFileSpreadsheets; }
            set { SetProperty(ref _DataFileSpreadsheets, value); }
        }
        public ICommand SelectUniverseFileCommand { get; private set; }
        private void OnSelectUniverseFileCommand(object arg)
        {
            OpenFileDialog FileDialog = new OpenFileDialog();
            FileDialog.DefaultExt = ".csv";
            FileDialog.AddExtension = true;
            FileDialog.Filter = "Text File (.txt)|*.txt|Dat File (*.dat)|*dat| Comma Delimited (.csv)|*.csv| Excel (.xlsx) |*.xlsx";
            if (FileDialog.ShowDialog() == true)
            {
                UniverseFileInputPath = FileDialog.FileName;
                switch (System.IO.Path.GetExtension(UniverseFileInputPath))
                {
                    case ".txt":
                        UniverseFileSelectedFileType = SupportedFileType.TXT;
                        Universe_File_Text_Options_Visible = true;
                        Universe_File_Excel_Options_Visible = false;
                        break;
                    case ".dat":
                        UniverseFileSelectedFileType = SupportedFileType.DAT;
                        Universe_File_Text_Options_Visible = true;
                        Universe_File_Excel_Options_Visible = false;
                        break;
                    case ".csv":
                        UniverseFileSelectedFileType = SupportedFileType.CSV;
                        Universe_File_Text_Options_Visible = true;
                        Universe_File_Excel_Options_Visible = false;
                        break;
                    case ".xlsx":
                        UniverseFileSelectedFileType = SupportedFileType.XLSX;
                        Universe_File_Text_Options_Visible = false;
                        Universe_File_Excel_Options_Visible = true;
                        UniverseFileLoadExcelSheets();
                        break;
                    default:
                        UniverseFileSelectedFileType = SupportedFileType.Unknown;
                        Universe_File_Text_Options_Visible = false;
                        Universe_File_Excel_Options_Visible = false;
                        break;
                }
            }
            else
            {
                UniverseFileInputPath = "";
                return;
            }
        }

        private List<ReadyToProceedError> _Errors = new List<ReadyToProceedError>();
        public List<ReadyToProceedError> Errors
        {
            get { return _Errors; }
            set { SetProperty(ref _Errors, value); }
        }

        private string _AuditReviewTitle = "";
        public string AuditReviewTitle
        {
            get { return _AuditReviewTitle; }
            set { SetProperty(ref _AuditReviewTitle, value); }
        }

        private int _NumberOfStrata;
        public int NumberOfStrata
        {
            get { return _NumberOfStrata; }
            set { SetProperty(ref _NumberOfStrata, value); }
        }

        private SupportedFileType _DataFileSelectedFileType = SupportedFileType.Unknown;
        public SupportedFileType DataFileSelectedFileType
        {
           get { return _DataFileSelectedFileType; }
           set { SetProperty(ref _DataFileSelectedFileType, value); }
        }

        private SupportedFileType _UniverseFileSelectedFileType = SupportedFileType.Unknown;
        public SupportedFileType UniverseFileSelectedFileType
        {
            get { return _UniverseFileSelectedFileType; }
            set { SetProperty(ref _UniverseFileSelectedFileType, value); }
        }

        private DataFileFormatType _SelectedDataFileFormatType = DataFileFormatType.Unknown;
        public DataFileFormatType SelectedDataFileFormatType
        {
            get { return _SelectedDataFileFormatType; }
            set { SetProperty(ref _SelectedDataFileFormatType, value);
                switch (value)
                {
                    case DataFileFormatType.Examined:
                        DataFirstCellText = "Examined Cell";
                        DataFirstFieldText = "Examined Column #";
                        SecondDataCellVisible = false;
                        break;
                    case DataFileFormatType.Audited:
                        DataFirstCellText = "Audited Cell";
                        DataFirstFieldText = "Audited Column #";
                        SecondDataCellVisible = false;
                        break;
                    case DataFileFormatType.Difference:
                        DataFirstCellText = "Difference Cell";
                        DataFirstFieldText = "Difference Column #";
                        SecondDataCellVisible = false;
                        break;
                    case DataFileFormatType.ExaminedAudited:
                        DataFirstCellText = "Examined Cell";
                        DataSecondCellText = "Audited Cell";
                        DataFirstFieldText = "Examined Column #";
                        DataSecondFieldText = "Audited Column #";
                        SecondDataCellVisible = true;
                        break;
                    case DataFileFormatType.ExaminedDifference:
                        DataFirstCellText = "Examined Cell";
                        DataSecondCellText = "Difference Cell";
                        DataFirstFieldText = "Examined Column #";
                        DataSecondFieldText = "Difference Column #";
                        SecondDataCellVisible = true;
                        break;
                    case DataFileFormatType.AuditedDifference:
                        DataFirstCellText = "Audited Cell";
                        DataSecondCellText = "Difference Cell";
                        DataFirstFieldText = "Audited Column #";
                        DataSecondFieldText = "Difference Column #";
                        SecondDataCellVisible = true;
                        break;
                }
            }
        }

        private bool _Data_File_Text_Options_Visible = false;
        public bool Data_File_Text_Options_Visible
        {
            get { return _Data_File_Text_Options_Visible;}
            set { SetProperty(ref _Data_File_Text_Options_Visible, value); }
        }

        private bool _Data_File_Excel_Options_Visible = false;
        public bool Data_File_Excel_Options_Visible
        {
            get { return _Data_File_Excel_Options_Visible; }
            set { SetProperty(ref _Data_File_Excel_Options_Visible, value); }
        }

        private bool _Universe_File_Text_Options_Visible = false;
        public bool Universe_File_Text_Options_Visible
        {
            get { return _Universe_File_Text_Options_Visible; }
            set { SetProperty(ref _Universe_File_Text_Options_Visible, value); }
        }

        private bool _Universe_File_Excel_Options_Visible = false;
        public bool Universe_File_Excel_Options_Visible
        {
            get { return _Universe_File_Excel_Options_Visible; }
            set { SetProperty(ref _Universe_File_Excel_Options_Visible, value); }
        }

        private bool _SecondDataCellVisible = false;
        public bool SecondDataCellVisible
        {
            get { return _SecondDataCellVisible; }
            set { SetProperty(ref _SecondDataCellVisible, value); }
        }

        private string _DataFirstCellText = "";
        public string DataFirstCellText
        {
            get { return _DataFirstCellText; }
            set { SetProperty(ref _DataFirstCellText, value); }
        }

        private string _DataFirstFieldText = "";
        public string DataFirstFieldText
        {
            get { return _DataFirstFieldText; }
            set { SetProperty(ref _DataFirstFieldText, value); }
        }

        private string _DataSecondFieldText = "";
        public string DataSecondFieldText
        {
            get { return _DataSecondFieldText; }
            set { SetProperty(ref _DataSecondFieldText, value); }
        }

        private string _DataSecondCellText = "";
        public string DataSecondCellText
        {
            get { return _DataSecondCellText; }
            set { SetProperty(ref _DataSecondCellText, value); }
        }


        private string _DataFileInputPath = "";
        public string DataFileInputPath
        {
            get { return _DataFileInputPath; }
            set { SetProperty(ref _DataFileInputPath, value); }
        }

        private string _UniverseFileInputPath = "";
        public string UniverseFileInputPath
        {
            get { return _UniverseFileInputPath; }
            set { SetProperty(ref _UniverseFileInputPath, value); }
        }

        private bool _DataFileHasHeaders = false;
        public bool DataFileHasHeaders
        {
            get { return _DataFileHasHeaders; }
            set { SetProperty(ref _DataFileHasHeaders, value); }
        }


        private bool _UniverseFileHasHeaders = false;
        public bool UniverseFileHasHeaders
        {
            get { return _UniverseFileHasHeaders; }
            set { SetProperty(ref _UniverseFileHasHeaders, value); }
        }


        private string _DataFirstCell = "";
        public string DataFirstCell
        {
            get { return _DataFirstCell; }
            set { SetProperty(ref _DataFirstCell, value); }

        }

        private string _DataSecondCell = "";
        public string DataSecondCell
        {
            get { return _DataSecondCell; }
            set { SetProperty(ref _DataSecondCell, value); }

        }


        private bool _SystemAssignedStratumCounter = false;
        public bool SystemAssignedStratumCounter
        {
            get { return _SystemAssignedStratumCounter; }
            set { SetProperty(ref _SystemAssignedStratumCounter, value); }
        }

        private int _StratumCounterColumn = 1;
        public int StratumCounterColumn
        {
            get { return _StratumCounterColumn; }
            set { SetProperty(ref _StratumCounterColumn, value); }
        }

        private int _UniverseSizeColumn = 2;
        public int UniverseSizeColumn
        {
            get { return _UniverseSizeColumn; }
            set { SetProperty(ref _UniverseSizeColumn, value); }
        }

        private int _SampleSizeColumn = 3;
        public int SampleSizeColumn
        {
            get { return _SampleSizeColumn; }
            set { SetProperty(ref _SampleSizeColumn, value); }
        }


        private string _Excel_UniverseSpreadsheet = "";
        public string Excel_UniverseSpreadsheet
        {
            get { return _Excel_UniverseSpreadsheet; }
            set { SetProperty(ref _Excel_UniverseSpreadsheet, value); }
        }

        private string _StratumCounterCell = "";
        public string StratumCounterCell
        {
            get { return _StratumCounterCell; }
            set { SetProperty(ref _StratumCounterCell, value); }
        }

        private string _UniverseSizeCell = "";
        public string UniverseSizeCell
        {
            get { return _UniverseSizeCell; }
            set { SetProperty(ref _UniverseSizeCell, value); }
        }

        private string _SampleSizeCell = "";
        public string SampleSizeCell
        {
            get { return _SampleSizeCell; }
            set { SetProperty(ref _SampleSizeCell, value); }
        }

        private int _DataFirstColumn = 1;
        public int DataFirstColumn
        {
            get { return _DataFirstColumn; }
            set { SetProperty(ref _DataFirstColumn, value); }
        }

        private int _DataSecondColumn = 2;
        public int DataSecondColumn
        {
            get { return _DataSecondColumn; }
            set { SetProperty(ref _DataSecondColumn, value); }
        }

        private string _TextFileOutputPath = "";
        public string TextFileOutputPath
        {
            get { return _TextFileOutputPath; }
            set { SetProperty(ref _TextFileOutputPath, value); }
        }

        private bool _TextFileOutput = false;
        public bool TextFileOutput
        {
            get { return _TextFileOutput; }
            set
            {
                if (!_TextFileOutput && value)
                {
                    SaveFileDialog FileDialog = new SaveFileDialog();
                    FileDialog.DefaultExt = ".txt";
                    FileDialog.AddExtension = true;
                    FileDialog.Filter = "Text File (*.txt)|*txt";
                    if (FileDialog.ShowDialog() == true)
                    {
                        TextFileOutputPath = FileDialog.FileName;
                    }
                    else
                    {
                        TextFileOutputPath = "";
                        return;
                    }
                }
                else
                    TextFileOutputPath = "";
                SetProperty(ref _TextFileOutput, value);
            }
        }

        private string _ExcelFileOutputPath = "";
        public string ExcelFileOutputPath
        {
            get { return _ExcelFileOutputPath; }
            set { SetProperty(ref _ExcelFileOutputPath, value); }
        }

        private bool _ExcelFileOutput = false;
        public bool ExcelFileOutput
        {
            get { return _ExcelFileOutput; }
            set
            {
                if (!_ExcelFileOutput && value)
                {
                    SaveFileDialog FileDialog = new SaveFileDialog();
                    FileDialog.DefaultExt = ".xlsx";
                    FileDialog.AddExtension = true;
                    FileDialog.Filter = "Excel |*.xlsx";
                    if (FileDialog.ShowDialog() == true)
                    {
                        ExcelFileOutputPath = FileDialog.FileName;
                    }
                    else
                    {
                        ExcelFileOutputPath = "";
                        return;
                    }
                }
                else
                    ExcelFileOutputPath = "";
                SetProperty(ref _ExcelFileOutput, value);
            }
        }

        public bool ReadyToProceed()
        {

            _Errors = new List<ReadyToProceedError>();
            bool result = true;
            
            if(DataFileSelectedFileType == SupportedFileType.TXT || DataFileSelectedFileType == SupportedFileType.DAT || DataFileSelectedFileType == SupportedFileType.CSV)
            {
                //Verify Data File Selections
                if (SecondDataCellVisible && _DataFirstColumn == _DataSecondColumn)
                {
                    switch (SelectedDataFileFormatType)
                    {
                        case DataFileFormatType.ExaminedAudited:
                            _Errors.Add(new ReadyToProceedError("DataFirstColumnTextBox", "The Examined Cell and Audited Cell cannot be the same column."));
                            _Errors.Add(new ReadyToProceedError("DataSecondColumnTextBox", ""));
                            break;
                        case DataFileFormatType.AuditedDifference:
                            _Errors.Add(new ReadyToProceedError("DataFirstColumnTextBox", "The Audited Cell and Difference Cell cannot be the same column."));
                            _Errors.Add(new ReadyToProceedError("DataSecondColumnTextBox", ""));
                            break;
                        case DataFileFormatType.ExaminedDifference:
                            _Errors.Add(new ReadyToProceedError("DataFirstColumnTextBox", "The Examined Cell and Difference Cell cannot be the same column."));
                            _Errors.Add(new ReadyToProceedError("DataSecondColumnTextBox", ""));
                            break;
                    }
                    result = false;
                }
            }
            if (DataFileSelectedFileType == SupportedFileType.XLSX)
            {
                //Verify Excel File Selections
                Excel.Workbook workbook = ExcelAppInterface.excelApp.Workbooks.Open(_DataFileInputPath, null, true);
                Excel.Worksheet worksheet = workbook.Worksheets[_SelectedDataSpreadsheet];
                Excel.Range UsedCells = worksheet.UsedRange.Columns;
                Excel.Range FDCell = null, SDCell = null;
                int FDCellRow = -1, SDCellRow = -1;
                
                bool ValidFDCell = false;
                try
                {
                    FDCell = worksheet.Range[_DataFirstCell];
                    Excel.Range InRange = UsedCells.Application.Intersect(UsedCells, FDCell);
                    
                    if (InRange == null)
                    {
                        
                        switch (SelectedDataFileFormatType)
                        {
                            case DataFileFormatType.Examined:
                            case DataFileFormatType.ExaminedAudited:
                            case DataFileFormatType.ExaminedDifference:
                                _Errors.Add(new ReadyToProceedError("DataFirstCell", "Examined Cell is not within the range of data in spreadsheet"));
                                break;
                            case DataFileFormatType.Audited:
                            case DataFileFormatType.AuditedDifference:
                                _Errors.Add(new ReadyToProceedError("DataFirstCell", "Audited Cell is not within the range of data in spreadsheet"));
                                break;
                            case DataFileFormatType.Difference:
                                _Errors.Add(new ReadyToProceedError("DataFirstCell", "Difference Cell is not within the range of data in spreadsheet"));
                                break;
                        }
                        result = false;
                    }
                    ValidFDCell = true;
                    FDCellRow = FDCell.Row;
                }
                catch (Exception)
                {
                    //Invalid Cell Identifier
                    switch (SelectedDataFileFormatType)
                    {
                        case DataFileFormatType.Examined:
                        case DataFileFormatType.ExaminedAudited:
                        case DataFileFormatType.ExaminedDifference:
                            _Errors.Add(new ReadyToProceedError("DataFirstCell", "Invalid Examined Cell"));
                            break;
                        case DataFileFormatType.Audited:
                        case DataFileFormatType.AuditedDifference:
                            _Errors.Add(new ReadyToProceedError("DataFirstCell", "Invalid Audited Cell"));
                            break;
                        case DataFileFormatType.Difference:
                            _Errors.Add(new ReadyToProceedError("DataFirstCell", "Invalid Difference Cell"));
                            break;
                    }
                    result = false;
                }
                if(SecondDataCellVisible)
                {
                    try
                    {
                        SDCell = worksheet.Range[_DataSecondCell];
                        Excel.Range InRange = UsedCells.Application.Intersect(UsedCells, SDCell);
                        if (InRange == null)
                        {
                            switch (SelectedDataFileFormatType)
                            {
                                case DataFileFormatType.ExaminedAudited:
                                    _Errors.Add(new ReadyToProceedError("DataSecondCell", "Audited Cell is not within the range of data in spreadsheet"));
                                    break;
                                case DataFileFormatType.AuditedDifference:
                                case DataFileFormatType.ExaminedDifference:
                                    _Errors.Add(new ReadyToProceedError("DataSecondCell", "Difference Cell is not within the range of data in spreadsheet"));
                                    break;
                            }
                            result = false;
                        }

                        SDCellRow = SDCell.Row;
                        if (FDCell != null && _DataFirstCell == _DataSecondCell)
                        {
                            switch (SelectedDataFileFormatType)
                            {
                                case DataFileFormatType.ExaminedAudited:
                                    _Errors.Add(new ReadyToProceedError("DataFirstCell", "The Examined Cell and Audited Cell cannot be the same cell."));
                                    _Errors.Add(new ReadyToProceedError("DataSecondCell", ""));
                                    break;
                                case DataFileFormatType.AuditedDifference:
                                    _Errors.Add(new ReadyToProceedError("DataFirstCell", "The Audited Cell and Difference Cell cannot be the same cell."));
                                    break;
                                case DataFileFormatType.ExaminedDifference:
                                    _Errors.Add(new ReadyToProceedError("DataFirstCell", "The Examined Cell and Difference Cell cannot be the same cell."));
                                    break;
                            }
                            
                            result = false;
                        }
                        if (ValidFDCell && FDCellRow != SDCellRow)
                        {
                            switch (SelectedDataFileFormatType)
                            {
                                case DataFileFormatType.ExaminedAudited:
                                    _Errors.Add(new ReadyToProceedError("DataFirstCell", "The Examined Cell and Audited Cell must be on the same row."));
                                    _Errors.Add(new ReadyToProceedError("DataSecondCell", ""));
                                    break;
                                case DataFileFormatType.AuditedDifference:
                                    _Errors.Add(new ReadyToProceedError("DataFirstCell", "The Audited Cell and Difference Cell must be on the same row."));
                                    _Errors.Add(new ReadyToProceedError("DataSecondCell", ""));
                                    break;
                                case DataFileFormatType.ExaminedDifference:
                                    _Errors.Add(new ReadyToProceedError("DataFirstCell", "The Examined Cell and Difference Cell must be on the same row."));
                                    _Errors.Add(new ReadyToProceedError("DataSecondCell", ""));
                                    break;
                            }
                            result = false;
                        }
                    }
                    catch (Exception)
                    {
                        //Invalid Cell Identifier
                        switch (SelectedDataFileFormatType)
                        {
                            case DataFileFormatType.ExaminedAudited:
                                _Errors.Add(new ReadyToProceedError("DataSecondCell", "Invalid Audited Cell"));
                                break;
 
                            case DataFileFormatType.AuditedDifference:
                            case DataFileFormatType.ExaminedDifference:
                                _Errors.Add(new ReadyToProceedError("DataSecondCell", "Invalid Difference Cell"));
                                break;
                        }
                        result = false;
                    }
                }
                worksheet = null;
                workbook.Close();
            }

            //Verify Universe File Selections
            if (UniverseFileSelectedFileType == SupportedFileType.TXT || UniverseFileSelectedFileType == SupportedFileType.DAT || UniverseFileSelectedFileType == SupportedFileType.CSV)
            {
                //Verify Data File Selections
                if (!SystemAssignedStratumCounter && (StratumCounterColumn == UniverseSizeColumn || StratumCounterColumn == SampleSizeColumn))
                {
                    _Errors.Add(new ReadyToProceedError("StratumCounterColumnTextBox", "The Stratum/Counter column cannot be the same as the universe or sample sizes columns."));
                    result = false;
                }
                if(UniverseSizeColumn == SampleSizeColumn)
                {
                    _Errors.Add(new ReadyToProceedError("UniverseSizeColumnTextBox", "The universe column cannot be the same as th sample sizes columns."));
                    _Errors.Add(new ReadyToProceedError("SampleSizeColumnTextBox", ""));
                    result = false;
                }
            }
            if (UniverseFileSelectedFileType == SupportedFileType.XLSX)
            {
                Excel.Workbook workbook = ExcelAppInterface.excelApp.Workbooks.Open(_UniverseFileInputPath, null, true);
                Excel.Worksheet worksheet = workbook.Worksheets[_SelectedUniverseSpreadsheet];
                Excel.Range UsedCells = worksheet.UsedRange.Columns;
                int UniverseCellRow = -1, SampleSizeCellRow = -1, StratumCounterCellRow = -1;
                bool ValidUniversSizeCell = false;
                Excel.Range UCell = null, SCell = null, SCCell = null;
                try
                {
                    UCell = worksheet.Range[_UniverseSizeCell];
                    Excel.Range InRange = UsedCells.Application.Intersect(UsedCells, UCell);
                    if (InRange == null)
                    {
                        _Errors.Add(new ReadyToProceedError("UniverseSizeCell", "Universe Size Cell is not within the range of data in spreadsheet"));
                        result = false;
                    }
                    ValidUniversSizeCell = true;
                    UniverseCellRow = UCell.Row;
                }
                catch (Exception)
                {
                    //Invalid Cell Identifier
                    _Errors.Add(new ReadyToProceedError("UniverseSizeCell", "Invalid Universe Size Cell"));
                    result = false;
                }

                try
                {
                    SCell = worksheet.Range[_SampleSizeCell];

                    Excel.Range InRange = UsedCells.Application.Intersect(UsedCells, SCell);
                    if (InRange == null)
                    {
                        _Errors.Add(new ReadyToProceedError("SampleSizeCell", "Sample Size Cell is not within the range of data in spreadsheet"));
                        result = false;
                    }
                    SampleSizeCellRow = SCell.Row;
                    if (UCell != null && _UniverseSizeCell == _SampleSizeCell)
                    {
                        _Errors.Add(new ReadyToProceedError("UniverseSizeCell", "The Universe Size Cell and Sample Size Cell cannot be the same cell."));
                        _Errors.Add(new ReadyToProceedError("SampleSizeCell", ""));
                        result = false;
                    }
                    if (ValidUniversSizeCell && UniverseCellRow != SampleSizeCellRow)
                    {
                        _Errors.Add(new ReadyToProceedError("UniverseSizeCell", "The Universe Size Cell and Sample Size Cell must be on the same row."));
                        _Errors.Add(new ReadyToProceedError("SampleSizeCell", ""));
                        result = false;
                    }
                }
                catch (Exception)
                {
                    //Invalid Cell Identifier
                    _Errors.Add(new ReadyToProceedError("SampleSizeCell", "Invalid Sample Size Cell"));
                    result = false;
                }
                if (!SystemAssignedStratumCounter)
                {
                    try
                    {
                        SCCell = worksheet.Range[_StratumCounterCell];

                        Excel.Range InRange = UsedCells.Application.Intersect(UsedCells, SCCell);
                        if (InRange == null)
                        {
                            _Errors.Add(new ReadyToProceedError("StratumCounterCell", "Stratum/Counter Cell is not within the range of data in spreadsheet"));
                            result = false;
                        }
                        StratumCounterCellRow = SCCell.Row;
                        if (UCell != null && _UniverseSizeCell == _StratumCounterCell)
                        {
                            _Errors.Add(new ReadyToProceedError("UniverseSizeCell", "The Universe Size Cell and the Stratum/Counter Cell cannot be the same cell."));
                            _Errors.Add(new ReadyToProceedError("StratumCounterCell", ""));
                            result = false;
                        }
                        if (ValidUniversSizeCell && UniverseCellRow != StratumCounterCellRow)
                        {
                            _Errors.Add(new ReadyToProceedError("StratumCounterCell", "The Stratum/Counter Cell and Universe Size Cell must be on the same row."));
                            _Errors.Add(new ReadyToProceedError("UniverseSizeCell", ""));
                            result = false;
                        }

                    }
                    catch (Exception)
                    {
                        //Invalid Cell Identifier
                        _Errors.Add(new ReadyToProceedError("StratumCounterCell", "Invalid Stratum/Counter Cell"));
                        result = false;
                    }
                }

                worksheet = null;
                workbook.Close();
            }


            if (_NumberOfStrata == 0)
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("NumberOfStrata", "Number of Strata must be greater than zero."));
            }
            if (_NumberOfStrata == 1)
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("NumberOfStrata", "Number of Strata must be at least two."));
            }
            if (_NumberOfStrata > 50)
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("NumberOfStrata", "Number of Strata cannot exceed fifty."));
            }
            if (SelectedDataFileFormatType == DataFileFormatType.Unknown)
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("SelectedDataFileFormatType", "You must select a data file format."));
            }
            if (DataFileInputPath.Length == 0)
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("DataFileInputPath", "You must select a data file."));
            }
            if (UniverseFileInputPath.Length == 0)
            {
                result = false;
                _Errors.Add(new ReadyToProceedError("UniverseFileInputPath", "You must select a Universe data file."));
            }
            OnPropertyChanged("Errors");
            return result;
        }
        public void Process()
        {
            if (DataFileSelectedFileType == SupportedFileType.TXT || DataFileSelectedFileType == SupportedFileType.DAT || DataFileSelectedFileType == SupportedFileType.CSV)
            {
                ProcessDataTextFile();
            }
            else if (DataFileSelectedFileType == SupportedFileType.XLSX)
            {
                ProcessDataExcelFile();
            }
            SDS = new StratifiedVariableAppraisal();
            SDS.AuditReviewName = _AuditReviewTitle;
            SDS.SelectedDataFileFormat = SelectedDataFileFormatType;
            SDS.OverallSampleSize = DS.SampleSize;
            SDS.OverallAuditedGroup = DS.AuditedGroup;
            SDS.OverallDifferenceGroup = DS.DifferenceGroup;
            SDS.OverallExaminedGroup = DS.ExaminedGroup;
            SDS.TextFileOutput = _TextFileOutput;
            SDS.TextFileOutputPath = _TextFileOutputPath;
            SDS.ExcelFileOutput = ExcelFileOutput;
            SDS.ExcelFileOutputPath = ExcelFileOutputPath;
            SDS.DataFileInputPath = _DataFileInputPath;
            SDS.UniverseFileInputPath = _UniverseFileInputPath;
            SDS.LogTime = DateTime.Now;
            
            if (UniverseFileSelectedFileType == SupportedFileType.TXT || UniverseFileSelectedFileType == SupportedFileType.DAT || UniverseFileSelectedFileType == SupportedFileType.CSV)
            {
                ProcessUniverseTextFile();
            }
            else if(UniverseFileSelectedFileType == SupportedFileType.XLSX)
                ProcessUniverseExcelFile();

            if (TextFileOutput)
            {
                Stratified_TXT page = new Stratified_TXT(SDS);
                String pageContent = page.TransformText();
                System.IO.File.WriteAllText(TextFileOutputPath, pageContent);
            }
            
            var parameters = new NavigationParameters();
                parameters.Add("ReportData", SDS);
                this.MyRegionManager.RequestNavigate("PrimaryPageRegion", "VariableAppraisals.StratifiedReportView", parameters);

            if (ExcelFileOutput)
            {
                try
                {
                    SDS.ExportToExcel();
                }
                catch (Exception Ex)
                {
                    throw new Exception(Ex.Message, Ex);
                }
            }
        }

        public void ProcessDataTextFile()
        {
            DS = new StratifiedVariableAppraisalDataset();
            TextFieldParser TFP = new TextFieldParser(_DataFileInputPath);
            TFP.TextFieldType = FieldType.Delimited;
            if (DataFileSelectedFileType == SupportedFileType.CSV)
                TFP.Delimiters = new string[] { "," };
            else
                TFP.Delimiters = new string[] { " ", "\t" };

            string[] Fields;
            int RowIndex = 1;

            while (!TFP.EndOfData)
            {
                try
                {
                    TFP.TrimWhiteSpace = true;
                    Fields = TFP.ReadFields();
                    //Remove Any Empty Fields
                    Fields = Fields.Where(a => a != "").ToArray();
                    if (RowIndex > 1 || !_DataFileHasHeaders)
                    {
                        string value;
                        UnrestrictedVariableAppraisalDataRow DR = new UnrestrictedVariableAppraisalDataRow();
                        switch (SelectedDataFileFormatType)
                        {
                            case DataFileFormatType.Examined:
                                value = Fields[DataFirstColumn - 1];
                                if (value == "$-")
                                    value = "$0";
                                DR.ExaminedValue = double.Parse(value, System.Globalization.NumberStyles.Any);
                                DS.ExaminedGroup.Group_Sum += DR.ExaminedValue;
                                DS.ExaminedGroup.Group_Sqr += Math.Pow(DR.ExaminedValue, 2.0);
                                DS.ExaminedGroup.Group_Cube += Math.Pow(DR.ExaminedValue, 3.0);
                                DS.ExaminedGroup.Group_Quad += Math.Pow(DR.ExaminedValue, 4.0);
                                if (DR.ExaminedValue != 0)
                                    DS.ExaminedGroup.Group_NonZero++;
                                break;
                            case DataFileFormatType.Audited:
                                value = Fields[DataFirstColumn - 1];
                                if (value == "$-")
                                    value = "$0";
                                DR.AuditedValue = double.Parse(value, System.Globalization.NumberStyles.Any);
                                DS.AuditedGroup.Group_Sum += DR.AuditedValue;
                                DS.AuditedGroup.Group_Sqr += Math.Pow(DR.AuditedValue, 2.0);
                                DS.AuditedGroup.Group_Cube += Math.Pow(DR.AuditedValue, 3.0);
                                DS.AuditedGroup.Group_Quad += Math.Pow(DR.AuditedValue, 4.0);
                                if (DR.AuditedValue != 0)
                                    DS.AuditedGroup.Group_NonZero++;
                                break;
                            case DataFileFormatType.Difference:
                                value = Fields[DataFirstColumn - 1];
                                if (value == "$-")
                                    value = "$0";
                                DR.DifferenceValue = double.Parse(value, System.Globalization.NumberStyles.Any);
                                DS.DifferenceGroup.Group_Sum += DR.DifferenceValue;
                                DS.DifferenceGroup.Group_Sqr += Math.Pow(DR.DifferenceValue, 2.0);
                                DS.DifferenceGroup.Group_Cube += Math.Pow(DR.DifferenceValue, 3.0);
                                DS.DifferenceGroup.Group_Quad += Math.Pow(DR.DifferenceValue, 4.0);
                                if (DR.DifferenceValue != 0)
                                    DS.DifferenceGroup.Group_NonZero++;
                                break;
                            case DataFileFormatType.ExaminedAudited:
                                value = Fields[DataFirstColumn - 1];
                                if (value == "$-")
                                    value = "$0";
                                DR.ExaminedValue = double.Parse(value, System.Globalization.NumberStyles.Any);
                                DS.ExaminedGroup.Group_Sum += DR.ExaminedValue;
                                DS.ExaminedGroup.Group_Sqr += Math.Pow(DR.ExaminedValue, 2.0);
                                DS.ExaminedGroup.Group_Cube += Math.Pow(DR.ExaminedValue, 3.0);
                                DS.ExaminedGroup.Group_Quad += Math.Pow(DR.ExaminedValue, 4.0);
                                if (DR.ExaminedValue != 0)
                                    DS.ExaminedGroup.Group_NonZero++;
                                value = Fields[DataSecondColumn - 1];
                                if (value == "$-")
                                    value = "$0";
                                DR.AuditedValue = double.Parse(value, System.Globalization.NumberStyles.Any);
                                DS.AuditedGroup.Group_Sum += DR.AuditedValue;
                                DS.AuditedGroup.Group_Sqr += Math.Pow(DR.AuditedValue, 2.0);
                                DS.AuditedGroup.Group_Cube += Math.Pow(DR.AuditedValue, 3.0);
                                DS.AuditedGroup.Group_Quad += Math.Pow(DR.AuditedValue, 4.0);
                                if (DR.AuditedValue != 0)
                                    DS.AuditedGroup.Group_NonZero++;
                                DR.DifferenceValue = DR.ExaminedValue - DR.AuditedValue;
                                DS.DifferenceGroup.Group_Sum += DR.DifferenceValue;
                                DS.DifferenceGroup.Group_Sqr += Math.Pow(DR.DifferenceValue, 2.0);
                                DS.DifferenceGroup.Group_Cube += Math.Pow(DR.DifferenceValue, 3.0);
                                DS.DifferenceGroup.Group_Quad += Math.Pow(DR.DifferenceValue, 4.0);
                                if (DR.DifferenceValue != 0)
                                    DS.DifferenceGroup.Group_NonZero++;
                                break;
                            case DataFileFormatType.ExaminedDifference:
                                value = Fields[DataFirstColumn - 1];
                                if (value == "$-")
                                    value = "$0";
                                DR.ExaminedValue = double.Parse(value, System.Globalization.NumberStyles.Any);
                                DS.ExaminedGroup.Group_Sum += DR.ExaminedValue;
                                DS.ExaminedGroup.Group_Sqr += Math.Pow(DR.ExaminedValue, 2.0);
                                DS.ExaminedGroup.Group_Cube += Math.Pow(DR.ExaminedValue, 3.0);
                                DS.ExaminedGroup.Group_Quad += Math.Pow(DR.ExaminedValue, 4.0);
                                if (DR.ExaminedValue != 0)
                                    DS.ExaminedGroup.Group_NonZero++;
                                value = Fields[DataSecondColumn - 1];
                                if (value == "$-")
                                    value = "$0";
                                DR.DifferenceValue = double.Parse(value, System.Globalization.NumberStyles.Any);
                                DS.DifferenceGroup.Group_Sum += DR.DifferenceValue;
                                DS.DifferenceGroup.Group_Sqr += Math.Pow(DR.DifferenceValue, 2.0);
                                DS.DifferenceGroup.Group_Cube += Math.Pow(DR.DifferenceValue, 3.0);
                                DS.DifferenceGroup.Group_Quad += Math.Pow(DR.DifferenceValue, 4.0);
                                if (DR.DifferenceValue != 0)
                                    DS.DifferenceGroup.Group_NonZero++;
                                DR.AuditedValue = DR.ExaminedValue - DR.DifferenceValue;
                                DS.AuditedGroup.Group_Sum += DR.AuditedValue;
                                DS.AuditedGroup.Group_Sqr += Math.Pow(DR.AuditedValue, 2.0);
                                DS.AuditedGroup.Group_Cube += Math.Pow(DR.AuditedValue, 3.0);
                                DS.AuditedGroup.Group_Quad += Math.Pow(DR.AuditedValue, 4.0);
                                if (DR.AuditedValue != 0)
                                    DS.AuditedGroup.Group_NonZero++;
                                break;
                            case DataFileFormatType.AuditedDifference:
                                value = Fields[DataFirstColumn - 1];
                                if (value == "$-")
                                    value = "$0";
                                DR.AuditedValue = double.Parse(value, System.Globalization.NumberStyles.Any);
                                DS.AuditedGroup.Group_Sum += DR.AuditedValue;
                                DS.AuditedGroup.Group_Sqr += Math.Pow(DR.AuditedValue, 2.0);
                                DS.AuditedGroup.Group_Cube += Math.Pow(DR.AuditedValue, 3.0);
                                DS.AuditedGroup.Group_Quad += Math.Pow(DR.AuditedValue, 4.0);
                                if (DR.AuditedValue != 0)
                                    DS.AuditedGroup.Group_NonZero++;
                                value = Fields[DataSecondColumn - 1];
                                if (value == "$-")
                                    value = "$0";
                                DR.DifferenceValue = double.Parse(value, System.Globalization.NumberStyles.Any);
                                DS.DifferenceGroup.Group_Sum += DR.DifferenceValue;
                                DS.DifferenceGroup.Group_Sqr += Math.Pow(DR.DifferenceValue, 2.0);
                                DS.DifferenceGroup.Group_Cube += Math.Pow(DR.DifferenceValue, 3.0);
                                DS.DifferenceGroup.Group_Quad += Math.Pow(DR.DifferenceValue, 4.0);
                                if (DR.DifferenceValue != 0)
                                    DS.DifferenceGroup.Group_NonZero++;
                                DR.ExaminedValue = DR.AuditedValue + DR.DifferenceValue;
                                DS.ExaminedGroup.Group_Sum += DR.ExaminedValue;
                                DS.ExaminedGroup.Group_Sqr += Math.Pow(DR.ExaminedValue, 2.0);
                                DS.ExaminedGroup.Group_Cube += Math.Pow(DR.ExaminedValue, 3.0);
                                DS.ExaminedGroup.Group_Quad += Math.Pow(DR.ExaminedValue, 4.0);
                                if (DR.ExaminedValue != 0)
                                    DS.ExaminedGroup.Group_NonZero++;
                                break;
                        }
                        DS.DataRows.Add(DR);
                    }
                    RowIndex++;
                }
                catch (FormatException)
                {
                    throw new Exception("Invalid Number in Row " + RowIndex + " of the data file. Correct the issue and try processing the data file again.");
                }
                catch (IndexOutOfRangeException)
                {
                    throw new Exception("Missing Data in Row " + RowIndex + " of the data file. Correct the issue and try processing the data file again.");
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }

            }
            DS.SampleSize = _DataFileHasHeaders != true ? RowIndex - 1 : RowIndex - 2;
            if (DS.SampleSize > 10000)
            {
                throw new Exception("Sample sizes in excess of 10,000 are not allowed.");
            }
            return;
        }

        public void ProcessDataExcelFile()
        {
            DS = new StratifiedVariableAppraisalDataset();
            Excel.Workbook workbook = ExcelAppInterface.excelApp.Workbooks.Open(_DataFileInputPath, null, true);
            Excel.Worksheet workSheet = workbook.Sheets[SelectedDataSpreadsheet];
            workSheet.Select(Type.Missing);

            Excel.Range DataFirstRange = workSheet.get_Range(DataFirstCell, System.Type.Missing);
            Excel.Range DataSecondRange = SecondDataCellVisible == true ? workSheet.get_Range(DataSecondCell, System.Type.Missing) : null;

            Excel.Range excelRange = workSheet.UsedRange;
            object[,] valueArray = (object[,])excelRange.get_Value(Excel.XlRangeValueDataType.xlRangeValueDefault);

            int RowCount = 0;
            bool ExitFor = false;
            for (int z = DataFirstRange.Row; z <= excelRange.Rows.Count; z++)
            {
                try
                {
                    UnrestrictedVariableAppraisalDataRow DR = new UnrestrictedVariableAppraisalDataRow();
                    switch (SelectedDataFileFormatType)
                    {
                        case DataFileFormatType.Examined:
                            if (valueArray[z, DataFirstRange.Column] == null)
                            {
                                ExitFor = true;
                                break;
                            }
                            DR.ExaminedValue = double.Parse(valueArray[z, DataFirstRange.Column].ToString(), System.Globalization.NumberStyles.Any);
                            DS.ExaminedGroup.Group_Sum += DR.ExaminedValue;
                            DS.ExaminedGroup.Group_Sqr += Math.Pow(DR.ExaminedValue, 2.0);
                            DS.ExaminedGroup.Group_Cube += Math.Pow(DR.ExaminedValue, 3.0);
                            DS.ExaminedGroup.Group_Quad += Math.Pow(DR.ExaminedValue, 4.0);
                            if (DR.ExaminedValue != 0)
                                DS.ExaminedGroup.Group_NonZero++;
                            break;
                        case DataFileFormatType.Audited:
                            if (valueArray[z, DataFirstRange.Column] == null)
                            {
                                ExitFor = true;
                                break;
                            }
                            DR.AuditedValue = double.Parse(valueArray[z, DataFirstRange.Column].ToString(), System.Globalization.NumberStyles.Any);
                            DS.AuditedGroup.Group_Sum += DR.AuditedValue;
                            DS.AuditedGroup.Group_Sqr += Math.Pow(DR.AuditedValue, 2.0);
                            DS.AuditedGroup.Group_Cube += Math.Pow(DR.AuditedValue, 3.0);
                            DS.AuditedGroup.Group_Quad += Math.Pow(DR.AuditedValue, 4.0);
                            if (DR.AuditedValue != 0)
                                DS.AuditedGroup.Group_NonZero++;
                            break;
                        case DataFileFormatType.Difference:
                            if (valueArray[z, DataFirstRange.Column] == null)
                            {
                                ExitFor = true;
                                break;
                            }
                            DR.DifferenceValue = double.Parse(valueArray[z, DataFirstRange.Column].ToString(), System.Globalization.NumberStyles.Any);
                            DS.DifferenceGroup.Group_Sum += DR.DifferenceValue;
                            DS.DifferenceGroup.Group_Sqr += Math.Pow(DR.DifferenceValue, 2.0);
                            DS.DifferenceGroup.Group_Cube += Math.Pow(DR.DifferenceValue, 3.0);
                            DS.DifferenceGroup.Group_Quad += Math.Pow(DR.DifferenceValue, 4.0);
                            if (DR.DifferenceValue != 0)
                                DS.DifferenceGroup.Group_NonZero++;
                            break;
                        case DataFileFormatType.ExaminedAudited:
                            if (valueArray[z, DataFirstRange.Column] == null || valueArray[z, DataSecondRange.Column] == null)
                            {
                                ExitFor = true;
                                break;
                            }
                            DR.ExaminedValue = double.Parse(valueArray[z, DataFirstRange.Column].ToString(), System.Globalization.NumberStyles.Any);
                            DS.ExaminedGroup.Group_Sum += DR.ExaminedValue;
                            DS.ExaminedGroup.Group_Sqr += Math.Pow(DR.ExaminedValue, 2.0);
                            DS.ExaminedGroup.Group_Cube += Math.Pow(DR.ExaminedValue, 3.0);
                            DS.ExaminedGroup.Group_Quad += Math.Pow(DR.ExaminedValue, 4.0);
                            if (DR.ExaminedValue != 0)
                                DS.ExaminedGroup.Group_NonZero++;

                            DR.AuditedValue = double.Parse(valueArray[z, DataSecondRange.Column].ToString(), System.Globalization.NumberStyles.Any);
                            DS.AuditedGroup.Group_Sum += DR.AuditedValue;
                            DS.AuditedGroup.Group_Sqr += Math.Pow(DR.AuditedValue, 2.0);
                            DS.AuditedGroup.Group_Cube += Math.Pow(DR.AuditedValue, 3.0);
                            DS.AuditedGroup.Group_Quad += Math.Pow(DR.AuditedValue, 4.0);
                            if (DR.AuditedValue != 0)
                                DS.AuditedGroup.Group_NonZero++;
                            DR.DifferenceValue = DR.ExaminedValue - DR.AuditedValue;
                            DS.DifferenceGroup.Group_Sum += DR.DifferenceValue;
                            DS.DifferenceGroup.Group_Sqr += Math.Pow(DR.DifferenceValue, 2.0);
                            DS.DifferenceGroup.Group_Cube += Math.Pow(DR.DifferenceValue, 3.0);
                            DS.DifferenceGroup.Group_Quad += Math.Pow(DR.DifferenceValue, 4.0);
                            if (DR.DifferenceValue != 0)
                                DS.DifferenceGroup.Group_NonZero++;
                            break;
                        case DataFileFormatType.ExaminedDifference:
                            if (valueArray[z, DataFirstRange.Column] == null || valueArray[z, DataSecondRange.Column] == null)
                            {
                                ExitFor = true;
                                break;
                            }
                            DR.ExaminedValue = double.Parse(valueArray[z, DataFirstRange.Column].ToString(), System.Globalization.NumberStyles.Any);
                            DS.ExaminedGroup.Group_Sum += DR.ExaminedValue;
                            DS.ExaminedGroup.Group_Sqr += Math.Pow(DR.ExaminedValue, 2.0);
                            DS.ExaminedGroup.Group_Cube += Math.Pow(DR.ExaminedValue, 3.0);
                            DS.ExaminedGroup.Group_Quad += Math.Pow(DR.ExaminedValue, 4.0);
                            if (DR.ExaminedValue != 0)
                                DS.ExaminedGroup.Group_NonZero++;

                            DR.DifferenceValue = double.Parse(valueArray[z, DataSecondRange.Column].ToString(), System.Globalization.NumberStyles.Any);
                            DS.DifferenceGroup.Group_Sum += DR.DifferenceValue;
                            DS.DifferenceGroup.Group_Sqr += Math.Pow(DR.DifferenceValue, 2.0);
                            DS.DifferenceGroup.Group_Cube += Math.Pow(DR.DifferenceValue, 3.0);
                            DS.DifferenceGroup.Group_Quad += Math.Pow(DR.DifferenceValue, 4.0);
                            if (DR.DifferenceValue != 0)
                                DS.DifferenceGroup.Group_NonZero++;
                            DR.AuditedValue = DR.ExaminedValue - DR.DifferenceValue;
                            DS.AuditedGroup.Group_Sum += DR.AuditedValue;
                            DS.AuditedGroup.Group_Sqr += Math.Pow(DR.AuditedValue, 2.0);
                            DS.AuditedGroup.Group_Cube += Math.Pow(DR.AuditedValue, 3.0);
                            DS.AuditedGroup.Group_Quad += Math.Pow(DR.AuditedValue, 4.0);
                            if (DR.AuditedValue != 0)
                                DS.AuditedGroup.Group_NonZero++; break;
                        case DataFileFormatType.AuditedDifference:
                            if (valueArray[z, DataFirstRange.Column] == null || valueArray[z, DataSecondRange.Column] == null)
                            {
                                ExitFor = true;
                                break;
                            }
                            DR.AuditedValue = double.Parse(valueArray[z, DataFirstRange.Column].ToString(), System.Globalization.NumberStyles.Any);
                            DS.AuditedGroup.Group_Sum += DR.AuditedValue;
                            DS.AuditedGroup.Group_Sqr += Math.Pow(DR.AuditedValue, 2.0);
                            DS.AuditedGroup.Group_Cube += Math.Pow(DR.AuditedValue, 3.0);
                            DS.AuditedGroup.Group_Quad += Math.Pow(DR.AuditedValue, 4.0);
                            if (DR.AuditedValue != 0)
                                DS.AuditedGroup.Group_NonZero++;

                            DR.DifferenceValue = double.Parse(valueArray[z, DataSecondRange.Column].ToString(), System.Globalization.NumberStyles.Any);
                            DS.DifferenceGroup.Group_Sum += DR.DifferenceValue;
                            DS.DifferenceGroup.Group_Sqr += Math.Pow(DR.DifferenceValue, 2.0);
                            DS.DifferenceGroup.Group_Cube += Math.Pow(DR.DifferenceValue, 3.0);
                            DS.DifferenceGroup.Group_Quad += Math.Pow(DR.DifferenceValue, 4.0);
                            if (DR.DifferenceValue != 0)
                                DS.DifferenceGroup.Group_NonZero++;
                            DR.ExaminedValue = DR.AuditedValue + DR.DifferenceValue;
                            DS.ExaminedGroup.Group_Sum += DR.ExaminedValue;
                            DS.ExaminedGroup.Group_Sqr += Math.Pow(DR.ExaminedValue, 2.0);
                            DS.ExaminedGroup.Group_Cube += Math.Pow(DR.ExaminedValue, 3.0);
                            DS.ExaminedGroup.Group_Quad += Math.Pow(DR.ExaminedValue, 4.0);
                            if (DR.ExaminedValue != 0)
                                DS.ExaminedGroup.Group_NonZero++;
                            break;
                    }
                    if (ExitFor)
                        break;
                    DS.DataRows.Add(DR);
                }
                catch (FormatException)
                {
                    workbook.Close();
                    throw new Exception("Invalid Number in Row " + z + " of the data file. Correct the issue and try processing the data file again.");
                }
                catch (IndexOutOfRangeException)
                {
                    workbook.Close();
                    throw new Exception("Missing Data in Row " + z + " of the data file. Correct the issue and try processing the data file again.");
                }
                catch (Exception ex)
                {
                    workbook.Close();
                    throw new Exception(ex.Message);
                }
                RowCount++;
            }
            DS.SampleSize = RowCount;
            if (DS.SampleSize > 10000)
            {
                throw new Exception("Sample sizes in excess of 10,000 are not allowed.");
            }
            workbook.Close();
        }

        public void ProcessDataExcelFileOLD()
        {
            DS = new StratifiedVariableAppraisalDataset();
            Excel.Workbook workbook = ExcelAppInterface.excelApp.Workbooks.Open(_DataFileInputPath, null, true);
            Excel.Worksheet workSheet = workbook.Sheets[SelectedDataSpreadsheet];
            workSheet.Select(Type.Missing);
            
            Excel.Range DataFirstRange = workSheet.get_Range(DataFirstCell, System.Type.Missing);
            Excel.Range DataSecondRange = SecondDataCellVisible == true ? workSheet.get_Range(DataSecondCell, System.Type.Missing) : null;
            Excel.Range FirstCellRange, SecondCellRange;


            Excel.Range excelRange = workSheet.UsedRange;
            object[,] valueArray = (object[,])excelRange.get_Value(Excel.XlRangeValueDataType.xlRangeValueDefault);

            for(int z = DataFirstRange.Row; z <= workSheet.UsedRange.Rows.Count; z++)
            {

            }


            int RowCount = 0;
            for (int x = DataFirstRange.Row; x <= workSheet.UsedRange.Rows.Count; x++)
            {
                try
                {
                    UnrestrictedVariableAppraisalDataRow DR = new UnrestrictedVariableAppraisalDataRow();
                    switch (SelectedDataFileFormatType)
                    {
                        case DataFileFormatType.Examined:
                            FirstCellRange = workSheet.UsedRange.Cells[DataFirstRange.Column][x];
                            DR.ExaminedValue = double.Parse(FirstCellRange.Value.ToString(), System.Globalization.NumberStyles.Any);
                            DS.ExaminedGroup.Group_Sum += DR.ExaminedValue;
                            DS.ExaminedGroup.Group_Sqr += Math.Pow(DR.ExaminedValue, 2.0);
                            DS.ExaminedGroup.Group_Cube += Math.Pow(DR.ExaminedValue, 3.0);
                            DS.ExaminedGroup.Group_Quad += Math.Pow(DR.ExaminedValue, 4.0);
                            if (DR.ExaminedValue != 0)
                                DS.ExaminedGroup.Group_NonZero++;
                            break;
                        case DataFileFormatType.Audited:
                            FirstCellRange = workSheet.UsedRange.Cells[DataFirstRange.Column][x];
                            DR.AuditedValue = double.Parse(FirstCellRange.Value.ToString(), System.Globalization.NumberStyles.Any);
                            DS.AuditedGroup.Group_Sum += DR.AuditedValue;
                            DS.AuditedGroup.Group_Sqr += Math.Pow(DR.AuditedValue, 2.0);
                            DS.AuditedGroup.Group_Cube += Math.Pow(DR.AuditedValue, 3.0);
                            DS.AuditedGroup.Group_Quad += Math.Pow(DR.AuditedValue, 4.0);
                            if (DR.AuditedValue != 0)
                                DS.AuditedGroup.Group_NonZero++;
                            break;
                        case DataFileFormatType.Difference:
                            FirstCellRange = workSheet.UsedRange.Cells[DataFirstRange.Column][x];
                            DR.DifferenceValue = double.Parse(FirstCellRange.Value.ToString(), System.Globalization.NumberStyles.Any);
                            DS.DifferenceGroup.Group_Sum += DR.DifferenceValue;
                            DS.DifferenceGroup.Group_Sqr += Math.Pow(DR.DifferenceValue, 2.0);
                            DS.DifferenceGroup.Group_Cube += Math.Pow(DR.DifferenceValue, 3.0);
                            DS.DifferenceGroup.Group_Quad += Math.Pow(DR.DifferenceValue, 4.0);
                            if (DR.DifferenceValue != 0)
                                DS.DifferenceGroup.Group_NonZero++;
                            break;
                        case DataFileFormatType.ExaminedAudited:
                            FirstCellRange = workSheet.UsedRange.Cells[DataFirstRange.Column][x];
                            SecondCellRange = workSheet.UsedRange.Cells[DataSecondRange.Column][x];
                            DR.ExaminedValue = double.Parse(FirstCellRange.Value.ToString(), System.Globalization.NumberStyles.Any);
                            DS.ExaminedGroup.Group_Sum += DR.ExaminedValue;
                            DS.ExaminedGroup.Group_Sqr += Math.Pow(DR.ExaminedValue, 2.0);
                            DS.ExaminedGroup.Group_Cube += Math.Pow(DR.ExaminedValue, 3.0);
                            DS.ExaminedGroup.Group_Quad += Math.Pow(DR.ExaminedValue, 4.0);
                            if (DR.ExaminedValue != 0)
                                DS.ExaminedGroup.Group_NonZero++;

                            DR.AuditedValue = double.Parse(SecondCellRange.Value.ToString(), System.Globalization.NumberStyles.Any);
                            DS.AuditedGroup.Group_Sum += DR.AuditedValue;
                            DS.AuditedGroup.Group_Sqr += Math.Pow(DR.AuditedValue, 2.0);
                            DS.AuditedGroup.Group_Cube += Math.Pow(DR.AuditedValue, 3.0);
                            DS.AuditedGroup.Group_Quad += Math.Pow(DR.AuditedValue, 4.0);
                            if (DR.AuditedValue != 0)
                                DS.AuditedGroup.Group_NonZero++;
                            DR.DifferenceValue = DR.ExaminedValue - DR.AuditedValue;
                            DS.DifferenceGroup.Group_Sum += DR.DifferenceValue;
                            DS.DifferenceGroup.Group_Sqr += Math.Pow(DR.DifferenceValue, 2.0);
                            DS.DifferenceGroup.Group_Cube += Math.Pow(DR.DifferenceValue, 3.0);
                            DS.DifferenceGroup.Group_Quad += Math.Pow(DR.DifferenceValue, 4.0);
                            if (DR.DifferenceValue != 0)
                                DS.DifferenceGroup.Group_NonZero++;
                            break;
                        case DataFileFormatType.ExaminedDifference:
                            FirstCellRange = workSheet.UsedRange.Cells[DataFirstRange.Column][x];
                            SecondCellRange = workSheet.UsedRange.Cells[DataSecondRange.Column][x];
                            DR.ExaminedValue = double.Parse(FirstCellRange.Value.ToString(), System.Globalization.NumberStyles.Any);
                            DS.ExaminedGroup.Group_Sum += DR.ExaminedValue;
                            DS.ExaminedGroup.Group_Sqr += Math.Pow(DR.ExaminedValue, 2.0);
                            DS.ExaminedGroup.Group_Cube += Math.Pow(DR.ExaminedValue, 3.0);
                            DS.ExaminedGroup.Group_Quad += Math.Pow(DR.ExaminedValue, 4.0);
                            if (DR.ExaminedValue != 0)
                                DS.ExaminedGroup.Group_NonZero++;

                            DR.DifferenceValue = double.Parse(SecondCellRange.Value.ToString(), System.Globalization.NumberStyles.Any);
                            DS.DifferenceGroup.Group_Sum += DR.DifferenceValue;
                            DS.DifferenceGroup.Group_Sqr += Math.Pow(DR.DifferenceValue, 2.0);
                            DS.DifferenceGroup.Group_Cube += Math.Pow(DR.DifferenceValue, 3.0);
                            DS.DifferenceGroup.Group_Quad += Math.Pow(DR.DifferenceValue, 4.0);
                            if (DR.DifferenceValue != 0)
                                DS.DifferenceGroup.Group_NonZero++;
                            DR.AuditedValue = DR.ExaminedValue - DR.DifferenceValue;
                            DS.AuditedGroup.Group_Sum += DR.AuditedValue;
                            DS.AuditedGroup.Group_Sqr += Math.Pow(DR.AuditedValue, 2.0);
                            DS.AuditedGroup.Group_Cube += Math.Pow(DR.AuditedValue, 3.0);
                            DS.AuditedGroup.Group_Quad += Math.Pow(DR.AuditedValue, 4.0);
                            if (DR.AuditedValue != 0)
                                DS.AuditedGroup.Group_NonZero++; break;
                        case DataFileFormatType.AuditedDifference:
                            FirstCellRange = workSheet.UsedRange.Cells[DataFirstRange.Column][x];
                            SecondCellRange = workSheet.UsedRange.Cells[DataSecondRange.Column][x];
                            DR.AuditedValue = double.Parse(FirstCellRange.Value.ToString(), System.Globalization.NumberStyles.Any);
                            DS.AuditedGroup.Group_Sum += DR.AuditedValue;
                            DS.AuditedGroup.Group_Sqr += Math.Pow(DR.AuditedValue, 2.0);
                            DS.AuditedGroup.Group_Cube += Math.Pow(DR.AuditedValue, 3.0);
                            DS.AuditedGroup.Group_Quad += Math.Pow(DR.AuditedValue, 4.0);
                            if (DR.AuditedValue != 0)
                                DS.AuditedGroup.Group_NonZero++;

                            DR.DifferenceValue = double.Parse(SecondCellRange.Value.ToString(), System.Globalization.NumberStyles.Any);
                            DS.DifferenceGroup.Group_Sum += DR.DifferenceValue;
                            DS.DifferenceGroup.Group_Sqr += Math.Pow(DR.DifferenceValue, 2.0);
                            DS.DifferenceGroup.Group_Cube += Math.Pow(DR.DifferenceValue, 3.0);
                            DS.DifferenceGroup.Group_Quad += Math.Pow(DR.DifferenceValue, 4.0);
                            if (DR.DifferenceValue != 0)
                                DS.DifferenceGroup.Group_NonZero++;
                            DR.ExaminedValue = DR.AuditedValue + DR.DifferenceValue;
                            DS.ExaminedGroup.Group_Sum += DR.ExaminedValue;
                            DS.ExaminedGroup.Group_Sqr += Math.Pow(DR.ExaminedValue, 2.0);
                            DS.ExaminedGroup.Group_Cube += Math.Pow(DR.ExaminedValue, 3.0);
                            DS.ExaminedGroup.Group_Quad += Math.Pow(DR.ExaminedValue, 4.0);
                            if (DR.ExaminedValue != 0)
                                DS.ExaminedGroup.Group_NonZero++;
                            break;
                    }
                    DS.DataRows.Add(DR);
                }
                catch (FormatException)
                {
                    workbook.Close();
                    throw new Exception("Invalid Number in Row " + x + " of the data file. Correct the issue and try processing the data file again.");
                }
                catch (IndexOutOfRangeException)
                {
                    workbook.Close();
                    throw new Exception("Missing Data in Row " + x + " of the data file. Correct the issue and try processing the data file again.");
                }
                catch (Exception ex)
                {
                    workbook.Close();
                    throw new Exception(ex.Message);
                }

                RowCount++;
            }

            DS.SampleSize = RowCount;
            if (DS.SampleSize > 10000)
            {
                throw new Exception("Sample sizes in excess of 10,000 are not allowed.");
            }
            workbook.Close();
        }

        public void ProcessUniverseExcelFile()
        {
            Excel.Workbook workbook = ExcelAppInterface.excelApp.Workbooks.Open(_UniverseFileInputPath, null, true);
            Excel.Worksheet workSheet = workbook.Sheets[SelectedUniverseSpreadsheet];
            workSheet.Select(Type.Missing);

            Excel.Range StratumCounterRange = null;
            if (!SystemAssignedStratumCounter)
                StratumCounterRange = workSheet.get_Range(StratumCounterCell, System.Type.Missing);
            Excel.Range UniverseSizeRange = workSheet.get_Range(UniverseSizeCell, System.Type.Missing);
            Excel.Range SampleSizeRange = workSheet.get_Range(SampleSizeCell, System.Type.Missing);

            Excel.Range excelRange = workSheet.UsedRange;
            object[,] valueArray = (object[,])excelRange.get_Value(Excel.XlRangeValueDataType.xlRangeValueDefault);

            int StratumCount = 1;
            for (int z = UniverseSizeRange.Row; z <= excelRange.Rows.Count; z++)
            {
                try
                {
                    if(StratumCount > NumberOfStrata)
                    {
                        //Any additional stratum data will be ignored based on the number requested by the user
                        break;
                    }
                    StratifiedVariableAppraisalDataset VAS = new StratifiedVariableAppraisalDataset();
                    if (!SystemAssignedStratumCounter)
                        VAS.StratumID = valueArray[z, StratumCounterRange.Column].ToString();//workSheet.UsedRange.Cells[StratumCounterRange.Column][x].Value.ToString();
                    else
                        VAS.StratumID = StratumCount.ToString();

                    VAS.UniverseSize = int.Parse(valueArray[z, UniverseSizeRange.Column].ToString(), System.Globalization.NumberStyles.Any);
                    VAS.SampleSize = int.Parse(valueArray[z, SampleSizeRange.Column].ToString(), System.Globalization.NumberStyles.Any);
                    SDS.OverallUniverseSize += VAS.UniverseSize;
                    SDS.Strata.Add(VAS);

                }
                catch (FormatException)
                {
                    workbook.Close();
                    throw new Exception("Invalid Number in Row " + StratumCount);
                }
                StratumCount++;
            }
            workbook.Close();

            //Check Totals Against the Input
            int TotalSamples = SDS.Strata.Sum(a => a.SampleSize);
            long TotalUniverseSize = SDS.Strata.Sum(a => a.UniverseSize);
            int InvalidCount = SDS.Strata.Where(a => a.SampleSize > a.UniverseSize).Count();


            if (InvalidCount > 0)
            {
                throw new Exception("Sample Size cannot exceed Universe size within a Stratum.");
            }
            //Check if the Sample Size is Greater than the Universe Size
            if (TotalSamples > TotalUniverseSize)
            {
                throw new Exception("Total Sample Size cannot exceed Universe size.");
            }
            if (TotalSamples > DS.SampleSize)
            {
                throw new Exception("Total Strata Sample Size exceeds the input data count.");
            }
            //Copy Data into Strata
            int StrataIndex = 0;

            foreach (StratifiedVariableAppraisalDataset VAS in SDS.Strata)
            {
                VAS.DataRows = DS.DataRows.GetRange(StrataIndex, VAS.SampleSize);
                //VAS.CalculateGroupStats();
                StrataIndex = StrataIndex + VAS.SampleSize;
            }
            //Calculate Group Stats for Strata
            SDS.CalculateStrataGroupStats();

        }


        private void ProcessUniverseTextFile()
        {
            TextFieldParser TFP = new TextFieldParser(UniverseFileInputPath);
            TFP.TextFieldType = FieldType.Delimited;
            if (UniverseFileSelectedFileType == SupportedFileType.CSV)
                TFP.Delimiters = new string[] { "," };
            else
                TFP.Delimiters = new string[] { " ", "\t" };
            string[] Fields;
            int RowIndex = 1;

            while (!TFP.EndOfData && RowIndex <= NumberOfStrata)
            {
                try
                {
                    
                    TFP.TrimWhiteSpace = true;
                    Fields = TFP.ReadFields();
                    //Remove Any Empty Fields
                    Fields = Fields.Where(a => a != "").ToArray();
                    try
                    {
                        StratifiedVariableAppraisalDataset VAS = new StratifiedVariableAppraisalDataset();
                        VAS.StratumID = SystemAssignedStratumCounter == true ? RowIndex.ToString() : Fields[StratumCounterColumn - 1];
                        VAS.UniverseSize = int.Parse(Fields[UniverseSizeColumn - 1], System.Globalization.NumberStyles.Any);
                        VAS.SampleSize = int.Parse(Fields[SampleSizeColumn - 1], System.Globalization.NumberStyles.Any);
                        SDS.OverallUniverseSize += VAS.UniverseSize;
                        SDS.Strata.Add(VAS);

                    }
                    catch (FormatException)
                    {
                        throw new Exception("Invalid Number in Row " + RowIndex);
                    }

                }
                catch (Exception)
                {
                    throw new Exception("Error reading data from sample size file. Verify your column selections are correct.");
                }
                RowIndex++;
            }

            //Check Totals Against the Input
            int TotalSamples = SDS.Strata.Sum(a => a.SampleSize);
            long TotalUniverseSize = SDS.Strata.Sum(a => a.UniverseSize);
            //Check if the Sample Size is Greater than the Universe Size
            if (TotalSamples > TotalUniverseSize)
            {
                throw new Exception("Total Sample Size cannot exceed Universe size.");
            }
            if (TotalSamples > DS.SampleSize)
            {
                throw new Exception("Total Strata Sample Size exceeds the input data count.");
            }
            //Copy Data into Strata
            int StrataIndex = 0;

            foreach (StratifiedVariableAppraisalDataset VAS in SDS.Strata)
            {
                VAS.DataRows = DS.DataRows.GetRange(StrataIndex, VAS.SampleSize);
                //VAS.CalculateGroupStats();
                StrataIndex = StrataIndex + VAS.SampleSize;
            }
            //Calculate Group Stats for Strata
            SDS.CalculateStrataGroupStats();
            return;
        }
    }
}
