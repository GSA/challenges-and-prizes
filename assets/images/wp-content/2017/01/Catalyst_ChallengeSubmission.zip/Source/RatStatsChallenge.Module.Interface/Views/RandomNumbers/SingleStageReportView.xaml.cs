﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using RatStatsChallenge.Module.Infastructure;
using RatStatsChallenge.Module.Interface.ViewModels.RandomNumbers;
namespace RatStatsChallenge.Module.Interface.Views.RandomNumbers
{
    /// <summary>
    /// Interaction logic for SingleStageRandomNumbersReportView.xaml
    /// </summary>
    public partial class SingleStageReportView : UserControl
    {
        public SingleStageReportView(SingleStageReportViewModel viewModel)
        {
            this.DataContext = viewModel;
            InitializeComponent();
        }
    }
}
