﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using RatStatsChallenge.Module.Interface.ViewModels.AttributeAppraisals;
using RatStatsChallenge.Module.Infastructure;
namespace RatStatsChallenge.Module.Interface.Views.AttributeAppraisals
{
    /// <summary>
    /// Interaction logic for UnrestrictedView.xaml
    /// </summary>
    public partial class UnrestrictedView : UserControl
    {
        public UnrestrictedView(UnrestrictedViewModel viewModel)
        {
            this.DataContext = viewModel;
            InitializeComponent();
        }

        private void ClearFields()
        {
            //Clear Validation Errors
            UniverseSizeTextBox.Text = "0";
            Validation.ClearInvalid(UniverseSizeTextBox.GetBindingExpression(TextBox.TextProperty));
            SampleSizeTextBox.Text = "0";
            Validation.ClearInvalid(UniverseSizeTextBox.GetBindingExpression(TextBox.TextProperty));
            ItemsOfInterestTextBox.Text = "0";
            Validation.ClearInvalid(ItemsOfInterestTextBox.GetBindingExpression(TextBox.TextProperty));
            CustomConfidenceLevelTextBox.Text = "80";
            Validation.ClearInvalid(CustomConfidenceLevelTextBox.GetBindingExpression(TextBox.TextProperty));
            //Reset Error Indicators
            TwoSidedRadio.ClearValue(TextBox.BorderBrushProperty);
            TwoSidedRadio.BorderThickness = new Thickness(1);
            OneSidedRadio.ClearValue(TextBox.BorderBrushProperty);
            OneSidedRadio.BorderThickness = new Thickness(1);
            UniverseSizeTextBox.ClearValue(TextBox.BorderBrushProperty);
            UniverseSizeTextBox.BorderThickness = new Thickness(1);
            SampleSizeTextBox.ClearValue(TextBox.BorderBrushProperty);
            SampleSizeTextBox.BorderThickness = new Thickness(1);
            ItemsOfInterestTextBox.ClearValue(TextBox.BorderBrushProperty);
            ItemsOfInterestTextBox.BorderThickness = new Thickness(1);
            CustomConfidenceLevelTextBox.ClearValue(TextBox.BorderBrushProperty);
            CustomConfidenceLevelTextBox.BorderThickness = new Thickness(1);
            ((UnrestrictedViewModel)this.DataContext).ResetFields();
        }

        private void Clear_Fields_Button_Click(object sender, RoutedEventArgs e)
        {
            ClearFields();
        }

        private void Cancel_Button_Click(object sender, RoutedEventArgs e)
        {
            ClearFields();
            ((UnrestrictedViewModel)this.DataContext).GoHome();
        }

        private void Process_Button_Click(object sender, RoutedEventArgs e)
        {
            // Check For Validation Errors
            if (Validation.GetErrors(UniverseSizeTextBox).Count > 0)
                return;
            if (Validation.GetErrors(SampleSizeTextBox).Count > 0)
                return;
            if (Validation.GetErrors(ItemsOfInterestTextBox).Count > 0)
                return;
            //Reset Visual Error Indicators
            TwoSidedRadio.ClearValue(TextBox.BorderBrushProperty);
            TwoSidedRadio.BorderThickness = new Thickness(1);
            OneSidedRadio.ClearValue(TextBox.BorderBrushProperty);
            OneSidedRadio.BorderThickness = new Thickness(1);
            UniverseSizeTextBox.ClearValue(TextBox.BorderBrushProperty);
            UniverseSizeTextBox.BorderThickness = new Thickness(1);
            SampleSizeTextBox.ClearValue(TextBox.BorderBrushProperty);
            SampleSizeTextBox.BorderThickness = new Thickness(1);
            ItemsOfInterestTextBox.ClearValue(TextBox.BorderBrushProperty);
            ItemsOfInterestTextBox.BorderThickness = new Thickness(1);
            //Check for ViewModel Errors
            bool result = ((UnrestrictedViewModel)this.DataContext).ReadyToProceed();
            if (!result)
            {
                //ViewModel Errors were found so set visual error indicators
                foreach (ReadyToProceedError BR in ((UnrestrictedViewModel)this.DataContext).Errors)
                {
                    switch (BR.BindingName)
                    {
                        case "SelectedConfidenceIntervalType":
                            TwoSidedRadio.BorderBrush = Brushes.Red;
                            TwoSidedRadio.BorderThickness = new Thickness(2);
                            if (OneSidedRadio.IsEnabled)
                            {
                                OneSidedRadio.BorderBrush = Brushes.Red;
                                OneSidedRadio.BorderThickness = new Thickness(2);
                            }
                            break;
                        case "UniverseSize":
                            UniverseSizeTextBox.BorderBrush = Brushes.Red;
                            UniverseSizeTextBox.BorderThickness = new Thickness(2);
                            break;
                        case "SampleSize":
                            SampleSizeTextBox.BorderBrush = Brushes.Red;
                            SampleSizeTextBox.BorderThickness = new Thickness(2);
                            break;
                        case "SamplesOfInterestSize":
                            ItemsOfInterestTextBox.BorderBrush = Brushes.Red;
                            ItemsOfInterestTextBox.BorderThickness = new Thickness(2);
                            break;
                        case "TextOutputCheckBox":
                            TextOutputCheckBox.BorderBrush = Brushes.Red;
                            TextOutputCheckBox.BorderThickness = new Thickness(2);
                            break;
                        case "CustomConfidenceLevel":
                            CustomConfidenceLevelTextBox.BorderBrush = Brushes.Red;
                            CustomConfidenceLevelTextBox.BorderThickness = new Thickness(2);
                            break;
                    }
                }
            }
            else
                ((UnrestrictedViewModel)this.DataContext).Calculate();


        }
    }
}
