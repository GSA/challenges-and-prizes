﻿using System.Windows.Input;
using Prism.Mvvm;
using Prism.Commands;
using Prism.Regions;
using RatStatsChallenge.Module.Infastructure;
using System.Diagnostics;
using RatStatsChallenge.Module.Infastructure.Enums;
namespace RatStatsChallenge.Module.Interface.ViewModels.VariableAppraisals
{
    public class UnrestrictedReportViewModel : BindableBase, INavigationAware
    {
        private readonly IRegionManager MyRegionManager;
        private UnrestrictedVariableAppraisal.ReportData RD = new UnrestrictedVariableAppraisal.ReportData();
        public UnrestrictedReportViewModel(IRegionManager regionManager)
        {
            this.MyRegionManager = regionManager;
            this.GoHomeCommand = new DelegateCommand<object>(this.OnGoHomeCommand);
            this.GoBackCommand = new DelegateCommand<object>(this.OnGoBackCommand);
            this.ViewTextCommand = new DelegateCommand<object>(this.OnViewTextCommand);
        }

        public ICommand GoHomeCommand { get; private set; }
        private void OnGoHomeCommand(object arg)
        {
            MyRegionManager.RequestNavigate("PrimaryPageRegion", "HomePageView");
        }

        public ICommand GoBackCommand { get; private set; }
        private void OnGoBackCommand(object arg)
        {
            var parameters = new NavigationParameters();
            parameters.Add("SourceViewName", "VariableAppraisals.UnrestrictedReportView");
            this.MyRegionManager.RequestNavigate("PrimaryPageRegion", "VariableAppraisals.UnrestrictedView" + parameters);
        }

        public virtual bool IsNavigationTarget(NavigationContext navigationContext)
        {
            return true;
        }

        public virtual void OnNavigatedFrom(NavigationContext navigationContext)
        {

        }

        public virtual void OnNavigatedTo(NavigationContext navigationContext)
        {
            if (navigationContext.Parameters != null && navigationContext.Parameters["ReportData"] != null)
            {
                RD = (UnrestrictedVariableAppraisal.ReportData)navigationContext.Parameters["ReportData"];

                AuditReviewTitle = RD.AuditTitle;
                DataFileInputPath = RD.DataFileInputPath;
                TextFileOutput = RD.TextFileOutput;
                TextFileOutputPath = RD.TextFileOutputPath;
                UniverseSize = RD.UniverseSize;
                SampleSize = RD.SampleSize;
                SumOfExaminedValues = RD.ExaminedGroup.Group_Sum;
                SumOfAuditedValues = RD.AuditedGroup.Group_Sum;
                SumOfDifferenceValues = RD.DifferenceGroup.Group_Sum;
                //Tab Visibility Defaults to Hidden
                ExaminedTabVisibility = ControlVisibility.Hidden;
                AuditedTabVisibility = ControlVisibility.Hidden;
                DifferenceTabVisibility = ControlVisibility.Hidden;
                LogDate = "Date: " + RD.LogTime.ToShortDateString();
                LogTime = "Time: " + RD.LogTime.ToShortTimeString();
                switch (RD.SelectedDataFileFormatType)
                {
                    case DataFileFormatType.Examined:
                        SelectedTabIndex = 0;
                        ExaminedTabVisibility = ControlVisibility.Visible;
                        NonZeroDifferences = RD.ExaminedGroup.Group_NonZero;
                        break;
                    case DataFileFormatType.Audited:
                        SelectedTabIndex = 1;
                        AuditedTabVisibility = ControlVisibility.Visible;
                        NonZeroDifferences = RD.AuditedGroup.Group_NonZero;
                        break;
                    case DataFileFormatType.Difference:
                        SelectedTabIndex = 2;
                        DifferenceTabVisibility = ControlVisibility.Visible;
                        NonZeroDifferences = RD.DifferenceGroup.Group_NonZero;
                        break;
                    default:
                        SelectedTabIndex = 0;
                        ExaminedTabVisibility = ControlVisibility.Visible;
                        AuditedTabVisibility = ControlVisibility.Visible;
                        DifferenceTabVisibility = ControlVisibility.Visible;
                        NonZeroDifferences = RD.ExaminedGroup.Group_NonZero;
                        break;
                }
                if(ExaminedTabVisibility == ControlVisibility.Visible)
                {
                    ExaminedGroupData_Mean = RD.ExaminedGroup.Group_Mean;
                    ExaminedGroupData_Skewness = RD.ExaminedGroup.Group_SkewAmt;
                    ExaminedGroupData_StdDeviation = RD.ExaminedGroup.Group_StandardDeviation;
                    ExaminedGroupData_Kurtosis = RD.ExaminedGroup.Group_KurtAmt;
                    ExaminedGroupData_StdErrorMean = RD.ExaminedGroup.Group_StandardError;
                    ExaminedGroupData_StdErrorTotal = RD.ExaminedGroup.Group_StandardError * RD.UniverseSize;
                    ExaminedGroupData_PointEst = RD.ExaminedGroup.Group_PointEstimate;

                    ExaminedGroupData_EightyPercent_CI_LowerLimit = RD.ExaminedGroup.EightyPercent_Confidence.LowerLimit;
                    ExaminedGroupData_EightyPercent_CI_UpperLimit = RD.ExaminedGroup.EightyPercent_Confidence.UpperLimit;
                    ExaminedGroupData_EightyPercent_CI_PercisionAmount = RD.ExaminedGroup.EightyPercent_Confidence.PrecisionAmount * RD.UniverseSize;
                    ExaminedGroupData_EightyPercent_CI_PercisionPercent = RD.ExaminedGroup.EightyPercent_Confidence.PrecisionPercent * 100;
                    ExaminedGroupData_EightyPercent_CI_TValueUsed = RD.ExaminedGroup.EightyPercent_Confidence.T_Value;
                    ExaminedGroupData_NinetyPercent_CI_LowerLimit = RD.ExaminedGroup.NinetyPercent_Confidence.LowerLimit;
                    ExaminedGroupData_NinetyPercent_CI_UpperLimit = RD.ExaminedGroup.NinetyPercent_Confidence.UpperLimit;
                    ExaminedGroupData_NinetyPercent_CI_PercisionAmount = RD.ExaminedGroup.NinetyPercent_Confidence.PrecisionAmount * RD.UniverseSize;
                    ExaminedGroupData_NinetyPercent_CI_PercisionPercent = RD.ExaminedGroup.NinetyPercent_Confidence.PrecisionPercent * 100;
                    ExaminedGroupData_NinetyPercent_CI_TValueUsed = RD.ExaminedGroup.NinetyPercent_Confidence.T_Value;
                    ExaminedGroupData_NinetyFivePercent_CI_LowerLimit = RD.ExaminedGroup.NinetyFivePercent_Confidence.LowerLimit;
                    ExaminedGroupData_NinetyFivePercent_CI_UpperLimit = RD.ExaminedGroup.NinetyFivePercent_Confidence.UpperLimit;
                    ExaminedGroupData_NinetyFivePercent_CI_PercisionAmount = RD.ExaminedGroup.NinetyFivePercent_Confidence.PrecisionAmount * RD.UniverseSize;
                    ExaminedGroupData_NinetyFivePercent_CI_PercisionPercent = RD.ExaminedGroup.NinetyFivePercent_Confidence.PrecisionPercent * 100;
                    ExaminedGroupData_NinetyFivePercent_CI_TValueUsed = RD.ExaminedGroup.NinetyFivePercent_Confidence.T_Value;
                }

                if(AuditedTabVisibility == ControlVisibility.Visible)
                {
                    AuditedGroupData_Mean = RD.AuditedGroup.Group_Mean;
                    AuditedGroupData_Skewness = RD.AuditedGroup.Group_SkewAmt;
                    AuditedGroupData_StdDeviation = RD.AuditedGroup.Group_StandardDeviation;
                    AuditedGroupData_Kurtosis = RD.AuditedGroup.Group_KurtAmt;
                    AuditedGroupData_StdErrorMean = RD.AuditedGroup.Group_StandardError;
                    AuditedGroupData_StdErrorTotal = RD.AuditedGroup.Group_StandardError * RD.UniverseSize;
                    AuditedGroupData_PointEst = RD.AuditedGroup.Group_PointEstimate;

                    AuditedGroupData_EightyPercent_CI_LowerLimit = RD.AuditedGroup.EightyPercent_Confidence.LowerLimit;
                    AuditedGroupData_EightyPercent_CI_UpperLimit = RD.AuditedGroup.EightyPercent_Confidence.UpperLimit;
                    AuditedGroupData_EightyPercent_CI_PercisionAmount = RD.AuditedGroup.EightyPercent_Confidence.PrecisionAmount * RD.UniverseSize;
                    AuditedGroupData_EightyPercent_CI_PercisionPercent = RD.AuditedGroup.EightyPercent_Confidence.PrecisionPercent * 100;
                    AuditedGroupData_EightyPercent_CI_TValueUsed = RD.AuditedGroup.EightyPercent_Confidence.T_Value;
                    AuditedGroupData_NinetyPercent_CI_LowerLimit = RD.AuditedGroup.NinetyPercent_Confidence.LowerLimit;
                    AuditedGroupData_NinetyPercent_CI_UpperLimit = RD.AuditedGroup.NinetyPercent_Confidence.UpperLimit;
                    AuditedGroupData_NinetyPercent_CI_PercisionAmount = RD.AuditedGroup.NinetyPercent_Confidence.PrecisionAmount * RD.UniverseSize;
                    AuditedGroupData_NinetyPercent_CI_PercisionPercent = RD.AuditedGroup.NinetyPercent_Confidence.PrecisionPercent * 100;
                    AuditedGroupData_NinetyPercent_CI_TValueUsed = RD.AuditedGroup.NinetyPercent_Confidence.T_Value;
                    AuditedGroupData_NinetyFivePercent_CI_LowerLimit = RD.AuditedGroup.NinetyFivePercent_Confidence.LowerLimit;
                    AuditedGroupData_NinetyFivePercent_CI_UpperLimit = RD.AuditedGroup.NinetyFivePercent_Confidence.UpperLimit;
                    AuditedGroupData_NinetyFivePercent_CI_PercisionAmount = RD.AuditedGroup.NinetyFivePercent_Confidence.PrecisionAmount * RD.UniverseSize;
                    AuditedGroupData_NinetyFivePercent_CI_PercisionPercent = RD.AuditedGroup.NinetyFivePercent_Confidence.PrecisionPercent * 100;
                    AuditedGroupData_NinetyFivePercent_CI_TValueUsed = RD.AuditedGroup.NinetyFivePercent_Confidence.T_Value;
                }
                if(DifferenceTabVisibility == ControlVisibility.Visible)
                {
                    DifferenceGroupData_Mean = RD.DifferenceGroup.Group_Mean;
                    DifferenceGroupData_Skewness = RD.DifferenceGroup.Group_SkewAmt;
                    DifferenceGroupData_StdDeviation = RD.DifferenceGroup.Group_StandardDeviation;
                    DifferenceGroupData_Kurtosis = RD.DifferenceGroup.Group_KurtAmt;
                    DifferenceGroupData_StdErrorMean = RD.DifferenceGroup.Group_StandardError;
                    DifferenceGroupData_StdErrorTotal = RD.DifferenceGroup.Group_StandardError * RD.UniverseSize;
                    DifferenceGroupData_PointEst = RD.DifferenceGroup.Group_PointEstimate;

                    DifferenceGroupData_EightyPercent_CI_LowerLimit = RD.DifferenceGroup.EightyPercent_Confidence.LowerLimit;
                    DifferenceGroupData_EightyPercent_CI_UpperLimit = RD.DifferenceGroup.EightyPercent_Confidence.UpperLimit;
                    DifferenceGroupData_EightyPercent_CI_PercisionAmount = RD.DifferenceGroup.EightyPercent_Confidence.PrecisionAmount * RD.UniverseSize;
                    DifferenceGroupData_EightyPercent_CI_PercisionPercent = RD.DifferenceGroup.EightyPercent_Confidence.PrecisionPercent * 100;
                    DifferenceGroupData_EightyPercent_CI_TValueUsed = RD.DifferenceGroup.EightyPercent_Confidence.T_Value;
                    DifferenceGroupData_NinetyPercent_CI_LowerLimit = RD.DifferenceGroup.NinetyPercent_Confidence.LowerLimit;
                    DifferenceGroupData_NinetyPercent_CI_UpperLimit = RD.DifferenceGroup.NinetyPercent_Confidence.UpperLimit;
                    DifferenceGroupData_NinetyPercent_CI_PercisionAmount = RD.DifferenceGroup.NinetyPercent_Confidence.PrecisionAmount * RD.UniverseSize;
                    DifferenceGroupData_NinetyPercent_CI_PercisionPercent = RD.DifferenceGroup.NinetyPercent_Confidence.PrecisionPercent * 100;
                    DifferenceGroupData_NinetyPercent_CI_TValueUsed = RD.DifferenceGroup.NinetyPercent_Confidence.T_Value;
                    DifferenceGroupData_NinetyFivePercent_CI_LowerLimit = RD.DifferenceGroup.NinetyFivePercent_Confidence.LowerLimit;
                    DifferenceGroupData_NinetyFivePercent_CI_UpperLimit = RD.DifferenceGroup.NinetyFivePercent_Confidence.UpperLimit;
                    DifferenceGroupData_NinetyFivePercent_CI_PercisionAmount = RD.DifferenceGroup.NinetyFivePercent_Confidence.PrecisionAmount * RD.UniverseSize;
                    DifferenceGroupData_NinetyFivePercent_CI_PercisionPercent = RD.DifferenceGroup.NinetyFivePercent_Confidence.PrecisionPercent * 100;
                    DifferenceGroupData_NinetyFivePercent_CI_TValueUsed = RD.DifferenceGroup.NinetyFivePercent_Confidence.T_Value;
                }

            }

        }

        public ICommand ViewTextCommand { get; private set; }
        private void OnViewTextCommand(object arg)
        {
            if (System.IO.File.Exists(TextFileOutputPath))
                Process.Start(TextFileOutputPath);
        }

        private string _LogDate = "";
        public string LogDate
        {
            get { return _LogDate; }
            set { SetProperty(ref _LogDate, value); }
        }

        private string _LogTime = "";
        public string LogTime
        {
            get { return _LogTime; }
            set { SetProperty(ref _LogTime, value); }
        }

        private string _AuditReviewTitle = "";
        public string AuditReviewTitle
        {
            get { return _AuditReviewTitle; }
            set { SetProperty(ref _AuditReviewTitle, value); }
        }

        private string _DataFileInputPath = "";
        public string DataFileInputPath
        {
            get { return _DataFileInputPath; }
            set { SetProperty(ref _DataFileInputPath, value); }
        }

        private bool _TextFileOutput = false;
        public bool TextFileOutput
        {
            get { return _TextFileOutput; }
            set
            {
                SetProperty(ref _TextFileOutput, value);
            }
        }

        private string _TextFileOutputPath = "";
        public string TextFileOutputPath
        {
            get { return _TextFileOutputPath; }
            set { SetProperty(ref _TextFileOutputPath, value); }
        }

        private long _UniverseSize;
        public long UniverseSize
        {
            get { return _UniverseSize; }
            set { SetProperty(ref _UniverseSize, value); }
        }

        private int _SampleSize;
        public int SampleSize
        {
            get { return _SampleSize; }
            set { SetProperty(ref _SampleSize, value); }
        }

        private int _NonZeroDifferences = 0;
        public int NonZeroDifferences
        {
            get { return _NonZeroDifferences; }
            set { SetProperty(ref _NonZeroDifferences, value); }
        }

        private double _SumOfExaminedValues = 0;
        public double SumOfExaminedValues
        {
            get { return _SumOfExaminedValues; }
            set { SetProperty(ref _SumOfExaminedValues, value); }
        }
        private double _SumOfAuditedValues = 0;
        public double SumOfAuditedValues
        {
            get { return _SumOfAuditedValues; }
            set { SetProperty(ref _SumOfAuditedValues, value); }
        }
        private double _SumOfDifferenceValues = 0;
        public double SumOfDifferenceValues
        {
            get { return _SumOfDifferenceValues; }
            set { SetProperty(ref _SumOfDifferenceValues, value); }
        }
        private int _SelectedTabIndex = 0;
        public int SelectedTabIndex
        {
            get { return _SelectedTabIndex;}
            set { SetProperty(ref _SelectedTabIndex, value); }
        }

        private ControlVisibility _ExaminedTabVisibility = ControlVisibility.Hidden;
        public ControlVisibility ExaminedTabVisibility
        {
            get { return _ExaminedTabVisibility; }
            set { SetProperty(ref _ExaminedTabVisibility, value); }
        }

        private ControlVisibility _AuditedTabVisibility = ControlVisibility.Hidden;
        public ControlVisibility AuditedTabVisibility
        {
            get { return _AuditedTabVisibility; }
            set { SetProperty(ref _AuditedTabVisibility, value); }
        }

        private ControlVisibility _DifferenceTabVisibility = ControlVisibility.Hidden;
        public ControlVisibility DifferenceTabVisibility
        {
            get { return _DifferenceTabVisibility; }
            set { SetProperty(ref _DifferenceTabVisibility, value); }
        }


        private DataFileFormatType _SelectedDataFileFormatType = DataFileFormatType.Unknown;
        public DataFileFormatType SelectedDataFileFormatType
        {
            get { return _SelectedDataFileFormatType; }
            set { SetProperty(ref _SelectedDataFileFormatType, value); }
        }

        private double _ExaminedGroupData_Mean = 0;
        public double ExaminedGroupData_Mean
        {
            get { return _ExaminedGroupData_Mean; }
            set { SetProperty(ref _ExaminedGroupData_Mean, value); }
        }
        private double _ExaminedGroupData_Skewness = 0;
        public double ExaminedGroupData_Skewness
        {
            get { return _ExaminedGroupData_Skewness; }
            set { SetProperty(ref _ExaminedGroupData_Skewness, value); }
        }
        private double _ExaminedGroupData_StdDeviation = 0;
        public double ExaminedGroupData_StdDeviation
        {
            get { return _ExaminedGroupData_StdDeviation; }
            set { SetProperty(ref _ExaminedGroupData_StdDeviation, value); }
        }
        private double _ExaminedGroupData_Kurtosis = 0;
        public double ExaminedGroupData_Kurtosis
        {
            get { return _ExaminedGroupData_Kurtosis; }
            set { SetProperty(ref _ExaminedGroupData_Kurtosis, value); }
        }
        private double _ExaminedGroupData_StdErrorMean = 0;
        public double ExaminedGroupData_StdErrorMean
        {
            get { return _ExaminedGroupData_StdErrorMean; }
            set { SetProperty(ref _ExaminedGroupData_StdErrorMean, value); }
        }
        private double _ExaminedGroupData_StdErrorTotal = 0;
        public double ExaminedGroupData_StdErrorTotal
        {
            get { return _ExaminedGroupData_StdErrorTotal; }
            set { SetProperty(ref _ExaminedGroupData_StdErrorTotal, value); }
        }
        private double _ExaminedGroupData_PointEst = 0;
        public double ExaminedGroupData_PointEst
        {
            get { return _ExaminedGroupData_PointEst; }
            set { SetProperty(ref _ExaminedGroupData_PointEst, value); }
        }

        //LOWER LIMIT
        private double _ExaminedGroupData_EightyPercent_CI_LowerLimit = 0;
        public double ExaminedGroupData_EightyPercent_CI_LowerLimit
        {
            get { return _ExaminedGroupData_EightyPercent_CI_LowerLimit; }
            set { SetProperty(ref _ExaminedGroupData_EightyPercent_CI_LowerLimit, value); }
        }

        private double _ExaminedGroupData_NinetyPercent_CI_LowerLimit = 0;
        public double ExaminedGroupData_NinetyPercent_CI_LowerLimit
        {
            get { return _ExaminedGroupData_NinetyPercent_CI_LowerLimit; }
            set { SetProperty(ref _ExaminedGroupData_NinetyPercent_CI_LowerLimit, value); }
        }

        private double _ExaminedGroupData_NinetyFivePercent_CI_LowerLimit = 0;
        public double ExaminedGroupData_NinetyFivePercent_CI_LowerLimit
        {
            get { return _ExaminedGroupData_NinetyFivePercent_CI_LowerLimit; }
            set { SetProperty(ref _ExaminedGroupData_NinetyFivePercent_CI_LowerLimit, value); }
        }

        //UPPER LIMIT
        private double _ExaminedGroupData_EightyPercent_CI_UpperLimit = 0;
        public double ExaminedGroupData_EightyPercent_CI_UpperLimit
        {
            get { return _ExaminedGroupData_EightyPercent_CI_UpperLimit; }
            set { SetProperty(ref _ExaminedGroupData_EightyPercent_CI_UpperLimit, value); }
        }

        private double _ExaminedGroupData_NinetyPercent_CI_UpperLimit = 0;
        public double ExaminedGroupData_NinetyPercent_CI_UpperLimit
        {
            get { return _ExaminedGroupData_NinetyPercent_CI_UpperLimit; }
            set { SetProperty(ref _ExaminedGroupData_NinetyPercent_CI_UpperLimit, value); }
        }

        private double _ExaminedGroupData_NinetyFivePercent_CI_UpperLimit = 0;
        public double ExaminedGroupData_NinetyFivePercent_CI_UpperLimit
        {
            get { return _ExaminedGroupData_NinetyFivePercent_CI_UpperLimit; }
            set { SetProperty(ref _ExaminedGroupData_NinetyFivePercent_CI_UpperLimit, value); }
        }
        //PERCISION AMOUNT
        private double _ExaminedGroupData_EightyPercent_CI_PercisionAmount = 0;
        public double ExaminedGroupData_EightyPercent_CI_PercisionAmount
        {
            get { return _ExaminedGroupData_EightyPercent_CI_PercisionAmount; }
            set { SetProperty(ref _ExaminedGroupData_EightyPercent_CI_PercisionAmount, value); }
        }

        private double _ExaminedGroupData_NinetyPercent_CI_PercisionAmount = 0;
        public double ExaminedGroupData_NinetyPercent_CI_PercisionAmount
        {
            get { return _ExaminedGroupData_NinetyPercent_CI_PercisionAmount; }
            set { SetProperty(ref _ExaminedGroupData_NinetyPercent_CI_PercisionAmount, value); }
        }

        private double _ExaminedGroupData_NinetyFivePercent_CI_PercisionAmount = 0;
        public double ExaminedGroupData_NinetyFivePercent_CI_PercisionAmount
        {
            get { return _ExaminedGroupData_NinetyFivePercent_CI_PercisionAmount; }
            set { SetProperty(ref _ExaminedGroupData_NinetyFivePercent_CI_PercisionAmount, value); }
        }
        //PERCISION PERCENT
        private double _ExaminedGroupData_EightyPercent_CI_PercisionPercent = 0;
        public double ExaminedGroupData_EightyPercent_CI_PercisionPercent
        {
            get { return _ExaminedGroupData_EightyPercent_CI_PercisionPercent; }
            set { SetProperty(ref _ExaminedGroupData_EightyPercent_CI_PercisionPercent, value); }
        }

        private double _ExaminedGroupData_NinetyPercent_CI_PercisionPercent = 0;
        public double ExaminedGroupData_NinetyPercent_CI_PercisionPercent
        {
            get { return _ExaminedGroupData_NinetyPercent_CI_PercisionPercent; }
            set { SetProperty(ref _ExaminedGroupData_NinetyPercent_CI_PercisionPercent, value); }
        }

        private double _ExaminedGroupData_NinetyFivePercent_CI_PercisionPercent = 0;
        public double ExaminedGroupData_NinetyFivePercent_CI_PercisionPercent
        {
            get { return _ExaminedGroupData_NinetyFivePercent_CI_PercisionPercent; }
            set { SetProperty(ref _ExaminedGroupData_NinetyFivePercent_CI_PercisionPercent, value); }
        }
        //TVALUE USED
        private double _ExaminedGroupData_EightyPercent_CI_TValueUsed = 0;
        public double ExaminedGroupData_EightyPercent_CI_TValueUsed
        {
            get { return _ExaminedGroupData_EightyPercent_CI_TValueUsed; }
            set { SetProperty(ref _ExaminedGroupData_EightyPercent_CI_TValueUsed, value); }
        }

        private double _ExaminedGroupData_NinetyPercent_CI_TValueUsed = 0;
        public double ExaminedGroupData_NinetyPercent_CI_TValueUsed
        {
            get { return _ExaminedGroupData_NinetyPercent_CI_TValueUsed; }
            set { SetProperty(ref _ExaminedGroupData_NinetyPercent_CI_TValueUsed, value); }
        }

        private double _ExaminedGroupData_NinetyFivePercent_CI_TValueUsed = 0;
        public double ExaminedGroupData_NinetyFivePercent_CI_TValueUsed
        {
            get { return _ExaminedGroupData_NinetyFivePercent_CI_TValueUsed; }
            set { SetProperty(ref _ExaminedGroupData_NinetyFivePercent_CI_TValueUsed, value); }
        }

        private double _AuditedGroupData_Mean = 0;
        public double AuditedGroupData_Mean
        {
            get { return _AuditedGroupData_Mean; }
            set { SetProperty(ref _AuditedGroupData_Mean, value); }
        }
        private double _AuditedGroupData_Skewness = 0;
        public double AuditedGroupData_Skewness
        {
            get { return _AuditedGroupData_Skewness; }
            set { SetProperty(ref _AuditedGroupData_Skewness, value); }
        }
        private double _AuditedGroupData_StdDeviation = 0;
        public double AuditedGroupData_StdDeviation
        {
            get { return _AuditedGroupData_StdDeviation; }
            set { SetProperty(ref _AuditedGroupData_StdDeviation, value); }
        }
        private double _AuditedGroupData_Kurtosis = 0;
        public double AuditedGroupData_Kurtosis
        {
            get { return _AuditedGroupData_Kurtosis; }
            set { SetProperty(ref _AuditedGroupData_Kurtosis, value); }
        }
        private double _AuditedGroupData_StdErrorMean = 0;
        public double AuditedGroupData_StdErrorMean
        {
            get { return _AuditedGroupData_StdErrorMean; }
            set { SetProperty(ref _AuditedGroupData_StdErrorMean, value); }
        }
        private double _AuditedGroupData_StdErrorTotal = 0;
        public double AuditedGroupData_StdErrorTotal
        {
            get { return _AuditedGroupData_StdErrorTotal; }
            set { SetProperty(ref _AuditedGroupData_StdErrorTotal, value); }
        }
        private double _AuditedGroupData_PointEst = 0;
        public double AuditedGroupData_PointEst
        {
            get { return _AuditedGroupData_PointEst; }
            set { SetProperty(ref _AuditedGroupData_PointEst, value); }
        }

        //LOWER LIMIT
        private double _AuditedGroupData_EightyPercent_CI_LowerLimit = 0;
        public double AuditedGroupData_EightyPercent_CI_LowerLimit
        {
            get { return _AuditedGroupData_EightyPercent_CI_LowerLimit; }
            set { SetProperty(ref _AuditedGroupData_EightyPercent_CI_LowerLimit, value); }
        }

        private double _AuditedGroupData_NinetyPercent_CI_LowerLimit = 0;
        public double AuditedGroupData_NinetyPercent_CI_LowerLimit
        {
            get { return _AuditedGroupData_NinetyPercent_CI_LowerLimit; }
            set { SetProperty(ref _AuditedGroupData_NinetyPercent_CI_LowerLimit, value); }
        }

        private double _AuditedGroupData_NinetyFivePercent_CI_LowerLimit = 0;
        public double AuditedGroupData_NinetyFivePercent_CI_LowerLimit
        {
            get { return _AuditedGroupData_NinetyFivePercent_CI_LowerLimit; }
            set { SetProperty(ref _AuditedGroupData_NinetyFivePercent_CI_LowerLimit, value); }
        }

        //UPPER LIMIT
        private double _AuditedGroupData_EightyPercent_CI_UpperLimit = 0;
        public double AuditedGroupData_EightyPercent_CI_UpperLimit
        {
            get { return _AuditedGroupData_EightyPercent_CI_UpperLimit; }
            set { SetProperty(ref _AuditedGroupData_EightyPercent_CI_UpperLimit, value); }
        }

        private double _AuditedGroupData_NinetyPercent_CI_UpperLimit = 0;
        public double AuditedGroupData_NinetyPercent_CI_UpperLimit
        {
            get { return _AuditedGroupData_NinetyPercent_CI_UpperLimit; }
            set { SetProperty(ref _AuditedGroupData_NinetyPercent_CI_UpperLimit, value); }
        }

        private double _AuditedGroupData_NinetyFivePercent_CI_UpperLimit = 0;
        public double AuditedGroupData_NinetyFivePercent_CI_UpperLimit
        {
            get { return _AuditedGroupData_NinetyFivePercent_CI_UpperLimit; }
            set { SetProperty(ref _AuditedGroupData_NinetyFivePercent_CI_UpperLimit, value); }
        }
        //PERCISION AMOUNT
        private double _AuditedGroupData_EightyPercent_CI_PercisionAmount = 0;
        public double AuditedGroupData_EightyPercent_CI_PercisionAmount
        {
            get { return _AuditedGroupData_EightyPercent_CI_PercisionAmount; }
            set { SetProperty(ref _AuditedGroupData_EightyPercent_CI_PercisionAmount, value); }
        }

        private double _AuditedGroupData_NinetyPercent_CI_PercisionAmount = 0;
        public double AuditedGroupData_NinetyPercent_CI_PercisionAmount
        {
            get { return _AuditedGroupData_NinetyPercent_CI_PercisionAmount; }
            set { SetProperty(ref _AuditedGroupData_NinetyPercent_CI_PercisionAmount, value); }
        }

        private double _AuditedGroupData_NinetyFivePercent_CI_PercisionAmount = 0;
        public double AuditedGroupData_NinetyFivePercent_CI_PercisionAmount
        {
            get { return _AuditedGroupData_NinetyFivePercent_CI_PercisionAmount; }
            set { SetProperty(ref _AuditedGroupData_NinetyFivePercent_CI_PercisionAmount, value); }
        }
        //PERCISION PERCENT
        private double _AuditedGroupData_EightyPercent_CI_PercisionPercent = 0;
        public double AuditedGroupData_EightyPercent_CI_PercisionPercent
        {
            get { return _AuditedGroupData_EightyPercent_CI_PercisionPercent; }
            set { SetProperty(ref _AuditedGroupData_EightyPercent_CI_PercisionPercent, value); }
        }

        private double _AuditedGroupData_NinetyPercent_CI_PercisionPercent = 0;
        public double AuditedGroupData_NinetyPercent_CI_PercisionPercent
        {
            get { return _AuditedGroupData_NinetyPercent_CI_PercisionPercent; }
            set { SetProperty(ref _AuditedGroupData_NinetyPercent_CI_PercisionPercent, value); }
        }

        private double _AuditedGroupData_NinetyFivePercent_CI_PercisionPercent = 0;
        public double AuditedGroupData_NinetyFivePercent_CI_PercisionPercent
        {
            get { return _AuditedGroupData_NinetyFivePercent_CI_PercisionPercent; }
            set { SetProperty(ref _AuditedGroupData_NinetyFivePercent_CI_PercisionPercent, value); }
        }
        //TVALUE USED
        private double _AuditedGroupData_EightyPercent_CI_TValueUsed = 0;
        public double AuditedGroupData_EightyPercent_CI_TValueUsed
        {
            get { return _AuditedGroupData_EightyPercent_CI_TValueUsed; }
            set { SetProperty(ref _AuditedGroupData_EightyPercent_CI_TValueUsed, value); }
        }

        private double _AuditedGroupData_NinetyPercent_CI_TValueUsed = 0;
        public double AuditedGroupData_NinetyPercent_CI_TValueUsed
        {
            get { return _AuditedGroupData_NinetyPercent_CI_TValueUsed; }
            set { SetProperty(ref _AuditedGroupData_NinetyPercent_CI_TValueUsed, value); }
        }

        private double _AuditedGroupData_NinetyFivePercent_CI_TValueUsed = 0;
        public double AuditedGroupData_NinetyFivePercent_CI_TValueUsed
        {
            get { return _AuditedGroupData_NinetyFivePercent_CI_TValueUsed; }
            set { SetProperty(ref _AuditedGroupData_NinetyFivePercent_CI_TValueUsed, value); }
        }

        private double _DifferenceGroupData_Mean = 0;
        public double DifferenceGroupData_Mean
        {
            get { return _DifferenceGroupData_Mean; }
            set { SetProperty(ref _DifferenceGroupData_Mean, value); }
        }
        private double _DifferenceGroupData_Skewness = 0;
        public double DifferenceGroupData_Skewness
        {
            get { return _DifferenceGroupData_Skewness; }
            set { SetProperty(ref _DifferenceGroupData_Skewness, value); }
        }
        private double _DifferenceGroupData_StdDeviation = 0;
        public double DifferenceGroupData_StdDeviation
        {
            get { return _DifferenceGroupData_StdDeviation; }
            set { SetProperty(ref _DifferenceGroupData_StdDeviation, value); }
        }
        private double _DifferenceGroupData_Kurtosis = 0;
        public double DifferenceGroupData_Kurtosis
        {
            get { return _DifferenceGroupData_Kurtosis; }
            set { SetProperty(ref _DifferenceGroupData_Kurtosis, value); }
        }
        private double _DifferenceGroupData_StdErrorMean = 0;
        public double DifferenceGroupData_StdErrorMean
        {
            get { return _DifferenceGroupData_StdErrorMean; }
            set { SetProperty(ref _DifferenceGroupData_StdErrorMean, value); }
        }
        private double _DifferenceGroupData_StdErrorTotal = 0;
        public double DifferenceGroupData_StdErrorTotal
        {
            get { return _DifferenceGroupData_StdErrorTotal; }
            set { SetProperty(ref _DifferenceGroupData_StdErrorTotal, value); }
        }
        private double _DifferenceGroupData_PointEst = 0;
        public double DifferenceGroupData_PointEst
        {
            get { return _DifferenceGroupData_PointEst; }
            set { SetProperty(ref _DifferenceGroupData_PointEst, value); }
        }

        //LOWER LIMIT
        private double _DifferenceGroupData_EightyPercent_CI_LowerLimit = 0;
        public double DifferenceGroupData_EightyPercent_CI_LowerLimit
        {
            get { return _DifferenceGroupData_EightyPercent_CI_LowerLimit; }
            set { SetProperty(ref _DifferenceGroupData_EightyPercent_CI_LowerLimit, value); }
        }

        private double _DifferenceGroupData_NinetyPercent_CI_LowerLimit = 0;
        public double DifferenceGroupData_NinetyPercent_CI_LowerLimit
        {
            get { return _DifferenceGroupData_NinetyPercent_CI_LowerLimit; }
            set { SetProperty(ref _DifferenceGroupData_NinetyPercent_CI_LowerLimit, value); }
        }

        private double _DifferenceGroupData_NinetyFivePercent_CI_LowerLimit = 0;
        public double DifferenceGroupData_NinetyFivePercent_CI_LowerLimit
        {
            get { return _DifferenceGroupData_NinetyFivePercent_CI_LowerLimit; }
            set { SetProperty(ref _DifferenceGroupData_NinetyFivePercent_CI_LowerLimit, value); }
        }

        //UPPER LIMIT
        private double _DifferenceGroupData_EightyPercent_CI_UpperLimit = 0;
        public double DifferenceGroupData_EightyPercent_CI_UpperLimit
        {
            get { return _DifferenceGroupData_EightyPercent_CI_UpperLimit; }
            set { SetProperty(ref _DifferenceGroupData_EightyPercent_CI_UpperLimit, value); }
        }

        private double _DifferenceGroupData_NinetyPercent_CI_UpperLimit = 0;
        public double DifferenceGroupData_NinetyPercent_CI_UpperLimit
        {
            get { return _DifferenceGroupData_NinetyPercent_CI_UpperLimit; }
            set { SetProperty(ref _DifferenceGroupData_NinetyPercent_CI_UpperLimit, value); }
        }

        private double _DifferenceGroupData_NinetyFivePercent_CI_UpperLimit = 0;
        public double DifferenceGroupData_NinetyFivePercent_CI_UpperLimit
        {
            get { return _DifferenceGroupData_NinetyFivePercent_CI_UpperLimit; }
            set { SetProperty(ref _DifferenceGroupData_NinetyFivePercent_CI_UpperLimit, value); }
        }
        //PERCISION AMOUNT
        private double _DifferenceGroupData_EightyPercent_CI_PercisionAmount = 0;
        public double DifferenceGroupData_EightyPercent_CI_PercisionAmount
        {
            get { return _DifferenceGroupData_EightyPercent_CI_PercisionAmount; }
            set { SetProperty(ref _DifferenceGroupData_EightyPercent_CI_PercisionAmount, value); }
        }

        private double _DifferenceGroupData_NinetyPercent_CI_PercisionAmount = 0;
        public double DifferenceGroupData_NinetyPercent_CI_PercisionAmount
        {
            get { return _DifferenceGroupData_NinetyPercent_CI_PercisionAmount; }
            set { SetProperty(ref _DifferenceGroupData_NinetyPercent_CI_PercisionAmount, value); }
        }

        private double _DifferenceGroupData_NinetyFivePercent_CI_PercisionAmount = 0;
        public double DifferenceGroupData_NinetyFivePercent_CI_PercisionAmount
        {
            get { return _DifferenceGroupData_NinetyFivePercent_CI_PercisionAmount; }
            set { SetProperty(ref _DifferenceGroupData_NinetyFivePercent_CI_PercisionAmount, value); }
        }
        //PERCISION PERCENT
        private double _DifferenceGroupData_EightyPercent_CI_PercisionPercent = 0;
        public double DifferenceGroupData_EightyPercent_CI_PercisionPercent
        {
            get { return _DifferenceGroupData_EightyPercent_CI_PercisionPercent; }
            set { SetProperty(ref _DifferenceGroupData_EightyPercent_CI_PercisionPercent, value); }
        }

        private double _DifferenceGroupData_NinetyPercent_CI_PercisionPercent = 0;
        public double DifferenceGroupData_NinetyPercent_CI_PercisionPercent
        {
            get { return _DifferenceGroupData_NinetyPercent_CI_PercisionPercent; }
            set { SetProperty(ref _DifferenceGroupData_NinetyPercent_CI_PercisionPercent, value); }
        }

        private double _DifferenceGroupData_NinetyFivePercent_CI_PercisionPercent = 0;
        public double DifferenceGroupData_NinetyFivePercent_CI_PercisionPercent
        {
            get { return _DifferenceGroupData_NinetyFivePercent_CI_PercisionPercent; }
            set { SetProperty(ref _DifferenceGroupData_NinetyFivePercent_CI_PercisionPercent, value); }
        }
        //TVALUE USED
        private double _DifferenceGroupData_EightyPercent_CI_TValueUsed = 0;
        public double DifferenceGroupData_EightyPercent_CI_TValueUsed
        {
            get { return _DifferenceGroupData_EightyPercent_CI_TValueUsed; }
            set { SetProperty(ref _DifferenceGroupData_EightyPercent_CI_TValueUsed, value); }
        }

        private double _DifferenceGroupData_NinetyPercent_CI_TValueUsed = 0;
        public double DifferenceGroupData_NinetyPercent_CI_TValueUsed
        {
            get { return _DifferenceGroupData_NinetyPercent_CI_TValueUsed; }
            set { SetProperty(ref _DifferenceGroupData_NinetyPercent_CI_TValueUsed, value); }
        }

        private double _DifferenceGroupData_NinetyFivePercent_CI_TValueUsed = 0;
        public double DifferenceGroupData_NinetyFivePercent_CI_TValueUsed
        {
            get { return _DifferenceGroupData_NinetyFivePercent_CI_TValueUsed; }
            set { SetProperty(ref _DifferenceGroupData_NinetyFivePercent_CI_TValueUsed, value); }
        }
    }
}
