﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Prism.Modularity;
using Prism.Regions;
using Microsoft.Practices.ServiceLocation;
using Microsoft.Practices.Unity;
namespace RatStatsChallenge.Module.Interface
{
    public class Primary : IModule
    {
        private readonly IRegionManager regionManager;

        public Primary(IRegionManager regionManager)
        {
            this.regionManager = regionManager;
        }

        public void Initialize()
        {
            var container = ServiceLocator.Current.GetInstance<IUnityContainer>();
            regionManager.RegisterViewWithRegion("PrimaryPageRegion", typeof(Views.HomePageView));
            container.RegisterType<Object, ViewModels.HomePageViewModel>("HomePageViewModel");
            container.RegisterType<Object, Views.RandomNumbers.SingleStageView>("RandomNumbers.SingleStageView");
            container.RegisterType<Object, ViewModels.RandomNumbers.SingleStageViewModel>("RandomNumbers.SingleStageViewModel");
            container.RegisterType<Object, Views.RandomNumbers.SingleStageReportView>("RandomNumbers.SingleStageReportView");
            container.RegisterType<Object, ViewModels.RandomNumbers.SingleStageReportViewModel>("RandomNumbers.SingleStageReportViewModel");
            container.RegisterType<Object, Views.AttributeAppraisals.UnrestrictedView>("AttributeAppraisals.UnrestrictedView");
            container.RegisterType<Object, ViewModels.AttributeAppraisals.UnrestrictedViewModel>("AttributeAppraisals.UnrestrictedViewModel");
            container.RegisterType<Object, Views.AttributeAppraisals.UnrestrictedReportView>("AttributeAppraisals.UnrestrictedReportView");
            container.RegisterType<Object, ViewModels.AttributeAppraisals.UnrestrictedReportViewModel>("AttributeAppraisals.UnrestrictedReportViewModel");
            container.RegisterType<Object, Views.VariableAppraisals.UnrestrictedView>("VariableAppraisals.UnrestrictedView");
            container.RegisterType<Object, ViewModels.VariableAppraisals.UnrestrictedViewModel>("VariableAppraisals.UnrestrictedViewModel");
            container.RegisterType<Object, Views.VariableAppraisals.UnrestrictedReportView>("VariableAppraisals.UnrestrictedReportView");
            container.RegisterType<Object, ViewModels.VariableAppraisals.UnrestrictedReportViewModel>("VariableAppraisals.UnrestrictedReportViewModel");
            container.RegisterType<Object, Views.VariableAppraisals.StratifiedView>("VariableAppraisals.StratifiedView");
            container.RegisterType<Object, ViewModels.VariableAppraisals.StratifiedViewModel>("VariableAppraisals.StratifiedViewModel");
            container.RegisterType<Object, Views.VariableAppraisals.StratifiedReportView>("VariableAppraisals.StratifiedReportView");
            container.RegisterType<Object, ViewModels.VariableAppraisals.StratifiedReportViewModel>("VariableAppraisals.StratifiedReportViewModel");
            container.RegisterType<Object, Infastructure.ExcelAppInterface>("Infastructure.ExcelAppInterface");

        }
    }
}
