﻿using System.Windows.Input;
using Prism.Mvvm;
using Prism.Commands;
using Prism.Regions;
using RatStatsChallenge.Module.Infastructure;
using RatStatsChallenge.Module.Infastructure.Enums;
using System.Diagnostics;

namespace RatStatsChallenge.Module.Interface.ViewModels.AttributeAppraisals
{
    public class UnrestrictedReportViewModel : BindableBase, INavigationAware
    {
        private readonly IRegionManager MyRegionManager;
        private UnrestrictedAttributeAppraisal.ReportData RD = new UnrestrictedAttributeAppraisal.ReportData();
        public UnrestrictedReportViewModel(IRegionManager regionManager)
        {
            this.MyRegionManager = regionManager;
            this.GoHomeCommand = new DelegateCommand<object>(this.OnGoHomeCommand);
            this.GoBackCommand = new DelegateCommand<object>(this.OnGoBackCommand);
            this.ViewTextCommand = new DelegateCommand<object>(this.OnViewTextCommand);
        }
        public ICommand GoHomeCommand { get; private set; }
        private void OnGoHomeCommand(object arg)
        {
            MyRegionManager.RequestNavigate("PrimaryPageRegion", "HomePageView");
        }

        public ICommand GoBackCommand { get; private set; }
        private void OnGoBackCommand(object arg)
        {
            var parameters = new NavigationParameters();
            parameters.Add("SourceViewName", "AttributeAppraisals.UnrestrictedReportView");
            this.MyRegionManager.RequestNavigate("PrimaryPageRegion", "AttributeAppraisals.UnrestrictedView" + parameters);
        }

        public ICommand ViewTextCommand { get; private set; }
        private void OnViewTextCommand(object arg)
        {
            if (System.IO.File.Exists(TextFileOutputPath))
                Process.Start(TextFileOutputPath);
        }

        public virtual bool IsNavigationTarget(NavigationContext navigationContext)
        {
            return true;
        }

        public virtual void OnNavigatedFrom(NavigationContext navigationContext)
        {

        }

        public virtual void OnNavigatedTo(NavigationContext navigationContext)
        {
            if (navigationContext.Parameters != null && navigationContext.Parameters["ReportData"] != null)
            {
                RD = (UnrestrictedAttributeAppraisal.ReportData)navigationContext.Parameters["ReportData"];
                AuditReviewTitle = RD.AuditTitle;
                UniverseSize = RD.UniverseSize;
                SampleSize = RD.SampleSize;
                CI_QuantityIdentified = RD.CI_QuantityIdentified;
                DisplayZeroNote = false;
                DisplayEqualNote = false;
                UserSelectedConfidenceLevelType = RD.UserSelectedConfidenceLevelType;
                if (RD.UserSelectedConfidenceIntervalType == Infastructure.Enums.ConfidenceIntervalType.OneSided)
                {
                    if (CI_QuantityIdentified == 0)
                    {
                        LowerLimitVisible = false;
                        UpperLimitVisible = true;
                        DisplayZeroNote = true;
                    }     
                    else
                    {
                        LowerLimitVisible = true;
                        UpperLimitVisible = false;
                    }

                    if (SampleSize == CI_QuantityIdentified)
                    {
                        DisplayEqualNote = true;
                    }
                    
                }
                else
                {
                    LowerLimitVisible = true;
                    UpperLimitVisible = true;
                }
                LogDate = "Date: " + RD.LogTime.ToShortDateString();
                LogTime = "Time: " + RD.LogTime.ToShortTimeString();
                CI_ProjectedQuantity = RD.CI_ProjectedQuantity;
                CI_Percent = RD.CI_Percent;
                EightyPercent_CI_LowerLimitQuantity = RD.EightyPercent_ConfidenceInterval.LowerLimitQuantity;
                EightyPercent_CI_LowerLimitPercent = RD.EightyPercent_ConfidenceInterval.LowerLimitPercent;
                EightyPercent_CI_UpperLimitQuantity = RD.EightyPercent_ConfidenceInterval.UpperLimitQuantity;
                EightyPercent_CI_UpperLimitPercent = RD.EightyPercent_ConfidenceInterval.UpperLimitPercent;

                NinetyPercent_CI_LowerLimitQuantity = RD.NinetyPercent_ConfidenceInterval.LowerLimitQuantity;
                NinetyPercent_CI_LowerLimitPercent = RD.NinetyPercent_ConfidenceInterval.LowerLimitPercent;
                NinetyPercent_CI_UpperLimitQuantity = RD.NinetyPercent_ConfidenceInterval.UpperLimitQuantity;
                NinetyPercent_CI_UpperLimitPercent = RD.NinetyPercent_ConfidenceInterval.UpperLimitPercent;


                NinetyFivePercent_CI_LowerLimitQuantity = RD.NinetyFivePercent_ConfidenceInterval.LowerLimitQuantity;
                NinetyFivePercent_CI_LowerLimitPercent = RD.NinetyFivePercent_ConfidenceInterval.LowerLimitPercent;
                NinetyFivePercent_CI_UpperLimitQuantity = RD.NinetyFivePercent_ConfidenceInterval.UpperLimitQuantity;
                NinetyFivePercent_CI_UpperLimitPercent = RD.NinetyFivePercent_ConfidenceInterval.UpperLimitPercent;

                CustomPercent_CI_LowerLimitQuantity = RD.CustomPercent_ConfidenceInterval.LowerLimitQuantity;
                CustomPercent_CI_LowerLimitPercent = RD.CustomPercent_ConfidenceInterval.LowerLimitPercent;
                CustomPercent_CI_UpperLimitQuantity = RD.CustomPercent_ConfidenceInterval.UpperLimitQuantity;
                CustomPercent_CI_UpperLimitPercent = RD.CustomPercent_ConfidenceInterval.UpperLimitPercent;

                if (_UserSelectedConfidenceLevelType == ConfidenceLevelType.Custom)
                    CustomLimitLabel = RD.CustomConfidenceLevel.ToString() + "% Confidence Level";

                TextFileOutput = RD.TextFileOutput;
                TextFileOutputPath = RD.TextFileOutputPath;
                
            }

        }

        private bool _DisplayZeroNote = false;
        public bool DisplayZeroNote
        {
            get { return _DisplayZeroNote; }
            set { SetProperty(ref _DisplayZeroNote, value); }
        }

        private bool _DisplayEqualNote = false;
        public bool DisplayEqualNote
        {
            get { return _DisplayEqualNote; }
            set { SetProperty(ref _DisplayEqualNote, value); }
        }

        private string _AuditReviewTitle = "";
        public string AuditReviewTitle
        {
            get { return _AuditReviewTitle; }
            set { SetProperty(ref _AuditReviewTitle, value); }
        }

        private string _LogDate = "";
        public string LogDate
        {
            get { return _LogDate; }
            set { SetProperty(ref _LogDate, value); }
        }

        private string _LogTime = "";
        public string LogTime
        {
            get { return _LogTime; }
            set { SetProperty(ref _LogTime, value); }
        }

        private int _UniverseSize;
        public int UniverseSize
        {
            get { return _UniverseSize; }
            set { SetProperty(ref _UniverseSize, value); }
        }

        private int _SampleSize;
        public int SampleSize
        {
            get { return _SampleSize; }
            set { SetProperty(ref _SampleSize, value); }
        }

        private int _CI_QuantityIdentified;
        public int CI_QuantityIdentified
        {
            get { return _CI_QuantityIdentified; }
            set { SetProperty(ref _CI_QuantityIdentified, value); }
        }

        private double _CI_ProjectedQuantity;
        public double CI_ProjectedQuantity
        {
            get { return _CI_ProjectedQuantity; }
            set { SetProperty(ref _CI_ProjectedQuantity, value); }
        }

        private double _CI_Percent;
        public double CI_Percent
        {
            get { return _CI_Percent; }
            set { SetProperty(ref _CI_Percent, value); }
        }

        private bool _TextFileOutput = false;
        public bool TextFileOutput
        {
            get { return _TextFileOutput; }
            set
            {
                SetProperty(ref _TextFileOutput, value);
            }
        }

        private string _CustomLimitLabel = "";
        public string CustomLimitLabel
        {
            get { return _CustomLimitLabel; }
            set { SetProperty(ref _CustomLimitLabel, value); }
        }

        private ConfidenceLevelType _UserSelectedConfidenceLevelType = ConfidenceLevelType.Default;
        public ConfidenceLevelType UserSelectedConfidenceLevelType
        {
            get { return _UserSelectedConfidenceLevelType; }
            set { SetProperty(ref _UserSelectedConfidenceLevelType, value); }
        }

        private bool _LowerLimitVisible = true;
        public bool LowerLimitVisible
        {
            get { return _LowerLimitVisible; }
            set { SetProperty(ref _LowerLimitVisible, value);}
        }

        private bool _UpperLimitVisible = true;
        public bool UpperLimitVisible
        {
            get { return _UpperLimitVisible; }
            set { SetProperty(ref _UpperLimitVisible, value); }
        }
        
        private double? _EightyPercent_CI_LowerLimitQuantity = null;
        public double? EightyPercent_CI_LowerLimitQuantity
        {
            get { return _EightyPercent_CI_LowerLimitQuantity; }
            set { SetProperty(ref _EightyPercent_CI_LowerLimitQuantity, value); }
        }

        private double? _EightyPercent_CI_LowerLimitPercent = null;
        public double? EightyPercent_CI_LowerLimitPercent
        {
            get { return _EightyPercent_CI_LowerLimitPercent; }
            set { SetProperty(ref _EightyPercent_CI_LowerLimitPercent, value); }
        }

        private double? _EightyPercent_CI_UpperLimitQuantity = null;
        public double? EightyPercent_CI_UpperLimitQuantity
        {
            get { return _EightyPercent_CI_UpperLimitQuantity; }
            set { SetProperty(ref _EightyPercent_CI_UpperLimitQuantity, value); }
        }

        private double? _EightyPercent_CI_UpperLimitPercent = null;
        public double? EightyPercent_CI_UpperLimitPercent
        {
            get { return _EightyPercent_CI_UpperLimitPercent; }
            set { SetProperty(ref _EightyPercent_CI_UpperLimitPercent, value); }
        }

        private double? _NinetyPercent_CI_LowerLimitQuantity = null;
        public double? NinetyPercent_CI_LowerLimitQuantity
        {
            get { return _NinetyPercent_CI_LowerLimitQuantity; }
            set { SetProperty(ref _NinetyPercent_CI_LowerLimitQuantity, value); }
        }

        private double? _NinetyPercent_CI_LowerLimitPercent = null;
        public double? NinetyPercent_CI_LowerLimitPercent
        {
            get { return _NinetyPercent_CI_LowerLimitPercent; }
            set { SetProperty(ref _NinetyPercent_CI_LowerLimitPercent, value); }
        }

        private double? _NinetyPercent_CI_UpperLimitQuantity = null;
        public double? NinetyPercent_CI_UpperLimitQuantity
        {
            get { return _NinetyPercent_CI_UpperLimitQuantity; }
            set { SetProperty(ref _NinetyPercent_CI_UpperLimitQuantity, value); }
        }

        private double? _NinetyPercent_CI_UpperLimitPercent = null;
        public double? NinetyPercent_CI_UpperLimitPercent
        {
            get { return _NinetyPercent_CI_UpperLimitPercent; }
            set { SetProperty(ref _NinetyPercent_CI_UpperLimitPercent, value); }
        }

        private double? _NinetyFivePercent_CI_LowerLimitQuantity = null;
        public double? NinetyFivePercent_CI_LowerLimitQuantity
        {
            get { return _NinetyFivePercent_CI_LowerLimitQuantity; }
            set { SetProperty(ref _NinetyFivePercent_CI_LowerLimitQuantity, value); }
        }

        private double? _NinetyFivePercent_CI_LowerLimitPercent = null;
        public double? NinetyFivePercent_CI_LowerLimitPercent
        {
            get { return _NinetyFivePercent_CI_LowerLimitPercent; }
            set { SetProperty(ref _NinetyFivePercent_CI_LowerLimitPercent, value); }
        }

        private double? _NinetyFivePercent_CI_UpperLimitQuantity = null;
        public double? NinetyFivePercent_CI_UpperLimitQuantity
        {
            get { return _NinetyFivePercent_CI_UpperLimitQuantity; }
            set { SetProperty(ref _NinetyFivePercent_CI_UpperLimitQuantity, value); }
        }

        private double? _NinetyFivePercent_CI_UpperLimitPercent = null;
        public double? NinetyFivePercent_CI_UpperLimitPercent
        {
            get { return _NinetyFivePercent_CI_UpperLimitPercent; }
            set { SetProperty(ref _NinetyFivePercent_CI_UpperLimitPercent, value); }
        }

        private double? _CustomPercent_CI_LowerLimitQuantity = null;
        public double? CustomPercent_CI_LowerLimitQuantity
        {
            get { return _CustomPercent_CI_LowerLimitQuantity; }
            set { SetProperty(ref _CustomPercent_CI_LowerLimitQuantity, value); }
        }

        private double? _CustomPercent_CI_LowerLimitPercent = null;
        public double? CustomPercent_CI_LowerLimitPercent
        {
            get { return _CustomPercent_CI_LowerLimitPercent; }
            set { SetProperty(ref _CustomPercent_CI_LowerLimitPercent, value); }
        }

        private double? _CustomPercent_CI_UpperLimitQuantity = null;
        public double? CustomPercent_CI_UpperLimitQuantity
        {
            get { return _CustomPercent_CI_UpperLimitQuantity; }
            set { SetProperty(ref _CustomPercent_CI_UpperLimitQuantity, value); }
        }

        private double? _CustomPercent_CI_UpperLimitPercent = null;
        public double? CustomPercent_CI_UpperLimitPercent
        {
            get { return _CustomPercent_CI_UpperLimitPercent; }
            set { SetProperty(ref _CustomPercent_CI_UpperLimitPercent, value); }
        }

        private string _TextFileOutputPath = "";
        public string TextFileOutputPath
        {
            get { return _TextFileOutputPath; }
            set { SetProperty(ref _TextFileOutputPath, value); }
        }


    }
}
