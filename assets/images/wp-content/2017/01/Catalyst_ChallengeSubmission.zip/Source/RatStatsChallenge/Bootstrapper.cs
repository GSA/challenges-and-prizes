﻿
using System.Windows;
using Prism.Modularity;
using Prism.Unity;
namespace RatStatsChallenge
{
    class Bootstrapper : UnityBootstrapper
    {
        protected override DependencyObject CreateShell()
        {
            return new Shell();
        }

        protected override void InitializeShell()
        {
            base.InitializeShell();

            Application.Current.MainWindow = (Window)this.Shell;
            Application.Current.MainWindow.SizeToContent = SizeToContent.WidthAndHeight;
            Application.Current.MainWindow.Show();
            
    }

        protected override void ConfigureModuleCatalog()
        {
            base.ConfigureModuleCatalog();
            ModuleCatalog moduleCatalog = (ModuleCatalog)this.ModuleCatalog;
            moduleCatalog.AddModule(typeof(RatStatsChallenge.Module.Interface.Primary));
        }
    }
}
