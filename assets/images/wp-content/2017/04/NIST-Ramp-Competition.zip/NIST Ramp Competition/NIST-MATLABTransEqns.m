clear
clc
close all
%brass 
E=15200000; %psi  

%INPUTS
Width=1;
length=3;
Di=1;

%thickness for drilling
t=1.6;

%diameters of inner holes 
d_Big=0.625;  
d_Small=0.375;
d_Holes=0.1875;
%lengths of turning cuts 
L1=1.3625; 
L2=0.1375;
L3=1.2;
L4=0.3;

%Milling diameters 
D4=1; D3=0.875; D1=0.6; D2=(D1+D3)/2; %chamfer d2
%Original Diameter 
D0=1;

%feedrate inches/min for turning and drilling
for fr = 5:5:80  
%rotational speeds
N=1000;
%point angle for drilling
theta=118;

%calculate time to TURN
Turn_Tm1=L1/fr;  
Turn_Tm2=L2/fr; 
Turn_Tm3=L3/fr;
Turn_Tm4=L4/fr;
Total_Turning_Time=(Turn_Tm1+Turn_Tm2+Turn_Tm3+Turn_Tm4)*60;

%calculate cutting speed for turning 
v=pi*D0*N;
 
%depth of cuts for turning 
d1=(D0-D1)/2;
d2=(D0-D2)/2;
d3=(D0-D3)/2;
d4=(D0-D4)/2;

%calculating feeds for tunring and drilling
f=fr/N;

%turning material removal rates 
Turning_R_MR1=v*f*d1;  
Turning_R_MR2=v*f*d2;  
Turning_R_MR3=v*f*d3; 
Turning_R_MR4=v*f*d4;


%DRILLING EQUATIONS

%thickness of end holes 
tHoles=D1-d_Small;

%cutting speed for drilling
vDSmall=N*pi*d_Small;
vDBig=N*pi*d_Big;
vDHoles=N*pi*d_Holes;

%approach allowance for drilling
ABig=0.5*d_Big*tand(90-theta/2);
ASmall=0.5*d_Small*tand(90-theta/2);
AHoles=0.5*d_Holes*tand(90-theta/2);

%calculate time to DRILL a through hole
Drill_TmBig=(t+ABig)/fr;
Drill_TmSmall=(t+ASmall)/fr;
Drill_TmHoles=(tHoles+AHoles)/fr;
TotalDrillTime=(Drill_TmBig+Drill_TmSmall+2*Drill_TmHoles)*60;

%drilling material removal rates
Drilling_R_MRSmall=pi*d_Small^2*fr/4;
Drilling_R_MRBig=pi*d_Big^2*fr/4;
Drilling_R_MRHoles=pi*d_Holes^2*fr/4;

%inital volume of workpiece 
Vi=(pi*Di^2/4)*length;

%final diameter of work piee 
 Vf=0.79; %from autodesk 
 
 PercentRemoval=((Vi-Vf)/Vi)*100;
 %total time calculations 
 TotalWorkingTime = Total_Turning_Time + TotalDrillTime;


%unit power for brass 
Pu=0.8 %hp/in^3*min

%total power calcuations 
Pc_Turning=Pu*(Turning_R_MR1+Turning_R_MR2+Turning_R_MR3+Turning_R_MR4)
Pc_Drilling=Pu*(Drilling_R_MRSmall+Drilling_R_MRBig+Drilling_R_MRHoles)
Pc_total=Pc_Turning+Pc_Drilling

x(fr/5) = fr;
yp(fr/5) = Pc_total;
yt(fr/5) = TotalWorkingTime;

end
figure(1)
hold on
grid on
plot(x,yp,'r','Color',[0.85,0.4,0],'LineWidth',3)
title('Total Power vs. Feed Rate')
xlabel('Feed Rate (in/min)')
ylabel('Power (hp)')
figure(2)
hold on
grid on
plot(x,yt,'b','LineWidth',3)
title('Total Working Time vs. Feed Rate')
xlabel('Feed Rate (in/min)')
ylabel('Total Working Time (s)')
