ZIP file includes a folder sormaz-RAMP-Challenge-Submission with the following content:
1)	Sormaz-NIST-RAMP-challenge-submisison.pdf � PDF file completing the submission requirements
2)	README.txt  - this file
3)	Model-run-files folder
	a.	Slot-milling-input-xml.pdf� a PDF copy of a XML input file to execute UMP-MPP for slot milling process  
	b.	Slot-milling-output-xml.pdf� a PDF copy of a XML output file obtained by executing UMP-MPP for slot milling process  
	c.	Bracket-milling-output.pdf � a PDF copy of the XML output file that shows the execution of UMP-MPP for all features of bracket example
	d.	Cast-hole-output.pdf � a PDF copy of XML file that shows output of a sequence of processes to produce a high tolerance hole.
	e.	Rbpp-time.pdf � a PDF copy of Jess file with rules for mapping feature dimensions into parameters for process time calculation, and the function for calculation of process time
4)	Resources folder
	a.	UPLCI_milling_reference.pdf � a PDF copy of the primary reference used to construct this model.  URL: http://cratel.wichita.edu/uplci/milling/
	b.	survey-mfg-capabilities-nist.pdf � a PDF file of the report with survey of process capability research, obtained from http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.446.3369&rep=rep1&type=pdf
