var classWichmannHill =
[
    [ "WichmannHill", "dd/d12/classWichmannHill.html#a8392376d29433e4b56154f5af1570d7a", null ],
    [ "check_duplicate", "dd/d12/classWichmannHill.html#aba7ab5ea18a72bf24f2afce502607113", null ],
    [ "ExcelRand64", "dd/d12/classWichmannHill.html#a308f2a466cb8b15cb42942581ad35e96", null ],
    [ "ExcelRandomize64", "dd/d12/classWichmannHill.html#a82b958ef15529f91471a37bbc4969873", null ],
    [ "generateNumbers", "dd/d12/classWichmannHill.html#a909c5d264df92476ceda01c52275426b", null ],
    [ "sum", "dd/d12/classWichmannHill.html#a723a1fcebe1dac24e3226272280e9b07", null ]
];