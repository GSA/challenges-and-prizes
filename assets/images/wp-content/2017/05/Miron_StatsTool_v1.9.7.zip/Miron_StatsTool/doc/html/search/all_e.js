var searchData=
[
  ['ratstats_5fkurtosis',['ratstats_kurtosis',['../d7/d2e/classStatsTool.html#a9b758da29df0c30cf932cdabbb3d198d',1,'StatsTool::ratstats_kurtosis(matrix_t &amp;matrix, int column, long double mean)'],['../d7/d2e/classStatsTool.html#aa0e1fcc59a4cb201572bb495d8974bbc',1,'StatsTool::ratstats_kurtosis(matrix_t_view &amp;matrix, int column, long double mean)']]],
  ['ratstats_5fskewness',['ratstats_skewness',['../d7/d2e/classStatsTool.html#a609f39679ecbb57214cf1d09b462953d',1,'StatsTool::ratstats_skewness(matrix_t &amp;matrix, int column, long double mean)'],['../d7/d2e/classStatsTool.html#a09b3bc9c49370c372c3d188fc2b5a473',1,'StatsTool::ratstats_skewness(matrix_t_view &amp;matrix, int column, long double mean)']]],
  ['readfromfile',['readFromFile',['../d7/d2e/classStatsTool.html#ab279f41842ac1c789c50a54ef7ad5022',1,'StatsTool::readFromFile()'],['../d7/d2e/classStatsTool.html#ac87856e79b87aedadfc38a5825c3a23b',1,'StatsTool::readFromFile(QString inputFileName)']]],
  ['run',['run',['../d9/d79/classAttributeAppraisal.html#a06dc5b93e1c6816143dfd41701ce4fd7',1,'AttributeAppraisal']]]
];
