var searchData=
[
  ['keyoverride',['KeyOverride',['../d7/d0a/classKeyOverride.html',1,'KeyOverride'],['../d7/d0a/classKeyOverride.html#a461aebdb8bb4c1c4eebd2746d83be9d0',1,'KeyOverride::KeyOverride(QObject *parent=0)'],['../d7/d0a/classKeyOverride.html#ac250399ecf70f5a2a2c10751baea448b',1,'KeyOverride::KeyOverride(QObject *parent, Qt::Key key)'],['../d7/d0a/classKeyOverride.html#afa7facd28de2a7c880c266ecc2ed8245',1,'KeyOverride::KeyOverride(QObject *parent, Qt::Key key1, Qt::Key key2)']]]
];
