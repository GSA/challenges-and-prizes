var searchData=
[
  ['numrandoms',['numRandoms',['../d7/da5/classDialogSingleStageRandomNumbers.html#a8f2dde248394ea8b950251dc6134e150',1,'DialogSingleStageRandomNumbers']]],
  ['numspares',['numSpares',['../d7/da5/classDialogSingleStageRandomNumbers.html#a16a84504a4a768bf2ed5879288559959',1,'DialogSingleStageRandomNumbers']]]
];
