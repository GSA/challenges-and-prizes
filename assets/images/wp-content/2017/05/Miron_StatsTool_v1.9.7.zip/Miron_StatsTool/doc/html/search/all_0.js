var searchData=
[
  ['addcommastoinput',['addCommasToInput',['../db/d27/classDialogUnrestrictedAttributeAppraisal.html#afe1ddb2810560999318f0c11e6a713a1',1,'DialogUnrestrictedAttributeAppraisal::addCommasToInput()'],['../db/da5/classDialogUnrestrictedVariableAppraisal.html#a283b6db7bc19b26526b87db027624a06',1,'DialogUnrestrictedVariableAppraisal::addCommasToInput()']]],
  ['addfilteredkey',['addFilteredKey',['../d7/d0a/classKeyOverride.html#a7c973a749afce46600cc76367bb5cfc4',1,'KeyOverride']]],
  ['addmodifier',['addModifier',['../d7/d0a/classKeyOverride.html#a4a200216c6b82904da56ec16df32e92c',1,'KeyOverride']]],
  ['addsheetnames',['addSheetNames',['../d7/de1/classDialogSelectExcelSheet.html#a63bf27d4c1b4521a328d160bd5d7b188',1,'DialogSelectExcelSheet']]],
  ['attributeappraisal',['AttributeAppraisal',['../d9/d79/classAttributeAppraisal.html',1,'AttributeAppraisal'],['../d9/d79/classAttributeAppraisal.html#a94d7d2c21e92ee17b27a5172d14681ac',1,'AttributeAppraisal::AttributeAppraisal(interval_type arg, uint sample_size, uint population_size, uint sample_successes, double confidence, bool double_sided=false)'],['../d9/d79/classAttributeAppraisal.html#a253c8055391230652c64247b2f5f2614',1,'AttributeAppraisal::AttributeAppraisal()']]],
  ['auditname',['auditName',['../d7/da5/classDialogSingleStageRandomNumbers.html#a6a23845244561d4c8a7c2a9aa47a1349',1,'DialogSingleStageRandomNumbers::auditName()'],['../d7/d2e/classStatsTool.html#a9603b73b0a54778ee2964623c33207cf',1,'StatsTool::auditName()']]]
];
