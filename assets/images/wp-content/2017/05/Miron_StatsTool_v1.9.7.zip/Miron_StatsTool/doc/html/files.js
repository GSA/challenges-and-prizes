var files =
[
    [ "attributeappraisal.h", "dc/d9b/attributeappraisal_8h_source.html", null ],
    [ "dialogsamplesizebyattribute.h", "d7/db7/dialogsamplesizebyattribute_8h_source.html", null ],
    [ "dialogsamplesizebyestimatederror.h", "dc/db3/dialogsamplesizebyestimatederror_8h_source.html", null ],
    [ "dialogselectexcelsheet.h", "dd/d4b/dialogselectexcelsheet_8h_source.html", null ],
    [ "dialogsinglestagerandomnumbers.h", "d6/d2a/dialogsinglestagerandomnumbers_8h_source.html", null ],
    [ "dialogstratifiedvariableappraisal.h", "dc/de6/dialogstratifiedvariableappraisal_8h_source.html", null ],
    [ "dialogunrestrictedattributeappraisal.h", "d1/d79/dialogunrestrictedattributeappraisal_8h_source.html", null ],
    [ "dialogunrestrictedvariableappraisal.h", "d4/d40/dialogunrestrictedvariableappraisal_8h_source.html", null ],
    [ "exceltablemodel.hpp", "d7/d56/exceltablemodel_8hpp_source.html", null ],
    [ "keyoverride.h", "de/d32/keyoverride_8h_source.html", null ],
    [ "matrix.h", "dd/df4/matrix_8h_source.html", null ],
    [ "matrixtablemodel.h", "d2/d3f/matrixtablemodel_8h_source.html", null ],
    [ "matrixtablemodel.hpp", "dc/d1e/matrixtablemodel_8hpp_source.html", null ],
    [ "samplesizedetermination.h", "db/da8/samplesizedetermination_8h_source.html", null ],
    [ "st_boost.h", "d8/db4/st__boost_8h_source.html", null ],
    [ "st_macros.h", "d7/d25/st__macros_8h_source.html", null ],
    [ "statstool.h", "d3/dbd/statstool_8h_source.html", null ],
    [ "stdialog.h", "d9/d95/stdialog_8h_source.html", null ],
    [ "variableappraisal.h", "d0/d08/variableappraisal_8h_source.html", null ],
    [ "wichmannhill.h", "d7/d53/wichmannhill_8h_source.html", null ]
];