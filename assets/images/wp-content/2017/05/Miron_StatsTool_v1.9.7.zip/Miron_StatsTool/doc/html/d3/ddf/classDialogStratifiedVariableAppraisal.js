var classDialogStratifiedVariableAppraisal =
[
    [ "build_report", "d3/ddf/classDialogStratifiedVariableAppraisal.html#a100ec23e69055aacca77497856698ebc", null ],
    [ "displayHtml", "d3/ddf/classDialogStratifiedVariableAppraisal.html#a63281e6f0df2025a3da4efd45d36bd76", null ],
    [ "displayText", "d3/ddf/classDialogStratifiedVariableAppraisal.html#ac35f86b8310748a16b1d0e910a891b8d", null ],
    [ "enter_whats_this", "d3/ddf/classDialogStratifiedVariableAppraisal.html#a4771079631014b9ab9bb7274f81699d3", null ],
    [ "insert_header", "d3/ddf/classDialogStratifiedVariableAppraisal.html#a43cb78194f5ee17f276716878855acea", null ],
    [ "insert_summary", "d3/ddf/classDialogStratifiedVariableAppraisal.html#a21f906447858845b03b49e8a5eca1206", null ],
    [ "on_buttonBox_accepted_unsafe", "d3/ddf/classDialogStratifiedVariableAppraisal.html#acc82912b5667864cc8fd77e884e1b672", null ],
    [ "setAuditName", "d3/ddf/classDialogStratifiedVariableAppraisal.html#ad7b6a536c9b39b25433aeb85fe5da997", null ]
];