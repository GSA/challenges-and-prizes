var searchData=
[
  ['wichmannhill',['WichmannHill',['../dd/d12/classWichmannHill.html',1,'WichmannHill'],['../dd/d12/classWichmannHill.html#a8392376d29433e4b56154f5af1570d7a',1,'WichmannHill::WichmannHill()']]]
];
