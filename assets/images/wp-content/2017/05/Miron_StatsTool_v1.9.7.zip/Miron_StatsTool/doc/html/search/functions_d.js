var searchData=
[
  ['savetoexcelfile',['saveToExcelFile',['../d7/d2e/classStatsTool.html#aba43759358c66681e743cea2f253c3f3',1,'StatsTool']]],
  ['second_5fcolumn_5fis_5fdifference',['second_column_is_difference',['../db/da5/classDialogUnrestrictedVariableAppraisal.html#a28f49db0cf29d64d9cfa7f1fc6e0f4e4',1,'DialogUnrestrictedVariableAppraisal']]],
  ['setauditname',['setAuditName',['../d7/da5/classDialogSingleStageRandomNumbers.html#affaed9c0c9f907b3025708129e9123fc',1,'DialogSingleStageRandomNumbers::setAuditName()'],['../d3/ddf/classDialogStratifiedVariableAppraisal.html#ad7b6a536c9b39b25433aeb85fe5da997',1,'DialogStratifiedVariableAppraisal::setAuditName()'],['../db/d27/classDialogUnrestrictedAttributeAppraisal.html#ab656b6384b3989785a406a850d71c0fe',1,'DialogUnrestrictedAttributeAppraisal::setAuditName()'],['../d7/d2e/classStatsTool.html#ac8202edfccf10b45aa60fbc1f3c902b2',1,'StatsTool::setAuditName()']]],
  ['setupdisplayarea',['setupDisplayArea',['../d7/d2e/classStatsTool.html#a09755778ea7ac3ad9820f946871ef055',1,'StatsTool']]],
  ['stringtomatrix',['stringToMatrix',['../df/d66/classMatrixTableModel.html#a8b16d9ae76541c76aa673fdde6ed53f4',1,'MatrixTableModel']]],
  ['sum',['sum',['../dd/d12/classWichmannHill.html#a723a1fcebe1dac24e3226272280e9b07',1,'WichmannHill']]]
];
