var searchData=
[
  ['enter_5fwhats_5fthis',['enter_whats_this',['../d7/da5/classDialogSingleStageRandomNumbers.html#a4ec2f9fa20577ae529fcccaab9c6ddea',1,'DialogSingleStageRandomNumbers::enter_whats_this()'],['../d3/ddf/classDialogStratifiedVariableAppraisal.html#a4771079631014b9ab9bb7274f81699d3',1,'DialogStratifiedVariableAppraisal::enter_whats_this()'],['../db/d27/classDialogUnrestrictedAttributeAppraisal.html#a6c9e25e51ee8fb423590c5b6e19db727',1,'DialogUnrestrictedAttributeAppraisal::enter_whats_this()']]],
  ['excelfiletoplaintext',['excelFileToPlainText',['../d7/d2e/classStatsTool.html#acf65a728d0842a59c2aef4558e331560',1,'StatsTool::excelFileToPlainText(QString &amp;fileName)'],['../d7/d2e/classStatsTool.html#a6c49683909d41fedec795cd81b1c1ac0',1,'StatsTool::excelFileToPlainText(QXlsx::Document &amp;excel)'],['../d7/d2e/classStatsTool.html#a22b93e2ed751bab06516529de8036f8a',1,'StatsTool::excelFileToPlainText(YExcel::BasicExcelWorksheet *sheet)']]],
  ['excelrand64',['ExcelRand64',['../dd/d12/classWichmannHill.html#a308f2a466cb8b15cb42942581ad35e96',1,'WichmannHill']]],
  ['excelrandomize64',['ExcelRandomize64',['../dd/d12/classWichmannHill.html#a82b958ef15529f91471a37bbc4969873',1,'WichmannHill']]],
  ['exec',['exec',['../d7/de1/classDialogSelectExcelSheet.html#a20400c04571054c574c31e8a8e03ecf8',1,'DialogSelectExcelSheet']]]
];
