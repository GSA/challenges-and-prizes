var searchData=
[
  ['nonzero_5fitems',['nonzero_items',['../de/dc1/classVariableAppraisal.html#ab4725814aa5507b96fa5847a627ef149',1,'VariableAppraisal::nonzero_items(matrix_t &amp;mat, int column)'],['../de/dc1/classVariableAppraisal.html#a9a8c6fb5eaa8904fcda0cbabfa8ac2f6',1,'VariableAppraisal::nonzero_items(matrix_t &amp;mat)']]],
  ['numrandoms',['numRandoms',['../d7/da5/classDialogSingleStageRandomNumbers.html#a8f2dde248394ea8b950251dc6134e150',1,'DialogSingleStageRandomNumbers']]],
  ['numspares',['numSpares',['../d7/da5/classDialogSingleStageRandomNumbers.html#a16a84504a4a768bf2ed5879288559959',1,'DialogSingleStageRandomNumbers']]]
];
