var classVariableAppraisal =
[
    [ "build_report", "de/dc1/classVariableAppraisal.html#a315ec6e2c9c6131ef1348145bed82158", null ],
    [ "nonzero_items", "de/dc1/classVariableAppraisal.html#ab4725814aa5507b96fa5847a627ef149", null ],
    [ "nonzero_items", "de/dc1/classVariableAppraisal.html#a9a8c6fb5eaa8904fcda0cbabfa8ac2f6", null ]
];