var classMatrixTableModel =
[
    [ "stringToMatrix", "df/d66/classMatrixTableModel.html#a8b16d9ae76541c76aa673fdde6ed53f4", null ]
];