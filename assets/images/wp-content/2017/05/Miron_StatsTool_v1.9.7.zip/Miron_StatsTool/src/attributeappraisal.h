#ifndef ATTRIBUTEAPPRAISAL_H
#define ATTRIBUTEAPPRAISAL_H

#include <QObject>
#include <QThread>
#include "st_boost.h"

/**
 * @brief Implements the formulas and logic required for attribute appraisal in an optionally multi-threaded fashion
 *
 * If you want to multithread the calculations, you have to use the constructor that takes all the required parameters;
 * if not, you can just create an object with the default constructor and call the upper_limit() and lower_limit()
 * functions with all the necessary parameters.
 *
 * All memory accesses are fully reentrant and thread-safe.
 */
class AttributeAppraisal : public QThread
{

public:
    typedef enum { UPPER, LOWER, UPPER_AND_LOWER } interval_type;

    /**
     * @brief Constructor that's intended to set up the parameters for the caller to multithread calculations with
     * @param arg What to do after spawning a new thread: calculate limits for UPPER, LOWER, or UPPER_AND_LOWER
     * @param sample_size The sample size
     * @param population_size The population size
     * @param sample_successes The errors observed in the sample
     * @param confidence Desired confidence interval
     * @param double_sided Whether or not to compute a two-sided interval
     */
    AttributeAppraisal(interval_type arg, uint sample_size, uint population_size, uint sample_successes, double confidence, bool double_sided = false);
    /**
     * @brief Constructor that's not intended for the object to be utilized in a multithreaded way
     */
    AttributeAppraisal();
    /**
     * @brief Calculate the upper limit of a given confidence interval
     * @param sample_size The sample size
     * @param population_size The population size
     * @param sample_successes The errors observed in the sample
     * @param confidence Desired confidence interval
     * @param double_sided Whether or not to compute a two-sided interval
     * @return The upper limit
     */
    int64_t upper_limit(uint sample_size, uint population_size, uint sample_successes, double confidence, bool double_sided = true);
    /**
     * @brief Calculate the lower limit of a given confidence interval
     * @param sample_size The sample size
     * @param population_size The population size
     * @param sample_successes The errors observed in the sample
     * @param confidence Desired confidence interval
     * @param double_sided Whether or not to compute a two-sided interval
     * @return The lower limit
     */
    int64_t lower_limit(uint sample_size, uint population_size, uint sample_successes, double confidence, bool double_sided = true);
    /**
     * @brief floating-point only version
     *
     * benchmarks for 2,000,000,000 / 1,000,000,000 / 555,555,555:
     *   multiprecision:                    8 seconds
     *   floating-point only:               5 seconds
     *   single step floating point loop:   14 seconds
     */
    int64_t upper_limit_imprecise(uint sample_size, uint population_size, uint sample_successes, double confidence, bool double_sided = true);
    /**
     * @brief floating-point only version
     *
     * benchmarks for 2,000,000,000 / 1,000,000,000 / 555,555,555:
     *   multiprecision:                    8 seconds
     *   floating-point only:               5 seconds
     *   single step floating point loop:   14 seconds
     */
    int64_t lower_limit_imprecise(uint sample_size, uint population_size, uint sample_successes, double confidence, bool double_sided = true);
    /**
     * @brief Lower limit accessor
     * @return The lower limit, if calculations are finished; if not, -1
     *
     * This function is reentrant and thread-safe; you can poll it, if necessary
     */
    int64_t getLower();
    /**
     * @brief Upper limit accessor
     * @return The upper limit, if calculations are finished; if not, -1
     *
     * This function is reentrant and thread-safe; you can poll it, if necessary
     */
    int64_t getUpper();
    boost_cast_type upper_bound_on_p(uint sample_size, uint sample_successes, double C);
    boost_cast_type lower_bound_on_p(uint sample_size, uint sample_successes, double C);
    int sampleSizeByAttribute(double errorRate, uint universeSize, double precision, QStringList *ret = NULL);

protected:
    double getUpperCDF();
    double getLowerCDF();

private:
    /**
     * @brief Called internally when thread execution begins, if the object was created with an UPPER job
     * @return The upper limit
     */
    int64_t upper_limit();
    /**
     * @brief Called internally when thread execution begins, if the object was created with a LOWER job
     * @return The lower limit
     */
    int64_t lower_limit();
    /**
     * @brief Don't ever use this function; use the inherited member function start() instead
     *
     * To interrupt the calculations mid-way, call requestInterruption() on the object (member function inherited from QThread)
     */
    void run();
    /**
     * @brief What to do after our thread of execution starts
     */
    interval_type job;
    uint64_t sample_size = 0;
    uint64_t population_size = 0;
    uint64_t sample_successes = 0;
    double confidence = 0.0;
    bool beFast;
    bool double_sided;
    QAtomicInteger<int64_t> upper = -1;
    QAtomicInteger<int64_t> lower = -1;
    double upperCDF = -1;
    double lowerCDF = -1;
};

#endif // ATTRIBUTEAPPRAISAL_H
