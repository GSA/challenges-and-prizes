#include "dialogunrestrictedattributeappraisal.h"
#include "ui_dialogunrestrictedattributeappraisal.h"
#include "statstool.h"
#include "st_boost.h"
#include "attributeappraisal.h"
#include <boost/math/special_functions/binomial.hpp>
#include <QThread>
#include <QtConcurrent>
#include <qtconcurrentrun.h>


DialogUnrestrictedAttributeAppraisal::DialogUnrestrictedAttributeAppraisal(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogUnrestrictedAttributeAppraisal)
{
    validator = new QIntValidator(0, INT_MAX, this);

    ui->setupUi(this);
    ui->lineEdit_universeSize->setValidator(validator);
    ui->lineEdit_sampleSize->setValidator(validator);
    ui->lineEdit_itemsOfInterest->setValidator(validator);
    ui->lineEdit_auditName->setFocus();

    connect(ui->lineEdit_universeSize, SIGNAL(textEdited(QString)), this, SLOT(addCommasToInput(QString)));
    connect(ui->lineEdit_sampleSize, SIGNAL(textEdited(QString)), this, SLOT(addCommasToInput(QString)));
    connect(ui->lineEdit_itemsOfInterest, SIGNAL(textEdited(QString)), this, SLOT(addCommasToInput(QString)));
}

DialogUnrestrictedAttributeAppraisal::~DialogUnrestrictedAttributeAppraisal()
{
    delete ui;
    if ( validator) delete validator;
}

void DialogUnrestrictedAttributeAppraisal::addCommasToInput(QString str)
{
    QLineEdit *edit = static_cast<QLineEdit*>(QWidget::focusWidget());
    int cursorPos = edit->cursorPosition();

    validator->fixup(str);
    edit->setText(str);

    if (abs(edit->cursorPosition() - cursorPos) > 1)
        edit->setCursorPosition(cursorPos);
}

void DialogUnrestrictedAttributeAppraisal::calculate_multithreaded(uint64_t n, uint64_t N, uint64_t k, QStringList &out)
{
    int64_t upper = 0;
    int64_t lower = 0;
    uint64_t K = round(k / (n / (double)N));
    AttributeAppraisal *threads[9] = { NULL };
    long double confidence_levels[] = { 0.20, 0.10, 0.05, 0.01, 0.00 };

    KeyOverride keyOverride(this, Qt::Key_Escape);
    this->installEventFilter(&keyOverride);

    out << QString::asprintf("Characteristic of interest in sample: %'ld<br/>", k);
    out << QString::asprintf("Projected quantity in universe: %'ld (%'.3f%%)", K, (100 * (K / (double)N))) << "<br/>";

    if (n == 0 || n > N || k > n || N == 0)
        throw std::exception();

    int i = 0;
    for (int j = 0; confidence_levels[j] != 0; j++)
    {
        long double C = confidence_levels[j];
        threads[i] = new AttributeAppraisal(AttributeAppraisal::LOWER, n, N, k, C, ui->checkBox_upperLimit->isChecked());
        threads[i + 1] = new AttributeAppraisal(AttributeAppraisal::UPPER, n, N, k, C, ui->checkBox_lowerLimit->isChecked());
        threads[i]->start();
        threads[i + 1]->start();
        i += 2;
    }
    for (int i = 0; threads[i] != NULL; i++) {
        while (threads[i]->isRunning()) {
            QApplication::processEvents();
            if (abortRequested) {
                for (int j = 0; threads[j] != NULL; j++)
                    threads[j]->requestInterruption();
                goto display_report;
            }
        }
    }
    // Yes.  Goto.  Because sometimes, it's the cleanest answer, no matter what your friends say :)
    display_report:
    i = 0;
    for (int j = 0; confidence_levels[j] != 0; j++)
    {
        long double C = confidence_levels[j];
        out << QString::asprintf("<div class='confidence_interval'><h4>%d%% confidence interval</h4>", (int)roundl(100 * (1 - C)));
        if (ui->checkBox_lowerLimit->isChecked()) {
            lower = threads[i]->getLower();
            if (lower != -1)
                out << QString::asprintf("Lower bound: %'lld (%'.3f%%)<br/>", (long long int)lower, (100 * (lower / (double)N)));
        }
        if (ui->checkBox_upperLimit->isChecked()) {
            upper = threads[i+1]->getUpper();
            if (upper != -1)
                out << QString::asprintf("Upper bound: %'lld (%'.3f%%)<br/>", (long long int)upper, (100 * (upper / (double)N)));
        }
        i += 2;
        out << "</div>";
    }
    emit displayHtml(out.join(""));
}

void DialogUnrestrictedAttributeAppraisal::calculate(uint64_t n, uint64_t N, uint64_t k, QStringList &out)
{
    int64_t upper = 0;
    int64_t lower = 0;
    uint64_t K = round(k / (n / (double)N));
    long double confidence_levels[] = { 0.20, 0.10, 0.05, 0.01, 0.00 };

    KeyOverride keyOverride(this, Qt::Key_Escape);
    this->installEventFilter(&keyOverride);

    out << QString::asprintf("Characteristic of interest in sample: %'ld<br/>", k);
    out << QString::asprintf("Projected quantity in universe: %'ld (%'.3f%%)", K, (100 * (K / (double)N)));

    if (n == 0 || n > N || k > n || N == 0)
        throw std::exception();
    for (int i = 0; confidence_levels[i] != 0; i++)
    {
        long double C = confidence_levels[i];
        AttributeAppraisal lowerAtt(AttributeAppraisal::LOWER, n, N, k, C, ui->checkBox_upperLimit->isChecked());
        AttributeAppraisal upperAtt(AttributeAppraisal::UPPER, n, N, k, C, ui->checkBox_lowerLimit->isChecked());
        if (ui->checkBox_lowerLimit->isChecked())
            lowerAtt.start();
        if (ui->checkBox_upperLimit->isChecked())
            upperAtt.start();

        while (lowerAtt.isRunning() || upperAtt.isRunning()) {
            QApplication::processEvents();
            if (abortRequested) {
                lowerAtt.requestInterruption();
                upperAtt.requestInterruption();
            }
        }
        if (abortRequested)
            return;

        out << QString::asprintf("<div class='confidence_interval'><h4>%d%% confidence interval</h4>", (int)roundl(100 * (1 - C)));
        if (ui->checkBox_lowerLimit->isChecked()) {
            lower = lowerAtt.getLower();
            out << QString::asprintf("Lower bound: %'lld (%'.3f%%)<br/>", (long long int)lower, (100 * (lower / (double)N)));
        }
        if (ui->checkBox_upperLimit->isChecked()) {
            upper = upperAtt.getUpper();
            out << QString::asprintf("Upper bound: %'lld (%'.3f%%)<br/>", (long long int)upper, (100 * (upper / (double)N)));
        }
        out << "</div>";
        emit displayHtml(out.join(""));
    }
}

void DialogUnrestrictedAttributeAppraisal::calculate_table(uint64_t n, uint64_t N, uint64_t k, QStringList &out)
{
    int64_t upper = 0;
    int64_t lower = 0;
    uint64_t K = round(k / (n / (double)N));
    AttributeAppraisal attributeApp;

    out << QString::asprintf("Characteristic of interest in sample: %'ld<br/>", k);
    out << QString::asprintf("Projected quantity in universe: %'ld (%'.3f%%)", K, (100 * (K / (double)N))) << "<br/>\n";
    out << "<center><table border='0' cellpadding='10' cellspacing='10'>";
    out << "<tr><th colspan='4'><u>Confidence intervals</u></th></tr><tr><td/>";
    if (n == 0 || n > N || k > n || N == 0)
        throw std::exception();
    for (long double C = 0.20; C >= 0.05; C /= 2)
    {
        out << QString::asprintf("<td>%d%% confidence</td>", (int)round(100 * (1 - C)));
    }
    out << "</tr><tr><td>Lower bound</td>";
    for (long double C = 0.20; C >= 0.05; C /= 2)
    {
        if (ui->checkBox_lowerLimit->isChecked()) {
            if (n == N)
                lower = k;
            else
                lower = attributeApp.lower_limit(n, N, k, C, ui->checkBox_upperLimit->isChecked());
            out << QString::asprintf("<td>%'lld (%'.3f%%)</td>", (long long int)lower, (100 * (lower / (double)N)));
        }
    }
    out << "</tr><tr><td>Upper bound</td>";
    for (long double C = 0.20; C >= 0.05; C /= 2)
    {
        if (ui->checkBox_upperLimit->isChecked()) {
            upper = attributeApp.upper_limit(n, N, k, C, ui->checkBox_lowerLimit->isChecked());
            out << QString::asprintf("<td>%'lld (%'.3f%%)</td>", (long long int)upper, (100 * (upper / (double)N)));
        }
    }
    out << "</table></center>";
}

void DialogUnrestrictedAttributeAppraisal::insert_header(uint64_t n, uint64_t N, QStringList &out)
{
    out << "<div class='module_header'>";
    out << "<h3>Attribute Appraisal - Unrestricted</h3><br/>";
    out << "Audit: " << ui->lineEdit_auditName->text() << "<br/>";
    out << "Date: " << QDateTime::currentDateTime().toString() << "<br/>";
    out << "</div>";
    out << "Universe size: " << QString::asprintf("%'ld", N) << "<br/>";
    out << "Sample size: " << QString::asprintf("%'ld", n) << "<br/>";
}

// Qt doesn't like exceptions, so provide an exception-safe wrapper
void DialogUnrestrictedAttributeAppraisal::on_buttonBox_accepted()
{
    QApplication::setOverrideCursor(Qt::WaitCursor);
    qint64 start_msecs = QDateTime::currentMSecsSinceEpoch();

    ui->buttonBox->setDisabled(true);
    ui->pushButton_abort->setEnabled(true);
    abortRequested = false;

    try {
        on_buttonBox_accepted_unsafe();
    } catch (std::exception &e) {
        qDebug() << e.what();
        ST_ERRORBOX("An error occurred; please check your input values and try again.");
    }

    ui->buttonBox->setEnabled(true);
    ui->pushButton_abort->setDisabled(true);

    QApplication::restoreOverrideCursor();
    qDebug() << QString("Finished in %1 seconds").arg( (QDateTime::currentMSecsSinceEpoch() - start_msecs) / 1000.0);
}

void DialogUnrestrictedAttributeAppraisal::on_buttonBox_accepted_unsafe()
{
    uint64_t N = 0, n = 0, k = 0;
    QStringList out;

    N = ui->lineEdit_universeSize->text().remove(tr(",")).toInt();
    n = ui->lineEdit_sampleSize->text().remove(tr(",")).toInt();
    k = ui->lineEdit_itemsOfInterest->text().remove(tr(",")).toInt();

    insert_header(n, N, out);
    if (QThread::idealThreadCount() > 4)
        calculate_multithreaded(n, N, k, out);
    else
        calculate(n, N, k, out);

    emit setAuditName(ui->lineEdit_auditName->text());
    emit displayHtml(out.join(""));
    emit reject();
}

void DialogUnrestrictedAttributeAppraisal::on_pushButton_abort_clicked()
{
    ui->pushButton_abort->setDisabled(true);
    abortRequested = true;
}
