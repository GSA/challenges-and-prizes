#include "stdialog.h"
#include "st_macros.h"
#include <QtWidgets>
#include <float.h>

STDialog::STDialog(QWidget *parent) :
    QDialog(parent),
    validator(new QIntValidator(0, INT_MAX, this)),
    dblValidator(new QDoubleValidator(DBL_MIN, DBL_MAX, 3, this)),
    negValidator(new QIntValidator(-INT_MAX, INT_MAX, this))
{
}

STDialog::~STDialog()
{
    if ( validator )
        delete validator;
    if ( dblValidator )
        delete dblValidator;
    if ( negValidator )
        delete negValidator;
}

void STDialog::addCommasToInput(QString str)
{
    QLineEdit *edit = static_cast<QLineEdit*>(QWidget::focusWidget());
    int cursorPos = edit->cursorPosition();

    validator->fixup(str);
    edit->setText(str);

    if (abs(edit->cursorPosition() - cursorPos) > 1)
        edit->setCursorPosition(cursorPos);
}

void STDialog::on_buttonBox_accepted()
{
    QApplication::setOverrideCursor(Qt::WaitCursor);
    qint64 start_msecs = QDateTime::currentMSecsSinceEpoch();
    try {
        on_buttonBox_accepted_unsafe();
    } catch (std::exception &e) {
        qDebug() << e.what();
        ST_ERRORBOX("An error occurred; please check your input values and try again.");
    }
    QApplication::restoreOverrideCursor();
    qDebug() << QString("Finished in %1 seconds").arg( (QDateTime::currentMSecsSinceEpoch() - start_msecs) / 1000.0);
}

void STDialog::on_actionWhat_s_this_triggered()
{
    emit enter_whats_this();
}
