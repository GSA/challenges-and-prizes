#ifndef DIALOGSAMPLESIZEBYATTRIBUTE_H
#define DIALOGSAMPLESIZEBYATTRIBUTE_H

#include <QDialog>
#include <QValidator>

namespace Ui {
class DialogSampleSizeByAttribute;
}

/**
 * @brief Not fully implemented and currently disabled
 */
class DialogSampleSizeByAttribute : public QDialog
{
    Q_OBJECT

public:
    explicit DialogSampleSizeByAttribute(QWidget *parent = 0);
    ~DialogSampleSizeByAttribute();
    void calculate(QStringList &report, double error_rate, uint N, double precision);

signals:
    void displayHtml(QString html);
    void displayText(QString text);
    void enter_whats_this();

public slots:
    void on_actionWhat_s_this_triggered();

private slots:
    void on_buttonBox_accepted();
    void on_buttonBox_accepted_unsafe();
    void addCommasToInput(QString str);

private:
    Ui::DialogSampleSizeByAttribute *ui;
    QValidator *validator;
    QValidator *double_validator;
};

#endif // DIALOGSAMPLESIZEBYATTRIBUTE_H
