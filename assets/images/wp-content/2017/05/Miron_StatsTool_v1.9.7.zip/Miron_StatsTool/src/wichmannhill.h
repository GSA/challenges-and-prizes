#ifndef WICHMANNHILL_H
#define WICHMANNHILL_H

#include <unordered_map>
#include <map>
#include <cmath>

/**
 * @brief An implementation of the Wichmann-Hill pseudo-random number generator
 *
 * Designed and coded to mimic the original RAT-STATS software
 */
class WichmannHill
{
	private:
        /**
         * @brief A C++ implementation (of an R version provided by the OIG) of the Visual Basic function used by RAT-STATS
         *
         * A C++ implementation (of an R version provided by the OIG) of the Visual Basic function used by RAT-STATS
         */
        void ExcelRand64(int64_t ExcelSeed, int64_t outputmax, int64_t &Step, long double &ExcelOutput, long double &RATSTAT);
        /**
         * @brief C++ implementation (of an R version provided by the OIG) of the Visual Basic function used by RAT-STATS
         *
         * C++ implementation (of an R version provided by the OIG) of the Visual Basic function used by RAT-STATS
         */
        int64_t ExcelRandomize64(double startingpoint, int64_t ExcelSeed);
        /**
         * @brief Check if a given number has already been generated
         * @param hashmap The object storing the previously generated values
         * @param temp The value that may be a duplicate
         * @return True if it's a duplicate, false otherwise
         *
         * This is executed for every number generated; since it's much faster to use hash buckets than to
         * iterate through an array, a std::unordered_map (implemented with hash buckets) is used
         */
        bool check_duplicate(std::unordered_map<int64_t, int64_t> &hashmap, int64_t temp);
        long double seed_a = 0;
        long double seed_b = 0;
        long double seed_c = 0;

	public:
        /**
         * @brief Generate random numbers using the same algorithm as RAT-STATS
         * @param how_many How many random numbers to generate
         * @param min The minimum possible value desired for the generated numbers
         * @param max The maximum possible value desired for the generated numbers
         * @param randoms Storage for the numbers, also used to return them
         * @return -1 on failure, 0 on success
         *
         * Generate random numbers using the same algorithm as RAT-STATS
         */
        int generateNumbers(int how_many, int64_t min, int64_t max, std::map<int64_t, int64_t> &randoms);
        /**
         * @brief Compute the sum of a set of random numbers
         * @param randoms The random numbers to sum
         * @return The sum of all the numbers
         *
         * Compute the sum of a set of random numbers
         */
        int64_t sum(std::map<int64_t, int64_t> &randoms);
        /**
         * @brief Construct a Wichmann-Hill PRNG with the given seed
         * @param seed The seed to use
         *
         * Construct a Wichmann-Hill PRNG with the given seed
         */
        WichmannHill(double seed);
};

#endif
