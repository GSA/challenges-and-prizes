#ifndef ST_MACROS_H
#define ST_MACROS_H

#include <QApplication>
#include <QMessageBox>
#include <errno.h>
#include <stdlib.h>
#include <cmath>

#define PROGRAM_TITLE QString("RAT-STATS")
#define PROGRAM_VERSION_STRING (QString("v") + QString("%1").arg(PROGRAM_VERSION_MAJOR) + "." + QString("%1").arg(PROGRAM_VERSION_MINOR))
#define PROGRAM_STRING_FULL PROGRAM_TITLE + " " + PROGRAM_VERSION_STRING

#define ST_ERRORBOX(str) { QApplication::setOverrideCursor(Qt::ArrowCursor); \
    QMessageBox errBox; \
    errBox.setWindowTitle(PROGRAM_TITLE); \
    errBox.setText(str); \
    errBox.setWhatsThis("Click this button to close the message box."); \
    errBox.exec(); \
    QApplication::restoreOverrideCursor(); \
}

#define STRIP_REGEXP QRegExp("\\$|,|\\(|\\)")
#define SPLIT_REGEXP QRegExp("\t| ")
#define NONNUMERIC_RX QRegExp("[^\\,\\-\\.0-9\\$]+")

#define DIALOG_SIGNAL_DECLARATIONS \
void displayHtml(QString str); \
void displayText(QString str); \
void enter_whats_this(); \
void setAuditName(QString str);

#define CLEANUP_DIALOG(dialog) { \
    if ( !SAVE_DIALOG_STATE && dialog ) { \
        delete dialog; \
        dialog = NULL; \
    } }

#define strtold_chk(str, ptr) strtold_chk_func(str, ptr, __FILE__, __LINE__)

static long double strtold_chk_func(const char *str, char **ptr, const char *file, const int line)
{
    errno = 0;
    long double strtold_chk_ret = strtold(str, ptr);
    if ( errno == ERANGE )
        qDebug("Range error (int %'lld, float %'Lf) at %s: %d", static_cast<long long>(strtold_chk_ret), strtold_chk_ret, file, line);
    return strtold_chk_ret;
}

//#ifdef WIN64
//#define isnormal(a) isnormal<long double>( (long double)a )
//#endif

//#ifdef WIN64
//#define isnormal(a) ( (a != FP_NAN && a != FP_INFINITE && a != -FP_NAN && a != -FP_INFINITE && a != FP_SUBNORMAL && a != FP_ZERO) ? true : false )
//#endif

//#define isnormal(a) (fpclassify( static_cast<double>(a) ) == FP_NORMAL)

#define SUBTLE_COLORS { "azure", "ivory", "mintcream", "oldlace", "whitesmoke", "mistyrose", "lavender", "honeydew", NULL }
#endif // ST_MACROS_H
