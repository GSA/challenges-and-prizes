#ifndef MATRIXTABLEMODEL_H
#define MATRIXTABLEMODEL_H

#include "matrixtablemodel.hpp"

class MatrixTableModel
{
public:

signals:
    void focusCell(int, int);
};

#endif // MATRIXTABLEMODEL_H
