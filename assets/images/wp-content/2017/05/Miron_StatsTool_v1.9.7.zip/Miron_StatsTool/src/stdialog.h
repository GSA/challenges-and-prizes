#ifndef STDIALOG_H
#define STDIALOG_H

#include <QDialog>
#include <QValidator>

namespace Ui {
class STDialog;
}

/**
 * @brief For module windows, inherit from this class (which itself inherits from QDialog)
 *
 * This class serves to reduce the amount of boilerplate code required to set up things like
 * the F1 key entering "What's this?" mode, etc.
 */
class STDialog : public QDialog
{
    Q_OBJECT

public:
    explicit STDialog(QWidget *parent = 0);
    ~STDialog();

signals:
    void displayHtml(QString html);
    void displayText(QString text);
    void enter_whats_this();
    void setAuditName(QString str);

public slots:
    void on_actionWhat_s_this_triggered();

    void addCommasToInput(QString str);
    virtual void on_buttonBox_accepted_unsafe() = 0;
    void on_buttonBox_accepted();

protected:
    QValidator *validator = NULL;
    QValidator *dblValidator = NULL;
    QValidator *negValidator = NULL;
};

#endif // STDIALOG_H
