/*
 * All the code that implements the logic for the Stratified
 * Variable Appraisal module is found in this file.  As with
 * the rest of the project, the actual GUI design is in the
 * .ui file.
 */

#include "dialogstratifiedvariableappraisal.h"
#include "ui_dialogstratifiedvariableappraisal.h"
#include "statstool.h"
#include "keyoverride.h"
#include "variableappraisal.h"





DialogStratifiedVariableAppraisal::DialogStratifiedVariableAppraisal(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogStratifiedVariableAppraisal)
{
    ui->setupUi(this);
//    keyOverride = new KeyOverride(this, Qt::Key_Return);
    keyOverride = new KeyOverride(this, Qt::Key_Tab, KeyOverride::Key_Shift_Tab);
    model = new MatrixTableModel<matrix_t>(ui->tableView);

    ui->lineEdit_auditName->setFocus();
    ui->plainTextEdit_data->installEventFilter(keyOverride);
    ui->plainTextEdit_strata->installEventFilter(keyOverride);
    ui->tableView->installEventFilter(keyOverride);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableView->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->plainTextEdit_data->hide();
}

DialogStratifiedVariableAppraisal::~DialogStratifiedVariableAppraisal()
{
    delete ui;
    delete keyOverride;
    delete model;
}

void DialogStratifiedVariableAppraisal::on_pushButton_openDataFile_clicked()
{
    QString inputFileName = QFileDialog::getOpenFileName(NULL, tr("Input File"), "", tr("*.txt *.xlsx *.xls"));
    if (inputFileName.isEmpty())
        return;
    else
        dataFileName = inputFileName;

    ui->plainTextEdit_data->setPlainText(StatsTool::readFromFile(dataFileName));
    if (model)
        delete model;
    model = new MatrixTableModel<matrix_t>(ui->tableView);
    ui->tableView->setModel(model);

    model->stringToMatrix(ui->plainTextEdit_data->document()->toPlainText(),
                          false, false);
    for (int i = 0; i < model->columnCount(); i++)
        model->setHeaderData(i, Qt::Horizontal, QVariant());
    ui->tableView->show();
    ui->plainTextEdit_data->hide();
}

void DialogStratifiedVariableAppraisal::focusTableViewCell(int i, int j)
{
    QItemSelectionModel::SelectionFlags flags = QItemSelectionModel::ClearAndSelect;
    QModelIndex index = model->index(i, j);

    ui->tableView->selectionModel()->select(index, flags);
    return;
}

void DialogStratifiedVariableAppraisal::on_pushButton_openStrataFile_clicked()
{
    QString inputFileName = QFileDialog::getOpenFileName(NULL, tr("Input File"), "", tr("*.txt *.xlsx *.xls"));
    if (inputFileName.isEmpty())
        return;
    else
        strataFileName = inputFileName;

    QString text = StatsTool::readFromFile(strataFileName);
    ui->plainTextEdit_strata->setPlainText(text);

    QStringList textList = text.split(QRegExp("\r?\n"), QString::SkipEmptyParts);
    if ( textList.size() < 1 )
        return;
    QStringList tokens = textList.at(0).split(SPLIT_REGEXP, QString::SkipEmptyParts);
    foreach ( QString token, tokens ) {
        bool ok = true;
        token.toDouble(&ok);
        if ( !ok )
            ui->checkBox_ignoreFirstStrataRow->setChecked(true);
    }
}

void DialogStratifiedVariableAppraisal::on_buttonBox_accepted()
{
    QApplication::setOverrideCursor(Qt::WaitCursor);
    qint64 start_msecs = QDateTime::currentMSecsSinceEpoch();
    try {
        on_buttonBox_accepted_unsafe();
    } catch (std::exception &e) {
        qDebug() << e.what();
        ST_ERRORBOX("An error occurred; please check your input values and try again.");
    }
    QApplication::restoreOverrideCursor();
    qDebug() << QString("Finished in %1 seconds").arg( (QDateTime::currentMSecsSinceEpoch() - start_msecs) / 1000.0);
}

void DialogStratifiedVariableAppraisal::insert_summary(const matrix_t &sums, const matrix_t &strata_matrix, const matrix_t &nonzero_items, QStringList &report, QStringList &column_labels, int idx_to_insert)
{
    QString summary("\n<div class='summary'><h3>Summary</h3><pre>STRATUM  SAMPLE");

    if (column_labels.empty())
        for (uint i = 0; i < sums.cols(); i++)
            column_labels << QString("COLUMN %1    ").arg(i + 1);

    foreach(QString label, column_labels) {
            summary.append(QString::asprintf("%18.18s   NONZERO", label.toStdString().c_str()));
    }
    summary.append(QString::asprintf("\n  %3.3s   %6.6s", "NUM", "SIZE"));
    foreach(QString label, column_labels) {
        summary.append(QString::asprintf(" %18.18s    %5.5s", "", "ITEMS"));
    }
    summary.append("\n\n");
    for (uint i = 0; i < sums.rows(); i++)
    {
        summary.append(QString::asprintf(" <a href='#stratum_%d'>%'4d</a>    %'5lld", i + 1, i + 1, (long long int)strata_matrix(i, 1)));
        for (uint j = 0; j < sums.cols(); j++)
        {
            summary.append(QString::asprintf("%'18.2Lf%'10lld", sums(i, j), (long long int)nonzero_items(i, j)));
        }
        summary.append("\n");
    }
    matrix_t total_sums = scythe::sumc(sums);
    matrix_t total_nonzero = scythe::sumc(nonzero_items);
    matrix_t total_samples = scythe::sumc(strata_matrix);
    summary.append("\n");
    summary.append( QString::asprintf("%'14lld", (long long int)total_samples(1)) );
    for (uint i = 0; i < total_sums.cols(); i++)
    {
        summary.append( QString::asprintf("%'18.2Lf%'10lld", total_sums(i), (long long int)total_nonzero(i)) );
    }
    summary.append("</pre></div>");
//    summary.append("</pre><hr width='90%'/>\n");
    report.insert(idx_to_insert, summary);
}

void DialogStratifiedVariableAppraisal::insert_header(QStringList &report, QString &dataFileName, QString &strataFileName, int idx)
{
    if (idx == -1)
        idx = report.size();

    report.insert(idx++, QString("<div class='module_header'><h3>Variable Appraisal - Stratified</h3>\n"));
    report.insert(idx++, QString("Audit: %1\n").arg(ui->lineEdit_auditName->text()));
    report.insert(idx++, QString("Date: %1\n\n").arg(QDateTime::currentDateTime().toString()));
    report.insert(idx++, QString("Data file: %1\n").arg(dataFileName));
    report.insert(idx++, QString("Strata file: %1</div>").arg(strataFileName));
}

/**
 * @brief Called when the user presses the OK button to start the calculations
 *
 * This function implements most of the parsing involved with it's module; the
 * actual calculations on the parsed input is done elsewhere (the VariableAppraisal
 * class.)
 */
void DialogStratifiedVariableAppraisal::on_buttonBox_accepted_unsafe()
{
    QString data = ui->plainTextEdit_data->toPlainText();
    QString strata = ui->plainTextEdit_strata->toPlainText();
    QStringList column_labels;
    QStringList report;
    VariableAppraisal varApp;
    QStringList data_lines = data.remove(STRIP_REGEXP).split(QRegExp("\r?\n"), QString::SkipEmptyParts);
    QStringList strata_lines = strata.split(QRegExp("\r?\n"), QString::SkipEmptyParts);
    int data_col_start = (ui->checkBox_ignoreFirstDataColumn->isChecked() ? 1 : 0);
    int strata_row_start = ui->checkBox_ignoreFirstStrataRow->isChecked() ? 1 : 0;
    int n_cols;

    if (strata_row_start && strata_lines.size() > 0)
        strata_lines.removeFirst();
    if (data_lines.size() < 1) {
        ST_ERRORBOX("I see no data to run an analysis on?");
        return;
    }
    if ( strata_lines.size() < 1 ) {
        ST_ERRORBOX("I see no strata definitions to run an analysis with?");
        return;
    }

    if ( QRegExp("[^\t\\s]").indexIn(data_lines.at(0)) == -1 )
        data_lines.removeFirst();
    if (QRegExp("[A-z]+").indexIn(data_lines.at(0)) > -1) {
        column_labels = data_lines.at(0).toUpper().split(SPLIT_REGEXP, QString::SkipEmptyParts);
        data_lines.removeFirst();
        n_cols = column_labels.size();
        if (data_col_start > 0)
            column_labels.removeFirst();
    } else {
        n_cols = data_lines.at(0).split(SPLIT_REGEXP, QString::SkipEmptyParts).size();
    }
    if (n_cols <= data_col_start) {
        ST_ERRORBOX("Not enough data columns (need to uncheck an option in that box?)");
        return;
    }
//    matrix_t full_matrix(data_lines.size(), n_cols - data_col_start);
    matrix_t strata_matrix(strata_lines.size(), 2);

    /*
     * build strata matrix
     */
    int c = 0;//ui->checkBox_firstStrataColumnContainsData->isChecked() ? 1 : 0;
    int strata_universe_first = -1;
    for (int i = 0; i < strata_lines.size(); i++)
    {
        QString buf = strata_lines.at(i);
        QStringList tokens = buf.remove(tr(",")).split(SPLIT_REGEXP, QString::SkipEmptyParts);

		// we expect two columns of data after adjusting for any line numbers present
        if (tokens.size() > 3 || tokens.size() < 2 || (tokens.size() == 2 && c == 1)) {
            ST_ERRORBOX(QString("Malformed strata definition; error on line %1").arg(i + 1));
            return;
        } else if (tokens.size() == 3) {
            for (int z = 1; z < tokens.size(); z++) {
                if (QRegExp("[^,\\-\\.0-9]").indexIn(tokens.at(z)) > -1) {
                    ST_ERRORBOX(tr("Non-numeric data in stratum definition %1").arg(i + 1));
                    return;
                }
            }
            c = 1;
        }
        // since it's impossible for the sample size to be larger than the universe size,
        // use whichever value is bigger for the universe size (accept both UNIVERSE_SIZE SAMPLE_SIZE
        // and SAMPLE_SIZE UNIVERSE_SIZE formatted columns); bad values will still generate a warning
        if (tokens.at(0 + c).toDouble() == tokens.at(1 + c).toDouble()) {
            strata_matrix(i, 0) = strtold_chk( tokens.at(0 + c).toStdString().c_str(), NULL );
            strata_matrix(i, 1) = strtold_chk( tokens.at(1 + c).toStdString().c_str(), NULL );
        }
        else if (tokens.at(0 + c).toDouble() > tokens.at(1 + c).toDouble()) {
            // check to make sure definition matches whichever format we're expecting
            if (strata_universe_first != -1 && strata_universe_first != 0) {
                ST_ERRORBOX(tr("The program assumed, based on the first unambiguous stratum definition, that the size column "
                            "formattings were SAMPLE then UNIVERSE, but on strata line %1, the UNIVERSE column "
                            "is larger than the SAMPLE column").arg(i + 1));
                return;
            }
            strata_universe_first = 0;
            strata_matrix(i, 0) = strtold_chk( tokens.at(0 + c).toStdString().c_str(), NULL );
            strata_matrix(i, 1) = strtold_chk( tokens.at(1 + c).toStdString().c_str(), NULL );
        } else {
            // check to make sure definition matches whichever format we're expecting
            if (strata_universe_first != -1 && strata_universe_first != 1) {
                ST_ERRORBOX(tr("The program assumed, based on the first unambiguous stratum definition, that the size column "
                            "formattings were UNIVERSE then SAMPLE, but on strata line %1, the SAMPLE column "
                            "is larger than the UNIVERSE column").arg(i + 1));
                return;
            }
            strata_universe_first = 1;
            strata_matrix(i, 0) = strtold_chk( tokens.at(1 + c).toStdString().c_str(), NULL );
            strata_matrix(i, 1) = strtold_chk( tokens.at(0 + c).toStdString().c_str(), NULL );;
        }
    }

    /*
     * build data matrix
     */
//    for (int i = 0; i < data_lines.size(); i++)
//    {
//        QStringList tokens = data_lines.at(i).split(SPLIT_REGEXP, QString::SkipEmptyParts);
//        if (tokens.size() != n_cols) {
//            ST_ERRORBOX(QString("Malformed data file; error on line %1").arg(i + 1));
//            return;
//        }
//        for (int j = data_col_start; j < tokens.size(); j++)
//        {
//                if (QRegExp("[^,\\-\\.\\$0-9]").indexIn(tokens.at(j)) > -1) {
//                    ST_ERRORBOX(tr("Non-numeric value on data line %1, column %2").arg(i + 1).arg(j + 1));
//                    return;
//                }
//            full_matrix(i, j - data_col_start) = tokens.at(j).toDouble();
//        }
//    }

//    varApp.fill_in_column(model);
//    column_labels = model->getHeaders();
//    if ( data_col_start )
//        column_labels.removeFirst();
    matrix_t_view full_matrix;
    full_matrix.reference( model->getMatrix()(1, data_col_start,
                           model->getMatrix().rows() - 1,
                           model->getMatrix().cols() - 1) );
    insert_header(report, dataFileName, strataFileName);
    if ( model->nonnumericDataInModel(true, 0) )
        return;
    column_labels = model->getFirstRow();
    for (int i = 0; i < data_col_start; i++)
        if ( column_labels.size() > 0 )
            column_labels.removeFirst();
//    qDebug() << QString("Column labels: ") << column_labels;

    // iterate over the strata, building a data matrix for each while inserting their report data
    matrix_t means(strata_matrix.rows(), n_cols);
    matrix_t sd(strata_matrix.rows(), n_cols);
    matrix_t stratum_sums(strata_matrix.rows(), n_cols - data_col_start);
    matrix_t nonzero_mat(strata_matrix.rows(), n_cols - data_col_start);
    uint current_stratum = 0;
    for (int i = 0; i < data_lines.size(); )
    {
        matrix_t temp_mat((uint)strata_matrix(current_stratum, 1), n_cols - data_col_start);
        for (uint j = 0; j < (uint)strata_matrix(current_stratum, 1); j++)
        {
            if (i + j >= full_matrix.rows()) {
                ST_ERRORBOX("The data has fewer values than the strata sample sizes say there should be.");
                return;
            }
            for (int k = 0; k < n_cols - data_col_start; k++)
            {
                temp_mat(j, k) = full_matrix(i + j, k);
            }
        }
        QString stratum_label;
        if (strata_lines.at(current_stratum).split(SPLIT_REGEXP, QString::SkipEmptyParts).size() == 3) {
            stratum_label = strata_lines.at(current_stratum).split(SPLIT_REGEXP, QString::SkipEmptyParts).at(0);
        }
        else {
            stratum_label = QString("%1").arg(current_stratum + 1);
        }

        for (int z = 0; z < n_cols - data_col_start; z++)
            nonzero_mat(current_stratum, z) = varApp.nonzero_items(temp_mat, z);

        report << QString::asprintf("\n<div class='variable_stratum'><a name='stratum_%d'><h3>Stratum %s - %'lld / %'lld (universe size / sample size)</h3></a>",
                                    current_stratum + 1,
                                    stratum_label.toStdString().c_str(),
                                    (long long int)strata_matrix(current_stratum, 0),
                                    (long long int)strata_matrix(current_stratum, 1));

        varApp.build_report(temp_mat, report, (int64_t)strata_matrix(current_stratum, 0), column_labels);
        report << QString("</div>");

        matrix_t tmp_sums = scythe::sumc(temp_mat);
        for (int z = 0; z < n_cols - data_col_start; z++)
            stratum_sums(current_stratum, z) = tmp_sums(z);

        matrix_t tmp_means = scythe::meanc(temp_mat);
        matrix_t tmp_sd = scythe::sdc(temp_mat);
        for (uint z = 0; z < tmp_means.cols(); z++) {
            means(current_stratum, z) = tmp_means(z);
            sd(current_stratum, z) = tmp_sd(z);
        }
        i += strata_matrix(current_stratum, 1);
        if (++current_stratum >= strata_matrix.rows())
            break;
    }

    insert_summary(stratum_sums, strata_matrix, nonzero_mat, report, column_labels, 5);

    // overall calculations
    matrix_t totals(1, n_cols);
    matrix_t variances(1, n_cols);
    matrix_t std_errors(1, n_cols);

    // sanity checks
    int64_t sampleSize = 0;
    for (uint i = 0; i < strata_matrix.rows(); i++)
        sampleSize += strata_matrix(i, 1);
    if (sampleSize != data_lines.size())
        ST_ERRORBOX("WARNING: your strata sample sizes do not add up to the amount of data provided!  Excess data has been ignored.  This warning will appear in the report.");
    int64_t universeSize = 0;
    for (uint i = 0; i < strata_matrix.rows(); i++)
    {
        universeSize += strata_matrix(i, 0);
        for (int j = 0; j < n_cols; j++) {
            totals(j) += means(i, j) * strata_matrix(i, 0);
        }
    }
    for (uint i = 0; i < strata_matrix.rows(); i++)
    {
        for (int j = 0; j < n_cols; j++)
        {
            long double stratum_val = powl(strata_matrix(i, 0), 2) *
                    ((strata_matrix(i, 0) - strata_matrix(i, 1)) / strata_matrix(i, 0)) *
                    (powl(sd(i, j), 2) / strata_matrix(i, 1));
            if (!isnan(stratum_val))
                variances(j) += stratum_val;
        }
    }
    for (int j = 0; j < n_cols; j++)
        std_errors(j) = sqrtl(variances(j));

    report << QString::asprintf("<div class='variable_stratum'><h3>Overall - %'lld / %'lld (universe size / sample size)</h3>",
                                (long long int)universeSize,
                                (long long int)sampleSize);
    if (sampleSize != data_lines.size())
        report.insert(5, QString("<div class='warning'><h3>WARNING</h3>Some of the input data was ignored due to not being included in any stratum definition.</div>"));
    double z_value = 0;
    for (int i = 0; i < n_cols - data_col_start; i++)
    {
        report << "\n";
        if (!column_labels.isEmpty()) {
            report << QString("<div class='variable_column'><h3>%1</h3>").arg(column_labels.at(i));
        } else {
            report << QString::asprintf("<div class='variable_column'><h3>Column %d</h3>", i + 1);
        }
        report << QString::asprintf("Point estimate: %'.2Lf\n", (isnormal(totals(i)) ? totals(i) : 0.0));
        report << QString::asprintf("Standard error: %'.2Lf\n", (isnormal(std_errors(i)) ? std_errors(i) : 0.0));
        for (double C = 0.20; C >= 0.05; C /= 2)
        {
            if (C == 0.05) z_value = CONFIDENCE_LEVEL_95_Z_VALUE;
            else if (C == 0.10) z_value = CONFIDENCE_LEVEL_90_Z_VALUE;
            else if (C == 0.20) z_value = CONFIDENCE_LEVEL_80_Z_VALUE;
//            report << "\n";
            report << QString("<div class='confidence_interval'><h4>%1% confidence interval</h4>").arg((int)((1 - C) * 100));
            report << QString::asprintf("Lower bound: %'.02Lf\nUpper bound: %'.02Lf\n",
                                        (isnormal(totals(i)) ? totals(i) - (std_errors(i) * z_value) : 0.0),
                                        (isnormal(totals(i)) ? totals(i) + (std_errors(i) * z_value) : 0.0));
            report << QString::asprintf("Precision amount: %'.02Lf (%.02Lf%%)\n", (isnormal(std_errors(i)) ? std_errors(i) * z_value : 0.0),
                                        (!isnormal(totals(i)) || totals(i) < 0) ? 0 : 100 * ((std_errors(i) * z_value) / totals(i)));
            report << QString::asprintf("z-Value used: %'.12f</div>", isnormal(z_value) ? z_value : 0.0);
        }
        double C = 0.01;
        z_value = CONFIDENCE_LEVEL_99_Z_VALUE;
//        report << "\n";
        report << QString("<div class='confidence_interval'><h4>%1% confidence interval</h4>").arg((int)((1 - C) * 100));
        report << QString::asprintf("Lower bound: %'.02Lf\nUpper bound: %'.02Lf\n",
                                    (isnormal(totals(i)) ? totals(i) - (std_errors(i) * z_value) : 0.0),
                                    (isnormal(totals(i)) ? totals(i) + (std_errors(i) * z_value) : 0.0));
        report << QString::asprintf("Precision amount: %'.02Lf (%.02Lf%%)\n",
                                    (isnormal(std_errors(i)) ? std_errors(i) * z_value : 0.0),
                                    (!isnormal(totals(i)) || totals(i) < 0) ? 0 : 100 * ((std_errors(i) * z_value) / totals(i)));
        report << QString::asprintf("z-Value used: %'.12f</div>", isnormal(z_value) ? z_value : 0.0);
        report << QString("</div>");
    }

    emit setAuditName(ui->lineEdit_auditName->text());
    emit displayHtml(report.join(""));
    this->reject();
}

void DialogStratifiedVariableAppraisal::on_checkBox_enableStrataEditing_toggled(bool checked)
{
    ui->plainTextEdit_strata->setReadOnly(!checked);
}

void DialogStratifiedVariableAppraisal::on_checkBox_enableDataEditing_toggled(bool checked)
{
    ui->plainTextEdit_data->setReadOnly(!checked);
    if (!checked)
        ui->tableView->setEditTriggers(QTableView::NoEditTriggers);
    else
        ui->tableView->setEditTriggers(QTableView::AnyKeyPressed |
                                       QTableView::DoubleClicked |
                                       QTableView::SelectedClicked |
                                       QTableView::EditKeyPressed);
}

void DialogStratifiedVariableAppraisal::on_checkBox_ignoreFirstDataColumn_toggled(bool checked)
{
    checked ? model->disableColumn(0) : model->enableColumn(0);
    model->dataChanged(model->index(0, 0), model->index(model->rowCount() - 1, 0));
}
