#ifndef EXCELTABLEMODEL_HPP
#define EXCELTABLEMODEL_HPP

#include <QtGui>
#include <QtXlsx/QtXlsx>
#include "basicexcel/BasicExcel.hpp"
#include "basicexcel/ExcelFormat.h"
#include "st_macros.h"


/**
 * @brief Provides table views (Excel-like spreadsheets) for Excel format input files
 *
 * This is the model for the tables shown when selecting which sheet (i.e. tab) to read
 * from if inputting data from an Excel (both .xls and .xlsx) file.
 *
 * It makes use of a model-view framework, which means that the underlying data used by
 * the View portion (which is the spreadsheet preview area in the window) isn't coupled
 * to the View object: this code accesses the data and hands it to the View for display.
 */
class ExcelTableModel : public QAbstractTableModel
{
public:
    ExcelTableModel(QXlsx::Document *data) : xls_doc(NULL)
    {
        qxlsx_doc = data;
    }

    ExcelTableModel(YExcel::BasicExcel *data) : qxlsx_doc(NULL)
    {
        xls_doc = data;
    }

    int rowCount(const QModelIndex& parent = QModelIndex()) const
    {
        Q_UNUSED(parent)
        if (qxlsx_doc) {
            return qxlsx_doc->dimension().rowCount() + 1;
        } else if (xls_doc) {
            if (xls_doc ->GetTotalWorkSheets() > xls_current_sheet) {
                YExcel::BasicExcelWorksheet *xls_sheet = xls_doc->GetWorksheet(xls_current_sheet);
                if (xls_sheet)
                    return xls_sheet->GetTotalRows();
            }
        }

        return 0;
    }

    int columnCount(const QModelIndex& parent = QModelIndex()) const
    {
        Q_UNUSED(parent)
        if (qxlsx_doc) {
            return qxlsx_doc->dimension().columnCount() + 1;
        } else if (xls_doc) {
            if (xls_doc->GetTotalWorkSheets() > xls_current_sheet) {
                YExcel::BasicExcelWorksheet *xls_sheet = xls_doc->GetWorksheet(xls_current_sheet);
                if (xls_sheet)
                    return xls_sheet->GetTotalCols();
            }
        }

        return 0;
    }

    QVariant data(const QModelIndex& index, int role = Qt::DisplayRole) const
    {
        if (!index.isValid() || role != Qt::DisplayRole)
            return QVariant();

        QString buf;
        if (qxlsx_doc) {
            QXlsx::Cell *ret = qxlsx_doc->cellAt(index.row() + 1, index.column() + 1);
            if (ret) {
                switch (ret->cellType()) {
                case QXlsx::Cell::CellType::StringType:
                case QXlsx::Cell::CellType::InlineStringType:
                case QXlsx::Cell::CellType::SharedStringType:
                    return ret->value();
                case QXlsx::Cell::CellType::NumberType:
                    buf = QString::asprintf( "%'.3Lf", strtold_chk(ret->value().toString().toStdString().c_str(), NULL) );
                    buf.remove(QRegExp("\\.0+$"));
                    return buf;
                default:
                    return QVariant();
                }
            } else
                return QVariant();

        } else if (xls_doc) {
            YExcel::BasicExcelWorksheet *sheet = xls_doc->GetWorksheet(xls_current_sheet);
            if (!sheet)
                return QVariant();

            YExcel::BasicExcelCell *cell = sheet->Cell(index.row(), index.column());
            if (!cell)
                return QVariant();

            switch (cell->Type()) {
            case YExcel::BasicExcelCell::DOUBLE:
                buf = QString::asprintf( "%'.3Lf", static_cast<long double>(cell->GetDouble()) );
                buf.remove(QRegExp("\\.0+$"));
                return buf;
                break;
            case YExcel::BasicExcelCell::STRING:
            case YExcel::BasicExcelCell::WSTRING:
                return QString(cell->GetString());
                break;
            case YExcel::BasicExcelCell::INT:
                return QString::asprintf( "%'lld", static_cast<long long int>(cell->GetInteger()) );
                break;
            default: break;
            }
        }

        return QVariant();
    }

public slots:
    int setXlsSheetIndex(int sheetNum)
    {
        xls_current_sheet = sheetNum;
        return xls_current_sheet;
    }

    int setXlsSheetIndex()
    {
        return setXlsSheetIndex(0);
    }

private:
    QXlsx::Document *qxlsx_doc = NULL;
    YExcel::BasicExcel *xls_doc = NULL;
    int xls_current_sheet = 0;
};

#endif // EXCELTABLEMODEL_HPP
