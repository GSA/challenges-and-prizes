#include "dialogsamplesizebyestimatederror.h"
#include "ui_dialogsamplesizebyestimatederror.h"
#include "stdialog.h"
#include "samplesizedetermination.h"
#include "st_macros.h"
#include "statstool.h"

DialogSampleSizeByEstimatedError::DialogSampleSizeByEstimatedError(QWidget *parent) :
    STDialog(parent)
{
    ui = new Ui::DialogSampleSizeByEstimatedError;
    ui->setupUi(this);

    ui->lineEdit_universeSize->setValidator(validator);
    ui->lineEdit_totalAmount->setValidator(dblValidator);
    ui->lineEdit_standardDeviation->setValidator(dblValidator);
    ui->lineEdit_expectedErrorRate->setValidator(dblValidator);
    ui->lineEdit_auditName->setFocus();

    connect(ui->lineEdit_totalAmount, SIGNAL(textChanged(QString)), this, SLOT(addCommasToInput(QString)));
    connect(ui->lineEdit_universeSize, SIGNAL(textChanged(QString)), this, SLOT(addCommasToInput(QString)));
    connect(ui->lineEdit_standardDeviation, SIGNAL(textChanged(QString)), this, SLOT(addCommasToInput(QString)));
}

DialogSampleSizeByEstimatedError::~DialogSampleSizeByEstimatedError()
{
    delete ui;
}

void DialogSampleSizeByEstimatedError::on_buttonBox_accepted_unsafe()
{
    SampleSizeDetermination sampleSize;
    QStringList report;
    int64_t universeSize = ui->lineEdit_universeSize->text().remove(tr(",")).toInt();
    long double reportedTotal = ui->lineEdit_totalAmount->text().remove(tr(",")).toDouble();
    long double expectedErrorRate = ui->lineEdit_expectedErrorRate->text().remove(tr(",")).toDouble() / 100.0;
    long double standard_deviation = ui->lineEdit_standardDeviation->text().remove(tr(",")).toDouble();

    StatsTool::buildModuleHeaderHtml(report, "Sample Size Determination - by Estimated Error Rate", ui->lineEdit_auditName->text());
    sampleSize.byEstimatedError(report, universeSize, expectedErrorRate, reportedTotal, standard_deviation);

    emit setAuditName(ui->lineEdit_auditName->text());
    emit displayHtml(report.join(""));
    emit reject();
}
