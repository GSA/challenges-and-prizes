#include "dialogsamplesizebyattribute.h"
#include "ui_dialogsamplesizebyattribute.h"
#include "attributeappraisal.h"
#include "statstool.h"


DialogSampleSizeByAttribute::DialogSampleSizeByAttribute(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogSampleSizeByAttribute)
{
    ui->setupUi(this);
    validator = new QIntValidator(0, INT_MAX, this);
    double_validator = new QDoubleValidator(0, 1, 3, this);

    ui->lineEdit_errorRate->setValidator(validator);
    ui->lineEdit_universeSize->setValidator(validator);
    ui->lineEdit_precision->setValidator(validator);

    connect(ui->lineEdit_errorRate, SIGNAL(textChanged(QString)), this, SLOT(addCommasToInput(QString)));
    connect(ui->lineEdit_universeSize, SIGNAL(textChanged(QString)), this, SLOT(addCommasToInput(QString)));
    connect(ui->lineEdit_precision, SIGNAL(textChanged(QString)), this, SLOT(addCommasToInput(QString)));
}

DialogSampleSizeByAttribute::~DialogSampleSizeByAttribute()
{
    delete ui;
    delete validator;
    delete double_validator;
}

void DialogSampleSizeByAttribute::addCommasToInput(QString str)
{
    QLineEdit *edit = static_cast<QLineEdit*>(QWidget::focusWidget());
    int cursorPos = edit->cursorPosition();

    validator->fixup(str);
    edit->setText(str);

    if (abs(edit->cursorPosition() - cursorPos) > 1)
        edit->setCursorPosition(cursorPos);
}

void DialogSampleSizeByAttribute::on_buttonBox_accepted()
{
    QApplication::setOverrideCursor(Qt::WaitCursor);
    qint64 start_msecs = QDateTime::currentMSecsSinceEpoch();
    try {
        on_buttonBox_accepted_unsafe();
    } catch (std::exception &e) {
        qDebug() << e.what();
        ST_ERRORBOX("An error occurred; please check your input values and try again.");
    }
    QApplication::restoreOverrideCursor();
    qDebug() << QString("Finished in %1 seconds").arg( (QDateTime::currentMSecsSinceEpoch() - start_msecs) / 1000.0);
}

void DialogSampleSizeByAttribute::on_buttonBox_accepted_unsafe()
{
    uint N = ui->lineEdit_universeSize->text().remove(tr(",")).toInt();
    double precision = ui->lineEdit_precision->text().remove(tr(",")).toInt() / 100.0;
    double errorRate = ui->lineEdit_errorRate->text().remove(tr(",")).toInt() / 100.0;
    QStringList report;

    calculate(report, errorRate, N, precision);
    emit displayHtml(report.join("\n"));
    this->reject();
}

void DialogSampleSizeByAttribute::calculate(QStringList &report, double error_rate, uint N, double precision)
{
    AttributeAppraisal attApp;

    if ( error_rate == 0 || N == 0 || precision == 0 )
        throw std::exception();

    attApp.sampleSizeByAttribute(error_rate, N, precision, &report);
    return;
}

void DialogSampleSizeByAttribute::on_actionWhat_s_this_triggered()
{
    emit enter_whats_this();
}
