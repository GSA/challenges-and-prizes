#include "samplesizedetermination.h"
#include <QDebug>

SampleSizeDetermination::SampleSizeDetermination()
{

}

void SampleSizeDetermination::byEstimatedError(QStringList &report, int64_t universeSize, long double expectedErrorRate, long double reportedTotal, long double standard_deviation)
{
    int64_t N = universeSize;
    int64_t n = 0;

    long double T_r = reportedTotal;
    long double mu_R = T_r / N;
    long double delta_R = standard_deviation;
    long double p_hat = expectedErrorRate;
    long double mu_D = p_hat * mu_R;
    long double delta_D = sqrtl( p_hat * ( delta_R * delta_R + (1.0 - p_hat) * (mu_R * mu_R) ) );

    report << QString::asprintf("Universe size: %'lld\n", static_cast<long long int>(universeSize));
    report << QString::asprintf("Reported total: %'.3Lf\n", reportedTotal);
    report << QString::asprintf("Estimated error rate: %d%%\n\n", static_cast<int>(expectedErrorRate * 100));
    report << QString::asprintf("Estimated std deviation: %.2Lf\n", delta_D);
    report << QString::asprintf("Estimated mean: %.2Lf\n", mu_D);

    report << "<table border='0' cellpadding='3' cellspacing='10'>";
    report << "<tr><th colspan='1' rowspan='2'><h4>\nSample\nprecision</h4></th>";
    report << "<th colspan='4'><h4>Confidence level</h4></th></tr>";
    report << "<tr>";
    for (int i = 0; confidence_levels[i] != 0; i++)
        report << QString::asprintf( "<th>%lld%%</th>", static_cast<long long int>(roundl(100 * confidence_levels[i])) );
    report << "</tr>";

    for (int i = 0; precisions[i] != 0; i++)
    {
        report << QString::asprintf( "<tr><th>%lld%%</th>", static_cast<long long int>(roundl(100 * precisions[i])) );
        for (int j = 0; confidence_levels[j] != 0; j++)
        {
            n = value(precisions[i], confidence_levels[j], universeSize, expectedErrorRate, reportedTotal, standard_deviation);

            if ( isnormal( static_cast<long double>(n) ) && n != INT64_MIN )
                report << QString::asprintf( "<td>%'lld</td>", static_cast<long long int>(n) );
            else
                report << QString("<td>---</td>");
        }
        report << "</tr>";
    }
    report << "</table>";
}

int64_t SampleSizeDetermination::value(long double precision, long double confidence, int64_t universeSize, long double error, long double total, long double stdDev)
{
    int64_t N = universeSize;
    confidence = 1 - confidence;
    long double T_r = total;
    long double mu_R = T_r / N;
    long double delta_R = stdDev;
    long double p_hat = error;
    long double mu_D = p_hat * mu_R;
    long double delta_D = sqrtl( p_hat * ( delta_R * delta_R + (1.0 - p_hat) * (mu_R * mu_R) ) );
    long double E = precision * mu_D * N;
    long double z = 0;

    switch ( (int)round(confidence * 100) ) {
    case 20: z = CONFIDENCE_LEVEL_80_Z_VALUE; break;
    case 10: z = CONFIDENCE_LEVEL_90_Z_VALUE; break;
    case 5: z = CONFIDENCE_LEVEL_95_Z_VALUE; break;
    case 1: z = CONFIDENCE_LEVEL_99_Z_VALUE; break;
    default: break;
    }

    long double numerator = (delta_D * N) * (delta_D * N);
    long double denominator = (E / z) * (E / z) + N * (delta_D * delta_D);

    return static_cast<int64_t>( roundl(numerator / denominator) );
}
