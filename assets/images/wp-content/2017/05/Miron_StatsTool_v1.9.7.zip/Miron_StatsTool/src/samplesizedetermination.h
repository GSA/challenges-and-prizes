#ifndef SAMPLESIZEDETERMINATION_H
#define SAMPLESIZEDETERMINATION_H

#include <QWidget>
#include <QMap>
#include <cmath>

#define CONFIDENCE_LEVEL_99_Z_VALUE 2.575829303549
#define CONFIDENCE_LEVEL_95_Z_VALUE 1.959963984540
#define CONFIDENCE_LEVEL_90_Z_VALUE 1.644853626951
#define CONFIDENCE_LEVEL_80_Z_VALUE 1.281551565545


/**
 * @brief Encapsulates the Sample Size Determination functions
 */
class SampleSizeDetermination
{
public:
    SampleSizeDetermination();
    /**
     * @brief Generate a report
     * @param report Where to insert the strings
     * @param universeSize The frame size
     * @param expectedErrorRate The estimated error rate
     * @param reportedTotal The total value
     * @param standard_deviation The standard deviation
     */
    void byEstimatedError(QStringList &report, int64_t universeSize, long double expectedErrorRate, long double reportedTotal, long double standard_deviation);
    /**
     * @brief Calculate a value in the (precision, confidence_level) space
     * @param precision The desired precision (e.g. .15)
     * @param confidence The desired confidence level (e.g. .80)
     * @param universeSize The frame size
     * @param error The estimated error rate
     * @param total The total value
     * @param stdDev The standard deviation
     * @return The answer
     */
    int64_t value(long double precision, long double confidence, int64_t universeSize = 0, long double error = 0, long double total = 0, long double stdDev = 0);

protected:
    long double precisions[7] = { 0.01, 0.02, 0.05, 0.10, 0.15, 0.25, 0.00 };
    long double confidence_levels[5] = { 0.80, 0.90, 0.95, 0.99, 0.00 };
};

#endif // SAMPLESIZEDETERMINATION_H
