#ifndef DIALOGUNRESTRICTEDATTRIBUTEAPPRAISAL_H
#define DIALOGUNRESTRICTEDATTRIBUTEAPPRAISAL_H

#include <QDialog>
#include <QValidator>


namespace Ui {
class DialogUnrestrictedAttributeAppraisal;
}

/**
 * @brief Encapsulates the Unrestricted Attribute Appraisal module
 */
class DialogUnrestrictedAttributeAppraisal : public QDialog
{
    Q_OBJECT

public:
    explicit DialogUnrestrictedAttributeAppraisal(QWidget *parent = 0);
    ~DialogUnrestrictedAttributeAppraisal();
    /**
     * @brief Insert the report header
     * @param n The sample size
     * @param N The population size
     * @param out Where to insert the strings; used as the return value
     *
     * This function inserts the header information (audit name, module, time, etc.)
     */
    void insert_header(uint64_t n, uint64_t N, QStringList &out);
    /**
     * @brief Performs the calculations necessary for the report data (multithreaded)
     * @param n The sample size
     * @param N The population size
     * @param k Sample error rate (or successes, or characteristic of interest)
     * @param out Where to insert the strings; used as the return value
     *
     * This function implements the logic of the Unrestricted Attribute Appraisal module and inserts the report.
     *
     * It makes use of as many CPU cores as the computer has, up to a max of 6.
     */
    void calculate_multithreaded(uint64_t n, uint64_t N, uint64_t k, QStringList &out);
    /**
     * @brief Performs the calculations necessary for the report data (two thread version)
     * @param n The sample size
     * @param N The population size
     * @param k Sample error rate (or successes, or characteristic of interest)
     * @param out Where to insert the strings; used as the return value
     *
     * This function implements the logic of the Unrestricted Attribute Appraisal module and inserts the report.
     *
     * It makes use of two CPU cores.  The GUI will call this version if less than 4 CPU cores are detected.  In
     * order to continue monitoring for the user aborting via the GUI abort button, at least two threads are used
     * even if only one core is available.
     */
    void calculate(uint64_t n, uint64_t N, uint64_t k, QStringList &out);
    /**
     * @brief Same as calculate, but inserts an HTML table
     * @param n The sample size
     * @param N The population size
     * @param k Sample error rate (or successes, or characteristic of interest)
     * @param out Where to insert the strings; used as the return value
     *
     * This function implements the logic of the Unrestricted Attribute Appraisal module and inserts the report
     * as a table
     */
    void calculate_table(uint64_t n, uint64_t N, uint64_t k, QStringList &out);

signals:
    /**
     * @brief Emitted to display rich text (HTML) in the main window
     * @param str The string to display
     */
    void displayHtml(QString str);
    /**
     * @brief Emitted to display plain text in the main window
     * @param str The string to display
     */
    void displayText(QString str);
    /**
     * @brief Emitted to enter "What's this?" mode
     */
    void enter_whats_this();
    /**
     * @brief Make the main window aware of the user-specified audit name
     * @param str The name of the audit to report to the main window
     */
    void setAuditName(QString str);

private slots:
    void on_buttonBox_accepted();
    /**
     * @brief Adds group placeholders to numbers being input by the user
     * @param str The current user input, before group placeholders have been added
     */
    void addCommasToInput(QString str);
    /**
     * @brief Abort a running calculation
     */
    void on_pushButton_abort_clicked();

private:
    Ui::DialogUnrestrictedAttributeAppraisal *ui;
    void on_buttonBox_accepted_unsafe();
    QIntValidator *validator = NULL;
    bool abortRequested = false;
};

#endif // DIALOGUNRESTRICTEDATTRIBUTEAPPRAISAL_H
