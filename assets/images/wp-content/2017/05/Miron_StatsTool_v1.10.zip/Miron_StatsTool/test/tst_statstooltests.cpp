//#include <QString>
#include <QtTest>
#include "st_boost.h"

#include "dialogunrestrictedattributeappraisal.h"
#include "dialogunrestrictedvariableappraisal.h"
#include "dialogstratifiedvariableappraisal.h"
#include "dialogsinglestagerandomnumbers.h"

#include "ui_dialogunrestrictedattributeappraisal.h"

#include "statstool.h"
#include "wichmannhill.h"
#include "attributeappraisal.h"
#include "variableappraisal.h"
#include "matrix.h"
#include "samplesizedetermination.h"
#include <float.h>

#ifndef QCOMPARE2
#define QCOMPARE2(a, b) QCOMPARE(b, a)
#endif

/**
 * Automated tests
 */
class StatsToolTests : public QObject
{
    Q_OBJECT

public:
    StatsToolTests();

private Q_SLOTS:
    void testCaseSingleStageRandomNumbers_data();
    void testCaseSingleStageRandomNumbers();
    void testCaseVariableAppraisal();
    void testCaseAttributeAppraisal_Threaded_data();
    void testCaseAttributeAppraisal_Threaded();
    void testCaseAttributeAppraisal_Upper();
    void testCaseAttributeAppraisal_Lower();
    void testCaseAttributeAppraisal_imprecise();
    void testCaseMatrixTable();
    void testCaseMultiprecisionType();
    void testCaseSampleSizeDetermination_byEstimatedError();
    void testCaseAttributeAppraisal();
    void testCaseAttributeAppraisal_data();
};

StatsToolTests::StatsToolTests()
{
}

void StatsToolTests::testCaseAttributeAppraisal()
{
    DialogUnrestrictedAttributeAppraisal attApp;

    QFETCH(QTestEventList, events);
    QFETCH(QString, expected);

    attApp.getUi()->lineEdit_universeSize->setFocus();
    events.simulate(attApp.getUi()->lineEdit_universeSize);
    QCOMPARE(attApp.getUi()->lineEdit_universeSize->text(), expected);

    attApp.getUi()->lineEdit_sampleSize->setFocus();
    events.simulate(attApp.getUi()->lineEdit_sampleSize);
    QCOMPARE(attApp.getUi()->lineEdit_sampleSize->text(), expected);

    attApp.getUi()->lineEdit_itemsOfInterest->setFocus();
    events.simulate(attApp.getUi()->lineEdit_itemsOfInterest);
    QCOMPARE(attApp.getUi()->lineEdit_itemsOfInterest->text(), expected);
}

void StatsToolTests::testCaseAttributeAppraisal_data()
{
    QTest::addColumn<QTestEventList>("events");
    QTest::addColumn<QString>("expected");

    QTestEventList list1;
    list1.addKeyClicks("1234567890123");
    list1.addKeyClick(Qt::Key_Return);

    QTest::newRow("0") << list1 << "1,234,567,890";
}

void StatsToolTests::testCaseSingleStageRandomNumbers_data()
{
    QTest::addColumn<QString>("data");
    QTest::newRow("0") << QString();
}

void StatsToolTests::testCaseAttributeAppraisal_Threaded_data()
{
    QTest::addColumn<int>("universeSize");
    QTest::addColumn<int>("sampleSize");
    QTest::addColumn<int>("errors");
    QTest::addColumn<int>("upper_95_should_be");
    QTest::addColumn<int>("lower_95_should_be");
    QTest::addColumn<bool>("doubleSided");

    QTest::newRow("0") << 2000000000 << 1000 << 2 << 14411675 << 484603 << true;
}

// Test the multithreaded code in the AttributeAppraisal class
void StatsToolTests::testCaseAttributeAppraisal_Threaded()
{
    QFETCH(int, universeSize);
    QFETCH(int, sampleSize);
    QFETCH(int, errors);
    QFETCH(int, upper_95_should_be);
    QFETCH(int, lower_95_should_be);
    QFETCH(bool, doubleSided);

    AttributeAppraisal attApp(AttributeAppraisal::UPPER_AND_LOWER, sampleSize, universeSize, errors, 0.05, doubleSided);

    attApp.start();
    while (attApp.getLower() == -1) ;
    while (attApp.getUpper() == -1) ;

    QCOMPARE2((int)upper_95_should_be, (int)attApp.getUpper());
    QCOMPARE2((int)lower_95_should_be, (int)attApp.getLower());
}

void StatsToolTests::testCaseAttributeAppraisal_imprecise()
{
    AttributeAppraisal d;
    uint64_t universeSize = 2000000000;
    uint64_t sampleSize = 1000;
    int64_t result = 0;
    int64_t result_imprecise = 0;

    for (int i = 0; i < 10; i++)
    {
        int factor = i * 10000;
        result = d.upper_limit(sampleSize + i * factor, universeSize - i * factor, i * factor, 0.05, true);
        result_imprecise = d.upper_limit_imprecise(sampleSize + i * factor, universeSize - i * factor, i * factor, 0.05, true);

        QVERIFY(result == result_imprecise);
    }
}

void StatsToolTests::testCaseSampleSizeDetermination_byEstimatedError()
{
    SampleSizeDetermination sampleSize;
    QStringList report;
    int64_t universeSize = 200;
    long double errorRate = 0.75;
    long double total = 500;
    long double stdDev = 25;

    QMap<long double, QMap<long double, int64_t> > correctValues;
    correctValues[.01][.99] = 200;
    correctValues[.10][.90] = 199;
    correctValues[.15][.80] = 196;

    QCOMPARE2( correctValues[.01][.99], sampleSize.value(.01, .99, universeSize, errorRate, total, stdDev) );
    QCOMPARE2( correctValues[.10][.90], sampleSize.value(.10, .90, universeSize, errorRate, total, stdDev) );
    QCOMPARE2( correctValues[.15][.80], sampleSize.value(.15, .80, universeSize, errorRate, total, stdDev) );
}

// Test the upper limit code in the AttributeAppraisal class
void StatsToolTests::testCaseAttributeAppraisal_Upper()
{
    AttributeAppraisal d;
    uint64_t universeSize = 2000000000;
    uint64_t sampleSize = 1000;
    uint64_t errors = 0;

    uint64_t upper_80_should_be = 4599871;
    uint64_t upper_90_should_be = 5982497;
    uint64_t upper_95_should_be = 7364165;

    QVERIFY(upper_80_should_be == d.upper_limit(sampleSize, universeSize, errors, 0.2, true));
    QVERIFY(upper_90_should_be == d.upper_limit(sampleSize, universeSize, errors, 0.1, true));
    QVERIFY(upper_95_should_be == d.upper_limit(sampleSize, universeSize, errors, 0.05, true));

//    QVERIFY(upper_80_should_be == d.upper_limit_imprecise(sampleSize, universeSize, errors, 0.2, true));
//    QVERIFY(upper_90_should_be == d.upper_limit_imprecise(sampleSize, universeSize, errors, 0.1, true));
//    QVERIFY(upper_95_should_be == d.upper_limit_imprecise(sampleSize, universeSize, errors, 0.05, true));

    upper_80_should_be = 3216286;
    upper_90_should_be = 4599871;
    upper_95_should_be = 5982497;

    QVERIFY(upper_80_should_be == d.upper_limit(sampleSize, universeSize, errors, 0.2, false));
    QVERIFY(upper_90_should_be == d.upper_limit(sampleSize, universeSize, errors, 0.1, false));
    QVERIFY(upper_95_should_be == d.upper_limit(sampleSize, universeSize, errors, 0.05, false));

//    QVERIFY(upper_80_should_be == d.upper_limit_imprecise(sampleSize, universeSize, errors, 0.2, false));
//    QVERIFY(upper_90_should_be == d.upper_limit_imprecise(sampleSize, universeSize, errors, 0.1, false));
//    QVERIFY(upper_95_should_be == d.upper_limit_imprecise(sampleSize, universeSize, errors, 0.05, false));

    upper_80_should_be = 7768207;
    upper_90_should_be = 9469985;
    upper_95_should_be = 11117846;
    errors = 1;

    QVERIFY(upper_80_should_be == d.upper_limit(sampleSize, universeSize, errors, 0.2, true));
    QVERIFY(upper_90_should_be == d.upper_limit(sampleSize, universeSize, errors, 0.1, true));
    QVERIFY(upper_95_should_be == d.upper_limit(sampleSize, universeSize, errors, 0.05, true));

//    QVERIFY(upper_80_should_be == d.upper_limit_imprecise(sampleSize, universeSize, errors, 0.2, true));
//    QVERIFY(upper_90_should_be == d.upper_limit_imprecise(sampleSize, universeSize, errors, 0.1, true));
//    QVERIFY(upper_95_should_be == d.upper_limit_imprecise(sampleSize, universeSize, errors, 0.05, true));

    upper_80_should_be = 30729948;
    upper_90_should_be = 33806346;
    upper_95_should_be = 36626481;
    errors = 10;

    QVERIFY(upper_80_should_be == d.upper_limit(sampleSize, universeSize, errors, 0.2, true));
    QVERIFY(upper_90_should_be == d.upper_limit(sampleSize, universeSize, errors, 0.1, true));
    QVERIFY(upper_95_should_be == d.upper_limit(sampleSize, universeSize, errors, 0.05, true));

//    QVERIFY(upper_80_should_be == d.upper_limit_imprecise(sampleSize, universeSize, errors, 0.2, true));
//    QVERIFY(upper_90_should_be == d.upper_limit_imprecise(sampleSize, universeSize, errors, 0.1, true));
//    QVERIFY(upper_95_should_be == d.upper_limit_imprecise(sampleSize, universeSize, errors, 0.05, true));

}

// Test the lower limit code in the AttributeAppraisal class
void StatsToolTests::testCaseAttributeAppraisal_Lower()
{
    AttributeAppraisal d;
    uint64_t universeSize = 2000000000;
    uint64_t sampleSize = 1000;
    uint64_t errors = 0;

    uint64_t lower_80_should_be = 0;
    uint64_t lower_90_should_be = 0;
    uint64_t lower_95_should_be = 0;

    QVERIFY(lower_80_should_be == d.lower_limit(sampleSize, universeSize, errors, 0.2, true));
    QVERIFY(lower_90_should_be == d.lower_limit(sampleSize, universeSize, errors, 0.1, true));
    QVERIFY(lower_95_should_be == d.lower_limit(sampleSize, universeSize, errors, 0.05, true));

    lower_80_should_be = 0;
    lower_90_should_be = 0;
    lower_95_should_be = 0;

    QVERIFY(lower_80_should_be == d.lower_limit(sampleSize, universeSize, errors, 0.2, false));
    QVERIFY(lower_90_should_be == d.lower_limit(sampleSize, universeSize, errors, 0.1, false));
    QVERIFY(lower_95_should_be == d.lower_limit(sampleSize, universeSize, errors, 0.05, false));

    lower_80_should_be = 210710;
    lower_90_should_be = 102584;
    lower_95_should_be = 50635;
    errors = 1;

    QVERIFY(lower_80_should_be == d.lower_limit(sampleSize, universeSize, errors, 0.2, true));
    QVERIFY(lower_90_should_be == d.lower_limit(sampleSize, universeSize, errors, 0.1, true));
    QVERIFY(lower_95_should_be == d.lower_limit(sampleSize, universeSize, errors, 0.05, true));

//    QVERIFY(lower_80_should_be == d.lower_limit_imprecise(sampleSize, universeSize, errors, 0.2, true));
//    QVERIFY(lower_90_should_be == d.lower_limit_imprecise(sampleSize, universeSize, errors, 0.1, true));
//    QVERIFY(lower_95_should_be == d.lower_limit_imprecise(sampleSize, universeSize, errors, 0.05, true));

    lower_80_should_be = 12459963;
    lower_90_should_be = 10870283;
    lower_95_should_be = 9611024;
    errors = 10;

    QVERIFY(lower_80_should_be == d.lower_limit(sampleSize, universeSize, errors, 0.2, true));
    QVERIFY(lower_90_should_be == d.lower_limit(sampleSize, universeSize, errors, 0.1, true));
    QVERIFY(lower_95_should_be == d.lower_limit(sampleSize, universeSize, errors, 0.05, true));

//    QVERIFY(lower_80_should_be == d.lower_limit_imprecise(sampleSize, universeSize, errors, 0.2, true));
//    QVERIFY(lower_90_should_be == d.lower_limit_imprecise(sampleSize, universeSize, errors, 0.1, true));
//    QVERIFY(lower_95_should_be == d.lower_limit_imprecise(sampleSize, universeSize, errors, 0.05, true));
}

// Test the Wichmann-Hill code
void StatsToolTests::testCaseSingleStageRandomNumbers()
{
    WichmannHill rng(1000.0);
    int howMany = 50;
    int max = 100;
    int min = 0;
    std::map<int64_t, int64_t> randoms;
    int64_t firstvals[] = { 2, 7, 6, 17, 14, 16, 23, 9, 25, 18, 19,
                            5, 11, 15, 21, 4, 12, 20, 24, 8, 1, 13, 10,
                            22, 3, 26, 27, 28, 29, 30, 31, 32, 33, 34,
                            35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45,
                            46, 47, 48, 49, 50 };
    int64_t secondvals[] = { 0, 9, 10, 14, 15, 22, 24, 31, 33, 34, 42, 43,
                             49, 50, 51, 52, 55, 69, 71, 77, 84, 87, 90, 96,
                             99, 64, 28, 80, 37, 36, 92, 76, 27, 39, 59, 12,
                             26, 60, 91, 30, 63, 53, 6, 54, 11, 44, 35, 65,
                             94, 79 };

    rng.generateNumbers(howMany, min, max, randoms);

    std::map<int64_t, int64_t>::iterator it = randoms.begin();
    for (int i = 0; i < howMany; i++)
    {
        std::map<int64_t, int64_t>::const_iterator it = randoms.find(firstvals[i]);
        QCOMPARE(secondvals[i], it->second);
    }
}

void StatsToolTests::testCaseVariableAppraisal()
{
        QStringList inputList = {
                                  "963.09 963.09  0",
                                  "5,278,193.57 0  0",
                                  "1,779,532.70 1,779,532.70  0",
                                  "19,161,376.21 0  0",
                                  "339,977.50 0  0",
                                  "4,281,305.84 4,281,305.84  0",
                                  "2,823.40 0  0",
                                  "16,803,188.94 16,803,188.94  0",
                                  "1,207,452.06 1,207,452.06  0",
                                  "16,690,388.26 16,690,388.26  0",
                                  "16,410,255.58 0  0",
                                  "13,108,185.91 13,108,185.91  0",
                                  "3,383,342.09 3,383,342.09  0",
                                  "276,978.45 0  0",
                                  "8,511,934.59 8,511,934.59  0",
                                  "11,195,459.11 0  0",
                                  "13,391,946.55 13,391,946.55  0",
                                  "1,508,415.26 0  0",
                                  "1,395,454.09 1,395,454.09  0",
                                  "14,272,845.74 0  0",
                                  "14,461,204.21 14,461,204.21  0",
                                  "1,344,427.16 1,344,427.16  0",
                                  "14,822,971.63 0  0",
                                  "9,062,847.08 9,062,847.08  0",
                                  "460,320.14 0  0",
                                  "1,285,290.04 0  0",
                                  "472,287.44 0  0",
                                  "13,352,765.58 13,352,765.58  0",
                                  "3,618,332.43 3,618,332.43  0",
                                  "13,081,756.89 13,081,756.89  0",
                                  "251,661.60 251,661.60  0",
                                  "22,237,520.48 0  0",
                                  "14,254,261.05 14,254,261.05  0",
                                  "18,719,626.47 0  0",
                                  "85,296.27 0  0",
                                  "10,808,948.82 0  0",
                                  "13,446,852.14 13,446,852.14  0",
                                  "6,847,666.50 0  0",
                                  "13,543,697.14 0  0",
                                  "15,653,652.59 15,653,652.59  0",
                                  "2,858,487.04 0  0",
                                  "121,875.43 0  0",
                                  "14,590,856.36 14,590,856.36  0",
                                  "10,913,628.87 10,913,628.87  0",
                                  "2,753,170.64 2,753,170.64  0",
                                  "5,259,947.68 5,259,947.68  0",
                                  "22,790,142.23 0  0",
                                  "8,541,114.52 0  0",
                                  "13,073,910.10 0  0",
                                  "11,998,238.47 11,998,238.47  0",
                                  "8,139,912.70 8,139,912.70  0",
                                  "1,780,907.76 0  0",
                                  "20,872,697.17 20,872,697.17  0",
                                  "16,629,038.45 16,629,038.45  0",
                                  "1,484,480.39 1,484,480.39  0",
                                  "20,570,091.40 0  0",
                                  "610,666.13 0  0",
                                  "5,851,678.48 5,851,678.48  0",
                                  "810,815.06 0  0",
                                  "14,263,719.65 0  0",
                                  "2,797,971.82 2,797,971.82  0",
                                  "14,096,452.55 14,096,452.55  0",
                                  "2,216,902.83 2,216,902.83  0",
                                  "154,380.65 0  0",
                                  "2,136,791.33 2,136,791.33  0",
                                  "1,903,772.00 0  0",
                                  "5,050,231.88 0  0",
                                  "6,888,705.85 6,888,705.85  0",
                                  "5,019,408.48 0  0",
                                  "2,437,175.26 2,437,175.26  0",
                                  "3,837,996.51 0  0",
                                  "4,358,372.23 4,358,372.23  0",
                                  "235,403.35 0  0",
                                  "156,649.20 156,649.20  0",
                                  "15,676,109.05 15,676,109.05  0",
                                  "10,961,692.88 10,961,692.88  0",
                                  "23,832,788.72 23,832,788.72  0",
                                  "3,077,643.70 3,077,643.70  0",
                                  "1,991,903.52 1,991,903.52  0",
                                  "2,580,210.56 0  0",
                                  "3,439,283.58 3,439,283.58  0",
                                  "248,562.79 248,562.79  0",
                                  "21,795,214.74 0  0",
                                  "9,506,900.88 9,506,900.88  0",
                                  "11,465,610.43 11,465,610.43  0",
                                  "16,208,517.09 16,208,517.09  0",
                                  "18,923,597.14 0  0",
                                  "122,159.80 0  0",
                                  "127,704.93 127,704.93  0",
                                  "5,639.80 5,639.80  0",
                                  "3,697,080.89 0  0",
                                  "2,393,765.36 0  0",
                                  "22,989,384.10 0  0",
                                  "8,114,563.93 0  0",
                                  "6,328,122.05 0  0",
                                  "1,783,062.76 0  0",
                                  "1,260,282.83 0  0",
                                  "21,853,666.06 21,853,666.06  0",
                                  "12,100,714.65 12,100,714.65  0",
                                  "851,367.35 851,367.35  0" };
        QString input = inputList.join("\n");
        QStringList report;
        QStringList columnLabels;
        QStringList searchStrings2 = { "Sum793,352,546.66",
                                       "Mean7,933,525.47",
                                       "Standard deviation7,159,126.19",
                                       "Skewness0.58",
                                       "Kurtosis2.05",
                                       "Standard error (mean)697,785.31",
                                       "Standard error (total)1,395,570,613.86",
                                       "Point estimate15,867,050,933.20",
                                       "Lower bound14,066,539,537.56",
                                       "Upper bound17,667,562,328.84",
                                       "Lower bound13,549,857,828.34",
                                       "Upper bound18,184,244,038.06",
                                       "Sum444,012,230.56",
                                       "Standard deviation6,370,058.06",
                                       "Point estimate8,880,244,611.20",
                                       "Lower bound6,416,337,420.67",
                                       "Upper bound11,344,151,801.73",
                                       "Sum349,340,316.10",
                                       "Point estimate6,986,806,322.00",
                                       "Lower bound4,479,757,035.62",
                                       "Upper bound9,493,855,608.38",
                                     };
        QStringList searchStrings3 = { "Skewness0.00",
                                       "Kurtosis0.00",
                                     };

        VariableAppraisal varApp;
        MatrixTableModel<matrix_t> model;

        auto stripHtml = [](QString a) {
            a.remove(QRegExp("<\\/?[^>]+\\/?>"));
            a.remove("&nbsp;");
            return a;
        };

        model.stringToMatrix(input);
        model.setHeaders("Examined Audited Difference");
        varApp.fill_in_column(&model);
        columnLabels = model.getHeaders();
        varApp.build_report(model.getMatrix(), report, 2000, columnLabels, 3);
        bool printed = false;
        QString correctReport2 = stripHtml(report.join(""));
        foreach(QString str, searchStrings2)
        {
            QRegExp rx(QRegExp::escape(str), Qt::CaseInsensitive);
            if ( rx.indexIn(correctReport2) < 0 ) {
                if (!printed)
                    qDebug() << correctReport2.toStdString().c_str();
                printed = true;
                qDebug("Search string not found: %s", str.toStdString().c_str());
            }
        }
        QVERIFY(!printed);

        MatrixTableModel<matrix_t> model2;

        model.stringToMatrix("963.09 963.09 0");
        model.setHeaders("Examined Audited Difference");
        columnLabels = model.getHeaders();
        varApp.build_report(model.getMatrix(), report, 1, columnLabels, 3);
        printed = false;
        correctReport2 = stripHtml(report.join(""));
        foreach(QString str, searchStrings3)
        {
            QRegExp rx(QRegExp::escape(str), Qt::CaseInsensitive);
            if ( rx.indexIn(correctReport2) < 0 ) {
                if (!printed)
                    qDebug() << correctReport2.toStdString().c_str();
                printed = true;
                qDebug("Search string not found: %s", str.toStdString().c_str());
            }
        }
        QVERIFY(!printed);
}

void StatsToolTests::testCaseMatrixTable()
{
    MatrixTableModel<matrix_t> *model = new MatrixTableModel<matrix_t>();
    MatrixTableModel<matrix_t> *strModel = new MatrixTableModel<matrix_t>();

    QCOMPARE(model->rowCount(), 0);
    QCOMPARE(model->columnCount(), 0);

    model->insertRows(0, 6);
    model->insertColumns(0, 6);
    strModel->insertRows(0, 6);
    strModel->insertColumns(0, 6);

    for (int i = 0; i < model->rowCount(); i++) {
        for (int j = 0; j < model->columnCount(); j++) {
            model->setData(model->index(i, j), i * j);
            strModel->setData(strModel->index(i, j), QString("string %1").arg(i * j));
        }
    }

    for (int i = 0; i < model->rowCount(); i++) {
        for (int j = 0; j < model->columnCount(); j++) {
            if (model->data(model->index(i, j)).toInt() != (i) * (j))
                qDebug("%d,%d", i, j);
            QCOMPARE(model->data(model->index(i, j)).toInt(), (i) * (j));
        }
    }

    model->insertRows(0, 2);
    model->insertColumns(0, 2);
    strModel->insertRows(0, 2);
    strModel->insertColumns(0, 2);

    for (int i = 2; i < model->rowCount(); i++) {
        for (int j = 2; j < model->columnCount(); j++) {
            int y = j - 2;
            int x = i - 2;
            if (model->data(model->index(i, j)).toInt() != x * y)
                qDebug("%d,%d", i, j);
            QCOMPARE(model->data(model->index(i, j)).toInt(), x * y);
        }
    }
}

void StatsToolTests::testCaseMultiprecisionType()
{
    multiprecision_type bigNum("1234567890.01234567890123456789");
    boost::multiprecision::cpp_dec_float_100 epsilon(".0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001");
    uint i = 0;

    while ( epsilon * powl(10, i) < boost::math::tools::epsilon<multiprecision_type>() )
        i++;
    qDebug("The multiprecision type being used has a precision of 1e-%d", 100 - i);

    bigNum += 5;
    QVERIFY( QString("1234567895.01234567890123456789") == QString(static_cast<std::string>(bigNum).c_str()) );
    bigNum += multiprecision_type("0.00000000005");
    QVERIFY( QString("1234567895.01234567895123456789") == QString(static_cast<std::string>(bigNum).c_str()) );
}

QTEST_MAIN(StatsToolTests)

#include "tst_statstooltests.moc"

