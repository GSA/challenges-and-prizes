var searchData=
[
  ['m_5fdata',['m_data',['../df/d66/classMatrixTableModel.html#abea20818fd9fc1db4ac062164a77fb4f',1,'MatrixTableModel']]],
  ['m_5fheaders',['m_headers',['../df/d66/classMatrixTableModel.html#a5221324e873fdf0766fa7f127e2e9c04',1,'MatrixTableModel']]],
  ['m_5fstrings',['m_strings',['../df/d66/classMatrixTableModel.html#a8e07d1da3cd3dd22678f67675524413b',1,'MatrixTableModel']]],
  ['max',['max',['../d7/da5/classDialogSingleStageRandomNumbers.html#a59ed13b57633aaa340b36ebb54b8cb96',1,'DialogSingleStageRandomNumbers']]],
  ['min',['min',['../d7/da5/classDialogSingleStageRandomNumbers.html#afb2ee6002e56bec48a673e7f54b20e77',1,'DialogSingleStageRandomNumbers']]],
  ['movie',['movie',['../d7/d2e/classStatsTool.html#a079f74d7495c154b7fc0f6fbdb28374f',1,'StatsTool']]]
];
