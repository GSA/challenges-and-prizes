var classDialogStratifiedVariableAppraisal =
[
    [ "build_report", "d3/ddf/classDialogStratifiedVariableAppraisal.html#a100ec23e69055aacca77497856698ebc", null ],
    [ "insert_header", "d3/ddf/classDialogStratifiedVariableAppraisal.html#a43cb78194f5ee17f276716878855acea", null ],
    [ "insert_summary", "d3/ddf/classDialogStratifiedVariableAppraisal.html#a21f906447858845b03b49e8a5eca1206", null ],
    [ "on_buttonBox_accepted_unsafe", "d3/ddf/classDialogStratifiedVariableAppraisal.html#acc82912b5667864cc8fd77e884e1b672", null ]
];