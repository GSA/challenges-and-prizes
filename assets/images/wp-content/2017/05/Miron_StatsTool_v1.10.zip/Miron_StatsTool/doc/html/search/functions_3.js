var searchData=
[
  ['data',['data',['../d8/dfe/classExcelTableModel.html#a37025adedb41f80d5fb6881942a668d1',1,'ExcelTableModel::data()'],['../df/d66/classMatrixTableModel.html#a77985ab2ff940ac32bf52bbdb0cd7212',1,'MatrixTableModel::data()']]],
  ['displayhtml',['displayHtml',['../d7/d2e/classStatsTool.html#af339b0dfcdc469d3024e61ccfb391be8',1,'StatsTool::displayHtml()'],['../d6/d76/classSTDialog.html#aa4560c1cbb0f35b66a71b7aedee62ada',1,'STDialog::displayHtml()']]],
  ['displayimage',['displayImage',['../d7/d2e/classStatsTool.html#ada8a83934a51edf075cc65d1363e0590',1,'StatsTool::displayImage()'],['../d6/d76/classSTDialog.html#a6b3db476e4f495631bdeb1ff23e47139',1,'STDialog::displayImage()']]],
  ['displaymovie',['displayMovie',['../d7/d2e/classStatsTool.html#a02cee7941234889d5bb30f75299a1e3b',1,'StatsTool::displayMovie()'],['../d6/d76/classSTDialog.html#aa09ce1b0fbcdde24862141c7b41d8588',1,'STDialog::displayMovie()']]],
  ['displaytext',['displayText',['../d7/d2e/classStatsTool.html#ad58b4fd6042be12ff3ed50ee2789b942',1,'StatsTool::displayText()'],['../d6/d76/classSTDialog.html#a8f10135d1c33f1bd2a4c64a1297cc350',1,'STDialog::displayText()']]],
  ['dragenterevent',['dragEnterEvent',['../db/da5/classDialogUnrestrictedVariableAppraisal.html#a4d92af10768b33b0cda985e70e172dec',1,'DialogUnrestrictedVariableAppraisal']]],
  ['dropevent',['dropEvent',['../db/da5/classDialogUnrestrictedVariableAppraisal.html#acc26ab0634342bee24dd91c5eab86165',1,'DialogUnrestrictedVariableAppraisal']]],
  ['dumptoexcelfile',['dumpToExcelFile',['../d7/d2e/classStatsTool.html#aa68b4063ca9aab3fdbb3ee68b77c5229',1,'StatsTool']]]
];
