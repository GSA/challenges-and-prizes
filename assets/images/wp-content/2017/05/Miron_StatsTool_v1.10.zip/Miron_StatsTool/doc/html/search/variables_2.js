var searchData=
[
  ['framesize',['framesize',['../d7/da5/classDialogSingleStageRandomNumbers.html#a4eabb5430aa8ceffae1835e23c7741d5',1,'DialogSingleStageRandomNumbers']]]
];
