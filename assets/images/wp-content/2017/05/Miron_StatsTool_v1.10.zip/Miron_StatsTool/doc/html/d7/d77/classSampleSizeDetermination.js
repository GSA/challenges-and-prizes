var classSampleSizeDetermination =
[
    [ "byEstimatedError", "d7/d77/classSampleSizeDetermination.html#af4b0ebf86c0fb7af7ad28a1cd483052f", null ],
    [ "value", "d7/d77/classSampleSizeDetermination.html#aa1545db6a409bc22789841f2346394a3", null ]
];