Team members:

1. Murray Miron, Murray.T.Miron@gmail.com



5-digit prefix:

Miron



Submission description:

A redesign of the original RAT-STATS statistical software, meeting all challenge.gov requirements, which is able to be rapidly and easily extended from its current form.
The program is as cross-platform as is practical, and can be compiled to execute on Windows, Mac, or Linux.

The program should also translate symbols and numeric group placeholders, etc., to various international locales based on the user's operating system settings;
the author has not, however, tested this.

Additionally, I would like to say that while it does not represent a legally binding contract, I do stand by my work: if any bugs are found -- whether before or after the
challenge.gov contest ends -- a simple email and description of what causes the problem will have a fixed build out to you within a week or two.



Files / directories:

- bin/
        The program executable files.  Run "RATSTATS.exe" to execute the program.

- src/
	The program source code.  

- doc/
	Documentation for the program; navigate to the "html/index.html" file and open it in a web browser to view.
