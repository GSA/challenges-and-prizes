#ifndef DIALOGSAMPLESIZEBYESTIMATEDERROR_H
#define DIALOGSAMPLESIZEBYESTIMATEDERROR_H

#include "stdialog.h"
#include "st_macros.h"


namespace Ui {
class DialogSampleSizeByEstimatedError;
}

/**
 * @brief The Sample Size by Estimated Error module's window
 */
class DialogSampleSizeByEstimatedError : public STDialog
{
    Q_OBJECT

public:
    explicit DialogSampleSizeByEstimatedError(QWidget *parent = 0, QString auditName = QString());
    ~DialogSampleSizeByEstimatedError();

public slots:
    void on_buttonBox_accepted_unsafe();

private:
    Ui::DialogSampleSizeByEstimatedError *ui;
};

#endif // DIALOGSAMPLESIZEBYESTIMATEDERROR_H
