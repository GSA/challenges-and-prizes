#ifndef DIALOGSINGLESTAGERANDOMNUMBERS_H
#define DIALOGSINGLESTAGERANDOMNUMBERS_H

#include <QFileDialog>
#include <QValidator>
#include "stdialog.h"


namespace Ui {
class DialogSingleStageRandomNumbers;
}

/**
 * @brief Encapsulates the Single Stage Random Numbers module
 */
class DialogSingleStageRandomNumbers : public STDialog
{
    Q_OBJECT

public:
    explicit DialogSingleStageRandomNumbers(QWidget *parent = 0, QString auditName = QString());
    ~DialogSingleStageRandomNumbers();

    /**
     * @brief Stores the name given to the audit (usually what the user entered in that box)
     */
    QString auditName;
    /**
     * @brief Stores the time at which the random numbers were generated
     */
    QString generationTime;
    /**
     * @brief Stores the seed value used
     */
    double seed;
    /**
     * @brief Stores the frame size: |max - min| + 1
     */
    long int framesize;
    /**
     * @brief Stores the sum of the random numbers
     */
    int64_t sum;
    /**
     * @brief The minimum value used in the algorithm
     */
    int min;
    /**
     * @brief The maximum value used in the algorithm
     */
    int max;
    /**
     * @brief The number of sorted-by-value random numbers generated
     */
    int numRandoms;
    /**
     * @brief The number of sorted-by-sequence-order random numbers generated
     */
    int numSpares;
    /**
     * @brief Perform this module's calculations and store the data in public member variables
     * @param name The name of the audit
     * @param numRandoms How many sorted-by-value numbers to generate
     * @param numSpares How many sorted-by-generation-order numbers to generate
     * @param seed Value to initialize the RNG with
     * @param min Minimum value of random numbers
     * @param max Maximum value of random numbers
     * @param randoms The map object to store the generated numbers in
     *
     * This function takes all the data provided by this module's window and implements
     * the logic.  Can be used by instantiating an object of this dialog's class and
     * providing the same input as the GUI window would have; the results are then
     * available in member variables of the object and the _randoms_ parameter.
     */
    void calculate(QString name, int numRandoms, int numSpares, double seed, int min, int max, std::map<int64_t, int64_t> &randoms);
    /**
     * @brief Generate a report from previously performed calculations
     * @param out Used as the return value
     * @param randoms The randomly generated numbers
     *
     * Uses previously calculated values to build a report for display to the user
     */
    void buildHtmlReport(QTextStream &out, std::map<int64_t, int64_t> &randoms);

private:
    Ui::DialogSingleStageRandomNumbers *ui;
    void on_buttonBox_accepted_unsafe() override;
};

#endif // DIALOGSINGLESTAGERANDOMNUMBERS_H
