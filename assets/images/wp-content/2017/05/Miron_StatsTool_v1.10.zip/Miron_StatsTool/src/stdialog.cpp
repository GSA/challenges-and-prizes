#include "stdialog.h"
#include "st_macros.h"
#include <QtWidgets>
#include <float.h>

STDialog::STDialog(QWidget *parent) :
    QDialog(parent),
    validator(new QIntValidator(0, INT_MAX, this)),
    dblValidator(new QDoubleValidator(0, DBL_MAX, 3, this)),
    negValidator(new QIntValidator(INT_MIN, INT_MAX, this))
{
    whatsThisShortcut = new QShortcut(QKeySequence(tr("F1")), this, SLOT(on_actionWhat_s_this_triggered()));
}

STDialog::~STDialog()
{
    if ( validator )
        delete validator;
    if ( dblValidator )
        delete dblValidator;
    if ( negValidator )
        delete negValidator;
    if ( whatsThisShortcut )
        delete whatsThisShortcut;
}

void STDialog::addCommasToInput(QString str)
{
    QLineEdit *edit = static_cast<QLineEdit*>(QWidget::focusWidget());
    int oldCursorPos = 0;
    int cursorPos = 0;
    int commasBefore = 0;
    int commasAfter = 0;

    if ( !edit || !edit->validator() )
        return;

    oldCursorPos = edit->cursorPosition();
    commasBefore = str.count( tr(",") );
    edit->validator()->fixup(str);

    edit->setText(str);
    commasAfter = str.count( tr(",") );
    cursorPos = edit->cursorPosition();

    edit->setCursorPosition( oldCursorPos + (commasAfter - commasBefore) );
}

void STDialog::on_buttonBox_accepted()
{
    QApplication::setOverrideCursor(Qt::WaitCursor);
    qint64 start_msecs = QDateTime::currentMSecsSinceEpoch();

    try {
        on_buttonBox_accepted_unsafe();
    } catch (std::exception &e) {
        qDebug() << e.what();
        ST_ERRORBOX("An error occurred; please check your input values and try again.");
    }

    QApplication::restoreOverrideCursor();
    qDebug() << QString("Finished in %1 seconds").arg( (QDateTime::currentMSecsSinceEpoch() - start_msecs) / 1000.0 );
}

void STDialog::on_actionWhat_s_this_triggered()
{
    QWhatsThis::enterWhatsThisMode();
}
