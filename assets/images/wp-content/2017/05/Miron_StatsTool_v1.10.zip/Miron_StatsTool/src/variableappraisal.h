#ifndef VARIABLEAPPRAISAL_H
#define VARIABLEAPPRAISAL_H

#include <QString>
#include <QStringList>
#include "matrix.h"
#include "matrixtablemodel.hpp"

#define CONFIDENCE_LEVEL_99_Z_VALUE 2.575829303549
#define CONFIDENCE_LEVEL_95_Z_VALUE 1.959963984540
#define CONFIDENCE_LEVEL_90_Z_VALUE 1.644853626951
#define CONFIDENCE_LEVEL_80_Z_VALUE 1.281551565545

/**
 * @brief Implements the logic for the Variable Appraisal modules
 *
 * \todo Provide results of analyses, not just reports using them 
 */
class VariableAppraisal
{
public:
    VariableAppraisal();

    /**
     * @brief Build a Variable Appraisal report
     * @param mat The matrix to use for the analysis
     * @param report Where to insert the strings of the report; this is effectively the return value
     * @param universeSize The population size for use in the calculations
     * @param column_labels The name to give each column; order must match that of the matrix parameter
     * @param maxColumn Optional index of max column in the matrix to consider; if omitted, all matrix columns are used
     */
    void build_report(matrix_t &mat, QStringList &report, int64_t universeSize, QStringList &column_labels, int maxColumn = -1);
    void build_report(matrix_t &mat, QStringList &report, int64_t universeSize, QString column_label);
    void build_report(MatrixTableModel<matrix_t> *model, QStringList &report, int64_t universeSize, uint row_start = 0, uint col_start = 0);
    void build_report(matrix_t_view &mat, QStringList &report, int64_t universeSize, QStringList &column_labels, int maxColumn = -1);
    void build_report_table(matrix_t_view &mat, QStringList &report, int64_t universeSize, QStringList &column_labels, int maxColumn = -1);
    bool fill_in_column(matrix_t &mat, int examined_column, int audited_column, int difference_column, int64_t n_rows = -1);
    bool fill_in_column(MatrixTableModel<matrix_t> *model);
    static void figure_out_remaining_columns(int *one, int *two, int *three);

    /**
     * @brief Count how many nonzero items there are in a column of a matrix
     * @param mat The matrix to consider values within
     * @param column The column index of the matrix to consider values within
     * @return How many nonzero entities exist in the given column of the given matrix
     */
    int64_t nonzero_items(matrix_t &mat, int column);
    int64_t nonzero_items(matrix_t_view &mat, int column);
    /**
     * @brief Add up all the nonzero elements of each column in a matrix
     * @param mat The matrix to consider elements within
     * @return A 1xN matrix/vector, where N is the number of columns in the given matrix parameter
     *
     * There will be one element in the returned matrix per column; each element is the number of nonzero elements in the
     * corresponding column
     */
    matrix_t nonzero_items(matrix_t &mat);
};

#endif // VARIABLEAPPRAISAL_H
