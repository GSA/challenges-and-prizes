#include "dialogunrestrictedattributeappraisal.h"
#include "ui_dialogunrestrictedattributeappraisal.h"
#include "statstool.h"
#include "st_boost.h"
#include "attributeappraisal.h"
#include <boost/math/special_functions/binomial.hpp>
#include <QThread>
#include <QtConcurrent>
#include <qtconcurrentrun.h>


DialogUnrestrictedAttributeAppraisal::DialogUnrestrictedAttributeAppraisal(QWidget *parent, QString auditName) :
    STDialog(parent),
    ui(new Ui::DialogUnrestrictedAttributeAppraisal)
{
    validator->setRange(0, INT_MAX);

    ui->setupUi(this);
    ui->lineEdit_universeSize->setValidator(validator);
    ui->lineEdit_sampleSize->setValidator(validator);
    ui->lineEdit_itemsOfInterest->setValidator(validator);

    ui->lineEdit_auditName->setText(auditName);
    ui->lineEdit_auditName->setFocus();

    connect(ui->lineEdit_universeSize, SIGNAL(textEdited(QString)), this, SLOT(addCommasToInput(QString)));
    connect(ui->lineEdit_sampleSize, SIGNAL(textEdited(QString)), this, SLOT(addCommasToInput(QString)));
    connect(ui->lineEdit_itemsOfInterest, SIGNAL(textEdited(QString)), this, SLOT(addCommasToInput(QString)));
}

DialogUnrestrictedAttributeAppraisal::~DialogUnrestrictedAttributeAppraisal()
{
    delete ui;
}

Ui::DialogUnrestrictedAttributeAppraisal *DialogUnrestrictedAttributeAppraisal::getUi()
{
    return ui;
}

void DialogUnrestrictedAttributeAppraisal::on_thread_finished()
{
    if ( abortRequested )
        return;

    for (int i = 0; threads[i] != NULL; i++)
        if ( !threads[i]->isRunning() && !threads[i]->isFinished() )
            threads[i]->start();
}

void DialogUnrestrictedAttributeAppraisal::calculate(uint64_t n, uint64_t N, uint64_t k, QStringList &out)
{
    int64_t upper = 0;
    int64_t lower = 0;
    uint64_t K = round(k / (n / (double)N));
    long double confidence_levels[] = { 0.20, 0.10, 0.05, 0.01, 0.00 };

    KeyOverride keyOverride(this, Qt::Key_Escape);
    this->installEventFilter(&keyOverride);

    out << QString::asprintf("Characteristic of interest in sample: %'ld<br/>", k);
    out << QString::asprintf("Projected quantity in universe: %'ld (%'.3f%%)", K, (100 * (K / (double)N))) << "<br/>";

    if (n == 0 || n > N || k > n || N == 0)
        throw std::exception();

    int i = 0;
    for (int j = 0; confidence_levels[j] != 0; j++)
    {
        long double C = confidence_levels[j];

        if ( threads[i] )
            threads[i]->deleteLater();
        threads[i] = new AttributeAppraisal( ui->checkBox_lowerLimit->isChecked() ? AttributeAppraisal::LOWER : AttributeAppraisal::NONE,
                                             n, N, k, C, ui->checkBox_upperLimit->isChecked() );
        connect(threads[i], SIGNAL(finished()), this, SLOT(on_thread_finished()));

        if ( threads[i + 1] )
            threads[i + 1]->deleteLater();
        threads[i + 1] = new AttributeAppraisal( ui->checkBox_upperLimit->isChecked() ? AttributeAppraisal::UPPER : AttributeAppraisal::NONE,
                                                 n, N, k, C, ui->checkBox_lowerLimit->isChecked() );
        connect(threads[i + 1], SIGNAL(finished()), this, SLOT(on_thread_finished()));
        i += 2;
    }

    for (int j = 0; j < QThread::idealThreadCount() && threads[j] != NULL; j++)
        threads[j]->start();

    for (i = 0; threads[i] != NULL; i++) {
        while ( threads[i]->isRunning() ) {
            QApplication::processEvents();
            if (abortRequested) {
                for (int j = 0; threads[j] != NULL; j++)
                    if ( threads[j]->isRunning() )
                        threads[j]->requestInterruption();
                goto display_report;
            }
        }
    }

    // Yes.  Goto.  Because sometimes, it's the cleanest answer, no matter what your friends say :)
    display_report:
    i = 0;
    for (int j = 0; confidence_levels[j] != 0; j++)
    {
        long double C = confidence_levels[j];
        out << QString::asprintf("<table border='0' width='250'><caption><h4>%d%% confidence level</h4></caption>", (int)roundl(100 * (1 - C)));
//        out << QString::asprintf("<table border='0' width='350'>");
        out << tr("<tr><td align='center'>Lower bound</th><td align='center'>Upper bound</th></tr>");
        out << tr("<tr>");
        if (ui->checkBox_lowerLimit->isChecked()) {
            lower = threads[i]->getLower();
            if (lower != -1)
                out << QString::asprintf( "<td align='center'>%'lld</td>", (long long int)lower );
        } else {
            out << "<td align='center'>---</td>";
        }
        if (ui->checkBox_upperLimit->isChecked()) {
            upper = threads[i+1]->getUpper();
            if (upper != -1)
                out << QString::asprintf( "<td align='center'>%'lld</td>", (long long int)upper );
        } else {
            out << "<td align='center'>---</td>";
        }
        out << "</tr>";

        out << "<tr>";
        if ( ui->checkBox_lowerLimit->isChecked() ) {
            if ( lower != -1 )
                out << QString::asprintf( "<td align='center'>%'.3f%%</td>", (100 * (lower / (double)N)) );
        } else {
            out << "<td align='center'>---</td>";
        }
        if ( ui->checkBox_upperLimit->isChecked() ) {
            if ( upper != -1 )
                out << QString::asprintf( "<td align='center'>%'.3f%%</td>", (100 * (upper / (double)N)) );
        } else {
            out << "<td align='center'>---</td>";
        }
        out << "</tr>";
        out << "</table>\n";
        i += 2;
    }
}

void DialogUnrestrictedAttributeAppraisal::insert_header(uint64_t n, uint64_t N, QStringList &out)
{
    out << "<div class='module_header'>";
    out << "<h3>Attribute Appraisal - Unrestricted</h3><br/>";
    out << "Audit: " << ui->lineEdit_auditName->text() << "<br/>";
    out << "Date: " << QDateTime::currentDateTime().toString() << "<br/>";
    out << "</div>";
    out << "Universe size: " << QString::asprintf("%'ld", N) << "<br/>";
    out << "Sample size: " << QString::asprintf("%'ld", n) << "<br/>";
}

void DialogUnrestrictedAttributeAppraisal::on_buttonBox_accepted()
{
    QApplication::setOverrideCursor(Qt::WaitCursor);
    qint64 start_msecs = QDateTime::currentMSecsSinceEpoch();

    ui->buttonBox->setDisabled(true);
    ui->pushButton_abort->setEnabled(true);
    abortRequested = false;

    try {
        on_buttonBox_accepted_unsafe();
    } catch (std::exception &e) {
        qDebug() << e.what();
        ST_ERRORBOX("An error occurred; please check your input values and try again.");
    }

    ui->buttonBox->setEnabled(true);
    ui->pushButton_abort->setDisabled(true);

    QApplication::restoreOverrideCursor();
    qDebug() << QString("Finished in %1 seconds").arg( (QDateTime::currentMSecsSinceEpoch() - start_msecs) / 1000.0);
}

void DialogUnrestrictedAttributeAppraisal::on_buttonBox_accepted_unsafe()
{
    uint64_t N = 0, n = 0, k = 0;
    QStringList out;

    N = ui->lineEdit_universeSize->text().remove(tr(",")).toInt();
    n = ui->lineEdit_sampleSize->text().remove(tr(",")).toInt();
    k = ui->lineEdit_itemsOfInterest->text().remove(tr(",")).toInt();

    insert_header(n, N, out);
    calculate(n, N, k, out);

    emit setAuditName(ui->lineEdit_auditName->text());
    emit displayHtml(out.join(""));
    emit reject();
}

void DialogUnrestrictedAttributeAppraisal::on_pushButton_abort_clicked()
{
    ui->pushButton_abort->setDisabled(true);
    abortRequested = true;
}
