/*
 * All the code for the "Single Stage Random Numbers" module
 * logic is in here; the actual GUI design is in the .ui file.
 *
 * The Wichmann-Hill code is found in that file and not this one,
 * as well.
 */

#include "dialogsinglestagerandomnumbers.h"
#include "ui_dialogsinglestagerandomnumbers.h"
#include "statstool.h"
#include "ui_statstool.h"
#include "wichmannhill.h"
#include <QValidator>

DialogSingleStageRandomNumbers::DialogSingleStageRandomNumbers(QWidget *parent, QString auditName) :
    STDialog(parent),
    ui(new Ui::DialogSingleStageRandomNumbers)
{
    validator->setRange(0, 1000000);
    dblValidator->setRange(0, DBL_MAX, 2);
    ui->setupUi(this);

    ui->lineEdit_numbersToGenerate->setValidator(validator);
    ui->lineEdit_spareNumbersToGenerate->setValidator(validator);
    ui->lineEdit_maximumValue->setValidator(negValidator);
    ui->lineEdit_minimumValue->setValidator(negValidator);
    ui->lineEdit_seed->setValidator(dblValidator);

    ui->lineEdit_auditName->setText(auditName);
    ui->lineEdit_auditName->setFocus();

    connect(ui->lineEdit_numbersToGenerate, SIGNAL(textEdited(QString)), this, SLOT(addCommasToInput(QString)));
    connect(ui->lineEdit_spareNumbersToGenerate, SIGNAL(textEdited(QString)), this, SLOT(addCommasToInput(QString)));
    connect(ui->lineEdit_minimumValue, SIGNAL(textEdited(QString)), this, SLOT(addCommasToInput(QString)));
    connect(ui->lineEdit_maximumValue, SIGNAL(textEdited(QString)), this, SLOT(addCommasToInput(QString)));
}

DialogSingleStageRandomNumbers::~DialogSingleStageRandomNumbers()
{
    delete ui;
}

static void insert_ratstats_compliant_number_list(std::map<int64_t, int64_t> &randoms, QTextStream &out, int n_sorted)
{
    std::map<int64_t, int64_t> sorted_randoms;

    out << "<pre>";
    out << "Selection\n  Order   Value\n\n";
    out << "<a name='sequential'>";

    if (n_sorted > 0) {
        // sort by value (std::map objects are sorted by key)
        for (std::map<int64_t, int64_t>::iterator it = randoms.begin(); it != randoms.end(); it++)
        {
            sorted_randoms.insert(std::pair<int64_t, int64_t>(it->second, it->first));
            if (it->first == n_sorted)
                break;
        }
        // insert strings for sorted-by-value numbers
        for (std::map<int64_t, int64_t>::iterator it = sorted_randoms.begin(); it != sorted_randoms.end(); it++)
        {
            out << QString::asprintf("%6ld  %6ld\n", it->second, it->first);
        }
    }

    out << "</a><a name='spares'>";
    // insert strings for sorted-by-generation-order numbers
    for (std::map<int64_t, int64_t>::iterator it = randoms.find(n_sorted + 1); it != randoms.end(); it++)
    {
        out << QString::asprintf("%6ld  %6ld\n", it->first, it->second);
    }
    out << "</a></pre>";
}

void DialogSingleStageRandomNumbers::calculate(QString name, int numRandoms, int numSpares, double seed, int min, int max, std::map<int64_t, int64_t> &randoms)
{
    this->auditName = name;
    this->generationTime = QDateTime::currentDateTime().toString();
    this->seed = seed;
    this->framesize = max - min + 1;
    this->max = max;
    this->min = min;
    this->numRandoms = numRandoms;
    this->numSpares = numSpares;

    if (this->seed == 0.00) {
        this->seed = QDateTime::currentMSecsSinceEpoch() % 100000;
    }
    if (max - min + 1 < numRandoms + numSpares)
        return;

    WichmannHill rng(this->seed);
    rng.generateNumbers(numRandoms + numSpares, min, max, randoms);
    this->sum = rng.sum();
}

void DialogSingleStageRandomNumbers::buildHtmlReport(QTextStream &out, std::map<int64_t, int64_t> &randoms)
{
    QString seedStr = QString::asprintf("%.2Lf", (long double)this->seed);

    out << tr("<div class='module_header'><h3>Random Numbers - Single Stage</h3>");
    out << tr("Audit: ") << this->auditName << "\n";
    out << tr("Time: ") << this->generationTime << "</div>\n";
    out << tr("Seed: ") << seedStr << "\n";
    out << tr("Frame size: ") << QString::asprintf("%'ld (%'d - %'d)", this->framesize, this->min, this->max) << "\n";
    out << QString::asprintf("Sum of all %'lld (<a href='#sequential'>%'lld</a> + <a href='#spares'>%'lld spares</a>) random numbers: %'lld\n",
                             (long long)(this->numRandoms + this->numSpares),
                             (long long)this->numRandoms, (long long)this->numSpares,
                             (long long int)this->sum);
    insert_ratstats_compliant_number_list(randoms, out, this->numRandoms);
}

void DialogSingleStageRandomNumbers::on_buttonBox_accepted_unsafe()
{
    QString buf;
    QTextStream out(&buf);
    QString audit = ui->lineEdit_auditName->text();
    double seed = ui->lineEdit_seed->text().toDouble();
    int numbers = ui->lineEdit_numbersToGenerate->text().remove(tr(",")).toInt();
    int spares = ui->lineEdit_spareNumbersToGenerate->text().remove(tr(",")).toInt();
    int min = ui->lineEdit_minimumValue->text().remove(tr(",")).toInt();
    int max = ui->lineEdit_maximumValue->text().remove(tr(",")).toInt();
    std::map<int64_t, int64_t> randoms;

    // sanity check on requested values
    if (max - min + 1 < numbers + spares) {
        ST_ERRORBOX("Not enough unique values in your universe to generate that many numbers.");
        return;
    }

    // perform the calculations and store the results in member variables
    calculate(audit, numbers, spares, seed, min, max, randoms);
    buildHtmlReport(out, randoms);

    emit setAuditName(audit);
    emit displayHtml(buf);
    this->reject();
}
