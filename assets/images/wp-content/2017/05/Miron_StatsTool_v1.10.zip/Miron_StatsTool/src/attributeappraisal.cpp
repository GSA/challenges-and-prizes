#include "attributeappraisal.h"
#include "st_boost.h"


AttributeAppraisal::AttributeAppraisal()
{

}

AttributeAppraisal::AttributeAppraisal(interval_type arg, uint sample_size, uint population_size, uint sample_successes, double confidence, bool double_sided)
    : sample_size(sample_size), population_size(population_size), sample_successes(sample_successes), confidence(confidence), double_sided(double_sided)
{
    job = arg;
}

AttributeAppraisal::~AttributeAppraisal()
{
    while ( isRunning() )
        ;
}

int64_t AttributeAppraisal::getLower()
{
    return lower.loadAcquire();
}

int64_t AttributeAppraisal::getUpper()
{
    return upper.loadAcquire();
}

double AttributeAppraisal::getUpperCDF()
{
    return upperCDF;
}

double AttributeAppraisal::getLowerCDF()
{
    return lowerCDF;
}

void AttributeAppraisal::run()
{
    switch (job) {
    case UPPER_AND_LOWER:
        upper_limit();
        lower_limit();
        break;
    case UPPER:
        upper_limit();
        break;
    case LOWER:
        lower_limit();
        break;
    case NONE:
        break;
    default:
        break;
    }
}

int64_t AttributeAppraisal::upper_limit()
{
    int64_t upper_result = upper_limit(sample_size, population_size, sample_successes, confidence, double_sided);
    upper.storeRelease(upper_result);
    return upper.loadAcquire();
}

int64_t AttributeAppraisal::lower_limit()
{
    int64_t lower_result = lower_limit(sample_size, population_size, sample_successes, confidence, double_sided);
    lower.storeRelease(lower_result);
    return lower.loadAcquire();
}

boost_cast_type AttributeAppraisal::upper_bound_on_p(uint sample_size, uint sample_successes, double C)
{
    return static_cast<boost_cast_type>(boost::math::binomial_distribution<double, boost_error_policy>::
            find_upper_bound_on_p(sample_size,
                                  sample_successes,
                                  C,
                                  boost::math::binomial_distribution<double, boost_error_policy>::
                                  clopper_pearson_exact_interval));
}

boost_cast_type AttributeAppraisal::lower_bound_on_p(uint sample_size, uint sample_successes, double C)
{
    return static_cast<boost_cast_type>(boost::math::binomial_distribution<double, boost_error_policy>::
            find_lower_bound_on_p(sample_size,
                                  sample_successes,
                                  C,
                                  boost::math::binomial_distribution<double, boost_error_policy>::
                                  clopper_pearson_exact_interval));
}

int AttributeAppraisal::sampleSizeByAttribute(double errorRate, uint universeSize, double precision, QStringList *ret)
{
    uint initial_width = universeSize * precision;
    uint initial_n = initial_width;
    uint x = initial_n * errorRate;
    uint k1 = initial_n;
    uint k2 = 0;
    double intervals[] = { 0.20, 0.10, 0.05, 0.01, 0.00 };
    boost_cast_type upper_bounds[5] = { 0, 0, 0, 0, 0 };
    boost_cast_type lower_bounds[5] = { 0, 0, 0, 0, 0 };

    return 0;
}

int64_t AttributeAppraisal::upper_limit_imprecise(uint sample_size, uint population_size, uint sample_successes, double confidence, bool double_sided)
{
    int64_t ret = 0;
    double cdf = 0;
    double C = confidence / (double_sided ? 2 : 1);
    boost_cast_type upper_bound = static_cast<boost_cast_type>(boost::math::binomial_distribution<double, boost_error_policy>::
            find_upper_bound_on_p(sample_size,
                                  sample_successes,
                                  C,
                                  boost::math::binomial_distribution<double, boost_error_policy>::
                                  clopper_pearson_exact_interval));
    ret = population_size * upper_bound;
    boost::math::hypergeometric_distribution<double, boost_error_policy> hg_dist(ret, sample_size, population_size);

    for (/* empty */; ret > 0; ret -= 3)
    {
        hg_dist = boost::math::hypergeometric_distribution<double, boost_error_policy>(ret, sample_size, population_size);
        cdf = boost::math::cdf<double>(hg_dist, sample_successes);

        if ( cdf > C || QThread::isInterruptionRequested() ) {
            for ( ret += 5; /* empty */; ret--)
            {
                hg_dist = boost::math::hypergeometric_distribution<double, boost_error_policy>(ret, sample_size, population_size);
                cdf = boost::math::cdf<double>(hg_dist, sample_successes);

                if ( cdf > C || QThread::isInterruptionRequested() ) {
                    upperCDF = cdf;
                    return ret;
                }
            }
        }
    }
    upperCDF = cdf;
    return ret;
}

int64_t AttributeAppraisal::lower_limit_imprecise(uint sample_size, uint population_size, uint sample_successes, double confidence, bool double_sided)
{
    int64_t ret = 0;
    double cdf = 0;
    double C = confidence / (double_sided ? 2 : 1);
    boost_cast_type lower_bound = static_cast<boost_cast_type>(boost::math::binomial_distribution<double, boost_error_policy>::
            find_lower_bound_on_p(sample_size,
                                  sample_successes,
                                  C,
                                  boost::math::binomial_distribution<double, boost_error_policy>::
                                  clopper_pearson_exact_interval));
    ret = population_size * lower_bound;
    boost::math::hypergeometric_distribution<double, boost_error_policy> hg_dist(ret, sample_size, population_size);

    if (sample_successes == 0)
        return 0;
    else if (sample_size == population_size)
        return sample_successes;
    for (/* empty */; ret < population_size; ret += 3)
    {
        hg_dist = boost::math::hypergeometric_distribution<double, boost_error_policy>(ret, sample_size, population_size);
        cdf = boost::math::cdf<double>(boost::math::complement(hg_dist, sample_successes - 1));

        if ( cdf > C || QThread::isInterruptionRequested() ) {
            for ( ret -= 5; /* empty */; ret++)
            {
                hg_dist = boost::math::hypergeometric_distribution<double, boost_error_policy>(ret, sample_size, population_size);
                cdf = boost::math::cdf<double>(boost::math::complement(hg_dist, sample_successes - 1));

                if ( cdf > C || QThread::isInterruptionRequested() ) {
                    lowerCDF = cdf;
                    return ret;
                }
            }
        }
    }
    lowerCDF = cdf;
    return ret;
}

int64_t AttributeAppraisal::upper_limit(uint sample_size, uint population_size, uint sample_successes, double confidence, bool double_sided)
{
    int64_t ret = 0;
    double cdf = 0;
    multiprecision_type cdf_precise = 0;
    double C = confidence / (double_sided ? 2 : 1);
    boost_cast_type upper_bound = static_cast<boost_cast_type>(boost::math::binomial_distribution<double, boost_error_policy>::
            find_upper_bound_on_p(sample_size,
                                  sample_successes,
                                  C,
                                  boost::math::binomial_distribution<double, boost_error_policy>::
                                  clopper_pearson_exact_interval));
    ret = population_size * upper_bound;
    boost::math::hypergeometric_distribution<double, boost_error_policy> hg_dist(ret, sample_size, population_size);
    boost::math::hypergeometric_distribution<multiprecision_type, boost_error_policy> hg_dist_precise(ret, sample_size, population_size);

    for (/* empty */; ret > 0; ret -= 3)
    {
        hg_dist = boost::math::hypergeometric_distribution<double, boost_error_policy>(ret, sample_size, population_size);
        cdf = boost::math::cdf<double>(hg_dist, sample_successes);

        if ( cdf > C || QThread::isInterruptionRequested() ) {
            for (ret += 5; /* empty */; ret--)
            {
                hg_dist_precise = boost::math::hypergeometric_distribution<multiprecision_type, boost_error_policy>(ret, sample_size, population_size);
                cdf_precise = boost::math::cdf<multiprecision_type>(hg_dist_precise, sample_successes);

                if ( cdf_precise > C || QThread::isInterruptionRequested() ) {
                    upperCDF = static_cast<double>(cdf_precise);
                    return ret;
                }
            }
        }
    }
    upperCDF = cdf;
    return ret;
}

// calculate the lower limit for a given confidence level
int64_t AttributeAppraisal::lower_limit(uint sample_size, uint population_size, uint sample_successes, double confidence, bool double_sided)
{
    int64_t ret = 0;
    double cdf = 0;
    multiprecision_type cdf_precise = 0;
    double C = confidence / (double_sided ? 2 : 1);
    boost_cast_type lower_bound = static_cast<boost_cast_type>(boost::math::binomial_distribution<double, boost_error_policy>::
            find_lower_bound_on_p(sample_size,
                                  sample_successes,
                                  C,
                                  boost::math::binomial_distribution<double, boost_error_policy>::
                                  clopper_pearson_exact_interval));
    ret = population_size * lower_bound;
    boost::math::hypergeometric_distribution<double, boost_error_policy> hg_dist(ret, sample_size, population_size);
    boost::math::hypergeometric_distribution<multiprecision_type, boost_error_policy> hg_dist_precise(ret, sample_size, population_size);

    if (sample_successes == 0)
        return 0;
    else if (sample_size == population_size)
        return sample_successes;
    for (/* empty */; ret < population_size; ret += 3)
    {
        hg_dist = boost::math::hypergeometric_distribution<double, boost_error_policy>(ret, sample_size, population_size);
        cdf = boost::math::cdf<double>(boost::math::complement(hg_dist, sample_successes - 1));

        if ( cdf > C || QThread::isInterruptionRequested() ) {
            for (ret -= 5; /* empty */; ret++)
            {
                hg_dist_precise = boost::math::hypergeometric_distribution<multiprecision_type, boost_error_policy>(ret, sample_size, population_size);
                cdf_precise = boost::math::cdf<multiprecision_type>(boost::math::complement(hg_dist_precise, sample_successes - 1));

                if ( cdf_precise > C || QThread::isInterruptionRequested() ) {
                    lowerCDF = static_cast<double>(cdf_precise);
                    return ret;
                }
            }
        }
    }
    lowerCDF = cdf;
    return ret;
}
