#include "variableappraisal.h"
#include "matrix.h"
#include "st_boost.h"
#include "statstool.h"
#include "matrixtablemodel.hpp"


VariableAppraisal::VariableAppraisal()
{

}

int64_t VariableAppraisal::nonzero_items(matrix_t &mat, int column)
{
    int64_t nonzero = 0;

    for (uint i = 0; i < mat.rows(); i++)
        if (mat(i, column) != 0)
            nonzero++;
    return nonzero;
}

int64_t VariableAppraisal::nonzero_items(matrix_t_view &mat, int column)
{
    int64_t nonzero = 0;

    for (uint64_t i = 0; i < mat.rows(); i++)
        if (mat(i, column) != 0)
            nonzero++;
    return nonzero;
}

matrix_t VariableAppraisal::nonzero_items(matrix_t &mat)
{
    matrix_t ret(1, mat.cols());

    for (uint i = 0; i < mat.cols(); i++)
        ret(i) = nonzero_items(mat, i);
    return ret;
}

void VariableAppraisal::build_report(matrix_t &mat, QStringList &report, int64_t universeSize, QString column_label)
{
    QStringList slist;
    slist << column_label;
    build_report(mat, report, universeSize, slist, 1);
}

bool VariableAppraisal::fill_in_column(MatrixTableModel<matrix_t> *model)
{
    bool ret;
    int known = 0;
    QStringList headers = model->getHeaders();

    int exa_col = headers.indexOf(QRegExp(".*Examined.*", Qt::CaseInsensitive));
    int aud_col = headers.indexOf(QRegExp(".*Audited.*", Qt::CaseInsensitive));
    int dif_col = headers.indexOf(QRegExp(".*Difference.*", Qt::CaseInsensitive));

    QVector<int> colList = { exa_col, aud_col, dif_col };
    foreach(int col, colList) {
        if ( col != -1 ) {
            known++;
        }
    }
    if ( known > 1 )
        figure_out_remaining_columns(&exa_col, &aud_col, &dif_col);
    ret = fill_in_column(model->getMatrix(), exa_col, aud_col, dif_col, model->rowCount());

    if (ret) {
            model->setHeaderData(exa_col, Qt::Horizontal, QVariant("EXAMINED"));
            model->setHeaderData(aud_col, Qt::Horizontal, QVariant("AUDITED"));
            model->setHeaderData(dif_col, Qt::Horizontal, QVariant("DIFFERENCE"));
        model->updateView();
    }

    return ret;
}

template <class T>
static int qvMax(QVector<T> v)
{
    int max = -1;
    foreach (int i, v)
        if ( i > max )
            max = i;

    return max;
}

void VariableAppraisal::figure_out_remaining_columns(int *one, int *two, int *three)
{
    QVector<int> avail = { 0, 1, 2, 3 };
    QVector<int*> used;

    used << one << two << three;
    foreach (int *u, used)
        if (*u != -1)
            avail.removeAll(*u);

    foreach(int *u, used)
        if (*u == -1)
            *u = qvMax(avail);
}

bool VariableAppraisal::fill_in_column(matrix_t &mat, int examined_column, int audited_column, int difference_column, int64_t n_rows)
{
    bool ret = false;

    if (n_rows < 0)
        n_rows = mat.rows();
    mat.resize( mat.rows(), qvMax(QVector<int>({examined_column, audited_column, difference_column})) + 1, true );

    if ( difference_column > audited_column && difference_column > examined_column ) {
        ret = true;
        for (int i = 0; i < n_rows; i++)
            mat(i, difference_column) = mat(i, examined_column) - mat(i, audited_column);
    }
    if ( examined_column > audited_column && examined_column > difference_column ) {
        ret = true;
        for (int i = 0; i < n_rows; i++)
            mat(i, examined_column) = mat(i, audited_column) + mat(i, difference_column);
    }
    if ( audited_column > examined_column && audited_column > difference_column ) {
        ret = true;
        for (int i = 0; i < n_rows; i++)
            mat(i, audited_column) = mat(i, examined_column) - mat(i, difference_column);
    }

    return ret;
}

void VariableAppraisal::build_report(MatrixTableModel<matrix_t> *model, QStringList &report, int64_t universeSize, uint row_start, uint col_start)
{
    matrix_t_view mat;
    QStringList column_labels;
    int64_t nRows = model->getMatrix().rows();
    int64_t nCols = model->getMatrix().cols();

    mat.reference( model->getMatrix()(row_start, col_start, nRows - 1, nCols - 1) );
    for (int i = col_start; i < nCols; i++)
        column_labels << model->data(model->index(0, i)).toString();

    build_report(mat, report, universeSize, column_labels);
}

void VariableAppraisal::build_report(matrix_t &mat, QStringList &report, int64_t universeSize, QStringList &column_labels, int maxColumn)
{
    matrix_t_view matView;

    matView.reference(mat);
    build_report_table(matView, report, universeSize, column_labels, maxColumn);
}

void VariableAppraisal::build_report(matrix_t_view &mat, QStringList &report, int64_t universeSize, QStringList &column_labels, int maxColumn)
{
    uint64_t sampleSize = mat.rows();
    double t_value = 0.0;
    matrix_t means = scythe::meanc(mat);
    matrix_t sums = scythe::sumc(mat);
    matrix_t std_devs = scythe::sdc(mat);
    matrix_t pnt_ests(1, mat.cols());
    matrix_t sd_means(1, mat.cols());
    matrix_t sd_totals(1, mat.cols());
    boost::math::students_t_distribution<double, boost_error_policy> dist(sampleSize - 1);
    double confidence_intervals[] = { 0.20, 0.10, 0.05, 0.01, 0.00 };

    if (maxColumn == -1)
        maxColumn = mat.cols();

    for (int column = 0; column < maxColumn; column++)
    {
        pnt_ests(0, column) = means(0, column) * universeSize;
        sd_means(0, column) = std_devs(0, column) * sqrtl((universeSize - sampleSize) / (long double)(sampleSize * universeSize));
        sd_totals(0, column) = sd_means(0, column) * universeSize;
        double skewness = StatsTool::ratstats_skewness(mat, column, means(0, column));
        double kurtosis = StatsTool::ratstats_kurtosis(mat, column, means(0, column));

        report << "<div class='variable_column'>";
        report << QString("<a name='column_%1'>").arg(column + 1);
        if (!column_labels.isEmpty()) {
            report << QString("<h3>%1</h3>").arg(column_labels.at(column));
        } else {
            report << QString::asprintf("<h3>Column %d</h3>", column + 1);
        }
        report << QString("</a>");
        report << "Sum: " << QString::asprintf("%'.02Lf", sums(0, column)) << "\n";
        report << "Mean: " << QString::asprintf("%'.02Lf", means(0, column)) << "\n";
        report << "Standard deviation: " << (isnormal(std_devs(0, column)) ? QString::asprintf("%'.02Lf\n", std_devs(0, column)) : "0\n");
        report << "Non-zero items: " << QString::asprintf("%'lld", (long long int)nonzero_items(mat, column)) << "\n";
        report << "Skewness: " << QString::asprintf("%'.02f", isnormal(skewness) ? skewness : 0.0) << "\n";
        report << "Kurtosis: " << QString::asprintf("%'.02f", isnormal(kurtosis) ? kurtosis : 0.0) << "\n";
        report << "Standard error (mean): " << (isnormal(sd_means(0, column)) ? QString::asprintf("%'.02Lf\n", sd_means(0, column)) : "0\n");
        report << "Standard error (total): " << (isnormal(sd_totals(0, column)) ? QString::asprintf("%'.02Lf\n", sd_totals(0, column)) : "0\n");
        report << "Point estimate: " << QString::asprintf("%'.02Lf", pnt_ests(0, column));
        for (int i = 0; confidence_intervals[i] != 0; i++)
        {
            double C = confidence_intervals[i];

            t_value = boost::math::quantile(boost::math::complement(dist, C / 2));
            if (!isnormal(t_value))
                t_value = 0.00;
            if (!isnormal(sd_totals(0, column)))
                sd_totals(0, column) = 0.0;
            long double lower_limit = pnt_ests(0, column) - (sd_totals(0, column) * t_value);
            long double upper_limit = pnt_ests(0, column) + (sd_totals(0, column) * t_value);
            long double precision = sd_totals(0, column) * t_value;
            long double precision_percent = pnt_ests(0, column) < 0 ? 0 : 100 * ((sd_totals(0, column) * t_value) / pnt_ests(0, column));

            report << QString("<div class='confidence_interval'><h4>%1% confidence interval</h4>").arg((int)((1 - C) * 100));
            report << QString::asprintf("Lower bound: %'.02Lf\nUpper bound: %'.02Lf\n",
                                        (isnormal(lower_limit) ? lower_limit : 0.0),
                                        (isnormal(upper_limit) ? upper_limit : 0.0));
            report << QString::asprintf("Precision amount: %'.02Lf  (%.02Lf%%)\n", (isnormal(precision) ? precision : 0.0),
                                        (isnormal(precision_percent) ? precision_percent : 0.0));
            report << QString::asprintf("t-Value used: %'.12f</div>", isnormal(t_value) ? t_value : 0.0);
        }
        report << "</div>\n";
    }
}

void VariableAppraisal::build_report_table(matrix_t_view &mat, QStringList &report, int64_t universeSize, QStringList &column_labels, int maxColumn)
{
    uint64_t sampleSize = mat.rows();
    double t_value = 0.0;
    matrix_t means = scythe::meanc(mat);
    matrix_t sums = scythe::sumc(mat);
    matrix_t std_devs = scythe::sdc(mat);
    matrix_t pnt_ests(1, mat.cols());
    matrix_t sd_means(1, mat.cols());
    matrix_t sd_totals(1, mat.cols());
    boost::math::students_t_distribution<double, boost_error_policy> dist(sampleSize - 1);
    double confidence_intervals[] = { 0.20, 0.10, 0.05, 0.01, 0.00 };

    if (maxColumn == -1)
        maxColumn = mat.cols();

    for (int column = 0; column < maxColumn; column++)
    {
        pnt_ests(0, column) = means(0, column) * universeSize;
        sd_means(0, column) = std_devs(0, column) * sqrtl((universeSize - sampleSize) / (long double)(sampleSize * universeSize));
        sd_totals(0, column) = sd_means(0, column) * universeSize;
        double skewness = StatsTool::ratstats_skewness(mat, column, means(0, column));
        double kurtosis = StatsTool::ratstats_kurtosis(mat, column, means(0, column));

        report << "<div class='variable_column'>";
        report << QString("<table border='0' width='300'><caption><a name='column_%1'>").arg(column + 1);
        if (!column_labels.isEmpty()) {
            report << QString("<h3>%1</h3>").arg(column_labels.at(column));
        } else {
            report << QString::asprintf("<h3>Column %d</h3>", column + 1);
        }
        report << QString("</a></caption><tr></tr>");
        report << "<tr><td align='left'>Sum</td>" << QString::asprintf("<td align='right'>%'.02Lf</td>", sums(0, column)) << "</tr>";
        report << "<tr><td align='left'>Mean</td>" << QString::asprintf("<td align='right'>%'.02Lf</td>", means(0, column)) << "</tr>";
        report << "<tr><td align='left'>Standard deviation</td><td align='right'>" << (isnormal(std_devs(0, column)) ? QString::asprintf("%'.02Lf", std_devs(0, column)) : "0") << "</td></tr>";
        report << "<tr><td align='left'>Non-zero items</td>" << QString::asprintf("<td align='right'>%'lld</td>", (long long int)nonzero_items(mat, column)) << "</tr>";
        report << "<tr><td align='left'>Skewness</td>" << QString::asprintf("<td align='right'>%'.02f</td>", isnormal(skewness) ? skewness : 0.0) << "</tr>";
        report << "<tr><td align='left'>Kurtosis</td>" << QString::asprintf("<td align='right'>%'.02f</td>", isnormal(kurtosis) ? kurtosis : 0.0) << "</tr>";
        report << "<tr><td align='left'>Standard error (mean)</td>" << (isnormal(sd_means(0, column)) ? QString::asprintf("<td align='right'>%'.02Lf</td>", sd_means(0, column)) : "<td align='right'>0</td>") << "</tr>";
        report << "<tr><td align='left'>Standard error (total)</td><td align='right'>" << (isnormal(sd_totals(0, column)) ? QString::asprintf("%'.02Lf", sd_totals(0, column)) : "0") << "</tr>";
        report << "<tr><td align='left'>Point estimate</td>" << QString::asprintf("<td align='right'>%'.02Lf</td></tr>", pnt_ests(0, column));
        report << "</table>";
        for (int i = 0; confidence_intervals[i] != 0; i++)
        {
            double C = confidence_intervals[i];

            t_value = boost::math::quantile(boost::math::complement(dist, C / 2));
            if (!isnormal(t_value))
                t_value = 0.00;
            if (!isnormal(sd_totals(0, column)))
                sd_totals(0, column) = 0.0;
            long double lower_limit = pnt_ests(0, column) - (sd_totals(0, column) * t_value);
            long double upper_limit = pnt_ests(0, column) + (sd_totals(0, column) * t_value);
            long double precision = sd_totals(0, column) * t_value;
            long double precision_percent = pnt_ests(0, column) < 0 ? 0 : 100 * ((sd_totals(0, column) * t_value) / pnt_ests(0, column));

            report << "<table border='0' width='300'>";
            report << QString("<caption><h4>%1% confidence interval</h4></caption><tr></tr>").arg((int)((1 - C) * 100));
            report << QString::asprintf("<tr><td align='left'>Lower bound</td><td align='right'>%'.02Lf</td></tr><tr><td align='left'>Upper bound</td><td align='right'>%'.02Lf</td></tr>",
                                        (isnormal(lower_limit) ? lower_limit : 0.0),
                                        (isnormal(upper_limit) ? upper_limit : 0.0));
            report << QString::asprintf("<tr><td align='left'>Precision amount</td><td align='right'>%'.02Lf</td></tr>"
                                        "<tr><td align='left'>Precision percent</td><td align='right'>%.02Lf%%</td></tr>", (isnormal(precision) ? precision : 0.0),
                                        (isnormal(precision_percent) ? precision_percent : 0.0));
            report << QString::asprintf("<tr><td align='left'>t-Value used</td><td align='right'>%'.12f</td></tr>", isnormal(t_value) ? t_value : 0.0);
            report << "</table>";
        }
        report << "</div>";
    }
}
