#ifndef STDIALOG_H
#define STDIALOG_H

#include <QDialog>
#include <QValidator>
#include <QShortcut>
#include <matrixtablemodel.hpp>

namespace Ui {
class STDialog;
}

/**
 * @brief For adding new module windows, you should inherit from this class
 *
 * This class serves to reduce the amount of boilerplate code required to maintain
 * continuity throughout the program (hotkeys, signals, etc.)
 */
class STDialog : public QDialog
{
    Q_OBJECT

public:
    explicit STDialog(QWidget *parent = 0);
    ~STDialog();

signals:
    /**
     * @brief Display some HTML in the main window
     * @param html The QString holding the HTML to be displayed
     *
     * The dialog isn't closed when you call this, but any text already existing in the main window
     * will be erased prior to the passed QString being shown
     */
    void displayHtml(QString html);
    /**
     * @brief Display some plaintext in the main window
     * @param text The QString holding the text to be displayed
     *
     * This actually wraps the text in "<pre>...</pre>" tags and displays it as HTML
     */
    void displayText(QString text);
    /**
     * @brief Display an arbitrary image in the report window
     */
    void displayImage(QString file);
    /**
     * @brief Play a moving image file (accepted formats are dictated by Qt) in the main window
     * @param fileName Path to the movie file
     *
     * Used to show the splash background at program start
     */
    void displayMovie(QString fileName);
    /**
     * @brief Tell the main window what the current audit name is
     * @param str The audit name
     *
     * The audit name is used as the default save filename
     */
    void setAuditName(QString str);
    void getAuditName(QLineEdit *edit);
    void puts(QString str);
    void setMatrixTable(MatrixTableModel<matrix_t> *model);
    void connectTableView(QTableView *view);

public slots:
    /**
     * @brief Enters "What's this?" mode
     */
    void on_actionWhat_s_this_triggered();
    /**
     * @brief Adds group placeholders to a line edit
     * @param str The text in the line edit
     *
     * Connect the QLineEdit::textChanged(QString) signal to this slot, or it won't ever be called; should work with
     * localization, but in right-to-left languages, the cursor may jump around some.  It casts the currently in-focus
     * widget to a QLineEdit pointer, then uses whatever QValidator is installed on it to fixup() the current text
     */
    void addCommasToInput(QString str);
    /**
     * @brief This function is called when the user clicks "okay"
     *
     * It's called by on_buttonBox_accepted(), and needs to be implemented in the inherited class
     */
    virtual void on_buttonBox_accepted_unsafe() = 0;
    /**
    * @brief This wraps the on_buttonBox_accepted_unsafe() function in an exception block
    *
    * Qt doesn't like exceptions (if you allow them to propagate up through Qt's callstack, it's
    * possible to crash the program)
    */
    virtual void on_buttonBox_accepted();


protected:
    /**
     * @brief A QIntValidator for restricting line edit input to valid positive values
     *
     * Call validator.setRange() to change the default behavior
     */
    QIntValidator *validator = NULL;
    /**
     * @brief A QIntValidator with it's minimum value set to the largest possible negative integer
     *
     * Call validator.setRange() to change the default behavior
     */
    QIntValidator *negValidator = NULL;
    /**
     * @brief A QDoubleValidator for restricting line edit input to valid double values
     *
     * Call validator.setRange() to change the default behavior
     */
    QDoubleValidator *dblValidator = NULL;
    /**
     * @brief The shortcut that enters "What's this?" mode
     */
    QShortcut *whatsThisShortcut = NULL;
};

#endif // STDIALOG_H
