/** \file dialogstratifiedvariableappraisal.h
 * @brief Dialog for the Stratified Variable Appraisal module (uses VariableAppraisal)
 */

#ifndef DIALOGSTRATIFIEDVARIABLEAPPRAISAL_H
#define DIALOGSTRATIFIEDVARIABLEAPPRAISAL_H

#include "keyoverride.h"
#include "matrix.h"
#include "matrixtablemodel.hpp"
#include "stdialog.h"


namespace Ui {
class DialogStratifiedVariableAppraisal;
}

/**
 * @brief Encapsulates the Stratified Variable Appraisal module
 */
class DialogStratifiedVariableAppraisal : public STDialog
{
    Q_OBJECT

public:
    explicit DialogStratifiedVariableAppraisal(QWidget *parent = 0, QString auditName = QString());
    ~DialogStratifiedVariableAppraisal();

    /**
     * @brief Generate a report for this module
     * @param mat The data matrix
     * @param report Where to insert the strings
     * @param universeSize The total population that the sampled data was drawn from
     * @param column_labels The label for each column of data in the data matrix
     *
     * Performs many of the calculations necessary for the Stratified Variable Appraisal module,
     * and generates a report for the results
     */
    void build_report(const matrix_t &mat, QStringList &report, int universeSize, QStringList column_labels);
    /**
     * @brief Inserts the summary at the top of the report
     * @param sums A matrix of the data sums, column for column
     * @param strata_matrix A matrix of the strata definitions
     * @param nonzero_items A matrix of the non-zero values from each column
     * @param report Where to insert the strings; also used as the return value
     * @param column_labels The labels given to the data columns
     * @param idx_to_insert The line number in the report where the summary should be inserted
     */
    void insert_summary(const matrix_t &sums, const matrix_t &strata_matrix, const matrix_t &nonzero_items, QStringList &report, QStringList &column_labels, int idx_to_insert);
    /**
     * @brief Insert the header in to a report (program name, audit name, etc.)
     * @param report Where to insert the strings
     * @param dataFileName The path to whatever file was used to load the data an analysis was performed on
     * @param strataFileName The path to whatever file was used to load the strata definitions for the analysis
     * @param idx The index (line no.) to insert the header at
     */
    void insert_header(QStringList &report, QString &dataFileName, QString &strataFileName, int idx = -1);
    void showTable(MatrixTableModel<matrix_t> *modelArg);

private slots:
    void on_pushButton_openDataFile_clicked();
    void on_pushButton_openStrataFile_clicked();
    void on_checkBox_enableStrataEditing_toggled(bool checked);
    void on_checkBox_enableDataEditing_toggled(bool checked);
    void on_checkBox_ignoreFirstDataColumn_toggled(bool checked);

private:
    Ui::DialogStratifiedVariableAppraisal *ui;
    QString strataFileName, dataFileName;
    void on_buttonBox_accepted_unsafe();
    void focusTableViewCell(int i, int j);
    KeyOverride *keyOverride = NULL;
    MatrixTableModel<matrix_t> *model = NULL;
};

#endif // DIALOGSTRATIFIEDVARIABLEAPPRAISAL_H
