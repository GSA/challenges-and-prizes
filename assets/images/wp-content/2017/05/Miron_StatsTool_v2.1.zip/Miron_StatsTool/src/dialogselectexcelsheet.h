/** \file dialogselectexcelsheet.h
 * @brief Dialog for previewing sheets when opening an Excel file
 */

#ifndef DIALOGSELECTEXCELSHEET_H
#define DIALOGSELECTEXCELSHEET_H

#include <QDialog>
#include <QtXlsx/QtXlsx>
#include "exceltablemodel.hpp"
#include <QHBoxLayout>
#include "keyoverride.h"


namespace Ui {
class DialogSelectExcelSheet;
}

/**
 * @brief A trivial class to allow the user to select a sheet within an Excel file
 */
class DialogSelectExcelSheet : public QDialog
{
    Q_OBJECT

public:
    explicit DialogSelectExcelSheet(QWidget *parent = 0);
    explicit DialogSelectExcelSheet(QXlsx::Document *doc, QWidget *parent = 0, bool *error_occurred = NULL);
    explicit DialogSelectExcelSheet(YExcel::BasicExcel *doc, QWidget *parent = 0, bool *error_occurred = NULL);
    ~DialogSelectExcelSheet();
    /**
     * @brief Add the names of the sheets in an Excel file so that they can be displayed in a combobox to the user
     * @param sheetNames The names of the sheets
     */
    void addSheetNames(QStringList sheetNames);
    /**
     * @brief Push a wait cursor before calling QDialog::exec(), and pop the cursor stack before returning
     * @return The return value of QDialog::exec()
     */
    int exec();
    void setExcelDocument(QXlsx::Document *doc);
    QXlsx::Document *getExcelDocument();
    ExcelTableModel *getModel();

public slots:
    void on_tabWidget_currentChanged(int index);
    void on_buttonBox_accepted();
    void setXlsSheetIndex();

signals:
    void activated(QString);

private:
    Ui::DialogSelectExcelSheet *ui;
    QXlsx::Document *qxlsx_doc = NULL;
    YExcel::BasicExcel *xls_doc = NULL;
    ExcelTableModel *model = NULL;
    KeyOverride *keyOverride = NULL;
    QStringList sheetNames;
    void on_tabWidget_currentIndexChanged(QString sheetName);
};

#endif // DIALOGSELECTEXCELSHEET_H
