/** \file stcli.h
 * @brief StatsTool Command Line Interface
 */
#ifndef CLI_H
#define CLI_H

#include <QtWidgets>
#include "attributeappraisal.h"
#include "dialogunrestrictedattributeappraisal.h"
#include "dialogsinglestagerandomnumbers.h"
#include "dialogunrestrictedvariableappraisal.h"
#include "dialogstratifiedvariableappraisal.h"
#include "dialogsamplesizebyestimatederror.h"

/**
 * @brief Provides a command line interface to the program's modules
 *
 * To get help information for the program, start it and pass the "-h" parameter on the command line;
 * or, for example, you can run the Single Stage Random Numbers module to generate 50 numbers and 0 spares
 * with a minimum value of 1, maximum value of 200, and a randomly generated seed with the following line:
 *
 * RATSTATS.exe -m ssrn 50 0 1 200 0
 *
 * Only modules that don't require input files are supported; the parameter to pass to the "-m" argument
 * is the acronym; and the order of the positional parameters matches the order of the input fields in the
 * GUI, from top to bottom (the order that TAB cycles through them), excluding the audit name.
 */
class STCLI : public QObject
{
    Q_OBJECT
public:
    explicit STCLI(QObject *parent, QCommandLineParser *parser);
    template <class T> bool call();

signals:
    void exec();

public slots:
    void printHtml(QString str);
    bool process();
    void quit();

private:
    QCommandLineParser *parser;
    QApplication *app;
};

#endif // CLI_H
