/*
 * All the logic for the program's main window is found here.  The
 * actual GUI design is found in the .ui file.
 *
 * The design is quite simple: encapsulate all the code as much as is
 * practical, so that even if one of the pieces ends up messy or
 * delicate in the future, it won't interfere with the rest of the
 * program.
 *
 * To accomplish that, modules get their data from the GUI windows,
 * then do whatever calculations they need to do, and execute the
 * appropriate callback provided by the main window (in this file here)
 * to display the results of their calculations.
 */

#include "statstool.h"
#include "ui_statstool.h"
#include "dialogsinglestagerandomnumbers.h"
#include "dialogunrestrictedattributeappraisal.h"
#include "ui_dialogsinglestagerandomnumbers.h"
#include "dialogunrestrictedvariableappraisal.h"
#include "ui_dialogunrestrictedvariableappraisal.h"
#include "dialogstratifiedvariableappraisal.h"
#include "ui_dialogstratifiedvariableappraisal.h"
#include "dialogselectexcelsheet.h"
#include "ui_dialogselectexcelsheet.h"
#include "dialogsamplesizebyattribute.h"
#include "ui_dialogsamplesizebyattribute.h"
#include "stdialog.h"
#include "dialogsamplesizebyestimatederror.h"
#include "ui_dialogsamplesizebyestimatederror.h"
#include <QMovie>
#include <QStyle>
#include <QDesktopWidget>
#include <QtPrintSupport/QPrinter>
#include <QtPrintSupport/QPrintDialog>
#include <QPainter>
#include <QShortcut>
#include "matrixtablemodel.hpp"
#include "st_macros.h"


#define SAVE_DIALOG_STATE true


StatsTool::StatsTool(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::StatsTool)
{
    ui->setupUi(this);

//    // center the program window
//    setGeometry( QStyle::alignedRect(Qt::LeftToRight,
//                                     Qt::AlignCenter,
//                                     size(),
//                                     qApp->desktop()->availableGeometry() )
//    );

    QShortcut(QKeySequence(tr("F1")), this, SLOT(on_actionWhat_s_this_triggered()));
    emit on_actionShow_splash_background_triggered();
    this->adjustSize();
    ui->textEdit_outputArea->document()->setDefaultStyleSheet(readFromFile("default.css"));
}

StatsTool::~StatsTool()
{
    delete ui;
    if (movie) delete movie;
    if (matrixTableModel) delete matrixTableModel;
    if (uaa_dialog) delete uaa_dialog;
    if (uva_dialog) delete uva_dialog;
    if (sva_dialog) delete sva_dialog;
    if (ssrn_dialog) delete ssrn_dialog;
    if (ssba_dialog) delete ssba_dialog;
    if (ssbee_dialog) delete ssbee_dialog;
}

void StatsTool::displayMovie(QString fileName)
{
    if (movie)
        delete movie;
    movie = new QMovie(fileName);
    ui->actionSave_Report_to_File->setDisabled(true);
    ui->actionPrint_report->setDisabled(true);
    ui->textEdit_outputArea->hide();
    ui->label_movie->setMovie(movie);
    ui->label_movie->show();
    ui->actionDecrease_report_size->setDisabled(true);
    ui->actionIncrease_report_size->setDisabled(true);
    ui->actionReset_report_size->setDisabled(true);
    movie->start();
}

void StatsTool::displayImage(QString file)
{
    ui->actionSave_Report_to_File->setDisabled(true);
    ui->actionPrint_report->setDisabled(true);
    ui->textEdit_outputArea->hide();
    ui->label_movie->setPixmap(QPixmap(file));
    ui->label_movie->show();
    ui->actionDecrease_report_size->setDisabled(true);
    ui->actionIncrease_report_size->setDisabled(true);
    ui->actionReset_report_size->setDisabled(true);
/*
    ui->textEdit_outputArea->setHtml(QString("<img src='%1'/>").arg(file));
    return;
    QUrl Uri ( QString ( "file://%1" ).arg ( file ) );
    QImage image = QImageReader ( file ).read();

    QTextDocument * textDocument = ui->textEdit_outputArea->document();
    textDocument->addResource( QTextDocument::ImageResource, Uri, QVariant ( image ) );
    QTextCursor cursor = ui->textEdit_outputArea->textCursor();
    QTextImageFormat imageFormat;
    imageFormat.setWidth( image.width() );
    imageFormat.setHeight( image.height() );
    imageFormat.setName( Uri.toString() );
    cursor.insertImage(imageFormat);
*/
}

void StatsTool::setupDisplayArea()
{
    ui->textEdit_outputArea->show();
    if (movie)
        ui->label_movie->movie()->stop();
    ui->label_movie->hide();
    ui->textEdit_outputArea->setEnabled(true);
    ui->actionSave_Report_to_File->setEnabled(true);
    ui->actionPrint_report->setEnabled(true);
    ui->actionDecrease_report_size->setEnabled(true);
    ui->actionIncrease_report_size->setEnabled(true);
    ui->actionReset_report_size->setEnabled(true);
}

void StatsTool::puts(QString str)
{
    if ( !ui->textEdit_outputArea->find(PROGRAM_TITLE) ) {
        displayHtml(str);
        return;
    }
    ui->textEdit_outputArea->append(str);
}

void StatsTool::setMatrixTable(MatrixTableModel<matrix_t> *model)
{
    if ( model )
        matrixTableModel = model;
}

void StatsTool::connectTableView(QTableView *view)
{
    if ( matrixTableModel && view ) {
        view->setModel(matrixTableModel);
        matrixTableModel->setView(view);
        matrixTableModel->updateView();
    }
}

void StatsTool::displayHtml(QString str)
{
    // if the module didn't explicitly set the audit name, try to pick it up from the report
    if (auditName.isEmpty()) {
        QRegExp audit_rx("(?:Audit|Review)[^:]*: ([A-z0-9\\-\\(\\) ]*)", Qt::CaseInsensitive);
        if (audit_rx.indexIn(str) > -1)
            auditName = audit_rx.cap(1);
    }
    // make sure we add the program header (note that the version is needed in case a bug in that version is found in the future)
    if ( !str.contains(PROGRAM_TITLE) ) {
        str.prepend(QString("<div class='program_header'><header><h2>%1</h2><p class='header'>%2 %3</p></header></div><hr width='90%'/>\n"));
        str = str.arg(PROGRAM_TITLE).arg(PROGRAM_SUBTITLE).arg(PROGRAM_VERSION_STRING);
    }
    str.replace("\n", "<br/>");
    ui->textEdit_outputArea->setHtml(str);
    setupDisplayArea();
}

void StatsTool::displayText(QString str)
{
    if (auditName.isEmpty()) {
        QRegExp audit_rx("(?:Audit|Review)[^:]*: ([A-z0-9\\-\\(\\) ]*)", Qt::CaseInsensitive);
        if (audit_rx.indexIn(str) > -1)
            auditName = audit_rx.cap(1);
    }
    if ( !str.contains(PROGRAM_TITLE) ) {
        str.prepend( QString("%1\n%2 %3").arg(PROGRAM_TITLE, 20).arg(PROGRAM_SUBTITLE, 20).arg(PROGRAM_VERSION_STRING) );
    }
    str.prepend("<pre>");
    str.append("</pre>");
    ui->textEdit_outputArea->setText(str);
    setupDisplayArea();
}

void StatsTool::setAuditName(QString str)
{
    auditName = str;
}

void StatsTool::getAuditName(QLineEdit *edit)
{
    edit->setText(auditName);
}

void StatsTool::buildModuleHeaderHtml(QStringList &report, QString moduleName, QString auditName, QString dataFile1, QString dataFile2, int64_t idx)
{
    report.insert(idx++, QString("<div class='module_header'><h3>%1</h3>").arg(moduleName));
    report.insert(idx++, QString("Audit: %1\n").arg(auditName));
    report.insert(idx++, QString("Date: %1\n").arg(QDateTime::currentDateTime().toString()));
    if ( !dataFile1.isNull() )
        report.insert(idx++, QString("Data file: %1\n").arg(dataFile1));
    if ( !dataFile2.isNull() )
        report.insert(idx++, QString("Strata file: %1").arg(dataFile2));
    report.insert(idx++, "</div>");
}

QString StatsTool::excelFileToPlainText(YExcel::BasicExcelWorksheet *sheet, MatrixTableModel<matrix_t> *model)
{
    QStringList ret;
    int64_t colCount = 0;
    int64_t rowCount = 0;
    int64_t maxRow = 0;
    int64_t maxCol = 0;
    bool ignored = false;

    if (!sheet) {
        ST_ERRORBOX("Failure reading the Excel worksheet.");
        return QString("");
    }
    if ( model )
        model->resizeStorage( sheet->GetTotalRows(), sheet->GetTotalCols() );
    maxRow = sheet->GetTotalRows();
    maxCol = sheet->GetTotalCols();

    for (int i = 0; i < maxRow; i++)
    {
        colCount = 0;

        for (int j = 0; j < maxCol; j++)
        {
            YExcel::BasicExcelCell *cell = sheet->Cell(i, j);
            QString buf;

            switch (cell->Type()) {
            case YExcel::BasicExcelCell::STRING:
                if ( model )
                    model->setData(model->index(i, j), cell->GetString());
                buf = QString::fromLocal8Bit(cell->GetString());
                buf = buf.remove(STRIP_REGEXP);
                buf = buf.split(SPLIT_REGEXP, QString::SkipEmptyParts).join("_");
                ret << QString::asprintf("%15s  ", buf.toStdString().c_str());
                break;
            case YExcel::BasicExcelCell::INT:
                if ( model )
                    model->setData(model->index(i, j), cell->GetInteger());
                ret << QString::asprintf("%'15lld  ", (long long int)cell->GetInteger());
                break;
            case YExcel::BasicExcelCell::DOUBLE:
                if ( model )
                    model->setData(model->index(i, j), cell->GetDouble());
                buf = QString::asprintf("%'15.3Lf", (long double)cell->GetDouble());
                buf.remove(QRegExp("\\.0+$"));
                ret << QString::asprintf("%15s  ", buf.toStdString().c_str());
                break;
            case YExcel::BasicExcelCell::UNDEFINED:
                int save_i = i;
                int save_j = j;
                if ( j == 0 ) {
                    while ( sheet->Cell(i, j)->Type() == YExcel::BasicExcelCell::UNDEFINED ) {
                        if ( ++j >= sheet->GetTotalCols() ) {
                            maxRow = rowCount;
                            ignored = true;
                            break;
                        }
                    }
                    j = save_j;
                }
                if ( i == 0 ) {
                    while ( sheet->Cell(i, j)->Type() == YExcel::BasicExcelCell::UNDEFINED ) {
                        if ( ++i >= sheet->GetTotalRows() ) {
                            maxCol = colCount;
                            ignored = true;
                            break;
                        }
                    }
                    i = save_i;
                }
                if ( model )
                    model->setData(model->index(i, j), QString(""));
                break;
            }
            colCount++;
        }
        rowCount++;
        ret << "\n";
    }
    if ( ignored ) {
    ST_ERRORBOX( tr("Data at the bottom of your spreadsheet has been ignored: the program only reads"
                    " the first contiguous block of cells, and ignores anything after the first blank"
                    " row or column.") );
    }
    if ( model )
        model->resizeStorage( maxRow, maxCol );//, colCount );
    return ret.join("");
}

QString StatsTool::excelFileToPlainText(QString &fileName, MatrixTableModel<matrix_t> *model)
{
    QMimeDatabase db;
    QMimeType type;

    QStringList sheetNames;
    YExcel::BasicExcel xls;
    int sheetnum = 0;

    type = db.mimeTypeForFile(fileName);
    if (QRegExp("spreadsheet").indexIn(type.name()) == -1) {
        if (!xls.Load(fileName.toStdString().c_str())) {
            ST_ERRORBOX(tr("Could not read file: %1").arg(fileName));
            return QString("");
        }
        if (xls.GetTotalWorkSheets() > 1) {
            bool error = false;
            DialogSelectExcelSheet dialog(&xls, 0, &error);
            if (error) {
                ST_ERRORBOX("The program was unable to read your file.");
                return QString();
            }
            sheetnum = dialog.exec();
        }
        YExcel::BasicExcelWorksheet *worksheet = xls.GetWorksheet(sheetnum);
        return excelFileToPlainText(worksheet, model);
    }

    QXlsx::Document excel(fileName);
    sheetNames = excel.sheetNames();

    if (sheetNames.size() > 1) {
        DialogSelectExcelSheet dialog(&excel);
        sheetnum = dialog.exec();
        excel.selectSheet(sheetNames.at(sheetnum));
    }
    return excelFileToPlainText(excel, model);
}

QString StatsTool::excelFileToPlainText(QXlsx::Document &excel, MatrixTableModel<matrix_t> *model)
{
    QString ret;
    QXlsx::CellRange cellRange = excel.dimension();
    QXlsx::Cell *cell;
    int64_t rowCount = 0;
    int64_t colCount = 0;
    int64_t maxCol = cellRange.columnCount();
    int64_t maxRow = cellRange.rowCount();

    if ( model ) {
        ExcelTableModel excelModel(&excel);
        model->resizeStorage( cellRange.rowCount(), cellRange.columnCount());
        for (int i = 0; excelModel.data(excelModel.index(i, 0)) != QVariant(); i++)
        {
            colCount = 0;
             for (int j = 0; excelModel.data(excelModel.index(i, j)) != QVariant(); j++)
             {
                 colCount++;
                 model->setData(model->index(i, j), excelModel.data(excelModel.index(i, j)));
             }
             rowCount++;
        }
        model->resizeStorage(rowCount, colCount);
//        return "";
    }

//    if ( model )
//        model->resizeStorage( cellRange.rowCount(), cellRange.columnCount());
    for (int i = 1; i <= cellRange.rowCount(); i++)
    {
        if ( (cell = excel.cellAt(i, 1)) == 0 )
            continue;
        QString row;
        colCount = 0;

        for (int j = 1; j <= cellRange.columnCount(); j++)
        {
//            if ( model )
//                if ( !model->getMatrix().inRange(i - 1, j - 1) )
//                    break;
            if ( excel.cellAt(1, j) == 0 ) {
//                if ( model )
//                    model->setData( model->index(i - 1, j - 1), QString("") );
                continue;
            }
            colCount++;
            cell = excel.cellAt(i, j);
            if ( cell == 0 && j == 1 ) {
                int save_j = j;
                while ( cell == 0 ) {
                    if ( model )
                        model->setData( model->index(i - 1, j - 1), QString("") );
                    cell = excel.cellAt(i, ++j);
                    if ( j >= cellRange.columnCount() ) {
                        maxRow = rowCount;
                        break;
                    }
                }
//                j = save_j;
//                continue;
//                break;
            }
            if ( cell == 0 && i == 1 ) {
                int save_i = i;
                while ( cell == 0 ) {
                    if ( model )
                        model->setData( model->index(i - 1, j - 1), QString("") );
                    cell = excel.cellAt(++i, j);
                    if ( i >= cellRange.rowCount() ) {
                        maxCol = colCount;
                        break;
                    }
                }
//                i = save_i;
//                continue;
//                break;
            }
            if ( cell == 0 ) {
                if ( model )
                    model->setData( model->index(i - 1, j - 1), QString("") );
                continue;
            }
//            break;
//            continue;
//                if ( j == 1 )
//                continue;
//                break;
//            }

            QString buf;
            switch(cell->cellType()) {
            case QXlsx::Cell::NumberType:
                if ( model ) {
//                    if ( cell->value().isNull() )
//                        model->setData( model->index(i - 1, j - 1), QString(""));
//                    else
                        model->setData( model->index(i - 1, j - 1), cell->value().toDouble() );
                }
                buf = QString::asprintf("%'15.3Lf", (long double)cell->value().toDouble());
                buf.remove(QRegExp("\\.0+$"));
                buf = QString::asprintf("%15s  ", buf.toStdString().c_str());
                row.append(buf);
                break;
            case QXlsx::Cell::StringType:
            case QXlsx::Cell::SharedStringType:
            case QXlsx::Cell::InlineStringType:
                if ( model ) {
//                    if ( cell->value().isNull() )
//                        model->setData( model->index(i - 1, j - 1), QString(""));
//                    else
                        model->setData( model->index(i - 1, j - 1), cell->value() );
                }
                row.append(QString::asprintf("%15s  ", cell->value().toString().split(QRegExp("\t| "), QString::SkipEmptyParts).join("_").toStdString().c_str()));
                break;
            default:
                if ( model )
                    model->setData( model->index(i - 1, j - 1), QString("") );
                break;
            }
        }
        ret.append(row + "\n");
        rowCount++;
    }
    if (cellRange.rowCount() > rowCount) {
        ST_ERRORBOX( tr("Data at the bottom of your spreadsheet has been ignored: the program only reads"
                        " the first contiguous block of cells, and ignores anything after the first blank"
                        " row or column.") );
    }
//    qDebug("count: %d,%d  range: %d,%d", rowCount, colCount, cellRange.rowCount(), cellRange.columnCount());
//    if ( model )
//        model->resizeStorage( std::min(maxRow, rowCount), std::min(maxCol, colCount) );
    return ret;
}

QString StatsTool::readFromFile(QString inputFileName, MatrixTableModel<matrix_t> *model)
{
    QMimeDatabase db;
    QMimeType type;
    QString plainText;

    if (inputFileName.isEmpty())
        return "";

    QApplication::setOverrideCursor(Qt::WaitCursor);
    type = db.mimeTypeForFile(inputFileName);
    if (QRegExp("spreadsheet|excel", Qt::CaseInsensitive).indexIn(type.name()) > -1) {
        plainText = excelFileToPlainText(inputFileName, model);
        if ( model )
            plainText = QString();
    } else {
        QFile inputfile(inputFileName);
        if (!inputfile.open(QIODevice::ReadOnly | QIODevice::Text)) {
            ST_ERRORBOX( tr("Error opening file: %1").arg(inputFileName) );
            QApplication::restoreOverrideCursor();
            return "";
        }
        QTextStream in(&inputfile);
        plainText = in.readAll();
        inputfile.close();
    }
    QApplication::restoreOverrideCursor();
    return plainText;
}

QString StatsTool::readFromFile()
{
    QString inputFileName = QFileDialog::getOpenFileName(NULL, tr("Input File"), "", tr("*.txt *.xlsx *.xls"));
    return readFromFile(inputFileName);
}

long double StatsTool::ratstats_kurtosis(const matrix_t &matrix, int column, long double mean)
{
    matrix_t_view matView;

    matView.reference(matrix);
    return ratstats_kurtosis(matView, column, mean);
}

long double StatsTool::ratstats_skewness(const matrix_t &matrix, int column, long double mean)
{
    matrix_t_view matView;

    matView.reference(matrix);
    return ratstats_skewness(matView, column, mean);
}

long double StatsTool::ratstats_kurtosis(const matrix_t_view &matrix, int column, long double mean)
{
    double x = 0, x_bar = mean, numerator = 0, denominator = 0;
    uint n = matrix.rows();

    for (uint i = 0; i < n; i++)
    {
        x = matrix(i, column);
        numerator += powl((x - x_bar), 4);
        denominator += powl((x - x_bar), 2);
    }
    numerator /= n;
    denominator /= n;
    denominator = powl(denominator, 2);
    return numerator / denominator;
}

long double StatsTool::ratstats_skewness(const matrix_t_view &matrix, int column, long double mean)
{
    long double x = 0, x_bar = mean, numerator = 0, denominator = 0;
    uint n = matrix.rows();

    for (uint i = 0; i < n; i++)
    {
        x = matrix(i, column);
        numerator += powl((x - x_bar), 3);
        denominator += powl((x - x_bar), 2);
    }
    numerator /= n;
    denominator /= n;
    denominator = powl(denominator, 3/2.0);
    return numerator / denominator;
}

void StatsTool::dumpToExcelFile(QString filename, QString html)
{
    QRegExp rx("<pre[^>]*>(.*)</.?pre>", Qt::CaseInsensitive);
    QString data;
    QXlsx::Document doc;

    if (rx.indexIn(html) == -1) {
        ST_ERRORBOX("This specific report does not provide enough information to format an Excel file properly.");
        return;
    }

    data = rx.cap(1);
    int x = 1, y = 1;
    foreach(QString line, data.split(QRegExp("\r?\n|</?.?br.?/?>"), QString::SkipEmptyParts))
    {
        foreach(QString cell, line.remove(QRegExp("<[^>]+>")).split(SPLIT_REGEXP, QString::SkipEmptyParts))
        {
            if (QRegExp("[^,\\-\\.0-9]+").indexIn(cell) > -1)
                doc.write(x, y++, cell);
            else if (QRegExp("[0-9]*\\.[0-9]+").indexIn(cell) > -1) {
                cell.remove(tr(","));
                doc.write(x, y++, cell.toDouble());
            }
            else
                doc.write(x, y++, cell.toLongLong());
        }
        x++;
        y = 1;
    }

    if (doc.saveAs(filename)) {
        ST_ERRORBOX(QString("Saved to %1").arg(filename));
    } else {
        ST_ERRORBOX("An error occurred while saving the file.");
    }
}

void StatsTool::saveToExcelFile(QString filename, QString text)
{
    dumpToExcelFile(filename, QString("<pre>%1</pre>").arg(text));
}

void StatsTool::on_actionSave_Report_to_File_triggered()
{
    QMimeDatabase db;
    QMimeType type;
    QString filename = QFileDialog::getSaveFileName( this,
                                                     tr("Select Output File"),
                                                     auditName.isEmpty() ? "" : auditName + tr(".html"),
                                                     tr("*.txt *.html *.xlsx") );
    if (filename.isEmpty())
        return;

    type = db.mimeTypeForFile(filename);
    QApplication::setOverrideCursor(Qt::WaitCursor);
    // dump to Excel format
    if (QRegExp("excel|spreadsheet", Qt::CaseInsensitive).indexIn(type.name()) > -1) {
        saveToExcelFile(filename, ui->textEdit_outputArea->toPlainText());
        QApplication::restoreOverrideCursor();
        return;
    }

    // write to text or html format
    QFile file(filename);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        ST_ERRORBOX("Error opening file.");
        QApplication::restoreOverrideCursor();
        return;
    }
    QTextStream out(&file);

    qDebug() << type.name();
    if ( QRegExp("html", Qt::CaseInsensitive).indexIn(type.name()) > -1 ) {
        out << ui->textEdit_outputArea->document()->toHtml("UTF-8");
    } else {
        QRegExp rx("<table");
        if ( rx.indexIn(ui->textEdit_outputArea->document()->toHtml()) == -1 ) {
            out << ui->textEdit_outputArea->toPlainText();
        } else {
            // preserve some formatting of HTML tables
            QTextBlock block = ui->textEdit_outputArea->document()->begin();
            QTextTable *table;
            QTextCursor cursor(block);
            QTextCursor saveCursor = cursor;
            int span = 22;
            while ( !cursor.atEnd() && cursor.block().isValid() )
            {
                table = cursor.currentTable();
                if ( table == NULL ) {
                    out << QString(cursor.block().text().replace(QChar(0x2028), QString("\n")));
                } else {
                    // if a cell spans multiple rows or columns, firstCursorPosition() will
                    // return the first position for the span, not the cell
                    for (int i = 0; i < table->rows(); i++)
                    {
                        for (int j = 0; j < table->columns(); j++)
                        {
                            if ( j > 0 && table->cellAt(i, j).firstCursorPosition() == cursor )
                                continue;
                            cursor = table->cellAt(i, j).firstCursorPosition();
                            QString buf = QString("%1").arg(cursor.block().text(), span * table->cellAt(i, j).columnSpan());
                            buf.replace(QChar(0x2028), QString("\n"));
                            out << buf;
                        }
                        out << "\n";
                    }
                    out << "\n";
                }
                out << "\n";
                saveCursor = cursor;
                cursor.movePosition(QTextCursor::NextBlock);
                if ( cursor == saveCursor )
                    break;
            }
        }
    }
    file.close();

    ST_ERRORBOX("Saved to " + filename);
    QApplication::restoreOverrideCursor();
}

QString StatsTool::htmlToPlainText(QString html)
{
    QTextBrowser *textBrowser = new QTextBrowser();
    QString buf;
    QTextStream out(&buf);

    textBrowser->setHtml(html);
    QRegExp rx("<table");
    if ( rx.indexIn(textBrowser->document()->toHtml()) == -1 ) {
        out << textBrowser->toPlainText();
    } else {
        // preserve some formatting of HTML tables
        QTextBlock block = textBrowser->document()->begin();
        QTextTable *table;
        QTextCursor cursor(block);
        QTextCursor saveCursor = cursor;
        int span = 22;
        while ( !cursor.atEnd() && cursor.block().isValid() )
        {
            table = cursor.currentTable();
            if ( table == NULL ) {
                out << QString(cursor.block().text().replace(QChar(0x2028), QString("\n")));
            } else {
                // if a cell spans multiple rows or columns, firstCursorPosition() will
                // return the first position for the span, not the cell
                for (int i = 0; i < table->rows(); i++)
                {
                    for (int j = 0; j < table->columns(); j++)
                    {
                        if ( j > 0 && table->cellAt(i, j).firstCursorPosition() == cursor )
                            continue;
                        cursor = table->cellAt(i, j).firstCursorPosition();
                        QString buf = QString("%1").arg(cursor.block().text(), span * table->cellAt(i, j).columnSpan());
                        buf.replace(QChar(0x2028), QString("\n"));
                        out << buf;
                    }
                    out << "\n";
                }
                out << "\n";
            }
            out << "\n";
            saveCursor = cursor;
            cursor.movePosition(QTextCursor::NextBlock);
            if ( cursor == saveCursor )
                break;
        }
    }
    delete textBrowser;
    return buf;
}

bool StatsTool::confirmationBox(QString message)
{
    QMessageBox mbox;
    mbox.setStandardButtons(QMessageBox::Ok | QMessageBox::Cancel);
    mbox.setText(message);

    return (mbox.exec() == QMessageBox::Ok);
}

void StatsTool::on_actionAbout_triggered()
{
    QMessageBox::about(this, PROGRAM_TITLE,
                       PROGRAM_STRING_FULL + tr(", by Murray Miron.\n\n"
                       "Written for the Department of Health and Human Services within the U.S. Office of Inspector General."
                       "  Thanks to Jared Smith, PhD (Office of Audit Services) for his assistance.\n\n"
                       "Prior versions credited to Janet Fowler, PhD (Office of Audit Services) and Al Kvanli, PhD (Associate Professor,"
                       " University of North Texas.)\n\n"
                       "This program uses the C++ STL, Qt, QtXlsx, BasicExcel, Scythe, and Boost.  Applicable license files can "
                       "be found in the program folder on your hard drive.\n\n"
                       "Program icon made with GIMP."));
}

void StatsTool::on_actionHelp_triggered()
{
    ST_ERRORBOX(tr("Hit F1 at any time to switch to \"What's this?\" mode, which allows you to click on most parts of the program"
                   " and get help about what you clicked on.\n\n"
                   "You can also skip clicking with the mouse and get the same information for whatever the current program focus"
                   " is (e.g. the text box a cursor is blinking in) by hitting SHIFT+F1.\n\n"
                   "Note that many menubar entries also provide help information."));
}

void StatsTool::on_actionShow_splash_background_triggered()
{
    ui->textEdit_outputArea->clear();
    displayImage(":/images/OIG.jpg");
//    displayMovie(":/images/splash");
}

void StatsTool::on_actionWhat_s_this_triggered()
{
    QWhatsThis::enterWhatsThisMode();
}

void StatsTool::on_actionQuit_triggered()
{
    exit(EXIT_SUCCESS);
}

void StatsTool::on_actionPrint_report_triggered()
{
    QPrinter printer;
    QPrintDialog dialog(&printer, this);

    dialog.setWindowTitle(tr("Print report"));
    if (dialog.exec() != QDialog::Accepted)
        return;

    ui->textEdit_outputArea->print(&printer);
    ST_ERRORBOX("The print job has been submitted.");
}

void StatsTool::on_actionIncrease_report_size_triggered()
{
    ui->textEdit_outputArea->zoomIn();
    zoomLevel++;
}

void StatsTool::on_actionDecrease_report_size_triggered()
{
    ui->textEdit_outputArea->zoomOut();
    zoomLevel--;
}

void StatsTool::on_actionReset_report_size_triggered()
{
    ui->textEdit_outputArea->zoomOut(zoomLevel);
    zoomLevel = 0;
}

void StatsTool::on_actionOpen_report_triggered()
{
    QMimeDatabase db;
    QString inputFileName = QFileDialog::getOpenFileName(NULL, tr("Input File"), "", tr("*.txt *.html *.xlsx *.xls"));

    if ( inputFileName.isEmpty() )
        return;
    QApplication::setOverrideCursor(Qt::WaitCursor);

    QString contents = readFromFile(inputFileName);
    setupDisplayArea();
    ui->textEdit_outputArea->clear();
    qDebug() << db.mimeTypeForFile(inputFileName).name();
    if ( db.mimeTypeForFile(inputFileName).name() == "text/html" )
        ui->textEdit_outputArea->setHtml(contents);
    else
        ui->textEdit_outputArea->setHtml("<pre>" + contents + "</pre>");

    QApplication::restoreOverrideCursor();
}

void StatsTool::on_actionBy_expected_error_rate_triggered()
{
    if ( !ssbee_dialog ) {
        ssbee_dialog = new DialogSampleSizeByEstimatedError(this, auditName);
        CONNECT_DIALOG(ssbee_dialog);
    }
    ssbee_dialog->exec();
    CLEANUP_DIALOG(ssbee_dialog);
}

void StatsTool::on_actionSingle_Stage_Random_Number_triggered()
{
    if (!ssrn_dialog) {
        ssrn_dialog = new DialogSingleStageRandomNumbers(this, auditName);
        CONNECT_DIALOG(ssrn_dialog);
    }
    ssrn_dialog->exec();
    CLEANUP_DIALOG(ssrn_dialog);
}

void StatsTool::on_actionUnrestricted_Attribute_Appraisal_triggered()
{
    if (!uaa_dialog) {
        uaa_dialog = new DialogUnrestrictedAttributeAppraisal(this, auditName);
        CONNECT_DIALOG(uaa_dialog);
    }
    uaa_dialog->exec();
    CLEANUP_DIALOG(uaa_dialog);
}

void StatsTool::on_actionStratified_Variable_Appraisal_triggered()
{
    if (!sva_dialog) {
        sva_dialog = new DialogStratifiedVariableAppraisal(this, auditName);
        CONNECT_DIALOG(sva_dialog);
    }
    if ( matrixTableModel )
        sva_dialog->showTable(matrixTableModel);
    sva_dialog->exec();
    CLEANUP_DIALOG(sva_dialog);
}

void StatsTool::on_actionUnrestricted_Variable_Appraisal_triggered()
{
    if (!uva_dialog) {
        uva_dialog = new DialogUnrestrictedVariableAppraisal(this, auditName);
        CONNECT_DIALOG(uva_dialog);
    }
    if ( matrixTableModel )
        uva_dialog->showTable(matrixTableModel);
    uva_dialog->exec();
    CLEANUP_DIALOG(uva_dialog);
}

void StatsTool::on_actionBy_attribute_triggered()
{
    if (!ssba_dialog) {
        ssba_dialog = new DialogSampleSizeByAttribute(this, auditName);
        CONNECT_DIALOG(ssba_dialog);
    }
    ssba_dialog->exec();
    CLEANUP_DIALOG(ssba_dialog);
}
