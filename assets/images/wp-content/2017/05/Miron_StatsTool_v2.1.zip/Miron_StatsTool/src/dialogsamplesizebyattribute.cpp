#include "dialogsamplesizebyattribute.h"
#include "ui_dialogsamplesizebyattribute.h"
#include "attributeappraisal.h"
#include "statstool.h"
#include "stdialog.h"


DialogSampleSizeByAttribute::DialogSampleSizeByAttribute(QWidget *parent, QString auditName) :
    STDialog(parent),
    ui(new Ui::DialogSampleSizeByAttribute)
{
    ui->setupUi(this);
    dblValidator->setRange(0, 1, 3);

    ui->lineEdit_errorRate->setValidator(validator);
    ui->lineEdit_universeSize->setValidator(validator);
    ui->lineEdit_precision->setValidator(validator);

    connect(ui->lineEdit_errorRate, SIGNAL(textChanged(QString)), this, SLOT(addCommasToInput(QString)));
    connect(ui->lineEdit_universeSize, SIGNAL(textChanged(QString)), this, SLOT(addCommasToInput(QString)));
    connect(ui->lineEdit_precision, SIGNAL(textChanged(QString)), this, SLOT(addCommasToInput(QString)));
}

DialogSampleSizeByAttribute::~DialogSampleSizeByAttribute()
{
    delete ui;
}

void DialogSampleSizeByAttribute::on_buttonBox_accepted_unsafe()
{
    uint N = ui->lineEdit_universeSize->text().remove(tr(",")).toInt();
    double precision = ui->lineEdit_precision->text().remove(tr(",")).toInt() / 100.0;
    double errorRate = ui->lineEdit_errorRate->text().remove(tr(",")).toInt() / 100.0;
    QStringList report;

    calculate(report, errorRate, N, precision);
    emit displayHtml(report.join("\n"));
    this->reject();
}

void DialogSampleSizeByAttribute::calculate(QStringList &report, double error_rate, uint N, double precision)
{
    AttributeAppraisal attApp;

    if ( error_rate == 0 || N == 0 || precision == 0 )
        throw std::exception();

    attApp.sampleSizeByAttribute(error_rate, N, precision, &report);
    return;
}
