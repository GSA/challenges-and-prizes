#include "statstool.h"
#include <QApplication>
#include "stcli.h"

/*
 * Program entry point (technically there are many other places where the program enters,
 * but all of that is just generic setup.)  From here, we create a StatsTool object
 * (inherits from QMainWindow), and execute it, which kicks off the entire application.
 */
int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    StatsTool w;
    QCommandLineParser parser;
    STCLI cli(&app, &parser);
    QTranslator qtTranslator;
    QTranslator statstoolTranslator;

    QCoreApplication::setApplicationName(PROGRAM_TITLE);
    QCoreApplication::setApplicationVersion(PROGRAM_VERSION_STRING);

    // localization
    qtTranslator.load("qt_" + QLocale::system().name(),
            QLibraryInfo::location(QLibraryInfo::TranslationsPath));
    app.installTranslator(&qtTranslator);

    statstoolTranslator.load("statstool_" + QLocale::system().name());
    app.installTranslator(&statstoolTranslator);

    parser.setApplicationDescription( PROGRAM_STRING_FULL + " (command line interface)" );
    parser.addHelpOption();
    parser.addVersionOption();
    if ( cli.process() )
        return 0;

    w.setWindowIcon(QIcon(":/icons/icon.xpm"));
    w.setWindowTitle(PROGRAM_TITLE);
    w.show();
    return app.exec();
}
