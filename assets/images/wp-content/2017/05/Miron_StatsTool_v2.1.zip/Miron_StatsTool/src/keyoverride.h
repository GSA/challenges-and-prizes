/** \file keyoverride.h
 * @brief A class to prevent keypress events from reaching objects
 */
#ifndef KEYOVERRIDE_H
#define KEYOVERRIDE_H

#include <QObject>
#include <QDialog>

/**
 * @brief This event filter prevents objects from receiving key events
 *
 * It's used here or there to change the behavior of keystrokes when specific objects
 * are the current program focus (e.g. blocking "escape" closing a dialog); the key
 * event will propagate up if ignored.
 */
class KeyOverride : public QObject
{
    Q_OBJECT

public:
    /**
     * @brief Construct a KeyOverride with no overridden keys
     * @param parent The owning object
     */
    explicit KeyOverride(QObject *parent = 0);
    /**
     * @brief Construct a KeyOverride with a single key overridden / ignored
     * @param parent The owning object
     * @param key The Qt::Key to ignore (e.g. Qt::Key_Tab)
     */
    KeyOverride(QObject *parent, Qt::Key key);
    /**
     * @brief Construct a KeyOverride with two keys overridden / ignored
     * @param parent The owning object
     * @param key1 The first Qt::Key to ignore (e.g. Qt::Key_Tab)
     * @param key2 The second Qt::Key to ignore (e.g. Qt::Key_Return)
     */
    KeyOverride(QObject *parent, Qt::Key key1, Qt::Key key2);
    /**
     * @brief Add a key that objects this filter is installed on should ignore
     * @param key The Qt::Key to ignore
     * @param idx Where in the stack of this object's ignored keys to insert the new one
     *
     * The order of the ignored keys doesn't matter, unless you're applying modifiers to them.
     */
    void addFilteredKey(Qt::Key key, int idx = -1);
    /**
     * @brief Add a modifier (e.g. the alt key) to an ignored key
     * @param mod The modifier to add to the key event
     * @param idx The index of the ignored key the modifier should apply to
     *
     * The key events that Qt passes around aren't always what you'd expect; for example,
     * SHIFT+TAB is a unique key value that doesn't seem to include the SHIFT key modifier.
     */
    void addModifier(Qt::KeyboardModifier mod, int idx = -1);
    /**
     * @brief The value corresponding to a SHIFT+TAB keystroke
     */
    static const Qt::Key Key_Shift_Tab = (Qt::Key)(16777218);


protected:
    bool eventFilter(QObject *obj, QEvent *event);

signals:
    void keyPressEvent(QKeyEvent *keyEvent);

private:
    QVector<Qt::Key> filteredKeys;
    QVector<Qt::KeyboardModifier> modifiers;
};

#endif // KEYOVERRIDE_H
