/*
 * All the code that implements the logic for the Unrestricted
 * Variable Appraisal is found in this file; as is the case elsewhere
 * however, the actual GUI design is in the corresponding .ui file.
 */

#include "dialogunrestrictedvariableappraisal.h"
#include "ui_dialogunrestrictedvariableappraisal.h"
#include "keyoverride.h"
#include "variableappraisal.h"
#include "matrixtablemodel.hpp"
#include <QScrollBar>
#include "statstool.h"
#include "st_macros.h"

DialogUnrestrictedVariableAppraisal::DialogUnrestrictedVariableAppraisal(QWidget *parent, QString auditName) :
    STDialog(parent),
    ui(new Ui::DialogUnrestrictedVariableAppraisal)
{
    ui->setupUi(this);
    validator = new QIntValidator(0, INT_MAX, this);
    tabOverride = new KeyOverride( this, Qt::Key_Tab, KeyOverride::Key_Shift_Tab );
    model = new MatrixTableModel<matrix_t>(ui->tableView);

    // we need to override the "dropEvent()" function of the text edit, so by disabling it
    // in that object, it propagates up to us (where we implement it below)
    ui->plainTextEdit->setAcceptDrops(false);
    ui->tableView->setAcceptDrops(false);
    setAcceptDrops(true);

//    ui->checkBox_ignoreFirstRow->hide();
    ui->plainTextEdit->installEventFilter(tabOverride);
    ui->tableView->installEventFilter(tabOverride);

    ui->lineEdit_universeSize->setValidator(validator);
    ui->lineEdit_auditName->setFocus();
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableView->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    ui->lineEdit_auditName->setText(auditName);
    ui->lineEdit_auditName->setFocus();

    connect(ui->lineEdit_universeSize, SIGNAL(textEdited(QString)), this, SLOT(addCommasToInput(QString)));
    connect(ui->comboBox_dataContains, SIGNAL(currentIndexChanged(int)), this, SLOT(setColumnHeaders(int)));

//    connect(model, SIGNAL(dataChanged(QModelIndex, QModelIndex)), ui->tableView, SLOT(resizeColumnsToContents()));
//    connect(model, SIGNAL(dataChanged(QModelIndex, QModelIndex)), ui->tableView, SLOT(resizeRowsToContents()));

#ifndef UNRESTRICTED_VARIABLE_APPRAISAL_USES_QPLAINTEXT
    ui->plainTextEdit->hide();
//    emit connectTableView(ui->tableView);
    ui->tableView->show();
#else
    ui->plainTextEdit->show();
    ui->tableView->hide();
    ui->checkBox_ignoreFirstRow->show();
#endif
//    ui->tableView->setModel(model);
}

DialogUnrestrictedVariableAppraisal::~DialogUnrestrictedVariableAppraisal()
{
    delete ui;
    delete tabOverride;
}

MatrixTableModel<matrix_t> *DialogUnrestrictedVariableAppraisal::getModel()
{
    return model;
}

void DialogUnrestrictedVariableAppraisal::showTable(MatrixTableModel<matrix_t> *modelArg)
{
    if ( !modelArg )
        return;

    model = modelArg;
    model->setView(ui->tableView);
    ui->tableView->setModel(model);
    ui->tableView->show();
    ui->tableView->horizontalHeader()->show();

    if ( modelArg->isColumnDisabled(0) )
        ui->checkBox_ignoreFirstColumn->setChecked(true);
    else
        ui->checkBox_ignoreFirstColumn->setChecked(false);

    if ( model->getHeaders().size() == 0 )
        setComboboxByHeaders(model->getFirstRow().join(" "));
    else
        setComboboxByHeaders(model->getHeaders().join(" "));
    ui->comboBox_dataContains->currentIndexChanged(ui->comboBox_dataContains->currentIndex());
    if ( modelArg->isRowDisabled(0) )
        ui->checkBox_ignoreFirstRow->setChecked(true);
    else
        ui->checkBox_ignoreFirstRow->setChecked(false);
    if ( QRegExp("[A-z]+").indexIn(model->getFirstRow().join(" ")) > -1 )
        ui->checkBox_ignoreFirstRow->setChecked(true);
    model->updateView();
//    emit connectTableView(ui->tableView);
//    model->setView(ui->tableView);
//    model->updateView();
//    model = modelArg;
//    ui->tableView->setModel(model);

//    if ( model->isColumnDisabled(0) )
//         ui->checkBox_ignoreFirstColumn->setChecked(true);
//    else
//        ui->checkBox_ignoreFirstColumn->setChecked(false);
//    model->setView(ui->tableView);
//    modelArg->enableAllRows();
//    modelArg->enableAllColumns();
//    ui->checkBox_ignoreFirstColumn->setChecked(false);
//    textToMatrix(modelArg->toString());
//    emit setMatrixTable(model);
}

void DialogUnrestrictedVariableAppraisal::focusTableViewCell(int i, int j)
{
    QItemSelectionModel::SelectionFlags flags = QItemSelectionModel::ClearAndSelect;
    QModelIndex index = model->index(i, j);

    ui->tableView->selectionModel()->select(index, flags);
    return;
}

void DialogUnrestrictedVariableAppraisal::setComboboxByHeaders(QString tokens)
{
    QStringList headers;
    QRegExp rx("(examined|audited|difference)", Qt::CaseInsensitive);
    if ( rx.indexIn(tokens) > 0 ) {
        ui->checkBox_ignoreFirstColumn->setChecked(true);
    }
    while ( rx.indexIn(tokens) > -1 ) {
        for (int i = 0; i < rx.captureCount(); i++) {
            headers << rx.cap(i).toUpper();
            tokens.remove(rx.cap(i));
        }
    }
    if ( headers.size() > 1 ) {
        if ( headers.at(0) == "EXAMINED" && headers.at(1) == "AUDITED" )
            ui->comboBox_dataContains->setCurrentIndex(3);
        else if ( headers.at(0) == "EXAMINED" && headers.at(1) == "DIFFERENCE" )
            ui->comboBox_dataContains->setCurrentIndex(4);
        else if ( headers.at(0) == "AUDITED" && headers.at(1) == "DIFFERENCE" )
            ui->comboBox_dataContains->setCurrentIndex(5);
    } else if ( headers.size() == 1 ) {
        if ( headers.at(0) == "EXAMINED" )
            ui->comboBox_dataContains->setCurrentIndex(0);
        else if ( headers.at(0) == "AUDITED" )
            ui->comboBox_dataContains->setCurrentIndex(1);
        else if ( headers.at(0) == "DIFFERENCE" )
            ui->comboBox_dataContains->setCurrentIndex(2);
    } else {
        ui->comboBox_dataContains->setCurrentIndex(0);
    }
}

void DialogUnrestrictedVariableAppraisal::textToMatrix(QString arg)
{
    if ( arg.isEmpty() )
        return;
    QString text = arg;
    QStringList list = text.split(QRegExp("\r?\n"), QString::SkipEmptyParts);

    if (list.size() < 1)
        return;
//    if ( model )
//        delete model;
    if ( !model )
        model = new MatrixTableModel<matrix_t>(ui->tableView);
    model->clearStrings();
    // parse the first line/row for possible column titles
//    QStringList tokens = list.at(0).split(SPLIT_REGEXP, QString::SkipEmptyParts);
    QString tokens = list.at(0);
    setComboboxByHeaders(tokens);
    text = list.join("\n");

    // convert the text to a matrix
    model->stringToMatrix(text, false, false);//, ui->checkBox_ignoreFirstRow->isChecked(), ui->checkBox_ignoreFirstColumn->isChecked());
    setupTableView();
//    for (int i = 0; i < headers.size(); i++) {
//        QVariant var(headers.at(i));
//        model->setHeaderData(i, Qt::Horizontal, var);
//    }
    ui->comboBox_dataContains->currentIndexChanged(ui->comboBox_dataContains->currentIndex());

    if ( !ui->checkBox_ignoreFirstColumn->isChecked() ) {
        if ( model->columnCount() > 1 && model->getHeaders().size() != model->columnCount() )
            ui->checkBox_ignoreFirstColumn->setChecked(true);
        else
            ui->checkBox_ignoreFirstColumn->setChecked(false);
    }
//    if ( QRegExp("[A-z]+").indexIn(list.at(0)) > -1 )
//        ui->checkBox_ignoreFirstRow->setChecked(true);

//    // update "ignore column" checkbox if we think it's what the user intends
//    if ( model->columnCount() > 2 &&  )
//        ui->checkBox_ignoreFirstColumn->setChecked(true);
//    else
//        ui->checkBox_ignoreFirstColumn->setChecked(false);
}

// this is called when something is dragged into our area: we need to say we want to accept the drop
void DialogUnrestrictedVariableAppraisal::dragEnterEvent(QDragEnterEvent *event)
{
    if (event->mimeData()->hasFormat("text/uri-list"))
        event->acceptProposedAction();
}

// called when something is actually dropped on us
void DialogUnrestrictedVariableAppraisal::dropEvent(QDropEvent *event)
{
    if (event->mimeData()->urls().isEmpty())
        return;

    inputFileName = event->mimeData()->urls().first().toLocalFile();
    ui->plainTextEdit->document()->setPlainText( StatsTool::readFromFile(inputFileName) );
    textToMatrix(ui->plainTextEdit->document()->toPlainText());
}

void DialogUnrestrictedVariableAppraisal::setupTableView()
{
    ui->tableView->setModel(model);
    ui->tableView->show();
    ui->plainTextEdit->hide();
}

void DialogUnrestrictedVariableAppraisal::on_pushButton_chooseInputFile_clicked()
{
    QString data;
    inputFileName = QFileDialog::getOpenFileName(this, tr("Input File"), "", tr("*.txt *.xlsx *.xls"));
    if (inputFileName.isEmpty())
        return;
    MatrixTableModel<matrix_t> *newModel = new MatrixTableModel<matrix_t>();

    ui->checkBox_ignoreFirstColumn->setChecked(false);
    ui->checkBox_ignoreFirstRow->setChecked(false);
    data = StatsTool::readFromFile(inputFileName, newModel);
    if ( !data.isNull() ) {
        if ( model )
            model->resizeStorage(0, 0);
#ifndef UNRESTRICTED_VARIABLE_APPRAISAL_USES_QPLAINTEXT
        textToMatrix(data);
#else
        ui->plainTextEdit->document()->setPlainText( data );
#endif
    } else {
        if ( model )
            delete model;
        model = newModel;
        model->setView(ui->tableView);
        setComboboxByHeaders(model->getFirstRow().join(" "));
        ui->comboBox_dataContains->currentIndexChanged(ui->comboBox_dataContains->currentIndex());
        setupTableView();
    }

    if ( QRegExp("[A-z]+").indexIn(model->getFirstRow().join(" ")) > -1 )
        ui->checkBox_ignoreFirstRow->setChecked(true);

    emit setMatrixTable(model);
}

bool DialogUnrestrictedVariableAppraisal::first_column_is_examined(QString str)
{
    QRegExp rx("[Ee]xamined");

    return rx.indexIn(str) > -1;
}

bool DialogUnrestrictedVariableAppraisal::second_column_is_difference(QString str)
{
    QRegExp rx(" [Dd]ifference");

    return rx.indexIn(str) > -1;
}

bool DialogUnrestrictedVariableAppraisal::first_column_is_audited(QString str)
{
    QRegExp rx("[Aa]udited");

    return (rx.indexIn(str) > -1 && !first_column_is_examined(str));
}

bool DialogUnrestrictedVariableAppraisal::first_column_is_difference(QString str)
{
    QRegExp rx("[Dd]ifference");

    return (rx.indexIn(str) > -1);
}

void DialogUnrestrictedVariableAppraisal::setColumnHeaders(int idx)
{
    int exa;
    int aud;
    int dif;

    setColumnIndices(exa, aud, dif);
    QVariant examined = (exa != -1 ? "EXAMINED" : QString());
    QVariant audited = (aud != -1 ? "AUDITED" : QString());
    QVariant difference = (dif != -1 ? "DIFFERENCE" : QString());

    model->clearHeaderData();
    model->setHeaderData(exa, Qt::Horizontal, examined);
    model->setHeaderData(aud, Qt::Horizontal, audited);
    model->setHeaderData(dif, Qt::Horizontal, difference);
//    ui->checkBox_ignoreFirstColumn->toggled(ui->checkBox_ignoreFirstColumn->isChecked());
}

int DialogUnrestrictedVariableAppraisal::setColumnIndices(int &examined, int &audited, int &difference, int idx)
{
    int ret = 0;

    if ( idx == -1 )
        idx = ui->comboBox_dataContains->currentIndex();

    switch (idx)
    {
    case 0: examined = 0; audited = -1; difference = -1; ret = 1;
        break;
    case 1: audited = 0; examined = -1; difference = -1; ret = 1;
        break;
    case 2: difference = 0; examined = -1; audited = -1; ret = 1;
        break;
    case 3: examined = 0; audited = 1; difference = 2; ret = 3;
        break;
    case 4: examined = 0; difference = 1; audited = 2; ret = 3;
        break;
    case 5: audited = 0; difference = 1; examined = 2; ret = 3;
        break;
    default:
        return -1;
    }
    return -1;
}

void DialogUnrestrictedVariableAppraisal::fill_in_column(matrix_t &mat, int examined_column, int audited_column, int difference_column, int64_t n_rows)
{
    VariableAppraisal varApp;

    varApp.fill_in_column(mat, examined_column, audited_column, difference_column, n_rows);
}

void DialogUnrestrictedVariableAppraisal::insert_header(QStringList &report, QString inputFileName, int64_t sampleSize, int64_t universeSize, int64_t n_nonzero_diffs, int idx)
{
    if (idx == -1)
        idx = report.size();

    report.insert(idx++, QString("<div class='module_header'>"));
    report.insert(idx++, QString("<h3>Variable Appraisal - Unrestricted</h3>\n"));
    report.insert(idx++, QString("Audit: %1\n").arg(ui->lineEdit_auditName->text()));
    report.insert(idx++, QString("Date: %1\n").arg(QDateTime::currentDateTime().toString()));
    report.insert(idx++, QString("Input file: %1\n\n").arg(inputFileName));
    report.insert(idx++, QString("Sample size: ") + QString::asprintf("%'lld\n", (long long int)sampleSize));
    report.insert(idx++, QString("Universe size: ") + QString::asprintf("%'lld", (long long int)universeSize));
    if (n_nonzero_diffs > -1)
        report.insert(idx++, tr("\nNonzero difference values: ") + QString::asprintf("%'lld", (long long int)n_nonzero_diffs));
    report.insert(idx, QString("</div>\n"));
}

int DialogUnrestrictedVariableAppraisal::getExaminedColumn()
{
    QRegExp rx("examined", Qt::CaseInsensitive);

    for (int i = 0; i < 5; i++)
        if ( rx.indexIn(model->headerData(i, Qt::Horizontal, Qt::DisplayRole).toString()) > -1 )
            return i;

    if ( first_column_is_examined(ui->comboBox_dataContains->currentText()) )
        return 0 + ui->checkBox_ignoreFirstColumn->isChecked();

    return -1;
}

int DialogUnrestrictedVariableAppraisal::getAuditedColumn()
{
    QRegExp rx("audited", Qt::CaseInsensitive);

    for (int i = 0; i < 5; i++)
        if ( rx.indexIn(model->headerData(i, Qt::Horizontal, Qt::DisplayRole).toString()) > -1 )
            return i;
    if ( first_column_is_audited(ui->comboBox_dataContains->currentText() ) )
        return 0 + ui->checkBox_ignoreFirstColumn->isChecked();

    return -1;
}

int DialogUnrestrictedVariableAppraisal::getDifferenceColumn()
{
    QRegExp rx("difference", Qt::CaseInsensitive);

    for (int i = 0; i < 5; i++) {
        if ( rx.indexIn(model->headerData(i, Qt::Horizontal, Qt::DisplayRole).toString()) > -1 )
            return i;
    }
    if ( first_column_is_difference(ui->comboBox_dataContains->currentText() ) )
        return 0 + ui->checkBox_ignoreFirstColumn->isChecked();
    else if ( second_column_is_difference(ui->comboBox_dataContains->currentText() ) )
        return 1 + ui->checkBox_ignoreFirstColumn->isChecked();

    return -1;
}

void DialogUnrestrictedVariableAppraisal::on_buttonBox_accepted_unsafe()
{
#ifdef UNRESTRICTED_VARIABLE_APPRAISAL_USES_QPLAINTEXT
    on_buttonBox_accepted_unsafe_qplaintextedit();
#else
    on_buttonBox_accepted_unsafe_tableview();
#endif
}

template <class T>
static int qvMax(QVector<T> v)
{
    int max = -1;
    foreach (int i, v)
        if ( i > max )
            max = i;

    return max;
}

void DialogUnrestrictedVariableAppraisal::on_buttonBox_accepted_unsafe_tableview()
{
    VariableAppraisal varApp;
    QStringList report;
    int64_t sample_size = 0;
    int64_t universe_size = 0;
    int64_t nonzero_diffs = -1;
    int dif_col = -1, aud_col = -1, exa_col = -1;
    int ignoreFirstCol = ( ui->checkBox_ignoreFirstColumn->isChecked() ? 1 : 0 );
    int ignoreFirstRow = ( ui->checkBox_ignoreFirstRow->isChecked() ? 1 : 0 );
    int used_col = 0;

//    if ( model->rowCount() < 1 )
//        textToMatrix(ui->plainTextEdit->toPlainText());
    if ( model->nonnumericDataInModel(true) )//, ui->checkBox_ignoreFirstRow->isChecked() ? 0 : -1) )
        return;
    if ( model->rowCount() < 1 ) {
        ST_ERRORBOX(tr("I see no data to run calculations on?"));
        return;
    }

    exa_col = getExaminedColumn();
    aud_col = getAuditedColumn();
    dif_col = getDifferenceColumn();

    QVector<int> colList = { exa_col, aud_col, dif_col };
    foreach( int c, colList ) {
        if (c != -1) {
            used_col++;
        }
    }
    if ( used_col > 1 && (exa_col == -1 || aud_col == -1 || dif_col == -1) ) {
        setColumnIndices(exa_col, aud_col, dif_col);
        if ( ignoreFirstCol ) {
            exa_col++;
            aud_col++;
            dif_col++;
        }
    }
    int availCols = model->columnCount() - ignoreFirstCol;
    used_col = 0;
    foreach( int c, colList ) {
        if (c != -1) {
            used_col++;
        }
    }
    if ( (availCols != used_col && availCols != used_col - 1) )
    {
        ST_ERRORBOX(tr("Wrong number of columns for the current settings."));
        return;
    } else if ( (availCols == 3 && used_col == 3) ) {
        ST_ERRORBOX("WARNING: if you run an analysis, then change the column orders, the second report will be incorrect.");
    }
    if (used_col > 1) {
        model->resizeStorage( model->rowCount(), qvMax(QVector<int>( { exa_col, aud_col, dif_col } )) + 1 );
        varApp.figure_out_remaining_columns(&exa_col, &aud_col, &dif_col);
        varApp.fill_in_column( model->getMatrix(), exa_col, aud_col, dif_col,
                        model->rowCount() );
    }

    sample_size = model->rowCount() - ignoreFirstRow;
    universe_size = strtold_chk( ui->lineEdit_universeSize->text().remove(tr(",")).toStdString().c_str(), NULL );
    if ( universe_size < sample_size ) {
        ui->lineEdit_universeSize->setText(QString::number(sample_size));
        universe_size = sample_size;
        ST_ERRORBOX("The entered universe size was smaller than the sample size; it has been set automatically.");
    }

    if ( exa_col > -1 ) {
        matrix_t bufMatrix = model->getMatrix()(scythe::_, exa_col);
        varApp.build_report(bufMatrix, report, universe_size, "EXAMINED VALUES", ignoreFirstRow);
    }
    if ( aud_col > -1 ) {
        matrix_t bufMatrix = model->getMatrix()(scythe::_, aud_col);
        varApp.build_report(bufMatrix, report, universe_size, "AUDITED VALUES", ignoreFirstRow);
    }
    if ( dif_col > -1 ) {
        matrix_t bufMatrix = model->getMatrix()(scythe::_, dif_col);
        varApp.build_report(bufMatrix, report, universe_size, "DIFFERENCE VALUES", ignoreFirstRow);
        nonzero_diffs = model->nonzeroItems(dif_col);
    }

    insert_header(report, inputFileName, sample_size, universe_size, nonzero_diffs, 0);
    model->updateView();

    emit setAuditName(ui->lineEdit_auditName->text());
    emit displayHtml(report.join(""));
    emit reject();
}

void DialogUnrestrictedVariableAppraisal::on_buttonBox_accepted_unsafe_qplaintextedit()
{
    VariableAppraisal varApp;
    QString buf = ui->plainTextEdit->document()->toPlainText();
    QStringList report;
    QStringList lines = buf.split(QRegExp("\r?\n"), QString::SkipEmptyParts);
    QStringList line_tokens;
    int64_t universeSize = 0;
    int64_t sampleSize = 0;
    // the index into the matrix of each data column
    int examined_column = -1, audited_column = -1, difference_column = -1;
    // flag indicating if the first row contains data or labels
    int row_start = ui->checkBox_ignoreFirstRow->isChecked() ? 1 : 0;
    // flag indicating if the first column contains data or labels
    int col_start = ui->checkBox_ignoreFirstColumn->isChecked() ? 1 : 0;
    int64_t n_rows = lines.size() - row_start;
    int n_cols, n_cols_expected;
    matrix_t matrix(n_rows, 3);

    // sanity checking
    if (n_rows <= row_start) {
        ST_ERRORBOX("Not enough data.");
        return;
    }
    // If the universe size wasn't set, make it the sample size
    if (ui->lineEdit_universeSize->text().remove(tr(",")).toInt() < n_rows) {
        ui->lineEdit_universeSize->setText(QString("%1").arg(n_rows));
        ST_ERRORBOX("The entered universe size was smaller than the amount of data entered; it has been set to equal the sample size automatically.");
    }
    universeSize = ui->lineEdit_universeSize->text().remove(tr(",")).toInt();

    // if the first column isn't data (e.g. labels), we expect an extra column in the input
    n_cols_expected = 1 + col_start;
    // if the user selected a multiple column input format (e.g. "examined and audited"), we expect an extra column
    if (ui->comboBox_dataContains->currentText().indexOf(" and ") > -1)
        n_cols_expected++;
    n_cols = lines.at(row_start).split(SPLIT_REGEXP, QString::SkipEmptyParts).size();
    if (n_cols > n_cols_expected || n_cols < n_cols_expected) {
        ST_ERRORBOX(tr("Data is not properly formatted; the selected options mean the program expected ") + QString("%1").arg(n_cols_expected)
                    + tr(" columns (including any non-data, e.g. label, column.)"));
        return;
    }

    // fill the scythe::matrix
    for (int i = row_start; i < lines.size(); i++)
    {
        line_tokens = lines.at(i).split(SPLIT_REGEXP, QString::SkipEmptyParts);
        for (int j = col_start; j < n_cols; j++)
        {
            if (line_tokens.size() < n_cols || line_tokens.size() > n_cols) {
                ST_ERRORBOX(tr("Data is not properly formatted; error at line ") + QString("%1").arg(i + 1));
                return;
            }
            buf = line_tokens.at(j);
            buf.remove(STRIP_REGEXP);
            if (QRegExp("[^\\-\\.,0-9]").indexIn(buf) > -1) {
                ST_ERRORBOX(tr("There is non-numeric data at line %1 in column %2").arg(i + 1).arg(j + 1));
                return;
            }
            matrix(i - row_start, j - col_start) = strtold_chk(buf.toStdString().c_str(), NULL);
        }
    }

    // determine column indexes and fill in missing column if necessary
    if (n_cols - col_start > 1) {
        if (second_column_is_difference(ui->comboBox_dataContains->currentText())) {
            if (first_column_is_examined(ui->comboBox_dataContains->currentText())) {
                examined_column = 0;
                audited_column = 2;
            } else {
                examined_column = 2;
                audited_column = 0;
            }
            difference_column = 1;
        } else {
            examined_column = 0;
            audited_column = 1;
            difference_column = 2;
        }
        fill_in_column(matrix, examined_column, audited_column, difference_column, n_rows);
    } else {
        if (first_column_is_examined(ui->comboBox_dataContains->currentText())) {
            examined_column = 0;
        } else if (first_column_is_difference(ui->comboBox_dataContains->currentText())) {
            difference_column = 0;
        } else {
            audited_column = 0;
        }
    }

    QStringList col_labels;
    int64_t nonzero_items = -1;
    sampleSize = matrix.rows();

    if (examined_column > -1) {
        col_labels << tr("EXAMINED VALUES");
        matrix_t colmat = matrix(scythe::_, examined_column);
        varApp.build_report(colmat, report, universeSize, col_labels);
        col_labels.clear();
    }
    if (audited_column > -1) {
        col_labels << tr("AUDITED VALUES");
        matrix_t colmat = matrix(scythe::_, audited_column);
        varApp.build_report(colmat, report, universeSize, col_labels);
        col_labels.clear();
    }
    if (difference_column > -1) {
        nonzero_items = varApp.nonzero_items(matrix, difference_column);
        col_labels << tr("DIFFERENCE VALUES");
        matrix_t colmat = matrix(scythe::_, difference_column);
        varApp.build_report(colmat, report, universeSize, col_labels);
        col_labels.clear();
    }

    insert_header(report, inputFileName, sampleSize, universeSize, nonzero_items, 0);

    emit setAuditName(ui->lineEdit_auditName->text());
    emit displayHtml(report.join(""));
    this->reject();
}

void DialogUnrestrictedVariableAppraisal::on_checkBox_enableEditing_toggled(bool checked)
{
    ui->plainTextEdit->setReadOnly(!checked);
    if (!checked)
        ui->tableView->setEditTriggers(QTableView::NoEditTriggers);
    else
        ui->tableView->setEditTriggers(QTableView::AnyKeyPressed |
                                       QTableView::DoubleClicked |
                                       QTableView::SelectedClicked |
                                       QTableView::EditKeyPressed);
}

void DialogUnrestrictedVariableAppraisal::on_checkBox_ignoreFirstRow_toggled(bool checked)
{
    checked ? model->disableRow(0) : model->enableRow(0);
    model->dataChanged(model->index(0, 0), model->index(0, model->columnCount() - 1));
}

void DialogUnrestrictedVariableAppraisal::on_checkBox_ignoreFirstColumn_toggled(bool checked)
{
    if ( checked ) {
        model->disableColumn(0);
        model->shiftHeadersUp(0);
    } else {
        model->enableColumn(0);
        model->shiftHeadersDown(0);
    }
    model->dataChanged(model->index(0, 0), model->index(model->rowCount() - 1, 0));
}
