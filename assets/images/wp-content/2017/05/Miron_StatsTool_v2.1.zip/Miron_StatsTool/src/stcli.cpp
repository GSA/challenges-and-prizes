#include "stcli.h"
#include "ui_dialogsinglestagerandomnumbers.h"
#include "statstool.h"
#include <QWidget>

STCLI::STCLI(QObject *parent, QCommandLineParser *parser) :
    parser(parser),
    app( static_cast<QApplication*>(parent) )
{

}

bool STCLI::process()
{
    QString moduleName;
    QCommandLineOption module("m", "module", "Abbreviated module to run (e.g. ssrn)");

    parser->addOption(module);
    parser->addPositionalArgument( "parameters", tr("Input in GUI display order (SKIPPING the audit name)"), tr("[arguments...]") );
    parser->process(*app);
    moduleName = parser->value(module);

    if ( moduleName == "ssrn" ) return call<DialogSingleStageRandomNumbers>();
    if ( moduleName == "uaa" ) return call<DialogUnrestrictedAttributeAppraisal>();
    if ( moduleName == "ssdbee" ) return call<DialogSampleSizeByEstimatedError>();
    return false;
}

void STCLI::quit()
{
    exit(EXIT_SUCCESS);
}

QList<QLineEdit*> getLineEdits(QDialog *dialog)
{
    return dialog->findChildren<QLineEdit*>();
}

void STCLI::printHtml(QString html)
{
#ifdef WIN32
    QDialog mbox;
    QTextBrowser text;
    QVBoxLayout layout;

    mbox.setLayout(&layout);
    text.setHtml(html);
    layout.addWidget(&text);
    text.show();
    mbox.resize(600, 800);
    mbox.show();

    mbox.exec();
#else
    QString plainText = StatsTool::htmlToPlainText(html);
    std::cout << std::endl << plainText.toStdString();
#endif
}

template <class T>
bool STCLI::call()
{
    StatsTool st;
    T dialog(&st);
    QList<QLineEdit*> lineEdits = getLineEdits(&dialog);

    for (int i = 1; i < lineEdits.size() && i < parser->positionalArguments().size(); i++)
        lineEdits[i]->setText(parser->positionalArguments()[i - 1]);

    connect( this, SIGNAL(exec()), &dialog, SLOT(on_buttonBox_accepted()) );
    connect( &dialog, SIGNAL(displayHtml(QString)), this, SLOT(printHtml(QString)) );

    emit exec();
    app->processEvents();
    return true;
}
