/** \file dialogunrestrictedattributeappraisal.h
 * @brief Dialog for the Unrestricted Attribute Appraisal module (uses AttributeAppraisal)
 */
#ifndef DIALOGUNRESTRICTEDATTRIBUTEAPPRAISAL_H
#define DIALOGUNRESTRICTEDATTRIBUTEAPPRAISAL_H

#include "stdialog.h"
#include "attributeappraisal.h"

namespace Ui {
class DialogUnrestrictedAttributeAppraisal;
}

/**
 * @brief Encapsulates the Unrestricted Attribute Appraisal module
 */
class DialogUnrestrictedAttributeAppraisal : public STDialog
{
    Q_OBJECT

public:
    explicit DialogUnrestrictedAttributeAppraisal(QWidget *parent = 0, QString auditName = QString());
    ~DialogUnrestrictedAttributeAppraisal();
    /**
     * @brief Insert the report header
     * @param n The sample size
     * @param N The population size
     * @param out Where to insert the strings; used as the return value
     *
     * This function inserts the header information (audit name, module, time, etc.)
     */
    void insert_header(uint64_t n, uint64_t N, QStringList &out);
    /**
     * @brief Performs the calculations necessary for the report data (multithreaded)
     * @param n The sample size
     * @param N The population size
     * @param k Sample error rate (or successes, or characteristic of interest)
     * @param out Where to insert the strings; used as the return value
     *
     * This function implements the logic of the Unrestricted Attribute Appraisal module and generates the report.
     *
     * It makes use of as many (or as few) CPU cores as the computer has, up to a max of 8.
     */
    void calculate(uint64_t n, uint64_t N, uint64_t k, QStringList &out);
    /**
     * @brief We override STDialog's on_buttonBox_accepted() to do the same thing with unique additions
     */
    void on_buttonBox_accepted() override;
    /**
     * @brief Primarily for automated GUI testings
     * @return The Ui object containing all the GUI widgets
     */
    Ui::DialogUnrestrictedAttributeAppraisal *getUi();


private slots:
    /**
     * @brief Abort a running calculation
     */
    void on_pushButton_abort_clicked();
    /**
     * @brief Called when a thread finishes
     *
     * Starts the next thread to make sure there's always the ideal number running.  This is called via a
     * Queued Qt connection, and executes in the context of the dialog (the context of the source file where
     * it's defined, as it exists at the time of this writing.)
     */
    void on_thread_finished();


private:
    Ui::DialogUnrestrictedAttributeAppraisal *ui;
    void on_buttonBox_accepted_unsafe();
    bool abortRequested = false;
    /**
     * @brief The worker threads
     */
    AttributeAppraisal *threads[16] = { NULL };
    /**
     * @brief Used to prevent race conditions
     */
    QMutex mutex;
};

#endif // DIALOGUNRESTRICTEDATTRIBUTEAPPRAISAL_H
