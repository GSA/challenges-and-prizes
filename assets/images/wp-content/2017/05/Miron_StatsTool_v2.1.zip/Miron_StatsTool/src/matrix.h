/** \file matrix.h
 * @brief Defines the matrix class to be used throughout the program
 */
#ifndef MATRIX_H
#define MATRIX_H

#include "scythestat/stat.h"
#include "st_boost.h"

typedef scythe::Matrix< long double, scythe::Row, scythe::Concrete > matrix_t;
typedef scythe::Matrix< long double, scythe::Row, scythe::View > matrix_t_view;
typedef scythe::Matrix< multiprecision_type, scythe::Row, scythe::Concrete > bigdata_matrix_t;

#endif // MATRIX_H
