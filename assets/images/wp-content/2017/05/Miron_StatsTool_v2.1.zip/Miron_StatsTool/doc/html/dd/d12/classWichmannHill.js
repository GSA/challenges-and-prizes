var classWichmannHill =
[
    [ "WichmannHill", "dd/d12/classWichmannHill.html#a8392376d29433e4b56154f5af1570d7a", null ],
    [ "check_duplicate", "dd/d12/classWichmannHill.html#afc15c29c2d3d067832fc10496c37450e", null ],
    [ "ExcelRand64", "dd/d12/classWichmannHill.html#a308f2a466cb8b15cb42942581ad35e96", null ],
    [ "ExcelRandomize64", "dd/d12/classWichmannHill.html#a82b958ef15529f91471a37bbc4969873", null ],
    [ "generateNumbers", "dd/d12/classWichmannHill.html#a909c5d264df92476ceda01c52275426b", null ],
    [ "sum", "dd/d12/classWichmannHill.html#a10c42ac2be8f21ddeb4bf9a842ef66b5", null ]
];