var searchData=
[
  ['zoomlevel',['zoomLevel',['../d7/d2e/classStatsTool.html#ac2af627de70100817671ea1d43a84ae0',1,'StatsTool']]]
];
