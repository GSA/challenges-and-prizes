var classDialogUnrestrictedVariableAppraisal =
[
    [ "build_report", "db/da5/classDialogUnrestrictedVariableAppraisal.html#aa6084c32b63750507f82974c6dca8e0b", null ],
    [ "dragEnterEvent", "db/da5/classDialogUnrestrictedVariableAppraisal.html#a4d92af10768b33b0cda985e70e172dec", null ],
    [ "dropEvent", "db/da5/classDialogUnrestrictedVariableAppraisal.html#acc26ab0634342bee24dd91c5eab86165", null ],
    [ "fill_in_column", "db/da5/classDialogUnrestrictedVariableAppraisal.html#a03e342aec2d0a49a3ad08bb88750c40a", null ],
    [ "first_column_is_audited", "db/da5/classDialogUnrestrictedVariableAppraisal.html#aa5d3cc542488158208fc99ca60e37f77", null ],
    [ "first_column_is_difference", "db/da5/classDialogUnrestrictedVariableAppraisal.html#a38acefa5d2108c28d8c75c781dec58ee", null ],
    [ "first_column_is_examined", "db/da5/classDialogUnrestrictedVariableAppraisal.html#a0ab67db8eb3e4911def2c65ca84cfe3d", null ],
    [ "insert_header", "db/da5/classDialogUnrestrictedVariableAppraisal.html#ad625699958948a7ea4378f20f526a323", null ],
    [ "on_buttonBox_accepted_unsafe", "db/da5/classDialogUnrestrictedVariableAppraisal.html#a4cfe7b3d2a2afda45478b5521e2ac624", null ],
    [ "on_checkBox_enableEditing_toggled", "db/da5/classDialogUnrestrictedVariableAppraisal.html#a4773ae9c36866858dd68dd1dc0c0cc21", null ],
    [ "on_pushButton_chooseInputFile_clicked", "db/da5/classDialogUnrestrictedVariableAppraisal.html#a4a152007998d9a31b30a6a4468e8c6bc", null ],
    [ "second_column_is_difference", "db/da5/classDialogUnrestrictedVariableAppraisal.html#a28f49db0cf29d64d9cfa7f1fc6e0f4e4", null ]
];