var files =
[
    [ "test", "dir_13e138d54eb8818da29c3992edef070a.html", "dir_13e138d54eb8818da29c3992edef070a" ],
    [ "attributeappraisal.h", "dc/d9b/attributeappraisal_8h.html", [
      [ "AttributeAppraisal", "d9/d79/classAttributeAppraisal.html", "d9/d79/classAttributeAppraisal" ]
    ] ],
    [ "dialogsamplesizebyattribute.h", "d7/db7/dialogsamplesizebyattribute_8h.html", [
      [ "DialogSampleSizeByAttribute", "dc/d77/classDialogSampleSizeByAttribute.html", "dc/d77/classDialogSampleSizeByAttribute" ]
    ] ],
    [ "dialogsamplesizebyestimatederror.h", "dc/db3/dialogsamplesizebyestimatederror_8h.html", [
      [ "DialogSampleSizeByEstimatedError", "dc/d18/classDialogSampleSizeByEstimatedError.html", null ]
    ] ],
    [ "dialogselectexcelsheet.h", "dd/d4b/dialogselectexcelsheet_8h.html", [
      [ "DialogSelectExcelSheet", "d7/de1/classDialogSelectExcelSheet.html", "d7/de1/classDialogSelectExcelSheet" ]
    ] ],
    [ "dialogsinglestagerandomnumbers.h", "d6/d2a/dialogsinglestagerandomnumbers_8h.html", [
      [ "DialogSingleStageRandomNumbers", "d7/da5/classDialogSingleStageRandomNumbers.html", "d7/da5/classDialogSingleStageRandomNumbers" ]
    ] ],
    [ "dialogstratifiedvariableappraisal.h", "dc/de6/dialogstratifiedvariableappraisal_8h.html", [
      [ "DialogStratifiedVariableAppraisal", "d3/ddf/classDialogStratifiedVariableAppraisal.html", "d3/ddf/classDialogStratifiedVariableAppraisal" ]
    ] ],
    [ "dialogunrestrictedattributeappraisal.h", "d1/d79/dialogunrestrictedattributeappraisal_8h.html", [
      [ "DialogUnrestrictedAttributeAppraisal", "db/d27/classDialogUnrestrictedAttributeAppraisal.html", "db/d27/classDialogUnrestrictedAttributeAppraisal" ]
    ] ],
    [ "dialogunrestrictedvariableappraisal.h", "d4/d40/dialogunrestrictedvariableappraisal_8h.html", [
      [ "DialogUnrestrictedVariableAppraisal", "db/da5/classDialogUnrestrictedVariableAppraisal.html", "db/da5/classDialogUnrestrictedVariableAppraisal" ]
    ] ],
    [ "exceltablemodel.hpp", "d7/d56/exceltablemodel_8hpp.html", [
      [ "ExcelTableModel", "d8/dfe/classExcelTableModel.html", "d8/dfe/classExcelTableModel" ]
    ] ],
    [ "keyoverride.h", "de/d32/keyoverride_8h.html", [
      [ "KeyOverride", "d7/d0a/classKeyOverride.html", "d7/d0a/classKeyOverride" ]
    ] ],
    [ "matrix.h", "dd/df4/matrix_8h.html", null ],
    [ "matrixtablemodel.hpp", "dc/d1e/matrixtablemodel_8hpp.html", [
      [ "MatrixTableModel", "df/d66/classMatrixTableModel.html", "df/d66/classMatrixTableModel" ]
    ] ],
    [ "samplesizedetermination.h", "db/da8/samplesizedetermination_8h.html", "db/da8/samplesizedetermination_8h" ],
    [ "st_boost.h", "d8/db4/st__boost_8h.html", "d8/db4/st__boost_8h" ],
    [ "st_macros.h", "d7/d25/st__macros_8h.html", null ],
    [ "statstool.h", "d3/dbd/statstool_8h.html", [
      [ "StatsTool", "d7/d2e/classStatsTool.html", "d7/d2e/classStatsTool" ]
    ] ],
    [ "stcli.h", "dc/d1d/stcli_8h.html", [
      [ "STCLI", "d7/d33/classSTCLI.html", null ]
    ] ],
    [ "stdialog.h", "d9/d95/stdialog_8h.html", [
      [ "STDialog", "d6/d76/classSTDialog.html", "d6/d76/classSTDialog" ]
    ] ],
    [ "variableappraisal.h", "d0/d08/variableappraisal_8h.html", "d0/d08/variableappraisal_8h" ],
    [ "wichmannhill.h", "d7/d53/wichmannhill_8h.html", [
      [ "WichmannHill", "dd/d12/classWichmannHill.html", "dd/d12/classWichmannHill" ]
    ] ]
];