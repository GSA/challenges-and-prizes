var annotated_dup =
[
    [ "AttributeAppraisal", "d9/d79/classAttributeAppraisal.html", "d9/d79/classAttributeAppraisal" ],
    [ "DialogSampleSizeByAttribute", "dc/d77/classDialogSampleSizeByAttribute.html", "dc/d77/classDialogSampleSizeByAttribute" ],
    [ "DialogSampleSizeByEstimatedError", "dc/d18/classDialogSampleSizeByEstimatedError.html", null ],
    [ "DialogSelectExcelSheet", "d7/de1/classDialogSelectExcelSheet.html", "d7/de1/classDialogSelectExcelSheet" ],
    [ "DialogSingleStageRandomNumbers", "d7/da5/classDialogSingleStageRandomNumbers.html", "d7/da5/classDialogSingleStageRandomNumbers" ],
    [ "DialogStratifiedVariableAppraisal", "d3/ddf/classDialogStratifiedVariableAppraisal.html", "d3/ddf/classDialogStratifiedVariableAppraisal" ],
    [ "DialogUnrestrictedAttributeAppraisal", "db/d27/classDialogUnrestrictedAttributeAppraisal.html", "db/d27/classDialogUnrestrictedAttributeAppraisal" ],
    [ "DialogUnrestrictedVariableAppraisal", "db/da5/classDialogUnrestrictedVariableAppraisal.html", "db/da5/classDialogUnrestrictedVariableAppraisal" ],
    [ "ExcelTableModel", "d8/dfe/classExcelTableModel.html", "d8/dfe/classExcelTableModel" ],
    [ "KeyOverride", "d7/d0a/classKeyOverride.html", "d7/d0a/classKeyOverride" ],
    [ "MatrixTableModel", "df/d66/classMatrixTableModel.html", "df/d66/classMatrixTableModel" ],
    [ "SampleSizeDetermination", "d7/d77/classSampleSizeDetermination.html", "d7/d77/classSampleSizeDetermination" ],
    [ "StatsTool", "d7/d2e/classStatsTool.html", "d7/d2e/classStatsTool" ],
    [ "StatsToolTests", "d1/dca/classStatsToolTests.html", null ],
    [ "STCLI", "d7/d33/classSTCLI.html", null ],
    [ "STDialog", "d6/d76/classSTDialog.html", "d6/d76/classSTDialog" ],
    [ "VariableAppraisal", "de/dc1/classVariableAppraisal.html", "de/dc1/classVariableAppraisal" ],
    [ "WichmannHill", "dd/d12/classWichmannHill.html", "dd/d12/classWichmannHill" ]
];