var variableappraisal_8h =
[
    [ "VariableAppraisal", "de/dc1/classVariableAppraisal.html", "de/dc1/classVariableAppraisal" ]
];