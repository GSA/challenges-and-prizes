var samplesizedetermination_8h =
[
    [ "SampleSizeDetermination", "d7/d77/classSampleSizeDetermination.html", "d7/d77/classSampleSizeDetermination" ]
];