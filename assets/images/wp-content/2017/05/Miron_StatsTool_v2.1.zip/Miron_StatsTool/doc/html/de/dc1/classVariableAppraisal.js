var classVariableAppraisal =
[
    [ "build_report", "de/dc1/classVariableAppraisal.html#a616b856ae7f978e9867bcd8fb7172986", null ],
    [ "nonzero_items", "de/dc1/classVariableAppraisal.html#ab4725814aa5507b96fa5847a627ef149", null ],
    [ "nonzero_items", "de/dc1/classVariableAppraisal.html#a9a8c6fb5eaa8904fcda0cbabfa8ac2f6", null ]
];