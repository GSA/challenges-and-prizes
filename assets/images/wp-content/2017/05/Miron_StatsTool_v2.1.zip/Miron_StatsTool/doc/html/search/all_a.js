var searchData=
[
  ['lower_5flimit',['lower_limit',['../d9/d79/classAttributeAppraisal.html#a88f1ed4179d65421e72984742e60f5de',1,'AttributeAppraisal::lower_limit(uint sample_size, uint population_size, uint sample_successes, double confidence, bool double_sided=true)'],['../d9/d79/classAttributeAppraisal.html#a657e75afead522bb572c1d09ebfc9ca3',1,'AttributeAppraisal::lower_limit()']]],
  ['lower_5flimit_5fimprecise',['lower_limit_imprecise',['../d9/d79/classAttributeAppraisal.html#aef58fc0b04269b93771f5cd73a2fe2c4',1,'AttributeAppraisal']]]
];
