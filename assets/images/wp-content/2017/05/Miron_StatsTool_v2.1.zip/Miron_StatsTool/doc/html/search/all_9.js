var searchData=
[
  ['key_5fshift_5ftab',['Key_Shift_Tab',['../d7/d0a/classKeyOverride.html#aafa80fe0836ccc90a37ddb61c76e57b9',1,'KeyOverride']]],
  ['keyoverride',['KeyOverride',['../d7/d0a/classKeyOverride.html',1,'KeyOverride'],['../d7/d0a/classKeyOverride.html#a461aebdb8bb4c1c4eebd2746d83be9d0',1,'KeyOverride::KeyOverride(QObject *parent=0)'],['../d7/d0a/classKeyOverride.html#ac250399ecf70f5a2a2c10751baea448b',1,'KeyOverride::KeyOverride(QObject *parent, Qt::Key key)'],['../d7/d0a/classKeyOverride.html#afa7facd28de2a7c880c266ecc2ed8245',1,'KeyOverride::KeyOverride(QObject *parent, Qt::Key key1, Qt::Key key2)']]],
  ['keyoverride_2eh',['keyoverride.h',['../de/d32/keyoverride_8h.html',1,'']]]
];
