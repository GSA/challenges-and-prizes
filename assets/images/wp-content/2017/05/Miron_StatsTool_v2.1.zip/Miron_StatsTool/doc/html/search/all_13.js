var searchData=
[
  ['validator',['validator',['../d6/d76/classSTDialog.html#a02178fd969627727d420e96bf2ed6a4a',1,'STDialog']]],
  ['value',['value',['../d7/d77/classSampleSizeDetermination.html#aa1545db6a409bc22789841f2346394a3',1,'SampleSizeDetermination']]],
  ['variableappraisal',['VariableAppraisal',['../de/dc1/classVariableAppraisal.html',1,'']]],
  ['variableappraisal_2eh',['variableappraisal.h',['../d0/d08/variableappraisal_8h.html',1,'']]]
];
