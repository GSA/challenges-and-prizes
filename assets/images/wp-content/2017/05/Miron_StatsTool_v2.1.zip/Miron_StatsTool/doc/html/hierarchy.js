var hierarchy =
[
    [ "QAbstractTableModel", null, [
      [ "ExcelTableModel", "d8/dfe/classExcelTableModel.html", null ],
      [ "MatrixTableModel< T >", "df/d66/classMatrixTableModel.html", null ],
      [ "MatrixTableModel< matrix_t >", "df/d66/classMatrixTableModel.html", null ]
    ] ],
    [ "QDialog", null, [
      [ "DialogSelectExcelSheet", "d7/de1/classDialogSelectExcelSheet.html", null ],
      [ "STDialog", "d6/d76/classSTDialog.html", [
        [ "DialogSampleSizeByAttribute", "dc/d77/classDialogSampleSizeByAttribute.html", null ],
        [ "DialogSampleSizeByEstimatedError", "dc/d18/classDialogSampleSizeByEstimatedError.html", null ],
        [ "DialogSingleStageRandomNumbers", "d7/da5/classDialogSingleStageRandomNumbers.html", null ],
        [ "DialogStratifiedVariableAppraisal", "d3/ddf/classDialogStratifiedVariableAppraisal.html", null ],
        [ "DialogUnrestrictedAttributeAppraisal", "db/d27/classDialogUnrestrictedAttributeAppraisal.html", null ],
        [ "DialogUnrestrictedVariableAppraisal", "db/da5/classDialogUnrestrictedVariableAppraisal.html", null ]
      ] ]
    ] ],
    [ "QMainWindow", null, [
      [ "StatsTool", "d7/d2e/classStatsTool.html", null ]
    ] ],
    [ "QObject", null, [
      [ "KeyOverride", "d7/d0a/classKeyOverride.html", null ],
      [ "StatsToolTests", "d1/dca/classStatsToolTests.html", null ],
      [ "STCLI", "d7/d33/classSTCLI.html", null ]
    ] ],
    [ "QThread", null, [
      [ "AttributeAppraisal", "d9/d79/classAttributeAppraisal.html", null ]
    ] ],
    [ "SampleSizeDetermination", "d7/d77/classSampleSizeDetermination.html", null ],
    [ "VariableAppraisal", "de/dc1/classVariableAppraisal.html", null ],
    [ "WichmannHill", "dd/d12/classWichmannHill.html", null ]
];