var searchData=
[
  ['uaa_5fdialog',['uaa_dialog',['../d7/d2e/classStatsTool.html#ac1f59948183f36f24c00eeac1e6438b1',1,'StatsTool']]],
  ['upper_5flimit',['upper_limit',['../d9/d79/classAttributeAppraisal.html#a68b2a9d99d4faf4697fae2a035b8d9b0',1,'AttributeAppraisal::upper_limit(uint sample_size, uint population_size, uint sample_successes, double confidence, bool double_sided=true)'],['../d9/d79/classAttributeAppraisal.html#a0158b512f1d103cae8311e97e435937e',1,'AttributeAppraisal::upper_limit()']]],
  ['upper_5flimit_5fimprecise',['upper_limit_imprecise',['../d9/d79/classAttributeAppraisal.html#a9d0dd70ed0dbb8cc5924e347c2f26732',1,'AttributeAppraisal']]],
  ['uva_5fdialog',['uva_dialog',['../d7/d2e/classStatsTool.html#aa34eea6f56c9985b084e442125fd1960',1,'StatsTool']]]
];
