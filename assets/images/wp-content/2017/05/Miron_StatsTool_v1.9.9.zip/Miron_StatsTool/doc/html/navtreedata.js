var NAVTREE =
[
  [ "RAT-STATS Stats Tool", "index.html", [
    [ "Stats Tool", "index.html", [
      [ "Description", "index.html#description", null ],
      [ "README info", "index.html#readme", null ],
      [ "Noncosmetic Differences", "index.html#noncosmetic_differences", null ],
      [ "Procedure to add functionality to the program", "index.html#additional_function_procedure", null ],
      [ "Licenses", "index.html#licenses", null ]
    ] ],
    [ "Todo List", "dd/da0/todo.html", null ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Functions", "functions_func.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';