var searchData=
[
  ['savetoexcelfile',['saveToExcelFile',['../d7/d2e/classStatsTool.html#aba43759358c66681e743cea2f253c3f3',1,'StatsTool']]],
  ['second_5fcolumn_5fis_5fdifference',['second_column_is_difference',['../db/da5/classDialogUnrestrictedVariableAppraisal.html#a28f49db0cf29d64d9cfa7f1fc6e0f4e4',1,'DialogUnrestrictedVariableAppraisal']]],
  ['setauditname',['setAuditName',['../d7/d2e/classStatsTool.html#ac8202edfccf10b45aa60fbc1f3c902b2',1,'StatsTool::setAuditName()'],['../d6/d76/classSTDialog.html#a13128c675d9680cfa19aebea85674da9',1,'STDialog::setAuditName()']]],
  ['setdata',['setData',['../df/d66/classMatrixTableModel.html#a11c44647643f65a979c876410fb0af75',1,'MatrixTableModel']]],
  ['setupdisplayarea',['setupDisplayArea',['../d7/d2e/classStatsTool.html#a09755778ea7ac3ad9820f946871ef055',1,'StatsTool']]],
  ['setview',['setView',['../df/d66/classMatrixTableModel.html#a20d8e6b3e32321e8714b065a82948d01',1,'MatrixTableModel']]],
  ['setxlssheetindex',['setXlsSheetIndex',['../d8/dfe/classExcelTableModel.html#abff5aa47b048b432d06b869040369542',1,'ExcelTableModel']]],
  ['shiftheadersdown',['shiftHeadersDown',['../df/d66/classMatrixTableModel.html#abd7becc6e66afe06177642f4177f87cb',1,'MatrixTableModel']]],
  ['shiftheadersup',['shiftHeadersUp',['../df/d66/classMatrixTableModel.html#a6553ddb98f463137bed25e713ba09988',1,'MatrixTableModel']]],
  ['stridx',['strIdx',['../df/d66/classMatrixTableModel.html#a12b1f5cf9b493f0737efb27cc039b555',1,'MatrixTableModel']]],
  ['stridxundo',['strIdxUndo',['../df/d66/classMatrixTableModel.html#a110cb4a1fc0ff6113b564b6f27e219e9',1,'MatrixTableModel']]],
  ['stringtomatrix',['stringToMatrix',['../df/d66/classMatrixTableModel.html#a8b16d9ae76541c76aa673fdde6ed53f4',1,'MatrixTableModel']]],
  ['sum',['sum',['../dd/d12/classWichmannHill.html#a10c42ac2be8f21ddeb4bf9a842ef66b5',1,'WichmannHill']]]
];
