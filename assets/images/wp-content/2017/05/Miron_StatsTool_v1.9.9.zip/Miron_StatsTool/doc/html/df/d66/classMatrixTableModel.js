var classMatrixTableModel =
[
    [ "data", "df/d66/classMatrixTableModel.html#a77985ab2ff940ac32bf52bbdb0cd7212", null ],
    [ "focusTableViewCell", "df/d66/classMatrixTableModel.html#abb1a2923d399e4af739aeb10d8d47d92", null ],
    [ "getMatrix", "df/d66/classMatrixTableModel.html#adac06921c60d69e77829dc9e21774ac7", null ],
    [ "nonnumericDataInModel", "df/d66/classMatrixTableModel.html#ab22e1e3db9b00bd12624ed5d2f3b6bff", null ],
    [ "setData", "df/d66/classMatrixTableModel.html#a11c44647643f65a979c876410fb0af75", null ],
    [ "setView", "df/d66/classMatrixTableModel.html#a20d8e6b3e32321e8714b065a82948d01", null ],
    [ "shiftHeadersDown", "df/d66/classMatrixTableModel.html#abd7becc6e66afe06177642f4177f87cb", null ],
    [ "shiftHeadersUp", "df/d66/classMatrixTableModel.html#a6553ddb98f463137bed25e713ba09988", null ],
    [ "strIdx", "df/d66/classMatrixTableModel.html#a12b1f5cf9b493f0737efb27cc039b555", null ],
    [ "strIdxUndo", "df/d66/classMatrixTableModel.html#a110cb4a1fc0ff6113b564b6f27e219e9", null ],
    [ "stringToMatrix", "df/d66/classMatrixTableModel.html#a8b16d9ae76541c76aa673fdde6ed53f4", null ],
    [ "disabledColumns", "df/d66/classMatrixTableModel.html#a77c27a41ae5a13d97eac34bee79e3c45", null ],
    [ "disabledRows", "df/d66/classMatrixTableModel.html#a87361f745717b0d63b33fd1738465629", null ],
    [ "m_data", "df/d66/classMatrixTableModel.html#abea20818fd9fc1db4ac062164a77fb4f", null ],
    [ "m_headers", "df/d66/classMatrixTableModel.html#a5221324e873fdf0766fa7f127e2e9c04", null ],
    [ "m_strings", "df/d66/classMatrixTableModel.html#a8e07d1da3cd3dd22678f67675524413b", null ]
];