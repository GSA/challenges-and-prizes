var searchData=
[
  ['xls_5fcurrent_5fsheet',['xls_current_sheet',['../d8/dfe/classExcelTableModel.html#a314f9542d61438e58f18202ee59b8b2e',1,'ExcelTableModel']]],
  ['xls_5fdoc',['xls_doc',['../d8/dfe/classExcelTableModel.html#af67e515e725dec8d8b30fbd05450d867',1,'ExcelTableModel']]]
];
