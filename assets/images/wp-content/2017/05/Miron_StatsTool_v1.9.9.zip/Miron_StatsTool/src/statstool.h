/*
 * The "main" program header file.
 *
 * In brief, GUI (Graphical User Interface) programs are event-driven: they
 * generally sit dormant until an event triggers an action (e.g. the user
 * clicking on a button.)  Usually that amounts to just calling a function.
 *
 * The Qt framework (which is a cross-platform toolkit that's primary aim
 * is to provide cross-platform GUI functionality) is no exception to this.  To
 * accomplish it's primary goal, it features its own objects, the point of which
 * is to leave the job of making sure everything behaves the same regardless of
 * what platform you're executing the program on, up to the Qt folks.
 *
 * So, throughout the program source code, you'll see classes that encapsulate
 * pieces of functionality.  Most of the GUI itself was designed as Qt Forms
 * in QtCreator (that's what all of the .ui files are), and when the project
 * is built, those .ui files are compiled into C++ code by Qt's "uic" program.
 *
 * The C++ code generated from the .ui files is then used by the rest of the
 * C++ source code throughout the project.
 *
 * Note that this is a high-level overview of how the source code ends up
 * as an executable file, and is meant only to give a reader unfamiliar with
 * Qt or traditional GUI programming some idea of what's going on.
 */

#ifndef STATSTOOL_H
#define STATSTOOL_H

#include <math.h>
#include <stdlib.h>

#include <QDropEvent>
#include <QMimeData>
#include <QRegExp>
#include <QMainWindow>
#include <QMessageBox>
#include <QFile>
#include <QFileDialog>
#include <QTextStream>
#include <QDateTime>
#include <QTextEdit>
#include <QString>
#include <QStringList>
#include <QTableView>
#include <QStandardItemModel>
#include <QStandardItem>
#include <QtAccessibilitySupport/QtAccessibilitySupport>
#include <QAccessibleWidget>
#include <QWhatsThis>
#include <QDebug>
#include <QShortcut>
#include <QtXlsx/QtXlsx>

#include "st_boost.h"

#include "basicexcel/BasicExcel.hpp"
#include "basicexcel/ExcelFormat.h"

#include "dialogsinglestagerandomnumbers.h"
#include "dialogunrestrictedattributeappraisal.h"
#include "dialogunrestrictedvariableappraisal.h"
#include "dialogstratifiedvariableappraisal.h"
#include "dialogsamplesizebyattribute.h"
#include "dialogsamplesizebyestimatederror.h"

#include "st_macros.h"



namespace Ui {
class StatsTool;
}

/**
 * @brief The program's main window
 *
 * This class serves as the main window, as well as providing a number of utility
 * functions
 */
class StatsTool : public QMainWindow
{
    Q_OBJECT

public:
    explicit StatsTool(QWidget *parent = 0);
    ~StatsTool();
    /**
     * @brief Open an Excel file by name and return the contents as a QString
     * @param fileName the full path to the file
     * @return The contents as a QString, or an empty string on failure
     */
    static QString excelFileToPlainText(QString &fileName);
    /**
     * @brief Overloaded
     * @param excel An already open excel object
     * @return The contents of the file as a QString, or an empty string on failure
     */
    static QString excelFileToPlainText(QXlsx::Document &excel);
    /**
     * @brief Overloaded
     * @param sheet The sheet to read from
     * @return The contents of the file as a string, or an empty string on failure
     */
    static QString excelFileToPlainText(YExcel::BasicExcelWorksheet *sheet);
    /**
     * @brief Show a file selection dialog, returning the contents of the selected file as a string
     * @return The contents of the filename chosen by the user
     */
    static QString readFromFile();
    /**
     * @brief Read the contents of a file and return it as a string
     * @param inputFileName The path to the file
     * @return The contents of the given file as a string, or an empty string on failure
     *
     * As of v1.5, handles .xls, .xlsx, and treats everything else as .txt
     */
    static QString readFromFile(QString inputFileName);
    /**
     * @brief Calculate the skewness of a matrix column using the same formula as RAT-STATS
     * @param matrix The matrix to operate on
     * @param column The column index into the matrix to operate on
     * @param mean The mean of the column (used in the formula)
     * @return The skewness, matching the RAT-STATS formula
     */
    static long double ratstats_skewness(const matrix_t &matrix, int column, long double mean);
    /**
     * @brief Overloaded
     */
    static long double ratstats_skewness(const matrix_t_view &matrix, int column, long double mean);
    /**
     * @brief Calculate the kurtosis of a matrix column using the same formula as RAT-STATS
     * @param matrix The matrix to operate on
     * @param column The column into the matrix to operate on
     * @param mean The mean of the column (used in the formula)
     * @return The kurtosis, matching the RAT-STATS formula
     */
    static long double ratstats_kurtosis(const matrix_t &matrix, int column, long double mean);
    /**
     * @brief Overloaded
     */
    static long double ratstats_kurtosis(const matrix_t_view &matrix, int column, long double mean);
    /**
     * @brief Dump preformatted text to an Excel format file (data between <pre></pre> tags)
     * @param filename Full path to the file
     * @param html The marked-up string to dump
     *
     * Will make any obviously numeric text strings numeric fields in the Excel file
     */
    void dumpToExcelFile(QString filename, QString html);
    /**
     * @brief Save all text to an Excel format file (does not strip out markup)
     * @param filename The full path to the file
     * @param text The string to save
     *
     * Will make any obviously numeric text strings numeric fields in the Excel file
     */
    void saveToExcelFile(QString filename, QString text);
    /**
     * @brief Display a confirmation dialog and return the result
     * @param message The string to display to the user
     * @return True if the user clicked OK, false if they canceled
     */
    static bool confirmationBox(QString message);
    /**
     * @brief Stores the name of the audit of the last generated report (used for default save filename)
     */
    QString auditName;
    /**
     * @brief Play a moving image file (accepted formats are dictated by Qt) in the main window
     * @param fileName Path to the movie file
     *
     * Used to show the splash background at program start
     */
    void displayMovie(QString fileName);


public slots:
    /**
     * @brief Display some text
     * @param str The text to display
     *
     * This is called, via the signals-and-slots mechanism, by any module that wishes to
     * display a generated plaintext report to the user via the main window.
     */
    void displayText(QString str);
    /**
     * @brief Display some rich text
     * @param str The rich text (HTML) to display
     *
     * Display the passed QString in the main window as rich text (HTML)
     */
    void displayHtml(QString str);
    /**
     * @brief Enter "What's this?" mode
     *
     * Enters "What's this?" mode
     */
    void on_actionWhat_s_this_triggered();
    /**
     * @brief Set the name of the report for the main window
     * @param str The name the user gave to the audit
     *
     * The audit name is the default filename when saving
     */
    void setAuditName(QString str);
    static void buildModuleHeaderHtml(QStringList &report, QString moduleName, QString auditName, QString dataFile1 = QString(), QString dataFile2 = QString(), int64_t idx = 0);


private slots:
    /**
     * @brief Display the Single Stage Random Number dialog
     */
    void on_actionSingle_Stage_Random_Number_triggered();
    /**
     * @brief Display the Unrestricted Attribute Appraisal dialog
     */
    void on_actionUnrestricted_Attribute_Appraisal_triggered();
    /**
     * @brief Display the Unrestricted Variable Appraisal dialog
     */
    void on_actionUnrestricted_Variable_Appraisal_triggered();
    /**
     * @brief Display the Stratified Variable Appraisal dialog
     */
    void on_actionStratified_Variable_Appraisal_triggered();
    /**
     * @brief Save the currently displayed report to a file
     */
    void on_actionSave_Report_to_File_triggered();
    /**
     * @brief Quit the program
     */
    void on_actionQuit_triggered();
    /**
     * @brief Display the About dialog
     */
    void on_actionAbout_triggered();
    /**
     * @brief Display the Help dialog
     */
    void on_actionHelp_triggered();
    /**
     * @brief on_actionShow_splash_background_triggered
     */
    void on_actionShow_splash_background_triggered();
    /**
     * @brief Print the currently displayed report, formatting intact
     */
    void on_actionPrint_report_triggered();
    /**
     * @brief Disabled because it's only half implemented
     *
     * Shows the window to take the input and calls the stub function on "ok"
     */
    void on_actionBy_attribute_triggered();
    /**
     * @brief Increases the font size of the report preview area
     */
    void on_actionIncrease_report_size_triggered();
    /**
     * @brief Decreases the font size of the report preview area
     */
    void on_actionDecrease_report_size_triggered();
    /**
     * @brief Resets the report font size; if the user uses CONTROL+(mousewheel), this no longer works
     */
    void on_actionReset_report_size_triggered();
    /**
     * @brief Shows a file dialog and reads the contents of the file in to the report preview area
     *
     * This ends up calling the same functions as the modules use to display their reports
     */
    void on_actionOpen_report_triggered();
    /**
     * @brief Shows the Sample Size Determination - by Estimated Error Rate dialog
     */
    void on_actionBy_expected_error_rate_triggered();

private:
    Ui::StatsTool *ui;
    /**
     * @brief Go from splash-style main window display to report-style
     */
    void setupDisplayArea();
    /**
     * @brief Display an arbitrary image in the report window
     */
    void displayImage(QString file);
    /**
     * @brief The Single Stage Random Numbers dialog
     */
    DialogSingleStageRandomNumbers *ssrn_dialog = NULL;
    /**
     * @brief The Unrestricted Attribute Appraisal dialog
     */
    DialogUnrestrictedAttributeAppraisal *uaa_dialog = NULL;
    /**
     * @brief The Unrestricted Variable Appraisal dialog
     */
    DialogUnrestrictedVariableAppraisal *uva_dialog = NULL;
    /**
     * @brief The Stratified Variable Appraisal dialog
     */
    DialogStratifiedVariableAppraisal *sva_dialog = NULL;
    /**
     * @brief The Sample Size by Attribute dialog
     */
    DialogSampleSizeByAttribute *ssba_dialog = NULL;
    /**
     * @brief The Sample Size by Estimated Error dialog
     */
    DialogSampleSizeByEstimatedError *ssbee_dialog = NULL;
    /**
     * @brief The moving splash background (if used)
     */
    QMovie *movie = NULL;
    /**
     * @brief The zoom level of the main window
     */
    int zoomLevel = 0;
};

#endif // STATSTOOL_H
