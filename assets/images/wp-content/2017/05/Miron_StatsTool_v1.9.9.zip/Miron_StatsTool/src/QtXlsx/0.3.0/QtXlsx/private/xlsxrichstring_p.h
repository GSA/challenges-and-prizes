#include "../../../../../src/xlsx/xlsxrichstring_p.h"
