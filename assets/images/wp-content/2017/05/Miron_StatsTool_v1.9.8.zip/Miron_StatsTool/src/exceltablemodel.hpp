#ifndef EXCELTABLEMODEL_HPP
#define EXCELTABLEMODEL_HPP

#include <QtGui>
#include <QtXlsx/QtXlsx>
#include "basicexcel/BasicExcel.hpp"
#include "basicexcel/ExcelFormat.h"
#include "st_macros.h"


/**
 * @brief Provides table views (Excel-like spreadsheets) for Excel format input files
 *
 * This is the model for the tables shown when selecting which sheet (i.e. tab) to read
 * from if inputting data from an Excel (both .xls and .xlsx) file.
 *
 * It makes use of a model-view framework, which means that the underlying data used by
 * the View portion (which is the spreadsheet preview area in the window) isn't coupled
 * to the View object: this code accesses the data and hands it to the View for display.
 */
class ExcelTableModel : public QAbstractTableModel
{
public:
    /**
     * @brief Constructor for QXlsx docs (.xlsx)
     * @param data The object to store and use as the data source
     */
    ExcelTableModel(QXlsx::Document *data) : xls_doc(NULL)
    {
        qxlsx_doc = data;
    }

    /**
     * @brief Constructor for BasicExcel docs (.xls)
     * @param data The BasicExcel object to store and use as the data source
     */
    ExcelTableModel(YExcel::BasicExcel *data) : qxlsx_doc(NULL)
    {
        xls_doc = data;
    }

    /**
     * @brief Returns the number of rows in the currently displayed tab (worksheet)
     * @param parent Unused in this model (all cells have the same parent)
     * @return The number of rows
     */
    int rowCount(const QModelIndex& parent = QModelIndex()) const
    {
        Q_UNUSED(parent)

        if (qxlsx_doc) {
            return qxlsx_doc->dimension().rowCount() + 1;
        } else if (xls_doc) {
            if (xls_doc ->GetTotalWorkSheets() > xls_current_sheet) {
                YExcel::BasicExcelWorksheet *xls_sheet = xls_doc->GetWorksheet(xls_current_sheet);
                if (xls_sheet)
                    return xls_sheet->GetTotalRows();
            }
        }

        return 0;
    }

    /**
     * @brief Returns the number of columns in the currently displayed tab (worksheet)
     * @param parent Unused in this model (all cells have the same parent)
     * @return The number of columns
     */
    int columnCount(const QModelIndex& parent = QModelIndex()) const
    {
        Q_UNUSED(parent)

        if (qxlsx_doc) {
            return qxlsx_doc->dimension().columnCount() + 1;
        } else if (xls_doc) {
            if (xls_doc->GetTotalWorkSheets() > xls_current_sheet) {
                YExcel::BasicExcelWorksheet *xls_sheet = xls_doc->GetWorksheet(xls_current_sheet);
                if (xls_sheet)
                    return xls_sheet->GetTotalCols();
            }
        }

        return 0;
    }

    /**
     * @brief Standard (as far as Qt is concerned) data() accessor
     * @param index The index of the cell, constructed with model.index(x, y)
     * @param role What the caller is trying to do (display data, write data, etc.)
     * @return If the index is good, a QVariant wrapping the data; if it's invalid, a null QVariant
     *
     * Qt uses the role to make sure nothing unexpected happens, as well as to provide flexibility if needed.
     * A recurring theme throughout Qt is returning null/empty QVariant() [or whatever the return type is] objects.
     * This can only access values in the currently displayed tab (worksheet)
     */
    QVariant data(const QModelIndex& index, int role = Qt::DisplayRole) const
    {
        if (!index.isValid() || role != Qt::DisplayRole)
            return QVariant();

        QString buf;
        if (qxlsx_doc) {
            QXlsx::Cell *ret = qxlsx_doc->cellAt(index.row() + 1, index.column() + 1);
            if (ret) {
                switch (ret->cellType()) {
                case QXlsx::Cell::CellType::StringType:
                case QXlsx::Cell::CellType::InlineStringType:
                case QXlsx::Cell::CellType::SharedStringType:
                    return ret->value();
                case QXlsx::Cell::CellType::NumberType:
                    buf = QString::asprintf( "%'.3Lf", strtold_chk(ret->value().toString().toStdString().c_str(), NULL) );
                    buf.remove(QRegExp("\\.0+$"));
                    return buf;
                default:
                    return QVariant();
                }
            } else
                return QVariant();

        } else if (xls_doc) {
            YExcel::BasicExcelWorksheet *sheet = xls_doc->GetWorksheet(xls_current_sheet);
            if (!sheet)
                return QVariant();

            YExcel::BasicExcelCell *cell = sheet->Cell(index.row(), index.column());
            if (!cell)
                return QVariant();

            switch (cell->Type()) {
            case YExcel::BasicExcelCell::DOUBLE:
                buf = QString::asprintf( "%'.3Lf", static_cast<long double>(cell->GetDouble()) );
                buf.remove(QRegExp("\\.0+$"));
                return buf;
                break;
            case YExcel::BasicExcelCell::STRING:
            case YExcel::BasicExcelCell::WSTRING:
                return QString(cell->GetString());
                break;
            case YExcel::BasicExcelCell::INT:
                return QString::asprintf( "%'lld", static_cast<long long int>(cell->GetInteger()) );
                break;
            default: break;
            }
        }

        return QVariant();
    }

public slots:
    /**
     * @brief Called to update the tab (worksheet) in the BasicExcel (.xls) file currently being displayed
     * @param sheetNum The index of the tab that (x,y) coords should refer to from now on
     * @return The updated value
     */
    int setXlsSheetIndex(int sheetNum)
    {
        xls_current_sheet = sheetNum;
        return xls_current_sheet;
    }

    int setXlsSheetIndex()
    {
        return setXlsSheetIndex(0);
    }

private:
    /**
     * @brief Used if we're reading from a QXlsx (.xlsx) file; only one or the other can be used per model
     */
    QXlsx::Document *qxlsx_doc = NULL;
    /**
     * @brief Used if we're reading from a BasicExcel (.xls) file; only one or the other can be used per model
     */
    YExcel::BasicExcel *xls_doc = NULL;
    /**
     * @brief The current BasicExcel (.xls) sheet index
     */
    int xls_current_sheet = 0;
};

#endif // EXCELTABLEMODEL_HPP
