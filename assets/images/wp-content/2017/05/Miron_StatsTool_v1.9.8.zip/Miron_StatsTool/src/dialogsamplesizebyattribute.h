#ifndef DIALOGSAMPLESIZEBYATTRIBUTE_H
#define DIALOGSAMPLESIZEBYATTRIBUTE_H

#include <QDialog>
#include <QValidator>
#include "stdialog.h"

namespace Ui {
class DialogSampleSizeByAttribute;
}

/**
 * @brief Not fully implemented and currently disabled
 */
class DialogSampleSizeByAttribute : public STDialog
{
    Q_OBJECT

public:
    explicit DialogSampleSizeByAttribute(QWidget *parent = 0);
    ~DialogSampleSizeByAttribute();
    void calculate(QStringList &report, double error_rate, uint N, double precision);

private:
    void on_buttonBox_accepted_unsafe() override;
    Ui::DialogSampleSizeByAttribute *ui;
};

#endif // DIALOGSAMPLESIZEBYATTRIBUTE_H
