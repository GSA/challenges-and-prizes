#ifndef MATRIXTABLEMODEL_H
#define MATRIXTABLEMODEL_H

#include <QtGui>
#include "matrix.h"
#include <QAbstractTableModel>
#include <math.h>
#include "st_macros.h"
#include <QTableView>
#include <iostream>
#include "st_boost.h"


/**
 * @brief The Model class used to translate internal scythe::matrix data to a table view for display to the user
 *
 * This class is the model portion of a model-view design; the table views in preview areas (the spreadsheet looking
 * things) don't carry around the data they display -- they get that data by asking this model what to display at a
 * given index position; the underlying data that this model accesses and translates is the same data in memory
 * that the program uses for it's calculations.
 *
 * The Unrestricted Variable Appraisal module's requirements are a little messy, and the headers shifting up and down
 * reflects that -- those functions can be safely ignored entirely if not required.
 *
 * \todo Strings aren't copied properly when addRows() and addColumns() add space < string position
 */
template < typename T = scythe::Matrix <long double, scythe::Row, scythe::Concrete > >
class MatrixTableModel : public QAbstractTableModel
{
public:
    MatrixTableModel() : m_data()
    {
    }

    MatrixTableModel(QTableView *ours) : view(ours)
    {
    }

    int rowCount(const QModelIndex& parent = QModelIndex()) const
    {
        Q_UNUSED(parent)
        return m_data.rows();
    }

    int columnCount(const QModelIndex& parent = QModelIndex()) const
    {
        Q_UNUSED(parent)
        return m_data.cols();
    }

    /**
     * @brief Turn (x,y) coords in to a 1-D position for the string storage
     * @param row The (conceptual) row coordinate
     * @param col The (conceptual) column coordinate
     * @param colCount Optionally specify the number of columns
     * @return The index in to the actual 1D array used to store strings
     *
     * The string storage is just a standard 1D array that uses a simple formula
     * to make it as easy to work with as a 2D array.
     */
    uint strIdx(uint row, uint col, int colCount = -1) const
    {
        if ( colCount == -1 )
            colCount = columnCount();
        return row * colCount + col;
    }

    /**
     * @brief Turn an actual 1D index back into conceptual 2D space (x,y)
     * @param row Where to store the row value
     * @param col Where to store the column value
     * @param idx The 1D index to "undo"
     */
    void strIdxUndo(int *row, int *col, uint idx)
    {
        // col = idx - row * colCount
        // row = ( idx - col ) / colCount
        *col = idx % columnCount();
        *row = (idx - *col) / columnCount();
    }

    QStringList getFirstRow()
    {
        QStringList ret;
        QString buf;

        for (int i = 0; i < columnCount(); i++) {
            buf = data(index(0, i)).toString();
            if ( !(buf.isNull() && buf.isEmpty()) )
                ret << buf;
        }
        return ret;
    }

    /**
     * @brief Standard data() accessor; strings at a given (x,y) position are returned if they exist, otherwise the long double there is
     * @param index The index of the cell to access
     * @param role Must be Qt::DisplayRole
     * @return The string if there is one there currently, otherwise the long double, otherwise a null QVariant()
     */
    QVariant data(const QModelIndex& index, int role = Qt::DisplayRole) const
    {
        if ( !index.isValid() || role != Qt::DisplayRole )
            return QVariant();

        if ( m_strings.size() > strIdx(index.row(), index.column()) && !m_strings[strIdx(index.row(), index.column())].isNull() )
            return m_strings[strIdx(index.row(), index.column())];
        else if ( isnormal(m_data(index.row(), index.column())) ) {
            QString buf = QString::asprintf("%'.3Lf", m_data(index.row(), index.column()));
            buf.remove(QRegExp("\\.0+$"));
            return buf;
        }
        return 0;
    }

    bool addData(int row, int col, const QVariant &value)
    {
        if ( !m_data.inRange(row, col) )
            resizeStorage(row, col);
        return setData(index(row, col), value);
    }

    QVariant headerData(int column, Qt::Orientation orientation = Qt::Horizontal, int role = Qt::DisplayRole) const
    {
        if ( role != Qt::DisplayRole )
            return QVariant();
        else if ( orientation != Qt::Horizontal )
            return QVariant(column + 1);
        else if ( m_headers.size() <= column )
            return QVariant(column + 1);
        else if (m_headers.at(column).isNull())
            return QVariant(column + 1);
        else
            return m_headers.at(column);
    }

    bool setHeaders(QVariant value, Qt::Orientation orientiation = Qt::Horizontal, int role = Qt::EditRole)
    {
        if ( role != Qt::EditRole || orientiation != Qt::Horizontal )
            return false;

        QVariant header;
        QStringList list = value.toString().split(QRegExp("\t| "), QString::SkipEmptyParts);
        for (int i = 0; i < list.size(); i++) {
            header = list.at(i);
            setHeaderData(i, Qt::Horizontal, header);
        }
        emit headerDataChanged(Qt::Horizontal, 0, columnCount());
        return true;
    }

    bool setHeaderData(int column, Qt::Orientation orientation, QVariant value, int role = Qt::EditRole)
    {
        if ( orientation != Qt::Horizontal || role != Qt::EditRole || column < 0 || column >= columnCount() )
            return false;

        int shiftUp = 0;
        for (int i = 0; i <= column; i++) {
            if ( !(flags(index(0, i)) & Qt::ItemIsEnabled) )
                shiftUp++;
        }
        column += shiftUp;
        while ( m_headers.size() <= column )
            m_headers.append(QString());
        m_headers.replace(column, value.toString());

        emit headerDataChanged(Qt::Horizontal, 0, columnCount());
        return true;
    }

    /**
     * @brief Store data in the model
     * @param index The index to store it at
     * @param value The (QVariant wrapped) data to store
     * @param role Fails if not Qt::EditRole
     * @return True if the data was stored, false if it couldn't be for any reason
     *
     * String data goes into the string storage, long doubles go into the matrix.  If a valid string exists
     * at a given (x,y) coordinate, it overrides (but doesn't erase) any long double at that coordinate (until
     * the string is erased, if ever.)
     */
    bool setData(const QModelIndex & index, const QVariant & value, int role = Qt::EditRole) override
    {
        if ( !index.isValid() || role != Qt::EditRole )
            return false;

        long double num = 0;
        bool ok = true;
        QString str = value.toString();
        str.remove(QRegExp("\\,|\\$"));
        num = str.toDouble(&ok);
        if ( num == 0 && ok == false ) {
            m_strings[strIdx(index.row(), index.column())] = value.toString();
        } else {
            // we need long double precision: a double won't do for our purposes
            num = strtold_chk(str.toStdString().c_str(), NULL);
            if ( errno == ERANGE ) {
                ST_ERRORBOX("That value is too large for the program to store precisely.");
                return false;
            } else {
                m_data(index.row(), index.column()) = num;
                m_strings[strIdx(index.row(), index.column())] = QString();
            }
        }
        emit dataChanged(index, index);
        return true;
    }

    bool insertRows(int row, int count, const QModelIndex &parent = QModelIndex()) override
    {
        if ( row > rowCount() )
            return false;

        beginInsertRows( parent, row, row + count );
        resizeStorage( rowCount() + count, columnCount() );

        for (int i = rowCount() - 1; i > row + count - 1; i--)
        {
            for (int j = 0; j < columnCount(); j++)
            {
                m_data(i, j) = m_data(i - count, j);
                m_data(i - count, j) = 0;
                m_strings[strIdx(i, j)] = m_strings[strIdx(i - count, j)];
                m_strings[strIdx(i - count, j)] = QString();
            }
        }

        endInsertRows();
        return true;
    }

    bool insertColumns(int column, int count, const QModelIndex &parent = QModelIndex()) override
    {
        if ( column > columnCount() )
            return false;

        uint oldCol = columnCount();
        beginInsertColumns(parent, column, column + count);
        resizeStorage( rowCount(), columnCount() + count);

        for (int i = 0; i < rowCount(); i++)
        {
            for (int j = columnCount() - 1; j > column + count - 1; j--)
            {
                m_data(i, j) = m_data(i, j - count);
                m_data(i, j - count) = 0;
                m_strings[strIdx(i, j)] = m_strings[strIdx(i, j, oldCol)];
                m_strings[strIdx(i, j, oldCol)] = QString();
            }
        }

        endInsertColumns();
        return true;
    }

    void resizeStorage(uint row, uint col)
    {
        uint old_row = rowCount();
        uint old_col = columnCount();

        m_data.resize(row, col, true);
        m_strings.resize(strIdx(row, col));
        for (uint i = old_row; i < row; i++)
            for (uint j = old_col; j < col; j++) {
                m_data(i, j) = 0;
                m_strings[strIdx(i, j)] = QString();
            }
        emit dataChanged(index(old_row, old_col), index(row, col));
    }

    Qt::ItemFlags flags(const QModelIndex & index) const
    {
        Qt::ItemFlags flags = Qt::ItemIsEditable | Qt::ItemIsSelectable | Qt::ItemIsEnabled;

        if ( disabledRows.contains(index.row())
                  || disabledColumns.contains(index.column()) ) {
            flags ^= Qt::ItemIsEnabled;
        }

        return flags;
    }

    void updateView()
    {
        emit dataChanged(index(0, 0), index(rowCount(), columnCount()));
        emit headerDataChanged(Qt::Horizontal, 0, m_headers.size());
    }

    /**
     * @brief Used if the user checks the "ignore first column" box
     * @param col Which header index to insert in to
     */
    void shiftHeadersUp(int col)
    {
        m_headers.insert(col, QString());
    }

    void disableColumn(int col)
    {
        disabledColumns.append(col);
        updateView();
    }

    void disableRow(int row)
    {
        disabledRows.append(row);
        updateView();
    }

    void enableRow(int row)
    {
        disabledRows.removeAll(row);
        updateView();
    }

    /**
     * @brief Used if the user unchecks the "ignore first column" box
     * @param col Which header index to throw away
     */
    void shiftHeadersDown(int col)
    {
        if ( m_headers.size() > 0 ) {
            if (col >= m_headers.size())
                m_headers.removeFirst();
            else
                m_headers.removeAt(col);
            updateView();
        }
    }

    void enableColumn(int col)
    {
        disabledColumns.removeAll(col);
    }

    void enableAllRows()
    {
        disabledRows.clear();
        updateView();
    }

    void enableAllColumns()
    {
        int n = disabledColumns.size();
        disabledColumns.clear();
        for (int i = 0; i < n; i++)
            if ( m_headers.size() > 0 )
                m_headers.removeFirst();
        updateView();
    }

    /**
     * @brief Return (by reference) the matrix object used for long double (numeric) storage
     * @return The storage object, of whatever type was given as a template parameter when this model was constructed
     */
    T &getMatrix()
    {
        return m_data;
    }

    /**
     * @brief Scan data storage to see if there are any strings in it
     * @param display_errors If true, a popup will notify the user of where any strings are and focus that cell (scrolling to it if necessary)
     * @param ignored_rows How many of the first rows to ignore, if any
     * @return True if string (nonnumeric) data exists anywhere in the model, false otherwise (same return value whether displayed to the user or not)
     */
    bool nonnumericDataInModel(bool display_errors = true, int ignored_rows = -1)
    {
        int x = 0;
        int y = 0;

        for (int i = 0; i < m_strings.size(); i++)
        {
            strIdxUndo(&x, &y, i);
            if ( x <= ignored_rows ) {
                continue;
            }
            if ( !m_strings.at(i).isNull() ) {
                if ( display_errors ) {
                    if ( m_strings.at(i).isEmpty() ) {
                        ST_ERRORBOX(tr("There is a missing value at line %1, column %2").arg(x + 1).arg(y + 1));
                    } else {
                        ST_ERRORBOX(tr("Nonnumeric data at line %1, column %2").arg(x + 1).arg(y + 1));
                    }
                    focusTableViewCell(x, y);
                }
                return true;
            }
        }
        return false;
    }

    /**
     * @brief Scroll to and focus (highlight) a given cell at (x,y)
     * @param i The row coordinate
     * @param j The column coordinate
     */
    void focusTableViewCell(int i, int j)
    {
        QItemSelectionModel::SelectionFlags flags = QItemSelectionModel::ClearAndSelect;
        QModelIndex idx = index(i, j);

        if (!view)
            return;
        view->selectionModel()->select(idx, flags);
        view->scrollTo(idx);
        return;
    }

    /**
     * @brief Store a view we're associated with (only necessary if we should be focusing arbitrary cells)
     *
     * This is poor code isolation, but the model focuses cells from time to time, so keep a pointer to a view for that
     */
    void setView(QTableView *view)
    {
        view = view;
    }

    int64_t nonzeroItems(int column = 0)
    {
        int64_t ret = 0;
        bool ok = false;

        for (int i = 0; i < rowCount(); i++)
        {
            if ( m_data(i, column) != 0 )
                    ret++;
        }
        return ret;
    }

    void clearHeaderData()
    {
        int old_size = m_headers.size();
        if ( old_size > 0 ) {
            m_headers.clear();
            emit headerDataChanged(Qt::Horizontal, 0, old_size);
        }
    }

    QStringList getHeaders()
    {
        return m_headers;
    }

    /**
     * @brief Convert a string (e.g. the contents of a text file) to a MatrixTableModel, assuming standard whitespace delimiters
     * @param text The string (e.g. contents of a text file, etc.) to be parsed as a whitespace-separated matrix
     * @param error_on_nonnumeric Whether or not to notify the user if there are non-numeric tokens, and if so, at what position
     * @param strip_headers If the first line contains only words, this should be TRUE if you don't want it in the matrix
     * @param ignore_first_rows How many of the first rows to ignore
     * @param ignore_first_columns How many of the first columns to ignore
     * @return -1 on error, 0 otherwise
     */
    int stringToMatrix(QString text, bool error_on_nonnumeric = false, bool strip_headers = true, uint64_t ignore_first_rows = 0, uint64_t ignore_first_columns = 0)
    {
        QStringList list = text.split(QRegExp("\r?\n"), QString::SkipEmptyParts);

        if (list.size() < 0)
            return -1;

        // parse the first line/row for possible column titles
        clearHeaderData();
        QStringList tokens = list.at(0).split(SPLIT_REGEXP, QString::SkipEmptyParts);
        if ( QRegExp("[A-z]+").indexIn(list.at(0)) > -1 ) {
            bool allWords = true;
            foreach(QString token, tokens) {
                bool ok = true;
                token.toDouble(&ok);
                if ( !ok )
                    m_headers << token;
                else
                    allWords = false;
            }
            if (allWords && strip_headers)
                list.removeFirst();
            text = list.join("\n");
        } else if (!strip_headers) {
            // the caller expects a first row of words, so put it there if necessary
            QStringList headers;
            for (int i = 0; i < tokens.size(); i++)
                headers << QString("COLUMN_%1").arg(i + 1);
            list.prepend(headers.join(" "));
            text = list.join("\n");
        }

        // convert the text to a matrix, warning the user if any nonnumeric data is found
        QString str = text;
        QString ref;
        bool ok = true;
        int ret = 0;
        int64_t nCols = 0, rowSize = 0;
        int64_t nRows = 0, colSize = 0;
        int64_t row = 0;
        int64_t col = 0;
        long double el = 0;

        str.remove(STRIP_REGEXP);
        nRows = colSize = str.split(QRegExp("\r?\n"), QString::SkipEmptyParts).size();
        if (nRows - ignore_first_rows <= 0)
            return -1;
        nCols = rowSize = str.split(QRegExp("\r?\n"), QString::SkipEmptyParts).at(ignore_first_rows).split(SPLIT_REGEXP, QString::SkipEmptyParts).size();
        if (nCols - ignore_first_columns <= 0)
            return -1;

        tokens = str.split(QRegExp("\t| |\r?\n"), QString::SkipEmptyParts);
        QStringList lines = str.split(QRegExp("\r?\n"), QString::SkipEmptyParts);

        if ( !index(nRows - ignore_first_rows, nCols - ignore_first_columns).isValid() )
            resizeStorage(nRows - ignore_first_rows, nCols - ignore_first_columns);

        for (row = ignore_first_rows; row < nRows; row++)
        {
            tokens = lines.at(row).split(QRegExp("\t| "), QString::SkipEmptyParts);
            for (col = ignore_first_columns; col < nCols; col++)
            {
                if ( col >= tokens.size() ) {
                    setData(index(row - ignore_first_rows, col - ignore_first_columns), QVariant(""));
                    m_data(row - ignore_first_rows, col - ignore_first_columns) = 0;
                    continue;
                }
                ref = tokens.at(col);
                el = ref.toDouble(&ok);
                if ( (el == 0) && (ok != true) ) {
                    if ( error_on_nonnumeric ) {
                        ST_ERRORBOX(tr("Nonnumeric value in input data at row %1, col %2").arg(row).arg(col));
                        return ret = -1;
                    }
                    setData(index(row - ignore_first_rows, col - ignore_first_columns), QVariant(ref));
                } else {
                    m_data(row - ignore_first_rows, col - ignore_first_columns) = strtold_chk(ref.toStdString().c_str(), NULL);
                }
            }
        }

        updateView();
        return 0;
    }

private:
    /**
     * @brief The numeric storage matrix, which must support object(x,y) accessing and assignment via object(x,y) = z
     */
    T m_data;
    /**
     * @brief A 1D array used for string storage
     */
    QVector<QString> m_strings;
    /**
     * @brief The table headers (mostly for the Unrestricted Variable Appraisal module)
     */
    QStringList m_headers;
    QTableView *view = NULL;
    /**
     * @brief Any columns which are disabled and should be greyed-out and unselectable
     */
    QVector<int> disabledColumns;
    /**
     * @brief Any rows which are disabled and should be greyed-out and unselectable
     */
    QVector<int> disabledRows;
};

#endif // MATRIXTABLEMODEL_H
