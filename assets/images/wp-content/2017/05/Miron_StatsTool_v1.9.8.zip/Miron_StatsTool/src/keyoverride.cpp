#include "keyoverride.h"
#include <QKeyEvent>
#include <QDebug>
#include <QDialog>


KeyOverride::KeyOverride(QObject *parent) : QObject(parent)
{

}

KeyOverride::KeyOverride(QObject *parent, Qt::Key key) : QObject(parent)
{
    filteredKeys << key;
}

KeyOverride::KeyOverride(QObject *parent, Qt::Key key1, Qt::Key key2) : QObject(parent)
{
    filteredKeys << key1;
    filteredKeys << key2;
}

void KeyOverride::addModifier(Qt::KeyboardModifier mod, int idx)
{
    if (idx == -1)
        modifiers << mod;
    else
        modifiers[idx] = mod;
}

void KeyOverride::addFilteredKey(Qt::Key key, int idx)
{
    if (idx == -1)
        filteredKeys << key;
    else
        filteredKeys[idx] = key;
}

bool KeyOverride::eventFilter(QObject *obj, QEvent *event)
{
    if (event->type() == QEvent::KeyPress) {
        QKeyEvent *keyEvent = dynamic_cast<QKeyEvent *>(event);
        if (!keyEvent)
            return false;

        for (int i = 0; i < filteredKeys.size(); i++) {
            Qt::Key fltr_key = filteredKeys[i];

            if (keyEvent->key() == fltr_key && (i < modifiers.size() ? keyEvent->modifiers().testFlag(modifiers[i]) : 1) ) {
                qDebug("Ignoring %d with modifier %d", fltr_key, (i < modifiers.size() ? modifiers[i] : 0) );
                keyEvent->ignore();
                return true;
            }
        }
        return false;
    }
    return false;
}
