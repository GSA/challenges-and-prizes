#include "dialogselectexcelsheet.h"
#include "ui_dialogselectexcelsheet.h"
#include "exceltablemodel.hpp"
#include "matrix.h"
#include "keyoverride.h"


DialogSelectExcelSheet::DialogSelectExcelSheet(QXlsx::Document *doc, QWidget *parent, bool *error_occurred) :
    QDialog(parent),
    ui(new Ui::DialogSelectExcelSheet)
{
    ui->setupUi(this);
    if (error_occurred != NULL)
        *error_occurred = false;

    xls_doc = NULL;
    qxlsx_doc = doc;

    model = new ExcelTableModel(qxlsx_doc);
    keyOverride = new KeyOverride(this, Qt::Key_Shift, KeyOverride::Key_Shift_Tab);
    model->installEventFilter(keyOverride);
    ui->tableView->setModel(model);
    ui->tableView->installEventFilter(keyOverride);

    connect(ui->tabWidget, SIGNAL(currentChanged(int)), this, SLOT(on_tabWidget_currentChanged(int)));

    addSheetNames(doc->sheetNames());
    ui->comboBox_sheetName->hide();
}

DialogSelectExcelSheet::DialogSelectExcelSheet(YExcel::BasicExcel *doc, QWidget *parent, bool *error_occurred) :
    QDialog(parent),
    ui(new Ui::DialogSelectExcelSheet)
{
    ui->setupUi(this);
    char ansiSheetName[4096] = { 0 };
    wchar_t uniSheetName[4096] = { 0 };
    if (error_occurred != NULL)
        *error_occurred = false;

    qxlsx_doc = NULL;
    xls_doc = doc;

    model = new ExcelTableModel(xls_doc);
    keyOverride = new KeyOverride(this, Qt::Key_Shift, KeyOverride::Key_Shift_Tab);
    model->installEventFilter(keyOverride);
    ui->tableView->setModel(model);
    ui->tableView->installEventFilter(keyOverride);

    connect(ui->tabWidget, SIGNAL(currentChanged(int)), this, SLOT(on_tabWidget_currentChanged(int)));

    QStringList sheetNames;
    if (xls_doc->GetTotalWorkSheets() > 1) {
        for (int i = 0; i < xls_doc->GetTotalWorkSheets(); i++)
        {
            if (!xls_doc->GetSheetName(i, ansiSheetName)) {
                if (!xls_doc->GetSheetName(i, uniSheetName)) {
                    if (error_occurred != NULL)
                        *error_occurred = true;
                    return;
                } else {
                    sheetNames.append(QString::fromStdWString(uniSheetName));
                }
            } else {
                sheetNames.append(QString::fromLocal8Bit(ansiSheetName));
            }
        }
    }

    addSheetNames(sheetNames);
    ui->comboBox_sheetName->hide();
}

DialogSelectExcelSheet::DialogSelectExcelSheet(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogSelectExcelSheet)
{
    ui->setupUi(this);
    xls_doc = NULL;
    qxlsx_doc = NULL;
}

DialogSelectExcelSheet::~DialogSelectExcelSheet()
{
    delete ui;
    delete model;
    delete keyOverride;
}

int DialogSelectExcelSheet::exec()
{
    int ret = 0;

    QApplication::setOverrideCursor(Qt::ArrowCursor);
    ret = QDialog::exec();
    QApplication::restoreOverrideCursor();

    return ret;
}

void DialogSelectExcelSheet::addSheetNames(QStringList sheetNames)
{
    ui->comboBox_sheetName->addItems(sheetNames);
    this->sheetNames = sheetNames;
    int i = 0;
    foreach(QString sheet, sheetNames) {
        this->sheetNames << sheet;
        QTableView *view = new QTableView(this);
        view->setModel(model);
        ui->tabWidget->insertTab(i++, view, sheet);
    }
    ui->tabWidget->removeTab(ui->tabWidget->currentIndex());
    ui->tabWidget->setCurrentIndex(0);
}

QXlsx::Document *DialogSelectExcelSheet::getExcelDocument()
{
    return this->qxlsx_doc;
}

void DialogSelectExcelSheet::setExcelDocument(QXlsx::Document *doc)
{
    if (model)
        delete(model);
    qxlsx_doc = doc;
    model = new ExcelTableModel(doc);
    ui->tableView->setModel(model);
    model->installEventFilter(keyOverride);
}

void DialogSelectExcelSheet::on_buttonBox_accepted()
{
    done(ui->tabWidget->currentIndex());
}

void DialogSelectExcelSheet::on_tabWidget_currentIndexChanged(QString sheetName)
{
    if (sheetName.isEmpty())
        return;

    if (model)
        delete model;

    if (qxlsx_doc) {
        qxlsx_doc->selectSheet(sheetName);
        model = new ExcelTableModel(qxlsx_doc);
    } else if (xls_doc) {
        for (int i = 0; i < sheetNames.size(); i++) {
            if (sheetNames.at(i) == sheetName) {
                model = new ExcelTableModel(xls_doc);
                model->setXlsSheetIndex(i);
                break;
            }
        }
    }

    model->installEventFilter(keyOverride);
    static_cast<QTableView *>(ui->tabWidget->currentWidget())->setModel(model);
}

void DialogSelectExcelSheet::on_tabWidget_currentChanged(int index)
{
    on_tabWidget_currentIndexChanged(sheetNames.at(index));
}

void DialogSelectExcelSheet::setXlsSheetIndex()
{
    model->setXlsSheetIndex(ui->tabWidget->currentIndex());
}
