#ifndef DIALOGUNRESTRICTEDVARIABLEAPPRAISAL_H
#define DIALOGUNRESTRICTEDVARIABLEAPPRAISAL_H

#include "keyoverride.h"
#include "matrixtablemodel.hpp"
#include "st_macros.h"
#include "stdialog.h"


namespace Ui {
class DialogUnrestrictedVariableAppraisal;
}

/**
 * @brief Encapsulates the Unrestricted Variable Appraisal module
 */
class DialogUnrestrictedVariableAppraisal : public STDialog
{
    Q_OBJECT

public:
    explicit DialogUnrestrictedVariableAppraisal(QWidget *parent = 0);
    ~DialogUnrestrictedVariableAppraisal();

    /**
     * @brief Test whether the first column contains "Examined" data
     * @param str The currently displayed text in the combobox
     * @return True if the first column of the data is the "Examined" data, false otherwise
     */
    static bool first_column_is_examined(QString str);
    /**
     * @brief Test whether the second column contains "Difference" data
     * @param str The currently displayed text in the combobox
     * @return True if the second column of the data is the "Difference" data, false otherwise
     */
    static bool second_column_is_difference(QString str);
    /**
     * @brief Test whether the first column contains "Audited" data
     * @param str The currently displayed text in the combobox
     * @return True if the first column of data is the "Audited" data, false otherwise
     */
    static bool first_column_is_audited(QString str);
    /**
     * @brief Test whether the first column contains "Difference" data
     * @param str The currently displayed text in the combobox
     * @return True if the first column of the data is the "Difference" data, false otherwise
     */
    static bool first_column_is_difference(QString str);
    /**
     * @brief Fill in a data matrix's missing third column
     * @param mat The data matrix
     * @param examined_column The column in the data matrix that corresponds to "Examined" data (audited + difference)
     * @param audited_column The column in the data matrix that corresponds to "Audited" data (examined - difference)
     * @param difference_column The column in the data matrix that corresponds to "Difference" data (examined - audited)
     * @param n_rows The number of rows in the data matrix
     *
     * This function fills in the missing third row, if two columns are given; the design follows the
     * original RAT-STATS functionality.  E.g. if the data given contains only "Examined" and "Audited"
     * data, then this function fills in the missing "Difference" data based on the given two columns.
     *
     * difference = examined - audited
     * audited = examined - difference
     * examined = audited + difference
     */
    static void fill_in_column(matrix_t &mat, int examined_column, int audited_column, int difference_column, int64_t n_rows);
    /**
     * @brief Generate a report for this module
     * @param mat The data matrix
     * @param report Where to insert the report strings
     * @param inputFileName The file that the data came from (inserted into the report)
     * @param universeSize The total population size that the sampled data was drawn from
     * @param exa_col The column in the data matrix that represents the "Examined" values
     * @param aud_col The column in the data matrix that represents the "Audited" values
     * @param dif_col The column in the data matrix that represents the "Difference" values
     *
     * Performs many of the calculations necessary, and generates a report for the Unrestricted
     * Variable Appraisal module
     */
    void build_report(matrix_t &mat, QStringList &report, QString &inputFileName, int universeSize, int exa_col, int aud_col, int dif_col);
    /**
     * @brief Insert this module's header string into a report
     * @param report Where to insert the strings
     * @param inputFileName The name of the file that the data came from
     * @param sampleSize The sample size
     * @param universeSize The population size
     * @param n_nonzero_diffs The number of non-zero difference values
     * @param idx The index into the report of where to insert the header
     */
    void insert_header(QStringList &report, QString inputFileName, int64_t sampleSize, int64_t universeSize, int64_t n_nonzero_diffs, int idx = 0);
    MatrixTableModel<matrix_t> *getModel();
    int setColumnIndices(int &examined, int &audited, int &difference, int idx = -1);

public slots:
    void focusTableViewCell(int i, int j);
    void setColumnHeaders(int idx);

private slots:
    /**
     * @brief Display a dialog to the user for selecting an input file
     */
    void on_pushButton_chooseInputFile_clicked();
    /**
     * @brief Whether to allow editing of the data preview area
     * @param checked The state of the checkbox
     */
    void on_checkBox_enableEditing_toggled(bool checked);
    /**
     * @brief Called if something is dropped by the cursor on to our window
     * @param event
     */
    void dropEvent(QDropEvent *event);
    /**
     * @brief Called if something is dragged over our window
     * @param event
     */
    void dragEnterEvent(QDragEnterEvent *event);
    void textToMatrix(QString arg = QString());
    void on_checkBox_ignoreFirstRow_toggled(bool checked);
    void on_checkBox_ignoreFirstColumn_toggled(bool checked);

private:
    Ui::DialogUnrestrictedVariableAppraisal *ui;
    QString inputFileName;
    void on_buttonBox_accepted_unsafe_qplaintextedit();
    void on_buttonBox_accepted_unsafe_tableview();
    void on_buttonBox_accepted_unsafe();
    KeyOverride *keyOverride;
    KeyOverride *tabOverride;
    matrix_t matrix = matrix_t(1, 1);
    MatrixTableModel<matrix_t> *model = NULL;
    int getExaminedColumn();
    int getAuditedColumn();
    int getDifferenceColumn();
    void setupTableView();
};

#endif // DIALOGUNRESTRICTEDVARIABLEAPPRAISAL_H
