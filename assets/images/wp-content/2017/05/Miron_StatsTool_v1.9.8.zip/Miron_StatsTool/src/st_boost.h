/*
 * The problem we have here is that different platforms and compilers produce
 * slightly different results for our floating-point calculations.  To
 * guarantee correctness, we use a multiprecision type for part of our
 * calculations instead.
 */
#ifndef ST_BOOST_H
#define ST_BOOST_H

#include <boost/math/distributions/students_t.hpp>
#include <boost/math/distributions/hypergeometric.hpp>
#include <boost/math/distributions/binomial.hpp>
#include <boost/math/policies/policy.hpp>
#include <boost/multiprecision/cpp_dec_float.hpp>


/**
 * @brief The error policy to use for Boost
 *
 * This error policy causes Boost to ignore hardware floating-point errors
 * (i.e. inexact, underrun), which is exactly what we want, since the
 * algorithm we're using compensates for that
 */
typedef boost::math::policies::policy<
    boost::math::policies::domain_error<boost::math::policies::errno_on_error>,
    boost::math::policies::pole_error<boost::math::policies::errno_on_error>,
    boost::math::policies::overflow_error<boost::math::policies::errno_on_error>,
    boost::math::policies::evaluation_error<boost::math::policies::errno_on_error>
> boost_error_policy;

typedef double boost_cast_type;
/**
 * @brief The multiprecision type to use for hypergeometric distributions
 *
 * Once the hardware floating-point unit is unable to provide the accuracy we
 * require, we start using 100 digits after the decimal point; since it's orders
 * of magnitude slower, we wait until regular floating-point arithmetic gives us
 * an answer, then we wind back a little bit and re-do the last iterations to
 * guarantee it's correct.
 */
typedef boost::multiprecision::cpp_dec_float_100 multiprecision_type;
//typedef long double multiprecision_type;

#endif // ST_BOOST_H

