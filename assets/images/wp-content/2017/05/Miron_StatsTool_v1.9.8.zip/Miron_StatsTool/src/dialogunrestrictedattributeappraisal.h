#ifndef DIALOGUNRESTRICTEDATTRIBUTEAPPRAISAL_H
#define DIALOGUNRESTRICTEDATTRIBUTEAPPRAISAL_H

#include "stdialog.h"


namespace Ui {
class DialogUnrestrictedAttributeAppraisal;
}

/**
 * @brief Encapsulates the Unrestricted Attribute Appraisal module
 */
class DialogUnrestrictedAttributeAppraisal : public STDialog
{
    Q_OBJECT

public:
    explicit DialogUnrestrictedAttributeAppraisal(QWidget *parent = 0);
    ~DialogUnrestrictedAttributeAppraisal();
    /**
     * @brief Insert the report header
     * @param n The sample size
     * @param N The population size
     * @param out Where to insert the strings; used as the return value
     *
     * This function inserts the header information (audit name, module, time, etc.)
     */
    void insert_header(uint64_t n, uint64_t N, QStringList &out);
    /**
     * @brief Performs the calculations necessary for the report data (multithreaded)
     * @param n The sample size
     * @param N The population size
     * @param k Sample error rate (or successes, or characteristic of interest)
     * @param out Where to insert the strings; used as the return value
     *
     * This function implements the logic of the Unrestricted Attribute Appraisal module and inserts the report.
     *
     * It makes use of as many CPU cores as the computer has, up to a max of 6.
     */
    void calculate_multithreaded(uint64_t n, uint64_t N, uint64_t k, QStringList &out);
    /**
     * @brief Performs the calculations necessary for the report data (two thread version)
     * @param n The sample size
     * @param N The population size
     * @param k Sample error rate (or successes, or characteristic of interest)
     * @param out Where to insert the strings; used as the return value
     *
     * This function implements the logic of the Unrestricted Attribute Appraisal module and inserts the report.
     *
     * It makes use of two CPU cores.  The GUI will call this version if less than 4 CPU cores are detected.  In
     * order to continue monitoring for the user aborting via the GUI abort button, at least two threads are used
     * even if only one core is available.
     */
    void calculate(uint64_t n, uint64_t N, uint64_t k, QStringList &out);
    /**
     * @brief Same as calculate, but inserts an HTML table
     * @param n The sample size
     * @param N The population size
     * @param k Sample error rate (or successes, or characteristic of interest)
     * @param out Where to insert the strings; used as the return value
     *
     * This function implements the logic of the Unrestricted Attribute Appraisal module and inserts the report
     * as a table
     */
    void calculate_table(uint64_t n, uint64_t N, uint64_t k, QStringList &out);
    /**
     * @brief We override STDialog's on_buttonBox_accepted() to do the same thing with unique additions
     */
    void on_buttonBox_accepted() override;
    /**
     * @brief Primarily for automated GUI testings
     * @return The Ui object containing all the GUI widgets
     */
    Ui::DialogUnrestrictedAttributeAppraisal *getUi();


private slots:
    /**
     * @brief Abort a running calculation
     */
    void on_pushButton_abort_clicked();


private:
    Ui::DialogUnrestrictedAttributeAppraisal *ui;
    void on_buttonBox_accepted_unsafe();
    bool abortRequested = false;
};

#endif // DIALOGUNRESTRICTEDATTRIBUTEAPPRAISAL_H
