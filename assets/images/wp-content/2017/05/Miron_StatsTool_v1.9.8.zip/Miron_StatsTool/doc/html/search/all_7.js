var searchData=
[
  ['insert_5fheader',['insert_header',['../d3/ddf/classDialogStratifiedVariableAppraisal.html#a43cb78194f5ee17f276716878855acea',1,'DialogStratifiedVariableAppraisal::insert_header()'],['../db/d27/classDialogUnrestrictedAttributeAppraisal.html#a784400905f432529ebe27707fa611734',1,'DialogUnrestrictedAttributeAppraisal::insert_header()'],['../db/da5/classDialogUnrestrictedVariableAppraisal.html#ad625699958948a7ea4378f20f526a323',1,'DialogUnrestrictedVariableAppraisal::insert_header()']]],
  ['insert_5fsummary',['insert_summary',['../d3/ddf/classDialogStratifiedVariableAppraisal.html#a21f906447858845b03b49e8a5eca1206',1,'DialogStratifiedVariableAppraisal']]]
];
