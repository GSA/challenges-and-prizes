var searchData=
[
  ['uaa_5fdialog',['uaa_dialog',['../d7/d2e/classStatsTool.html#ac1f59948183f36f24c00eeac1e6438b1',1,'StatsTool']]],
  ['uva_5fdialog',['uva_dialog',['../d7/d2e/classStatsTool.html#aa34eea6f56c9985b084e442125fd1960',1,'StatsTool']]]
];
