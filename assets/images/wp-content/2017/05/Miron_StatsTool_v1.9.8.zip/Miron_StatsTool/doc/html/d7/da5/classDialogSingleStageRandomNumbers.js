var classDialogSingleStageRandomNumbers =
[
    [ "buildHtmlReport", "d7/da5/classDialogSingleStageRandomNumbers.html#ac79e57abe1f9235df185647840aa0561", null ],
    [ "calculate", "d7/da5/classDialogSingleStageRandomNumbers.html#a33ac2b0602cb21236e9bf7dfebada2b0", null ],
    [ "on_buttonBox_accepted_unsafe", "d7/da5/classDialogSingleStageRandomNumbers.html#a02e14418aa2f6c3f4e1fd0b4135ddd21", null ],
    [ "auditName", "d7/da5/classDialogSingleStageRandomNumbers.html#a6a23845244561d4c8a7c2a9aa47a1349", null ],
    [ "framesize", "d7/da5/classDialogSingleStageRandomNumbers.html#a4eabb5430aa8ceffae1835e23c7741d5", null ],
    [ "generationTime", "d7/da5/classDialogSingleStageRandomNumbers.html#a19749ad139c3b82eb968b170c764f3c1", null ],
    [ "max", "d7/da5/classDialogSingleStageRandomNumbers.html#a59ed13b57633aaa340b36ebb54b8cb96", null ],
    [ "min", "d7/da5/classDialogSingleStageRandomNumbers.html#afb2ee6002e56bec48a673e7f54b20e77", null ],
    [ "numRandoms", "d7/da5/classDialogSingleStageRandomNumbers.html#a8f2dde248394ea8b950251dc6134e150", null ],
    [ "numSpares", "d7/da5/classDialogSingleStageRandomNumbers.html#a16a84504a4a768bf2ed5879288559959", null ],
    [ "seed", "d7/da5/classDialogSingleStageRandomNumbers.html#a89f111e74d257e1aae75cf1f89cc37da", null ],
    [ "sum", "d7/da5/classDialogSingleStageRandomNumbers.html#ac30d1f7836532de312aa96c19e03b386", null ]
];