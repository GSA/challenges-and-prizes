var searchData=
[
  ['ratstats_5fkurtosis',['ratstats_kurtosis',['../d7/d2e/classStatsTool.html#a69d38e2dc6b8d29d928b5fee830dcb07',1,'StatsTool::ratstats_kurtosis(const matrix_t &amp;matrix, int column, long double mean)'],['../d7/d2e/classStatsTool.html#a6dc37da77840edabf086f5fa77d41e76',1,'StatsTool::ratstats_kurtosis(const matrix_t_view &amp;matrix, int column, long double mean)']]],
  ['ratstats_5fskewness',['ratstats_skewness',['../d7/d2e/classStatsTool.html#adb7cc839cdecdffa481d8cd682c7149d',1,'StatsTool::ratstats_skewness(const matrix_t &amp;matrix, int column, long double mean)'],['../d7/d2e/classStatsTool.html#a86a8a4014a361570ea78c6e9c3adda49',1,'StatsTool::ratstats_skewness(const matrix_t_view &amp;matrix, int column, long double mean)']]],
  ['readfromfile',['readFromFile',['../d7/d2e/classStatsTool.html#ab279f41842ac1c789c50a54ef7ad5022',1,'StatsTool::readFromFile()'],['../d7/d2e/classStatsTool.html#ac87856e79b87aedadfc38a5825c3a23b',1,'StatsTool::readFromFile(QString inputFileName)']]],
  ['rowcount',['rowCount',['../d8/dfe/classExcelTableModel.html#ae9946ab9917aeed06c48dba674694e6d',1,'ExcelTableModel']]],
  ['run',['run',['../d9/d79/classAttributeAppraisal.html#a06dc5b93e1c6816143dfd41701ce4fd7',1,'AttributeAppraisal']]]
];
