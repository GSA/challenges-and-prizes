var searchData=
[
  ['build_5freport',['build_report',['../d3/ddf/classDialogStratifiedVariableAppraisal.html#a100ec23e69055aacca77497856698ebc',1,'DialogStratifiedVariableAppraisal::build_report()'],['../db/da5/classDialogUnrestrictedVariableAppraisal.html#aa6084c32b63750507f82974c6dca8e0b',1,'DialogUnrestrictedVariableAppraisal::build_report()'],['../de/dc1/classVariableAppraisal.html#a315ec6e2c9c6131ef1348145bed82158',1,'VariableAppraisal::build_report()']]],
  ['buildhtmlreport',['buildHtmlReport',['../d7/da5/classDialogSingleStageRandomNumbers.html#ac79e57abe1f9235df185647840aa0561',1,'DialogSingleStageRandomNumbers']]],
  ['byestimatederror',['byEstimatedError',['../d7/d77/classSampleSizeDetermination.html#af4b0ebf86c0fb7af7ad28a1cd483052f',1,'SampleSizeDetermination']]]
];
