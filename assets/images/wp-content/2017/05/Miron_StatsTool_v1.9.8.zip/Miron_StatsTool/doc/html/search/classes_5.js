var searchData=
[
  ['samplesizedetermination',['SampleSizeDetermination',['../d7/d77/classSampleSizeDetermination.html',1,'']]],
  ['statstool',['StatsTool',['../d7/d2e/classStatsTool.html',1,'']]],
  ['stdialog',['STDialog',['../d6/d76/classSTDialog.html',1,'']]]
];
