var searchData=
[
  ['excelfiletoplaintext',['excelFileToPlainText',['../d7/d2e/classStatsTool.html#acf65a728d0842a59c2aef4558e331560',1,'StatsTool::excelFileToPlainText(QString &amp;fileName)'],['../d7/d2e/classStatsTool.html#a6c49683909d41fedec795cd81b1c1ac0',1,'StatsTool::excelFileToPlainText(QXlsx::Document &amp;excel)'],['../d7/d2e/classStatsTool.html#a22b93e2ed751bab06516529de8036f8a',1,'StatsTool::excelFileToPlainText(YExcel::BasicExcelWorksheet *sheet)']]],
  ['excelrand64',['ExcelRand64',['../dd/d12/classWichmannHill.html#a308f2a466cb8b15cb42942581ad35e96',1,'WichmannHill']]],
  ['excelrandomize64',['ExcelRandomize64',['../dd/d12/classWichmannHill.html#a82b958ef15529f91471a37bbc4969873',1,'WichmannHill']]],
  ['exceltablemodel',['ExcelTableModel',['../d8/dfe/classExcelTableModel.html#a361ec7b2c1064dd384d4ef2c84d41953',1,'ExcelTableModel::ExcelTableModel(QXlsx::Document *data)'],['../d8/dfe/classExcelTableModel.html#a35001633ec6b822d56c57e0a82148536',1,'ExcelTableModel::ExcelTableModel(YExcel::BasicExcel *data)']]],
  ['exec',['exec',['../d7/de1/classDialogSelectExcelSheet.html#a20400c04571054c574c31e8a8e03ecf8',1,'DialogSelectExcelSheet']]]
];
