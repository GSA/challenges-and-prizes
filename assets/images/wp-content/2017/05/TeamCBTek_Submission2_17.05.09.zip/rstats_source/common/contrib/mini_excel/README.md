# MiniExcel

Mini Excel Reader(just .xlsx) for C++ & Lua
license MIT

##Build
* install cmake 2.6+ and make sure cmake in PATH
* run 
    * `mkdir build & cd build`
    * `cmake ..` or `cmake .. -DBUILD_LUA=1`
    * `cmake --build .`


